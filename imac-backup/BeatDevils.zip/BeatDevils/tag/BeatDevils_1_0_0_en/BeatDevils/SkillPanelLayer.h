//
//  SkillPanelLayer.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-30.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "BeatDevilsDef.h"

enum
{
    SkillPanelLayerAnimeTypeAddDiamond,                     // 带一个参数，DiamondType
    SkillPanelLayerAnimeTypeBreakBox,                       // 带一个参数，DiamondType
    SkillPanelLayerAnimeTypeRemoveFirstDiamond,
    SkillPanelLayerAnimeTypeMagicChangeDiamond,             // 带两个参数，DiamondType，Count
    SkillPanelLayerAnimeTypeBoomDiamond,                    // 带一个参数，Count
    SkillPanelLayerAnimeTypeRemoveAllDiamondDyWrong,
    SkillPanelLayerAnimeTypeMAX,
};
typedef int SkillPanelLayerAnimeType;

@protocol SkillPanelLayerDelegate

- (void)onRecoverHpClick;
- (void)onRecoverFuryClick;

- (void)onSkillTimeClick;
- (void)onSkillMagicClick;
- (void)onSkillBoomClick;

- (void)onShopClick;

@end

@class CCMenuItemButton;
@interface SkillPanelLayer : CCLayer
{
    // 操作队列
    NSMutableArray *animeFuncDataArray;
    
    // 不同的SkillPanelLayerAnimeType，对应的处理函数
    NSMutableDictionary *animeFuncDic;
    
    NSMutableArray *diamondSpriteQueue;
    
    // 按钮与其对应的提示图片
    NSMutableDictionary *buttonAndHintDic;
    
    // 按钮与其对应的初始坐标
    NSMutableDictionary *buttonAndInitPointDic;
}

@property (nonatomic, assign) id<SkillPanelLayerDelegate> delegate;

@property (nonatomic, retain) NSArray *diamondDisplaySpriteArray;

@property int animeBlockCount;

@property CGPoint initRoshamboMenuPos;
@property (readonly) CGPoint lastDiamondPosition;

@property (nonatomic, assign) CCMenuItemButton *btnTime;
@property (nonatomic, assign) CCMenuItemButton *btnMagic;
@property (nonatomic, assign) CCMenuItemButton *btnBoom;
@property (nonatomic, assign) CCMenuItemButton *btnHp;
@property (nonatomic, assign) CCMenuItemButton *btnFury;

@property (nonatomic, assign) CCLabelTTF *labRecoverHpCount;
@property (nonatomic, assign) CCLabelTTF *labRecoverFuryCount;
@property (nonatomic, assign) CCLabelTTF *labResistCount;
@property (nonatomic, assign) CCLabelTTF *labFury;

@property (nonatomic, assign) CCSprite *sprFreeze;
@property (nonatomic, assign) CCSprite *sprTimeBar;
@property (nonatomic, assign) CCSprite *sprDevilHead;
@property (nonatomic, assign) CCSprite *sprWrong;
@property (nonatomic, assign) CCSprite *sprSlot;
@property (nonatomic, assign) CCSprite *sprFury;

// button的提示操作
- (BOOL)isHint:(CCMenuItemButton *)button;
- (void)setButton:(CCMenuItemButton *)button isHint:(BOOL)isHint;
- (void)setButton:(CCMenuItemButton *)button isHint:(BOOL)isHint interval:(float)interval;

// 其它操作接口
// 增加回调接口，当之前的动画播放完毕时，会进行此回调
- (void)addAnimeAction:(SkillPanelLayerAnimeType)animeType info:(NSDictionary *)dic;
- (void)addCallBack:(id)target sel:(SEL)sel;
- (void)cleanAllDiamond;

@end
