//
//  PlayerGuideLayer.m
//  BeatDevils
//
//  Created by 青宝 中 on 12-1-6.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "PlayerGuideLayer.h"
#import "GameLayer.h"

static NSString *IsGuidedKey = @"PlayerGuideLayerGuidedKey";

@implementation PlayerGuideLayer

@synthesize sprGuide, isSwallowTouch;

#pragma mark -
#pragma mark 各个图片的处理函数

- (void)clearFlashSkillButton
{
    [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnHp
                                     isHint:NO];
    [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnFury
                                     isHint:NO];
    [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnBoom
                                     isHint:NO];
    [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnMagic
                                     isHint:NO];
    [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnTime
                                     isHint:NO];
}

- (void)onBoomGuideShow
{
    [self clearFlashSkillButton];
    [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnBoom
                                     isHint:YES];
    
    self.sprGuide.position = ccp(170, 220);
}

- (void)onMagicGuideShow
{
    [self clearFlashSkillButton];
    [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnMagic
                                     isHint:YES];
    
    self.sprGuide.position = ccp(160, 200);
}

- (void)onBeerGuideShow
{
    [self clearFlashSkillButton];
    [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnFury
                                     isHint:YES];
    
    self.sprGuide.position = ccp(160, 200);
}

- (void)onFoodGuideShow
{
    [self clearFlashSkillButton];
    [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnHp
                                     isHint:YES];
    
    self.sprGuide.position = ccp(160, 270);
}

- (void)onTimeGuideShow
{
    [self clearFlashSkillButton];
    [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnTime
                                     isHint:YES];
    
    self.sprGuide.position = ccp(180, 220);
}

- (BOOL)isLastGuide
{
    if (curPicIndex >= guidePicArray.count - 1)
    {
        return YES;
    }
    
    return NO;
}

- (void)showGuide:(int)picIndex
{
    if (picIndex >= guidePicArray.count)
    {
        return;
    }
    
    self.sprGuide.texture = [guidePicArray objectAtIndex:picIndex];
    self.sprGuide.textureRect = (CGRect){{0, 0}, self.sprGuide.texture.contentSize};
    
    SEL guideHandle[5] =
    {
        @selector(onBoomGuideShow),
        @selector(onTimeGuideShow),
        @selector(onMagicGuideShow),
        @selector(onBeerGuideShow),
        @selector(onFoodGuideShow),
    };
    
    [self performSelector:guideHandle[picIndex]];
}

- (void)onEnter
{
    [super onEnter];
    
    [[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self
                                                     priority:kCCMenuTouchPriority - 1
                                              swallowsTouches:YES];
}

- (void)onExit
{
    [super onExit];
    
    [[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
    if (self.isSwallowTouch == NO)
    {
        return NO;
    }
    
    if (self.isLastGuide)
    {
        [self clearFlashSkillButton];
        [self.sprGuide removeFromParentAndCleanup:YES];
        self.sprGuide = nil;
        [_gameLayer closePlayerGuide];
    }
    else
    {
        [self showGuide:++curPicIndex];
    }
    
    return YES;
}

//构造函数

- (id)init
{
    NSAssert(0, @"PlayerGuideLayer#init 不使用这个函数初始化");
    return nil;
}

- (id)initWithGameLayer:(GameLayer *)gameLayer
{
	self = [super init];
	if (self != nil)
	{
        self.isSwallowTouch = NO;
        
        _gameLayer = gameLayer;
        
        // 初始化引导图片
        guidePicArray = [[NSMutableArray alloc] init];
        for (int i = 1; i <= 5; ++i)
        {
            NSString *fileName = [NSString stringWithFormat:NSLocalizedString(@"UI/2-game/img-guide%d.png", nil), i];
            
            [guidePicArray addObject:[[CCTextureCache sharedTextureCache] addImage:fileName]];
        }
	}
	return self;
}

- (void)dealloc
{
    [guidePicArray release];
	[super dealloc];
}

+ (BOOL)isGuided
{
    if ([[NSUserDefaults standardUserDefaults] objectForKey:IsGuidedKey] == nil)
    {
        return NO;
    }
    else
    {
        return YES;
    }
}

+ (PlayerGuideLayer *)layerWithGameLayer:(GameLayer *)gameLayer
{
    return [[[PlayerGuideLayer alloc] initWithGameLayer:gameLayer] autorelease];
}

- (void)startGuide
{
    self.sprGuide = [CCSprite spriteWithTexture:[guidePicArray objectAtIndex:0]];
    [self addChild:self.sprGuide];
    curPicIndex = 0;
    [self showGuide:curPicIndex];
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:IsGuidedKey];
}

- (void)updateSkillButtonWithDiamondCount:(int)diamondCount
{
    return;
    if ([PlayerGuideLayer isGuided] == NO)
    {
        return;
    }
    
    if (diamondCount < 10)
    {
        [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnBoom
                                       isHint:NO];
        [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnMagic
                                       isHint:NO];
    }
    else if (diamondCount < 18)
    {
        [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnBoom
                                       isHint:NO];
        [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnMagic
                                       isHint:YES
                                     interval:4];
    }
    else
    {
        [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnBoom
                                       isHint:YES
                                     interval:5];
        [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnMagic
                                       isHint:NO];
    }
}

- (void)updateSkillButtonWithRoundTime:(float)roundTime totalTime:(float)totalTime
{
    return;
    if ([PlayerGuideLayer isGuided] == NO)
    {
        return;
    }
    
    if (totalTime - roundTime < 6.0f)
    {
        [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnTime
                                       isHint:YES
                                     interval:2];
    }
    else
    {
        [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnTime
                                       isHint:NO];
    }
}

- (void)updateSkillButtonWithCurHp:(int)curHp maxHp:(int)maxHp
{
    if ([PlayerGuideLayer isGuided] == NO)
    {
        return;
    }
    
    if (maxHp * 0.4f > curHp)
    {
        [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnHp
                                       isHint:YES
                                     interval:1.5f];
    }
    else
    {
        [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnHp
                                       isHint:NO];
    }
}

- (void)updateSkillButtonWithFury:(int)fury
{
    if ([PlayerGuideLayer isGuided] == NO)
    {
        return;
    }
    
    if (fury < 200)
    {
        [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnFury
                                       isHint:YES
                                     interval:1.5f];
    }
    else
    {
        [_gameLayer.skillPanelLayer setButton:_gameLayer.skillPanelLayer.btnFury
                                       isHint:NO];
    }
}

@end
