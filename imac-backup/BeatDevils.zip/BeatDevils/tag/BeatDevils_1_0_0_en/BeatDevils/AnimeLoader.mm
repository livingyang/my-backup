//
//  AnimeLoader.m
//  study_loadanime
//
//  Created by 青宝 中 on 11-12-26.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "AnimeLoader.h"
#import "csvParser.h"

@implementation AnimeLoader

+ (AnimeLoader *)instance
{
    static AnimeLoader *loader = nil;
    if (loader == nil)
    {
        loader = [[AnimeLoader alloc] init];
    }
    
    return loader;
}

- (void)loadAnime:(NSString *)animeName
{
    [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:animeName];
}

- (void)loadTotalAnime
{
    [CCTexture2D setDefaultAlphaPixelFormat:kCCTexture2DPixelFormat_RGBA4444];
    
    NSString *dir = @"anime";
    
    NSArray *totalPlistFile = [NSArray arrayWithObjects:
                               @"beatnpc-1-begin.plist",
                               @"beatnpc-1-end.plist",
                               @"beatnpc-3-begin.plist",
                               @"beatnpc-3-end.plist",
                               @"beatnpc-5-end.plist",
                               @"devil-down.plist",
                               @"devil-roshambo.plist",
                               @"npc-beat-player-action.plist",
                               @"npc-beat-player.plist",
                               @"npc-cry.plist",
                               @"npc-waiting.plist",
                               @"roshambo-fear.plist",
                               @"roshambo-jump.plist",
                               @"roshambo-normal.plist",
                               nil];
    for (NSString *plistName in totalPlistFile)
    {
        [self loadAnime:[dir stringByAppendingPathComponent:plistName]];
    }
    
    [CCTexture2D setDefaultAlphaPixelFormat:kCCTexture2DPixelFormat_Default];
}

- (void)loadAnimeDef:(NSString *)defPath
{
    CSV_RECORDS records;
    csv_populate(records, defPath.UTF8String, ',');
    
    NSMutableArray *array = [NSMutableArray array];
    for (int i = 0; i < records.size(); ++i)
    {
        [array addObject:[NSString stringWithUTF8String:records[i][0].c_str()]];
    }
    
    [animeInfoDic setObject:array forKey:defPath.lastPathComponent];
}

- (void)loadTotalAnimeDef
{
    NSString *dir = @"anime-def";
    
    NSString *animeFileNameArray[] =
    {
        @"1-beat-npc.csv",
        @"3-beat-npc.csv",
        @"5-beat-npc.csv",
        @"devil-down.csv",
        @"devil-before-roshambo.csv",
        @"devil-after-roshambo.csv",
        @"npc-beat-player.csv",
        @"npc-cry1.csv",
        @"npc-cry2.csv",
        @"npc-waiting.csv",
        @"paper-normal.csv",
        @"rock-normal.csv",
        @"scissors-normal.csv",
        @"paper-jump.csv",
        @"rock-jump.csv",
        @"scissors-jump.csv",
        @"paper-fear.csv",
        @"rock-fear.csv",
        @"scissors-fear.csv",
    };
    
    for (int i = 0; i < sizeof(animeFileNameArray) / sizeof(animeFileNameArray[0]); ++i)
    {
        NSString *relativePath = [dir stringByAppendingPathComponent:animeFileNameArray[i]];
        
        [self loadAnimeDef:[[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:relativePath]];
    }
}

- (CCAnimation *)getAnimationFromFileName:(NSString *)fileName
{
    CCAnimation *animation = [CCAnimation animation];
    for (NSString *spriteName in [animeInfoDic objectForKey:fileName])
    {
        CCSpriteFrame *frame = [[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:spriteName];
        
        [animation addFrame:frame];
    }
    
    return animation;
}

- (id)init
{
	self = [super init];
	if (self != nil)
	{
        animeInfoDic = [[NSMutableDictionary alloc] init];
        
        [self loadTotalAnime];
        [self loadTotalAnimeDef];
	}
	return self;
}

- (void)dealloc
{
    [animeInfoDic release];
    
	[super dealloc];
}

@end
