//
//  NextLayer.h
//  BalsamiqXmlReader
//
//  Created by lee living on 11-8-15.
//  Copyright 2011 LieHuo Tech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "RoshamboDef.h"
#import "BeatDevilsDef.h"
#import "SkillPanelLayer.h"
#import "ShopItemManager.h"

@class DiamondQueueLayer;
@class SpriteBarManager;
@class TimeSpriteBarManager;
@class CCBalsamiqLayer;
@class NpcAnimationManager;
@class CCMenuItemButton;
@class SkillPanelLayer;
@class CCAlertLayer;
@class PlayerGuideLayer;

@interface GameLayer : CCLayer <SkillPanelLayerDelegate, ShopItemManagerDelegate>
{
    NSValue *beatDevilsDelegateValue;
    
    CGPoint initTimePosition;
    
    SpriteBarManager *playerHpMgr;
    SpriteBarManager *npcHpMgr;
    SpriteBarManager *furyMgr;
    
    NpcAnimationManager *npcAnimationMgr;
    ShopItemManager *shopItemManager;
}

@property (nonatomic, retain) NSValue *beatDevilsDelegateValue;
@property CGPoint initRoshamboMenuPos;

@property (nonatomic, assign) SkillPanelLayer *skillPanelLayer;
@property (nonatomic, assign) PlayerGuideLayer *playerGuideLayer;
@property (nonatomic, assign) CCAlertLayer *shopLoadingAlert;

@property (nonatomic, assign) CCLabelAtlas *labHits;
@property (nonatomic, assign) CCLabelTTF *labStage;
@property (nonatomic, assign) CCLabelAtlas *labTotalScore;
@property (nonatomic, assign) CCLabelAtlas *labHighScore;

@property int lastStageScore;
@property int lastStageHits;

@property (nonatomic, assign) CCSprite *sprReady;
@property (nonatomic, assign) CCSprite *sprHitBg;

@property (nonatomic, readonly) SpriteBarManager *playerHpMgr;
@property (nonatomic, readonly) SpriteBarManager *npcHpMgr;
@property (nonatomic, readonly) TimeSpriteBarManager *timeBarMgr;
@property (nonatomic, readonly) SpriteBarManager *furyMgr;

@property (nonatomic, readonly) NpcAnimationManager *npcAnimationMgr;

+(CCScene *) scene;

- (void)setRoundTime:(float)roundTime totalTime:(float)totalTime;

- (void)setPlayerHP:(int)curHP maxHP:(int)maxHP;
- (void)setNpcHP:(int)curHP maxHP:(int)maxHP;
- (void)setFury:(int)curFury;

- (void)setHits:(int)hits;

// 动画播放函数

- (void)playNpcWaiting;

// 开始某一关函数，会打开关卡读取界面
- (void)showStageStartLayer:(int)stageNumber;
// 开始关卡函数，直接开始游戏，显示ready-go动画
- (void)showReadeyGoAnime;

- (void)addDevilBeforeRoshamboAnime;
- (void)addDevilAfterRoshamboAnime;

- (void)playBeatNpc:(DDamageContext)damageContext;
- (void)playBeatPlayer:(DDamageContext)damageContext;
- (void)cleanupNpcAnimeAndPlayWaitingAnime;

- (void)moveMenuUp;

- (void)showBeatAnimeAndNextStageLayer;
- (void)showBeatAnimeAndGameOverLayer;
- (void)showBeatAnimeAndClearStageLayer;

// 购买接口
- (void)buyFood;
- (void)buyBeer;

// 新手帮助
- (BOOL)isGuided;
- (void)attachPlayerGuide;
- (void)startPlayerGuide;
- (void)closePlayerGuide;

//  技能数据获取
- (void)buySkill:(SkillCode)skillCode;

- (int)getSkillCount:(SkillCode)skillCode;
- (int)getSkillMaxCount:(SkillCode)skillCode;
- (int)getSkillPrice:(SkillCode)skillCode;

- (void)addMoney:(int)money;
- (int)curMoney;

@end
