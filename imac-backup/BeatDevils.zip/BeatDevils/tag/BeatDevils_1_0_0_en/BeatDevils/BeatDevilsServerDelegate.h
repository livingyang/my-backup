/*
 *  BeatDevilsServerDelegate.h
 *  BeatDevils
 *
 *  Created by 青宝 中 on 11-11-24.
 *  Copyright 2011年 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef BeatDevils_BeatDevilsServerDelegate_cpp
#define BeatDevils_BeatDevilsServerDelegate_cpp

#import "IBeatDevilsServer.h"

@class GameLayer;
class BeatDevilsServerDelegate : public IBeatDevilsServerDelegate
{    
public:
    BeatDevilsServerDelegate(GameLayer *gameLayer);
    virtual ~BeatDevilsServerDelegate();
    
    //IBeatDevilsServerDelegate
    void OnAddNpcRoshambo(DiamondType diamondType);
    void OnAddPlayerRoshambo(Roshambo roshambo);
    void OnPlayerVSNpc(RoshamboResult result);
    void OnRemoveFirstDiamond();
    void OnRemoveAllDiamondWithWrong();
    void OnBreakBox(DiamondType changeType);
    
    void OnRoundStep(float roundTime, float totalTime);
    void OnRoundTimeOver();
    void OnNpcFightPlayer(DDamageContext damageContext);
    void OnPlayerFightNpc(DDamageContext damageContext);
    
    void OnStageBegin();
    void OnStageEnd();
    void OnRoundBegin();
    void OnRoundEnd();
    
    void OnStagePlayerLose();
    void OnStagePlayerWin();
    void OnStageClear();
    
    // 各种信息改变相关
    virtual void OnSkillCountChanged(SkillCode skillCode, int skillCount);
    virtual void OnMoneyChanged(int money);
    virtual void OnHitsChanged(int hits);
    virtual void OnFuryChanged(int fury);
    virtual void OnAddScore(int addScore, ScoreType scoreType);
    
    // 技能相关
    virtual void OnFreezeTimeStart();
    virtual void OnFreezeTimeStop();
    virtual void OnFreezeTimeStep(float freezeTime, float totalFreezeTime);
    virtual void OnUseMagicSkill(Roshambo sameRoshambo, int count);
    virtual void OnBoomFirstDiamond();
    
    // 技能购买相关
    void OnBuyFoodSuccess();
    void OnBuyBeerSuccess();
    
    //GameLayer操作函数
    
    // 游戏进入的时候调用
    void InitGame();
    // 玩家点击重新开始的时候调用
    void OnRestartClick();
    // 玩家点击下一关的时候调用
    void OnStartNextStageClick();
    
    void RoundStep(float dTime);
    
    // 动画结束函数
    void OnStageLoadingCompleted();
    void OnReadeyGoAnimeOver();
    void OnRoshamboClick(Roshambo roshambo);
    void OnSkillClick(SkillCode skillCode);
    void OnBuySkill(SkillCode skillCode);
    int GetSkillCount(SkillCode skillCode);
    
    void OnAddMoney(int money);
    int GetCurMoney();
    
    void OnBeatAnimeDone();
    void OnMenuBack();
    
private:
    void LoadInitData();
    void StartNextRound();
    
    NSString *GetRoshamboAnimeName(DiamondType diamondType, int curNpcHp, int maxNpcHp);
    
    BeatDevilsModel GetUnlockGameModel(BeatDevilsModel model);
    
private:
    typedef enum
    {
        kGameContinue,
        kStageWin,
        kStageLose,
        kGameClear,
    } BeatDevilsGameState;

    BeatDevilsGameState mGameState;
    
    GameLayer *m_GameLayer;
    
    int mLastHighHits;
    
    IBeatDevilsServer *m_Server;
};

#endif //BeatDevils_BeatDevilsServerDelegate_cpp