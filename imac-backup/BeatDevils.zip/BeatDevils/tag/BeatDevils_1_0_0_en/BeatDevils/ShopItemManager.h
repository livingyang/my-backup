//
//  ShopItemManager.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-23.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#define ITEM_1000_COINS @"1000Coins"
#define ITEM_2100_COINS @"2100Coins"
#define ITEM_5000_COINS @"5000Coins"
#define ITEM_12000_COINS @"12000Coins"

@protocol ShopItemManagerDelegate

- (void)onPurchaseItem:(NSString *)item success:(BOOL)isSuccess;

- (void)onPurchaseCancle;

- (void)onPurchaseTimeOut:(NSString *)item;

@end

@interface ShopItemManager : NSObject
{
}

@property (nonatomic, assign) id<ShopItemManagerDelegate> shopItemManagerDelegate;

- (id)initWithShopItemManagerDelegate:(id<ShopItemManagerDelegate>)delegate;

- (BOOL)canBuyShopItem;

- (void)purchaseItem:(NSString *)itemName;

@end
