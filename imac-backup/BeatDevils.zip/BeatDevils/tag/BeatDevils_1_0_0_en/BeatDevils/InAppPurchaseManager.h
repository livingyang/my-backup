//
//  InAppPurchaseManager.h
//  study_InApp
//
//  Created by 青宝 中 on 11-12-22.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <StoreKit/StoreKit.h>
#define kInAppPurchaseManagerProductsFetchedNotification @"kInAppPurchaseManagerProductsFetchedNotification"

// add a couple notifications sent out when the transaction completes
#define kTransactionKey @"kTransactionKey" // 通知中收到的消息里，事务的获取key

#define kInAppPurchaseManagerTransactionFailedNotification @"kInAppPurchaseManagerTransactionFailedNotification"
#define kInAppPurchaseManagerTransactionCancleNotification @"kInAppPurchaseManagerTransactionCancleNotification"
#define kInAppPurchaseManagerTransactionSucceededNotification @"kInAppPurchaseManagerTransactionSucceededNotification"

@interface InAppPurchaseManager : NSObject <SKProductsRequestDelegate, SKPaymentTransactionObserver>
{
    SKProduct *proUpgradeProduct;
    SKProductsRequest *productsRequest;
}

+ (InAppPurchaseManager *)instance;

- (void)requestProductData:(NSString *)productName;

// buy methods
- (void)loadStore:(NSString *)productName;
- (BOOL)canMakePurchases;

@end
