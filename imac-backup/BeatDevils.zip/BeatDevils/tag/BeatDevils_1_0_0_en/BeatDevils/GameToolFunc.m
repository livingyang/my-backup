//
//  GameToolFunc.m
//  BeatDevils
//
//  Created by 青宝 中 on 12-1-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "GameToolFunc.h"

@implementation GameToolFunc

static BeatDevilsModel g_BeatDevilsModel = BeatDevilsModelNormal;
+ (void)SetGameModel:(BeatDevilsModel)model
{
    g_BeatDevilsModel = model;
}

+ (BeatDevilsModel)GetGameModel
{
    return g_BeatDevilsModel;
}

+ (CCLabelAtlas *)getAndAddAtlasLabel:(CCLabelTTF *)parentLabel
                          anchorPoint:(CGPoint)anchorPoint
                          charMapFile:(NSString*)charmapfile
                            itemWidth:(NSUInteger)w
                           itemHeight:(NSUInteger)h
                         startCharMap:(unsigned char)c
{
    parentLabel.opacity = 0;
    
    CCLabelAtlas *label = [CCLabelAtlas labelWithString:parentLabel.string
                                            charMapFile:charmapfile
                                              itemWidth:w
                                             itemHeight:h
                                           startCharMap:c];
    [parentLabel addChild:label];
    label.anchorPoint = anchorPoint;//ccp(0.5f, 0.5f);
    
    label.position = ccp(parentLabel.contentSize.width * anchorPoint.x, parentLabel.contentSize.height * anchorPoint.y);
    return label;
}

+ (CCLabelAtlas *)getHitNumberLabel:(CCLabelTTF *)parentLabel
                        anchorPoint:(CGPoint)anchorPoint
{
    return [self getAndAddAtlasLabel:parentLabel
                         anchorPoint:anchorPoint
                         charMapFile:@"hit-number.png"
                           itemWidth:20
                          itemHeight:20
                        startCharMap:'0'];
}

+ (CCLabelAtlas *)getUINumberLabel:(CCLabelTTF *)parentLabel
                       anchorPoint:(CGPoint)anchorPoint
{
    return [self getAndAddAtlasLabel:parentLabel
                         anchorPoint:anchorPoint
                         charMapFile:@"ui-number.png"
                           itemWidth:20
                          itemHeight:22
                        startCharMap:'0'];
}

+ (CCLabelAtlas *)getScoreNumberLabel:(CCLabelTTF *)parentLabel
                          anchorPoint:(CGPoint)anchorPoint
{
    return [self getAndAddAtlasLabel:parentLabel
                         anchorPoint:anchorPoint
                         charMapFile:@"score-number.png"
                           itemWidth:14
                          itemHeight:16
                        startCharMap:'0'];
}

+ (CCLabelAtlas *)getStageNumberLabel:(CCLabelTTF *)parentLabel
                          anchorPoint:(CGPoint)anchorPoint
{
    return [self getAndAddAtlasLabel:parentLabel
                         anchorPoint:anchorPoint
                         charMapFile:@"stage-number.png"
                           itemWidth:33
                          itemHeight:33
                        startCharMap:'0'];
}

+ (CCTexture2D *)getModelTexture:(BeatDevilsModel)model
{
    NSString *textureImages[BeatDevilsModelMax] =
    {
        NSLocalizedString(@"UI/0-common/img-flag-normal.png", nil),
        NSLocalizedString(@"UI/0-common/img-flag-hard.png", nil),
        NSLocalizedString(@"UI/0-common/img-flag-expert.png", nil),
        NSLocalizedString(@"UI/0-common/img-flag-hell.png", nil),
    };
    
    return [[CCTextureCache sharedTextureCache] addImage:textureImages[model]];
}

#pragma mark -
#pragma mark 粒子效果

static const int TagParticle = 2349;

+ (void)removeParticle:(CCNode *)node
{
    [node removeChildByTag:TagParticle cleanup:YES];
}

+ (void)showSnow:(CCNode *)node
{
    [self removeParticle:node];
    
    CCParticleSystem *emitter = [CCParticleSnow node];
    emitter.tag = TagParticle;
	[node addChild:emitter];
	
	emitter.life = 3;
	emitter.lifeVar = 1;
	
	// gravity
	emitter.gravity = ccp(0,-10);
    
	// speed of particles
	emitter.speed = 130;
	emitter.speedVar = 30;
	
	
	ccColor4F startColor = emitter.startColor;
	startColor.r = 0.9f;
	startColor.g = 0.9f;
	startColor.b = 0.9f;
	emitter.startColor = startColor;
	
	ccColor4F startColorVar = emitter.startColorVar;
	startColorVar.b = 0.1f;
	emitter.startColorVar = startColorVar;
	
	emitter.emissionRate = emitter.totalParticles/emitter.life / 4.0f;
	
	emitter.texture = [[CCTextureCache sharedTextureCache] addImage: @"snow.png"];
}

+ (void)showRain:(CCNode *)node
{
    [self removeParticle:node];
    
    CCParticleSystem *emitter = [CCParticleRain node];
    emitter.tag = TagParticle;
	[node addChild:emitter z:TagParticle];
	
	emitter.life = 4;
}

+ (void)showLeaf:(CCNode *)node
{
    [self removeParticle:node];
    
    CCParticleSystem *emitter = [CCParticleRain node];
    emitter.tag = TagParticle;
	[node addChild:emitter z:TagParticle];
	
	emitter.life = 4;
    
	emitter.texture = [[CCTextureCache sharedTextureCache] addImage: @"leaf.png"];
    emitter.startSize = 20.0f;
    emitter.endSize = 40.0f;
	emitter.speed = 100;
    emitter.emissionRate = 2;
}

@end
