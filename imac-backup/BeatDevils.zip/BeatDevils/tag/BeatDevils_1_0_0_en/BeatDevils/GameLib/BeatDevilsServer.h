/*
 *  BeatDevilsServer.h
 *  BeatDevils
 *
 *  Created by 青宝 中 on 11-11-24.
 *  Copyright 2011年 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef BeatDevils_BeatDevilsServer_cpp
#define BeatDevils_BeatDevilsServer_cpp

#include "IBeatDevilsServer.h"

#include "FightSystem.h"
#include "RoundManager.h"

#include <vector>

class BeatDevilsServer : public IBeatDevilsServer, IRoundManagerDelegate, IFightSystemDelegate
{    
public:
    BeatDevilsServer(IBeatDevilsServerDelegate *delegate);
    virtual ~BeatDevilsServer();
    
    virtual void AddPlayerRoshambo(Roshambo roshambo);
    void AddPlayerWinRoshambo();
    void AddPlayerLostRoshambo();
    virtual int GetNpcDiamondCount();
    
    virtual void RoundStep(float dTime);
    
    virtual bool LoadStageInfo(const char *filePath);
    void AddStageInfo(const DStageInfo &stageInfo);
    virtual const DStageInfo *GetStageInfo(int stageIndex) const;
    virtual BeatDevilsGameData GetGameData() const;
    virtual void SetGameData(BeatDevilsGameData &gameData);
    
    virtual void ResetBeatDevilsServer(BeatDevilsModel model);
    virtual void StartNextStage();
    virtual bool IsStageStart();
    
    virtual int GetCurrentStage();
    virtual int GetMaxStageCount();
    
    virtual void StartNextRound();
    virtual bool IsRoundStart();
    
    int GetCurrentRound() const;
    int GetCurrentRoundDiamondCount() const;
    
    // 获取玩家和npc信息
    virtual int GetCurPlayerHP() const;
    virtual DRoleProperty GetPlayerPropFromSkill() const;
    virtual int GetCurNpcHP() const;
    virtual int GetMaxNpcHP() const;

    // 购买技能接口
    virtual void SetMoney(int money);
    virtual int GetMoney() const;
    virtual void BuySkill(SkillCode skillCode);
    
    // 技能接口
    virtual int GetMaxFury() const;
    virtual void UseSkill(SkillCode skillCode);
    virtual void SetSkillCount(SkillCode skillCode, int count);
    virtual int GetSkillCount(SkillCode skillCode) const;
    
    // 分数接口
    void SetScore(int64_t score);
    virtual int64_t GetScore() const;
    
private:
    // 设置默认的管理器属性
    void LoadDefaultFightManagerValue();
    
    void AddScore(int score, ScoreType scoreType);
    void SetIsRoundStart(bool isRoundStart);
    void SetIsStageStart(bool isStageStart);
    void SetFreezeTime(float freezeTime);
    void SetIsFreezing(bool isFreezing);
    bool IsFreezing() const;
    bool IsBooming() const;
    void ClearBoomInfo();
    
    int GetHightScoreParam() const;
    bool IsCriticalScore() const;
    int64_t GetRoundScore(int diamondScore,
                          int diamondCount,
                          int stageParam,
                          int beatDevilCount,
                          int beatDevilParam,
                          int playerWinCombo,
                          int playerWinParam,
                          int turnCount,
                          bool isCriticalScore);
    
    RandomDiamondParam GetRandomDiamondParam();
    
private:
    //IRoundManagerDelegate
    virtual void OnAddPlayerRoshambo(Roshambo roshambo);
    virtual void OnAddNpcRoshambo(DiamondType diamondType);
    
    virtual void OnPlayerRoshamboFull();
    virtual void OnPlayerVsNpc(RoshamboResult result);
    
    virtual void OnRemoveFirstDiamond();
    virtual void OnChangeDiamondToSame(DiamondType sameDiamond, int count);
    virtual void OnBoomFirstDiamond();
    virtual void OnBreakBox(DiamondType changeDiamondType);
private:
    //IFightSystemDelegate
    
    // 回合判定回调
    virtual void OnAddFightSystemRoshamboResult(RoshamboResult result);
    
    // 攻击回调
    virtual void OnPlayerFightNpc(DDamageContext damageContext);
    virtual void OnNpcFightPlayer(DDamageContext damageContext);
    
    // 玩家被击倒或npc被击倒
    virtual void OnPlayerDown();
    virtual void OnNpcDown();
    
    // 技能相关回调
    virtual void OnSkillCountChanged(SkillCode skillCode, int skillCount);
    virtual void OnUseSkillFreezeTime(float freezeTime);
    virtual void OnUseSkillMagic(int magicCount);
    virtual void OnUseSkillBoom(int boomCount);
    
    // 信息改变函数
    virtual void OnFuryChanged(int fury);
    virtual void OnHitsChanged(int hits);
    
private:
    IBeatDevilsServerDelegate *m_delegate;
    
    BeatDevilsModel mBeatDevilsModel;
    
    RoundManager mRoundManager;
    FightSystem mFightSystem;
    
    float mRoundTime;
    int mCurStage;      // 从1开始
    int mCurRound;      // 从1开始
    bool mIsRoundStart;
    bool mIsStageStart;
    
    bool mIsFreezing;
    float mFreezeTime;
    float mTotalFreezeTime;
    
    // 爆炸技能相关
    float mBoomElaspedTime;
    int mBoomCount;
    int mCurBoomCount;
    
    int mMoney;
    int64_t mScore;
    
    std::vector<DStageInfo> mStageInfoVector;
};

#endif //BeatDevils_BeatDevilsServer_cpp