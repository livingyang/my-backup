/*
 *  RoundManager.h
 *  BeatDevils
 *
 *  Created by 青宝 中 on 11-11-29.
 *  Copyright 2011年 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef BeatDevils_RoundManager_cpp
#define BeatDevils_RoundManager_cpp

#include "BeatDevilsDef.h"
#include <vector>

typedef struct
{
    unsigned int normalPercent;
    unsigned int reversePercent;
    unsigned int starPercent;
    unsigned int box1Percent;
    unsigned int box2Percent;
} RandomDiamondParam;

struct IRoundManagerDelegate
{
    virtual void OnAddPlayerRoshambo(Roshambo roshambo) = 0;
    virtual void OnAddNpcRoshambo(DiamondType diamondType) = 0;
    
    virtual void OnPlayerRoshamboFull() = 0;
    virtual void OnPlayerVsNpc(RoshamboResult result) = 0;
    
    // 消除相关接口
    virtual void OnRemoveFirstDiamond() = 0;
    virtual void OnChangeDiamondToSame(DiamondType sameDiamond, int count) = 0;
    virtual void OnBoomFirstDiamond() = 0;
    virtual void OnBreakBox(DiamondType changeDiamondType) = 0;
};

class RoundManager
{    
public:
    RoundManager(IRoundManagerDelegate *delegate);
    virtual ~RoundManager();
    
    bool Restart(DiamondType npcDiamondArray[], int npcDiamondCount);
    bool Restart(int npcDiamondCount, RandomDiamondParam param);
    
    void ChangeRoshamboToSame(int count);
    
    void AddPlayerRoshambo(Roshambo roshambo);
    void BoomOneDiamond();
    int GetNpcDiamondCount() const;
    
    DiamondType GetCurNpcDiamond() const;
    
private:
    void AddNpcDiamond(DiamondType diamond);
    int GetCurNpcDiamondIndex() const;
    void SetNpcDiamondAtIndex(DiamondType diamondType, int index);
    
    void AddNormalDiamond();
    void AddReverseDiamond();
    void AddStarDiamond();
    void AddBox1Diamond();
    void AddBox2Diamond();
    
    DiamondType GetBox1OpenDiamond();
    DiamondType GetBox2OpenDiamond();
    
private:
    IRoundManagerDelegate *m_delegate;

    std::vector<DiamondType> mNpcDiamondList;
    std::vector<Roshambo> mPlayerRoshamboList;
    
public:
    void SetBox1OpenDiamondList(DiamondType diamondArray[], int diamondCount);
    void SetBox2OpenDiamondList(DiamondType diamondArray[], int diamondCount);
    
private:
    std::vector<DiamondType> mBox1OpenDiamondList;
    std::vector<DiamondType> mBox2OpenDiamondList;
    
    typedef void (RoundManager::*CreateDiamondFuc)();
};

#endif //BeatDevils_RoundManager_cpp