//
//  BeatDevilsDef.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-11-24.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#ifndef BeatDevils_BeatDevilsDef_h
#define BeatDevils_BeatDevilsDef_h

#include "RoshamboDef.h"
#include "BeatDevilsDiamond.h"

#define MAX_ROUND_DIAMOND_COUNT (6)

#define MAX_BASE_FURY (500)
#define BASE_FREEZE_TIME (3.0f)
#define MAX_BASE_MAGIC_COUNT (5)
#define MAX_BASE_BOOM_COUNT (5)

#define BOOM_TIME (0.4f)

// 角色数据
typedef struct
{
    int maxHP;
    int attack;
    int defense;
} DRoleProperty;

enum
{
    AttackModelNpcAttackPlayer = 0,
    AttackModelPlayerAttackNpc_1,
    AttackModelPlayerAttackNpc_3,
    AttackModelPlayerAttackNpc_5,
    AttackModelMax,
};
typedef short AttackModel;

enum
{
    BeatDevilsModelNormal = 0,
    BeatDevilsModelHard,
    BeatDevilsModelExpert,
    BeatDevilsModelHell,
    BeatDevilsModelMax,
};
typedef short BeatDevilsModel;

// 伤害数据
typedef struct
{
    // true: Player under attack, false: NPC under attack
    bool isPlayerUnderAttack;
    
    // 攻击次数
    int attackCount;
    
    // 攻击模式
    AttackModel attackModel;
    
    // 攻击总伤害
    int attackDamage;
} DDamageContext;

// 关卡信息
typedef struct
{
    // 每局的方块数，从0开始，第 MAX_ROUND_DIAMOND_COUNT 局后的方块数不变
    int diamondCount[MAX_ROUND_DIAMOND_COUNT];
    
    // 各种模式的每局的时间
    float modelRoundTime[BeatDevilsModelMax];
    
    // npc的属性
    DRoleProperty npcProp;
    
    // 各种模式的星星百分比
    int starPercent[BeatDevilsModelMax];
    
    // 各种模式的一级魔盒百分比
    int box1Percent[BeatDevilsModelMax];
    
    // 各种模式的二级魔盒百分比
    int box2Percent[BeatDevilsModelMax];
    
    // 各种模式的反转方块百分比
    int reversePercent[BeatDevilsModelMax];
} DStageInfo;

// 技能等级
enum
{
    // 被动技能
    S_ATTACK_UP = 0,                // 增加攻击力10
    S_DEFENSE_UP,                   // 增加防御力5
    S_MAX_FURY_UP,                  // 增加怒气槽上限50
    S_HIGH_SCORE_RATE_UP,           // 高分获得概率加10
    S_FREEZE_TIME_UP,               // 延长暂停时间1秒
    S_CRITICAL_RATE_UP,             // 暴击率加10
    S_MAGIC_UP,                     // 魔棒威力加3
    S_BOOM_UP,                      // 手雷威力加3
    
    // 主动技能使用时，需要消耗道具
    S_RECOVER_FURY,                 // 怒气加满道具
    S_RECOVER_HEALTH,               // 生命加满道具
    S_RESIST_MISTAKE,               // 错误抵抗道具
    
    S_SKILL_FREEZE_TIME,            // 暂停道具
    S_SKILL_MAGIC,                  // 魔棒道具
    S_SKILL_BOOM,                   // 炸弹道具
    
    S_MAX_SKILL,
};
typedef short SkillCode;

#define S_MAX_PURCHASE_SKILL_CODE (S_SKILL_FREEZE_TIME)

enum
{
    ScoreTypeNormal = 0,
    ScoreTypeCritical,
    ScoreTypeNotCritical,
};
typedef short ScoreType;

typedef struct
{
    int totalSkillCount[S_MAX_SKILL];
    int money;
} BeatDevilsGameData;

extern const DRoleProperty DefaultPlayerProp;

#ifdef __cplusplus 
extern "C" { 
#endif 

int GetAttackCount(AttackModel attackModel);
int GetSkillMaxCount(SkillCode skillCode);
int GetSkillPrice(SkillCode skillCode);
    
#ifdef __cplusplus 
} 
#endif

#endif
