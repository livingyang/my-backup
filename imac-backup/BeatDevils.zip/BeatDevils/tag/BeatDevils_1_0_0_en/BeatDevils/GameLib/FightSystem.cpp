/*
 *  FightSystem.cpp
 *  BeatDevils
 *
 *  Created by 青宝 中 on 11-12-3.
 *  Copyright 2011年 __MyCompanyName__. All rights reserved.
 *
 */

#include "FightSystem.h"

FightSystem::FightSystem(IFightSystemDelegate *delegate):
m_FightSystemDelegate(delegate)
{
    mHits = 0;
    mPlayerWinCombo = 0;
    mFury = 0;
    mBaseCriticalRate = 0;
    
    {
        // 设置技能处理函数
        mSkillHandleList[S_RECOVER_FURY] = &FightSystem::UseFuryRecover;
        mSkillHandleList[S_RECOVER_HEALTH] = &FightSystem::UseHealthRecover;
        mSkillHandleList[S_RESIST_MISTAKE] = &FightSystem::UseResistMistake;
        
        mSkillHandleList[S_SKILL_FREEZE_TIME] = &FightSystem::UseFreezeTime;
        mSkillHandleList[S_SKILL_MAGIC] = &FightSystem::UseMagic;
        mSkillHandleList[S_SKILL_BOOM] = &FightSystem::UseBoom;
    }
}

FightSystem::~FightSystem()
{
}

void FightSystem::ResetFightSystem()
{
    SetCurPlayerHP(GetPlayerPropFromSkill().maxHP);
    SetFury(0);
    SetHits(0);
    SetPlayerWinCombo(0);
}

#pragma mark -
#pragma mark 角色设置

void FightSystem::SetPlayerProp(DRoleProperty playerProp)
{
    mPlayerProp = playerProp;
    SetCurPlayerHP(playerProp.maxHP);
}

DRoleProperty FightSystem::GetNpcProp() const
{
    return mNpcProp;
}

void FightSystem::SetNpcProp(DRoleProperty npcProp)
{
    mNpcProp = npcProp;
    SetCurNpcHP(npcProp.maxHP);
}

DRoleProperty FightSystem::GetPlayerPropFromSkill() const
{
    DRoleProperty prop = mPlayerProp;
    prop.attack += GetSkillUpValue(S_ATTACK_UP) * GetSkillCount(S_ATTACK_UP);
    prop.defense += GetSkillUpValue(S_DEFENSE_UP) * GetSkillCount(S_DEFENSE_UP);
    return prop;
}

int FightSystem::GetCurPlayerHP() const
{
    return mCurPlayerHP;
}

int FightSystem::GetCurNpcHP() const
{
    return mCurNpcHP;
}

#pragma mark -
#pragma mark 回合结束时的操作

void FightSystem::AddRoshamboResult(RoshamboResult result)
{
    if (result == RoshamboResultDraw || result == RoshamboResultLost)
    {
        if (UseSkill(S_RESIST_MISTAKE) == true)
        {
            result = RoshamboResultWin;
        }
    }
    
    if (result == RoshamboResultDraw || result == RoshamboResultLost)
    {
        NpcFightPlayer();
    }
    else if (result == RoshamboResultWin)
    {
        SetHits(GetHits() + 1);
    }
    
    if (m_FightSystemDelegate != NULL)
    {
        m_FightSystemDelegate->OnAddFightSystemRoshamboResult(result);
    }
}

void FightSystem::OnAllTurnEnd()
{
    PlayerFightNpc();
    
    SetFury(GetIncreaseFury() + GetFury());
}

void FightSystem::OnRoundTimeOver()
{
    NpcFightPlayer();
}

#pragma mark -
#pragma mark 怒气相关

int FightSystem::GetMaxFury() const
{
    return MAX_BASE_FURY + GetSkillCount(S_MAX_FURY_UP) * GetSkillUpValue(S_MAX_FURY_UP);
}

void FightSystem::SetFury(int fury)
{
    if (fury < 0 || fury > GetMaxFury())
    {
        return;
    }
    
    mFury = fury;
    
    UpdateFurySkillCount(S_SKILL_FREEZE_TIME);
    UpdateFurySkillCount(S_SKILL_MAGIC);
    UpdateFurySkillCount(S_SKILL_BOOM);
    
    if (m_FightSystemDelegate != NULL)
    {
        m_FightSystemDelegate->OnFuryChanged(GetFury());
    }
}

int FightSystem::GetFury() const
{
    return mFury;
}

void FightSystem::SetSkillCostFury(SkillCode skillCode, int costFury)
{
    mSkillCostFuryMap[skillCode] = costFury;
    
    UpdateFurySkillCount(skillCode);
}

int FightSystem::GetSkillCostFury(SkillCode skillCode) const
{
    if (mSkillCostFuryMap.find(skillCode) == mSkillCostFuryMap.end())
    {
        return 0;
    }
    
    return mSkillCostFuryMap.find(skillCode)->second;
}

#pragma mark -
#pragma mark 技能相关

bool FightSystem::UseSkill(SkillCode skillCode)
{
    if (mSkillHandleList.find(skillCode) != mSkillHandleList.end())
    {
        return (this->*mSkillHandleList[skillCode])();
    }
    
    return false;
}

void FightSystem::SetSkillCount(SkillCode skillCode, int count)
{
    if (skillCode >= S_MAX_SKILL || skillCode < S_ATTACK_UP)
    {
        return;
    }
    
    if (count > GetSkillMaxCount(skillCode))
    {
        return;
    }
    
    mSkillCountMap[skillCode] = count;
    
    if (m_FightSystemDelegate != NULL)
    {
        m_FightSystemDelegate->OnSkillCountChanged(skillCode, GetSkillCount(skillCode));
    }
}

int FightSystem::GetSkillCount(SkillCode skillCode) const
{
    if (mSkillCountMap.find(skillCode) == mSkillCountMap.end())
    {
        return 0;
    }
    
    return mSkillCountMap.find(skillCode)->second;
}

void FightSystem::SetSkillUpValue(SkillCode skillCode, int upValue)
{
    if (skillCode >= S_MAX_SKILL || skillCode < S_ATTACK_UP)
    {
        return;
    }
    
    mSkillUpValueMap[skillCode] = upValue;
}

int FightSystem::GetSkillUpValue(SkillCode skillCode) const
{
    if (mSkillUpValueMap.find(skillCode) == mSkillUpValueMap.end())
    {
        return 0;
    }
    
    return mSkillUpValueMap.find(skillCode)->second;
}

#pragma mark -
#pragma mark 暴击率相关

int FightSystem::GetBaseCriticalRate() const
{
    return mBaseCriticalRate;
}

void FightSystem::SetBaseCriticalRate(int baseCriticalRate)
{
    mBaseCriticalRate = baseCriticalRate;
}

int FightSystem::GetCriticalRate() const
{
    return GetBaseCriticalRate() + GetSkillCount(S_CRITICAL_RATE_UP) * GetSkillUpValue(S_CRITICAL_RATE_UP);
}

void FightSystem::SetHits(int hits)
{
    mHits = hits;
    
    if (m_FightSystemDelegate != NULL)
    {
        m_FightSystemDelegate->OnHitsChanged(GetHits());
    }
}

int FightSystem::GetHits() const
{
    return mHits;
}

void FightSystem::SetPlayerWinCombo(int playerWinCombo)
{
    mPlayerWinCombo = playerWinCombo;
}

int FightSystem::GetPlayerWinCombo() const
{
    return mPlayerWinCombo;
}

#pragma mark -
#pragma mark 私有函数

void FightSystem::PlayerFightNpc()
{
    SetPlayerWinCombo(GetPlayerWinCombo() + 1);
    
    int damage = GetDamage(GetPlayerPropFromSkill(), mNpcProp, GetPlayerAttackCount());
    
    if (m_FightSystemDelegate != NULL)
    {
        m_FightSystemDelegate->OnPlayerFightNpc((DDamageContext) {true, GetPlayerAttackCount(), GetPlayerAttackModel(), damage});
    }
    
    SetCurNpcHP((GetCurNpcHP() > damage) ? GetCurNpcHP() - damage : 0);
}

void FightSystem::NpcFightPlayer()
{
    SetPlayerWinCombo(0);
    SetHits(0);
    
    int damage = GetDamage(mNpcProp, GetPlayerPropFromSkill(), GetNpcAttackCount());
    
    SetCurPlayerHP((GetCurPlayerHP() > damage) ? GetCurPlayerHP() - damage : 0);
    
    if (m_FightSystemDelegate != NULL)
    {
        m_FightSystemDelegate->OnNpcFightPlayer((DDamageContext) {false, GetNpcAttackCount(), AttackModelNpcAttackPlayer, damage});
    }
}

void FightSystem::SetCurPlayerHP(int playerHP)
{
    mCurPlayerHP = playerHP;
    
    if (m_FightSystemDelegate != NULL)
    {
        if (GetCurPlayerHP() <= 0)
        {
            m_FightSystemDelegate->OnPlayerDown();
        }
    }
}

void FightSystem::SetCurNpcHP(int npcHP)
{
    mCurNpcHP = npcHP;
    
    if (GetCurNpcHP() <= 0 && m_FightSystemDelegate != NULL)
    {
        m_FightSystemDelegate->OnNpcDown();
    }
}

AttackModel FightSystem::GetPlayerAttackModel() const
{
    if (GetPlayerWinCombo() >= 5)
    {
        bool isCritical = (arc4random() % 100) < GetCriticalRate();
        return isCritical ? AttackModelPlayerAttackNpc_5 : AttackModelPlayerAttackNpc_3;
    }
    else if (GetPlayerWinCombo() >= 3)
    {
        return AttackModelPlayerAttackNpc_3;
    }
    
    return AttackModelPlayerAttackNpc_1;
}

int FightSystem::GetPlayerAttackCount() const
{
    return GetAttackCount(GetPlayerAttackModel());
}

int FightSystem::GetNpcAttackCount() const
{
    return GetAttackCount(AttackModelNpcAttackPlayer);
}

int FightSystem::GetDamage(const DRoleProperty &attacker, const DRoleProperty &defenser, int attackCount) const
{
    int oneDamage = attacker.attack - defenser.defense;
    if (oneDamage < 1)
    {
        oneDamage = 1;
    }
    
    return oneDamage * attackCount;
}

int FightSystem::GetIncreaseFury() const
{
    return (GetPlayerWinCombo() < 5 ? GetPlayerWinCombo() : 5) * 5;
}

bool FightSystem::UseFuryRecover()
{
    if (GetSkillCount(S_RECOVER_FURY) <= 0)
    {
        return false;
    }
    
    if (GetFury() == GetMaxFury())
    {
        return false;
    }
    
    SetSkillCount(S_RECOVER_FURY, GetSkillCount(S_RECOVER_FURY) - 1);
    SetFury(GetMaxFury());
    
    return true;
}

bool FightSystem::UseHealthRecover()
{
    if (GetSkillCount(S_RECOVER_HEALTH) <= 0)
    {
        return false;
    }
    
    if (GetCurPlayerHP() == GetPlayerPropFromSkill().maxHP)
    {
        return false;
    }
    
    SetCurPlayerHP(GetPlayerPropFromSkill().maxHP);
    SetSkillCount(S_RECOVER_HEALTH, GetSkillCount(S_RECOVER_HEALTH) - 1);
    
    return true;
}

bool FightSystem::UseResistMistake()
{
    if (GetSkillCount(S_RESIST_MISTAKE) <= 0)
    {
        return false;
    }
    
    SetSkillCount(S_RESIST_MISTAKE, GetSkillCount(S_RESIST_MISTAKE) - 1);

    return true;
}

bool FightSystem::UseFreezeTime()
{
    if (GetFury() < GetSkillCostFury(S_SKILL_FREEZE_TIME))
    {
        return false;
    }
    
    SetFury(GetFury() - GetSkillCostFury(S_SKILL_FREEZE_TIME));
    UpdateFurySkillCount(S_SKILL_FREEZE_TIME);
    
    if (m_FightSystemDelegate != NULL)
    {
        m_FightSystemDelegate->OnUseSkillFreezeTime(GetFreezeTimeFromSkill());
    }
    
    return true;
}

bool FightSystem::UseMagic()
{
    if (GetFury() < GetSkillCostFury(S_SKILL_MAGIC))
    {
        return false;
    }
    
    SetFury(GetFury() - GetSkillCostFury(S_SKILL_MAGIC));
    UpdateFurySkillCount(S_SKILL_MAGIC);
    
    if (m_FightSystemDelegate != NULL)
    {
        m_FightSystemDelegate->OnUseSkillMagic(GetMagicCountFromSkill());
    }
    
    return true;
}

bool FightSystem::UseBoom()
{
    if (GetFury() < GetSkillCostFury(S_SKILL_BOOM))
    {
        return false;
    }
    
    SetFury(GetFury() - GetSkillCostFury(S_SKILL_BOOM));
    UpdateFurySkillCount(S_SKILL_BOOM);
    
    if (m_FightSystemDelegate != NULL)
    {
        m_FightSystemDelegate->OnUseSkillBoom(GetBoomCountFromSkill());
    }
    
    return true;
}

void FightSystem::UpdateFurySkillCount(SkillCode skillCode)
{
    SetSkillCount(skillCode, GetFury() >= GetSkillCostFury(skillCode) ? 1 : 0);
}

int FightSystem::GetFreezeTimeFromSkill() const
{
    return BASE_FREEZE_TIME + GetSkillUpValue(S_FREEZE_TIME_UP) * GetSkillCount(S_FREEZE_TIME_UP);
}

int FightSystem::GetMagicCountFromSkill() const
{
    return MAX_BASE_MAGIC_COUNT + GetSkillUpValue(S_MAGIC_UP) * GetSkillCount(S_MAGIC_UP);
}

int FightSystem::GetBoomCountFromSkill() const
{
    return MAX_BASE_BOOM_COUNT + GetSkillUpValue(S_BOOM_UP) * GetSkillCount(S_BOOM_UP);
}

#pragma mark -
#pragma mark 公共函数

int GetAttackCount(AttackModel attackModel)
{
    switch (attackModel)
    {
        case AttackModelNpcAttackPlayer:
        {
            return 6;
        }break;
        case AttackModelPlayerAttackNpc_1:
        {
            return 1;
        }break;
        case AttackModelPlayerAttackNpc_3:
        {
            return 3;
        }break;
        case AttackModelPlayerAttackNpc_5:
        {
            return 5;
        }break;
        default:
            break;
    }
    
    return 0;
}

int GetSkillMaxCount(SkillCode skillCode)
{
    static int SKILL_MAX_COUNT[S_MAX_SKILL] = 
    {
        10,     //S_ATTACK_UP
        10,     //S_DEFENSE_UP
        6,      //S_MAX_FURY_UP
        6,      //S_HIGH_SCORE_RATE_UP
        5,      //S_FREEZE_TIME_UP
        10,     //S_CRITICAL_RATE_UP
        5,      //S_MAGIC_UP
        5,      //S_BOOM_UP
        
        99,     //S_RECOVER_FURY
        99,     //S_RECOVER_HEALTH
        99,     //S_RESIST_MISTAKE
        
        1,      //S_SKILL_FREEZE_TIME,            // 暂停道具
        1,      //S_SKILL_MAGIC,                  // 魔棒道具
        1,      //S_SKILL_BOOM,                   // 炸弹道具
    };
    
    if (skillCode >= S_MAX_SKILL || skillCode < S_ATTACK_UP)
    {
        return 0;
    }
    
    return SKILL_MAX_COUNT[skillCode];
}