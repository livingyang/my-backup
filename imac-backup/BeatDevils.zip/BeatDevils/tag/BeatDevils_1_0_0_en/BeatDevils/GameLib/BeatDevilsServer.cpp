/*
 *  BeatDevilsServer.cpp
 *  BeatDevils
 *
 *  Created by 青宝 中 on 11-11-24.
 *  Copyright 2011年 __MyCompanyName__. All rights reserved.
 *
 */

#include "BeatDevilsServer.h"

using std::vector;

#include <sstream>
using std::stringstream;

#include "csvParser.h"

#include <cmath>

const DRoleProperty DefaultPlayerProp =
{
    1800,
    100,
    0,
};

#define OUTPUT_STRING(str, target)\
{\
stringstream ss(str);\
ss >> target;\
}

BeatDevilsServer::BeatDevilsServer(IBeatDevilsServerDelegate *delegate):
m_delegate(delegate),
mBeatDevilsModel(BeatDevilsModelNormal),
mRoundManager(this),
mFightSystem(this),
mIsRoundStart(false),
mIsStageStart(false),
mCurStage(0),
mCurRound(0),
mIsFreezing(false),
mFreezeTime(0),
mTotalFreezeTime(0),
mMoney(0),
mScore(0),
mBoomElaspedTime(0),
mBoomCount(0),
mCurBoomCount(0)
{
    LoadDefaultFightManagerValue();
}

BeatDevilsServer::~BeatDevilsServer()
{
}

void BeatDevilsServer::AddPlayerRoshambo(Roshambo roshambo)
{
    mRoundManager.AddPlayerRoshambo(roshambo);
}

void BeatDevilsServer::AddPlayerWinRoshambo()
{
    mRoundManager.AddPlayerRoshambo(GetRoshamboFromDiamondTypeResult(mRoundManager.GetCurNpcDiamond(), RoshamboResultWin));
}

void BeatDevilsServer::AddPlayerLostRoshambo()
{
    mRoundManager.AddPlayerRoshambo(GetRoshamboFromDiamondTypeResult(mRoundManager.GetCurNpcDiamond(), RoshamboResultLost));
}

int BeatDevilsServer::GetNpcDiamondCount()
{
    return mRoundManager.GetNpcDiamondCount();
}

void BeatDevilsServer::RoundStep(float dTime)
{
    if (dTime <= 0 || IsRoundStart() == false)
    {
        return;
    }
    
    if (IsFreezing())
    {
        mFreezeTime += dTime;
        
        if (m_delegate != NULL)
        {
            m_delegate->OnFreezeTimeStep(mFreezeTime, mTotalFreezeTime);
        }
        
        if (mFreezeTime >= mTotalFreezeTime)
        {
            SetIsFreezing(false);
        }
    }
    else
    {
        mRoundTime += dTime;
        
        const DStageInfo *info = GetStageInfo(GetCurrentStage() - 1);
        m_delegate->OnRoundStep(mRoundTime, info->modelRoundTime[mBeatDevilsModel]);
        
        if (mRoundTime >= info->modelRoundTime[mBeatDevilsModel])
        {
            SetIsRoundStart(false);
            
            mFightSystem.OnRoundTimeOver();
            
            if (m_delegate != NULL)
            {
                m_delegate->OnRoundTimeOver();
            }
        }
    }
    
    // 在这里进行爆炸操作
    if (IsBooming())
    {
        mBoomElaspedTime += dTime;
        if (mCurBoomCount * BOOM_TIME <= mBoomElaspedTime)
        {
            // 进行爆炸操作
            ++mCurBoomCount;
            mRoundManager.BoomOneDiamond();
        }
    }
}

bool BeatDevilsServer::LoadStageInfo(const char *filePath)
{
    CSV_RECORDS records;
    csv_populate(records, filePath, ',');
    
    if (records.size() <= 1)
    {
        return false;
    }
    
    mStageInfoVector.clear();
    for (int recordIndex = 1; recordIndex < records.size(); ++recordIndex)
    {
        DStageInfo info;
        CSV_LINE &line = records[recordIndex];
        
        // 0       关卡名
        
        // 1～6    每个回合的方块数
        for (int lineIndex = 1; lineIndex <= 6; ++lineIndex)
        {
            OUTPUT_STRING(line[lineIndex], info.diamondCount[lineIndex - 1]);
        }
        
        // 7       回合时间
        vector<string> timeVec = splitEx(line[7], ";");
        for (int i = 0; i < timeVec.size(); ++i)
        {
            OUTPUT_STRING(trim(timeVec[i]), info.modelRoundTime[i]);
        }
        
        // 8～10   玩家信息
        OUTPUT_STRING(line[8], info.npcProp.maxHP);
        OUTPUT_STRING(line[9], info.npcProp.attack);
        OUTPUT_STRING(line[10], info.npcProp.defense);
        
        // 11      星星百分比
        vector<string> starVec = splitEx(line[11], ";");
        for (int i = 0; i < starVec.size(); ++i)
        {
            OUTPUT_STRING(trim(starVec[i]), info.starPercent[i]);
        }
        
        // 12      一级魔盒百分比
        vector<string> box1Vec = splitEx(line[12], ";");
        for (int i = 0; i < box1Vec.size(); ++i)
        {
            OUTPUT_STRING(trim(box1Vec[i]), info.box1Percent[i]);
        }
        
        // 13      二级魔盒百分比
        vector<string> box2Vec = splitEx(line[13], ";");
        for (int i = 0; i < box2Vec.size(); ++i)
        {
            OUTPUT_STRING(trim(box2Vec[i]), info.box2Percent[i]);
        }
        
        // 14      反转方块百分比
        vector<string> reverseVec = splitEx(line[14], ";");
        for (int i = 0; i < reverseVec.size(); ++i)
        {
            OUTPUT_STRING(trim(reverseVec[i]), info.reversePercent[i]);
        }
        
        AddStageInfo(info);
    }
    
    return true;
}

void BeatDevilsServer::AddStageInfo(const DStageInfo &stageInfo)
{
    mStageInfoVector.push_back(stageInfo);
}

const DStageInfo *BeatDevilsServer::GetStageInfo(int stageIndex) const
{
    if (stageIndex < 0 || stageIndex >= mStageInfoVector.size())
    {
        return NULL;
    }
    else
    {
        return &mStageInfoVector[stageIndex];
    }
}

BeatDevilsGameData BeatDevilsServer::GetGameData() const
{
    BeatDevilsGameData gameData = {};
    gameData.money = GetMoney();
    
    for (SkillCode skillCode = 0; skillCode < S_MAX_SKILL; ++skillCode)
    {
        gameData.totalSkillCount[skillCode] = GetSkillCount(skillCode);
    }
    
    return gameData;
}

void BeatDevilsServer::SetGameData(BeatDevilsGameData &gameData)
{
    SetMoney(gameData.money);
    
    for (SkillCode skillCode = 0; skillCode < S_MAX_SKILL; ++skillCode)
    {
        SetSkillCount(skillCode, gameData.totalSkillCount[skillCode]);
    }
}

void BeatDevilsServer::ResetBeatDevilsServer(BeatDevilsModel model)
{
    mBeatDevilsModel = model;
    
    mFightSystem.ResetFightSystem();
    
    SetScore(0);
    mCurStage = 0;
    mCurRound = 0;
    
    SetIsRoundStart(false);
    SetIsStageStart(false);
    
    // 爆炸效果相关
    ClearBoomInfo();
}

void BeatDevilsServer::StartNextStage()
{
    if (GetCurrentStage() >= GetMaxStageCount())
    {
        return;
    }
    
    ++mCurStage;
    mCurRound = 0;
    
    mFightSystem.SetNpcProp(GetStageInfo(GetCurrentStage() - 1)->npcProp);
    
    SetIsRoundStart(false);
    SetIsStageStart(true);
    
    if (m_delegate != NULL)
    {
        m_delegate->OnFuryChanged(mFightSystem.GetFury());
    }
}

bool BeatDevilsServer::IsStageStart()
{
    return mIsStageStart;
}

int BeatDevilsServer::GetCurrentStage()
{
    return mCurStage;
}

int BeatDevilsServer::GetMaxStageCount()
{
    return mStageInfoVector.size();
}

void BeatDevilsServer::StartNextRound()
{
    SetIsRoundStart(true);
    ++mCurRound;
    mRoundManager.Restart(GetCurrentRoundDiamondCount(), GetRandomDiamondParam());
    
    ClearBoomInfo();
}

bool BeatDevilsServer::IsRoundStart()
{
    return mIsRoundStart;
}

int BeatDevilsServer::GetCurrentRound() const
{
    return mCurRound;
}

int BeatDevilsServer::GetCurrentRoundDiamondCount() const
{
    const DStageInfo* info = GetStageInfo(mCurStage - 1);
    
    if (info == NULL)
    {
        return 0;
    }
    
    int diamondCountIndex = GetCurrentRound() - 1;
    if (diamondCountIndex < 0)
    {
        return 0;
    }
    else if (diamondCountIndex < MAX_ROUND_DIAMOND_COUNT)
    {
        return info->diamondCount[diamondCountIndex];
    }
    else
    {
        return info->diamondCount[MAX_ROUND_DIAMOND_COUNT - 1];
    }
}

int BeatDevilsServer::GetCurPlayerHP() const
{
    return mFightSystem.GetCurPlayerHP();
}

DRoleProperty BeatDevilsServer::GetPlayerPropFromSkill() const
{
    return mFightSystem.GetPlayerPropFromSkill();
}

int BeatDevilsServer::GetCurNpcHP() const
{
    return mFightSystem.GetCurNpcHP();
}

int BeatDevilsServer::GetMaxNpcHP() const
{
    return mFightSystem.GetNpcProp().maxHP;
}

void BeatDevilsServer::SetMoney(int money)
{
    mMoney = money;
    
    if (m_delegate != NULL)
    {
        m_delegate->OnMoneyChanged(GetMoney());
    }
}

int BeatDevilsServer::GetMoney() const
{
    return mMoney;
}

void BeatDevilsServer::BuySkill(SkillCode skillCode)
{
    if (GetMoney() < GetSkillPrice(skillCode))
    {
        return;
    }
    
    int foreCount = GetSkillCount(skillCode);
    SetSkillCount(skillCode, GetSkillCount(skillCode) + 1);
    int afterCount = GetSkillCount(skillCode);
    
    if (afterCount == foreCount + 1)
    {
        SetMoney(GetMoney() - GetSkillPrice(skillCode));
    }
}

int BeatDevilsServer::GetMaxFury() const
{
    return mFightSystem.GetMaxFury();
}

void BeatDevilsServer::UseSkill(SkillCode skillCode)
{
    if (IsRoundStart() == false)
    {
        return;
    }
    
    mFightSystem.UseSkill(skillCode);
}

void BeatDevilsServer::SetSkillCount(SkillCode skillCode, int count)
{
    mFightSystem.SetSkillCount(skillCode, count);
}

int BeatDevilsServer::GetSkillCount(SkillCode skillCode) const
{
    return mFightSystem.GetSkillCount(skillCode);
}

void BeatDevilsServer::SetScore(int64_t score)
{
    if (score < 0)
    {
        return;
    }
    
    mScore = score;
}

int64_t BeatDevilsServer::GetScore() const
{
    return mScore;
}

#pragma mark -
#pragma mark Private

void BeatDevilsServer::LoadDefaultFightManagerValue()
{
    // 设置游戏中，玩家的默认属性
    mFightSystem.SetPlayerProp(DefaultPlayerProp);
    mFightSystem.SetBaseCriticalRate(50);
    
    // 设置技能消耗怒气
    mFightSystem.SetSkillCostFury(S_SKILL_FREEZE_TIME, 60);
    mFightSystem.SetSkillCostFury(S_SKILL_MAGIC, 50);
    mFightSystem.SetSkillCostFury(S_SKILL_BOOM, 70);
    
    // 设置技能提升属性
    mFightSystem.SetSkillUpValue(S_ATTACK_UP, 10);
    mFightSystem.SetSkillUpValue(S_DEFENSE_UP, 5);
    mFightSystem.SetSkillUpValue(S_MAX_FURY_UP, 50);
    mFightSystem.SetSkillUpValue(S_HIGH_SCORE_RATE_UP, 10);
    mFightSystem.SetSkillUpValue(S_FREEZE_TIME_UP, 1);
    mFightSystem.SetSkillUpValue(S_CRITICAL_RATE_UP, 10);
    mFightSystem.SetSkillUpValue(S_MAGIC_UP, 3);
    mFightSystem.SetSkillUpValue(S_BOOM_UP, 3);
}

void BeatDevilsServer::AddScore(int score, ScoreType scoreType)
{
    if (score < 0)
    {
        return;
    }
    
    SetScore(GetScore() + score);
    
    if (m_delegate != NULL)
    {
        m_delegate->OnAddScore(score, scoreType);
    }
}

void BeatDevilsServer::SetIsRoundStart(bool isRoundStart)
{
    mIsRoundStart = isRoundStart;
    
    if (IsRoundStart() == false)
    {
        if (IsFreezing())
        {
            SetIsFreezing(false);
        }
    }
    else
    {
        mRoundTime = 0;
    }
    
    if (m_delegate != NULL)
    {
        IsRoundStart() ? m_delegate->OnRoundBegin() : m_delegate->OnRoundEnd();
    }
}

void BeatDevilsServer::SetIsStageStart(bool isStageStart)
{
    mIsStageStart = isStageStart;
    
    if (m_delegate != NULL)
    {
        IsStageStart() ? m_delegate->OnStageBegin() : m_delegate->OnStageEnd();
    }
}

void BeatDevilsServer::SetFreezeTime(float freezeTime)
{
    if (freezeTime <= 0)
    {
        return;
    }
    
    mTotalFreezeTime = freezeTime;
    mFreezeTime = 0;
    
    SetIsFreezing(true);
}

void BeatDevilsServer::SetIsFreezing(bool isFreezing)
{
    mIsFreezing = isFreezing;
    
    if (m_delegate != NULL)
    {
        if (IsFreezing())
        {
            m_delegate->OnFreezeTimeStart();
        }
        else
        {
            m_delegate->OnFreezeTimeStop();
        }
    }
}

bool BeatDevilsServer::IsFreezing() const
{
    return mIsFreezing;
}

bool BeatDevilsServer::IsBooming() const
{
    return mCurBoomCount < mBoomCount;
}

void BeatDevilsServer::ClearBoomInfo()
{
    mBoomCount = 0;
    mCurBoomCount = 0;
    mBoomElaspedTime = 0;
}

int BeatDevilsServer::GetHightScoreParam() const
{
    return mFightSystem.GetSkillCount(S_HIGH_SCORE_RATE_UP) * mFightSystem.GetSkillUpValue(S_HIGH_SCORE_RATE_UP) + 20;
}

bool BeatDevilsServer::IsCriticalScore() const
{
    return (arc4random() % 100) < GetHightScoreParam();
}

int64_t BeatDevilsServer::GetRoundScore(int diamondScore,
                                        int diamondCount,
                                        int stageParam,
                                        int beatDevilCount,
                                        int beatDevilParam,
                                        int playerWinCombo,
                                        int playerWinParam,
                                        int turnCount,
                                        bool isCriticalScore)
{
    int64_t baseScore = (diamondScore * diamondCount * stageParam)
    * (1 + beatDevilCount + beatDevilParam + (playerWinCombo <= 6 ? playerWinCombo : 6) * playerWinParam * (float)turnCount / 6.0f);
    
    return baseScore * (isCriticalScore ? 1.5f : 1.0f);
}

RandomDiamondParam BeatDevilsServer::GetRandomDiamondParam()
{
    if (mBeatDevilsModel < BeatDevilsModelNormal || mBeatDevilsModel >= BeatDevilsModelMax)
    {
        return (RandomDiamondParam){100};
    }
    
    const DStageInfo *info = GetStageInfo(GetCurrentStage() - 1);
    RandomDiamondParam param =
    {
        100 - info->reversePercent[mBeatDevilsModel] - info->starPercent[mBeatDevilsModel] - info->box1Percent[mBeatDevilsModel] - info->box2Percent[mBeatDevilsModel],
        info->reversePercent[mBeatDevilsModel],
        info->starPercent[mBeatDevilsModel],
        info->box1Percent[mBeatDevilsModel],
        info->box2Percent[mBeatDevilsModel],
    };
    
    return param;
}

#pragma mark -
#pragma mark IRoundManagerDelegate

void BeatDevilsServer::OnAddPlayerRoshambo(Roshambo roshambo)
{
    if (m_delegate != NULL)
    {
        m_delegate->OnAddPlayerRoshambo(roshambo);
    }
}

void BeatDevilsServer::OnAddNpcRoshambo(DiamondType diamondType)
{
    if (m_delegate != NULL)
    {
        m_delegate->OnAddNpcRoshambo(diamondType);
    }
}

void BeatDevilsServer::OnPlayerRoshamboFull()
{
    if (IsRoundStart())
    {
        mFightSystem.OnAllTurnEnd();
    }
}

void BeatDevilsServer::OnPlayerVsNpc(RoshamboResult result)
{
    mFightSystem.AddRoshamboResult(result);
}

void BeatDevilsServer::OnRemoveFirstDiamond()
{
    if (m_delegate != NULL)
    {
        m_delegate->OnRemoveFirstDiamond();
    }
}

void BeatDevilsServer::OnChangeDiamondToSame(DiamondType sameDiamond, int count)
{
    if (m_delegate != NULL)
    {
        m_delegate->OnUseMagicSkill(sameDiamond, count);
    }
}

void BeatDevilsServer::OnBoomFirstDiamond()
{
    if (m_delegate != NULL)
    {
        m_delegate->OnBoomFirstDiamond();
    }
}

void BeatDevilsServer::OnBreakBox(DiamondType changeDiamondType)
{
    if (m_delegate != NULL)
    {
        m_delegate->OnBreakBox(changeDiamondType);
    }
}

#pragma mark -
#pragma mark IFightSystemDelegate

// 回合判定回调
void BeatDevilsServer::OnAddFightSystemRoshamboResult(RoshamboResult result)
{
    if (result == RoshamboResultWin)
    {
        AddScore(10, ScoreTypeNormal);
    }
    
    if (m_delegate != NULL)
    {
        m_delegate->OnPlayerVSNpc(result);
    }
}

// 攻击回调
void BeatDevilsServer::OnPlayerFightNpc(DDamageContext damageContext)
{
    SetIsRoundStart(false);
    
    bool isCriticalScore = IsCriticalScore();
    
    int roundScore = GetRoundScore(10,
                                   GetCurrentRoundDiamondCount(),
                                   pow(GetCurrentStage(), 1.2f),
                                   damageContext.attackCount,
                                   5,
                                   mFightSystem.GetPlayerWinCombo(),
                                   2,
                                   GetCurrentRound(),
                                   isCriticalScore);
    AddScore(roundScore, isCriticalScore ? ScoreTypeCritical : ScoreTypeNotCritical);
    
    if (m_delegate != NULL)
    {
        m_delegate->OnPlayerFightNpc(damageContext);
    }
}

void BeatDevilsServer::OnNpcFightPlayer(DDamageContext damageContext)
{
    SetIsRoundStart(false);
    
    if (m_delegate != NULL)
    {
        m_delegate->OnRemoveAllDiamondWithWrong();
        m_delegate->OnNpcFightPlayer(damageContext);
    }
}

// 玩家被击倒或npc被击倒
void BeatDevilsServer::OnPlayerDown()
{
    SetIsStageStart(false);
    
    if (m_delegate != NULL)
    {
        m_delegate->OnStagePlayerLose();
    }
}

void BeatDevilsServer::OnNpcDown()
{
    SetIsStageStart(false);
    
    if (m_delegate != NULL)
    {
        m_delegate->OnStagePlayerWin();
        
        if (GetCurrentStage() == GetMaxStageCount())
        {
            m_delegate->OnStageClear();
        }
    }
}

// 技能相关回调
void BeatDevilsServer::OnSkillCountChanged(SkillCode skillCode, int skillCount)
{
    if (m_delegate != NULL)
    {
        m_delegate->OnSkillCountChanged(skillCode, skillCount);
    }
}

void BeatDevilsServer::OnUseSkillFreezeTime(float freezeTime)
{
    SetFreezeTime(freezeTime);
}

void BeatDevilsServer::OnUseSkillMagic(int magicCount)
{
    mRoundManager.ChangeRoshamboToSame(magicCount);
}

void BeatDevilsServer::OnUseSkillBoom(int boomCount)
{
    SetFreezeTime(boomCount * BOOM_TIME);
    
    mBoomCount += boomCount;
}

// 信息改变函数
void BeatDevilsServer::OnFuryChanged(int fury)
{
    if (m_delegate != NULL)
    {
        m_delegate->OnFuryChanged(fury);
    }
}

void BeatDevilsServer::OnHitsChanged(int hits)
{
    if (m_delegate != NULL)
    {
        m_delegate->OnHitsChanged(hits);
    }
}

#pragma mark -
#pragma mark 公共函数

IBeatDevilsServer *CreateBeatDevilsServer(IBeatDevilsServerDelegate *delegate)
{
    return new BeatDevilsServer(delegate);
}

void DeleteBeatDevilsServer(IBeatDevilsServer *server)
{
    delete server;
}

int GetSkillPrice(SkillCode skillCode)
{
    static int SKILL_PRICE[S_MAX_SKILL] = 
    {
        400,    //S_ATTACK_UP
        500,    //S_DEFENSE_UP
        350,    //S_MAX_FURY_UP
        200,    //S_HIGH_SCORE_RATE_UP
        500,    //S_FREEZE_TIME_UP
        500,    //S_CRITICAL_RATE_UP
        400,    //S_MAGIC_UP
        450,    //S_BOOM_UP
        
        300,     //S_RECOVER_FURY
        500,     //S_RECOVER_HEALTH
        150,     //S_RESIST_MISTAKE
        
        0,      //S_SKILL_FREEZE_TIME,            // 暂停道具
        0,      //S_SKILL_MAGIC,                  // 魔棒道具
        0,      //S_SKILL_BOOM,                   // 炸弹道具
    };
    
    if (skillCode >= S_MAX_SKILL || skillCode < S_ATTACK_UP)
    {
        return 0;
    }
    
    return SKILL_PRICE[skillCode];
}