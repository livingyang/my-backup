//
//  csvParser.h
//  study_CSV
//
//  Created by 青宝 中 on 11-11-28.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#ifndef study_CSV_csvParser_h
#define study_CSV_csvParser_h

#include <vector>
#include <string>

using std::string;

typedef std::vector<string> CSV_LINE;
typedef std::vector<CSV_LINE> CSV_RECORDS;

#ifdef __cplusplus
extern "C" {
#endif
    
void csvline_populate(CSV_LINE &record, const string& line, char delimiter);

void csv_populate(CSV_RECORDS &records, const char* fileName, char delimiter);

void print_csv_line(CSV_LINE &csvLine);

void print_csv_records(CSV_RECORDS &records);
    
std::vector<string> splitEx(const string& src, string sep);
    
string& trim(string &str);

#ifdef __cplusplus
}
#endif

#endif
