//
//  IBeatDevilsServer.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-3.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#ifndef BeatDevils_IBeatDevilsServer_h
#define BeatDevils_IBeatDevilsServer_h

#include "BeatDevilsDef.h"

struct IBeatDevilsServer
{
    // 猜拳操作函数
    virtual void AddPlayerRoshambo(Roshambo roshambo) = 0;
    virtual int GetNpcDiamondCount() = 0;
    
    // 时间相关函数
    virtual void RoundStep(float dTime) = 0;
    
    // 关卡信息管理
    virtual bool LoadStageInfo(const char *filePath) = 0;
    virtual const DStageInfo *GetStageInfo(int stageIndex) const = 0;
    
    virtual BeatDevilsGameData GetGameData() const = 0;
    virtual void SetGameData(BeatDevilsGameData &gameData) = 0;
    
    // 开始时，调用LoadStageInfo读取信息，随后每个关卡调用StartNextStage进行游戏
    virtual void ResetBeatDevilsServer(BeatDevilsModel model) = 0;
    virtual void StartNextStage() = 0;
    virtual bool IsStageStart() = 0;
    
    virtual int GetCurrentStage() = 0;
    virtual int GetMaxStageCount() = 0;
    
    virtual void StartNextRound() = 0;
    virtual bool IsRoundStart() = 0;
    
    // 获取玩家和npc信息
    virtual int GetCurPlayerHP() const = 0;
    virtual DRoleProperty GetPlayerPropFromSkill() const = 0;
    virtual int GetCurNpcHP() const = 0;
    virtual int GetMaxNpcHP() const = 0;
    
    // 购买技能接口
    virtual void SetMoney(int money) = 0;
    virtual int GetMoney() const = 0;
    virtual void BuySkill(SkillCode skillCode) = 0;
    
    // 技能接口
    virtual int GetMaxFury() const = 0;
    virtual void UseSkill(SkillCode skillCode) = 0;
    virtual void SetSkillCount(SkillCode skillCode, int count) = 0;
    virtual int GetSkillCount(SkillCode skillCode) const = 0;
    
    // 分数接口
    virtual int64_t GetScore() const = 0;
};

struct IBeatDevilsServerDelegate
{
    virtual void OnAddNpcRoshambo(DiamondType diamondType) = 0;
    virtual void OnAddPlayerRoshambo(Roshambo roshambo) = 0;
    virtual void OnPlayerVSNpc(RoshamboResult result) = 0;
    virtual void OnRemoveFirstDiamond() = 0;
    virtual void OnRemoveAllDiamondWithWrong() = 0;
    virtual void OnBreakBox(DiamondType changeType) = 0;
    
    // 单局函数
    virtual void OnRoundStep(float roundTime, float totalTime) = 0;
    virtual void OnRoundTimeOver() = 0;
    virtual void OnNpcFightPlayer(DDamageContext damageContext) = 0;
    virtual void OnPlayerFightNpc(DDamageContext damageContext) = 0;
    
    virtual void OnStageBegin() = 0;
    virtual void OnStageEnd() = 0;
    virtual void OnRoundBegin() = 0;
    virtual void OnRoundEnd() = 0;
    
    virtual void OnStagePlayerLose() = 0;
    virtual void OnStagePlayerWin() = 0;
    virtual void OnStageClear() = 0;
    
    // 各种信息改变相关
    virtual void OnSkillCountChanged(SkillCode skillCode, int skillCount) = 0;
    virtual void OnMoneyChanged(int money) = 0;
    virtual void OnHitsChanged(int hits) = 0;
    virtual void OnFuryChanged(int fury) = 0;
    virtual void OnAddScore(int addScore, ScoreType scoreType) = 0;
    
    // 技能相关
    virtual void OnFreezeTimeStart() = 0;
    virtual void OnFreezeTimeStop() = 0;
    virtual void OnFreezeTimeStep(float freezeTime, float totalFreezeTime) = 0;
    virtual void OnUseMagicSkill(Roshambo sameRoshambo, int count) = 0;
    virtual void OnBoomFirstDiamond() = 0;
};

extern IBeatDevilsServer *CreateBeatDevilsServer(IBeatDevilsServerDelegate *delegate);
extern void DeleteBeatDevilsServer(IBeatDevilsServer *server);

#endif
