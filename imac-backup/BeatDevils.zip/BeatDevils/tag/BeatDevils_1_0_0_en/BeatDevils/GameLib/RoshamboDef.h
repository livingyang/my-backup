//
//  RoshamboDef.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-11-21.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#ifndef BeatDevils_RoshamboDef_h
#define BeatDevils_RoshamboDef_h

#include <stdlib.h>

enum
{
    RoshamboInvalid = -1,
    RoshamboRock,
    RoshamboPaper,
    RoshamboScissors,
};
typedef short Roshambo;

enum
{
    RoshamboResultInvalid = -1,
    RoshamboResultWin,
    RoshamboResultLost,
    RoshamboResultDraw,
};
typedef short RoshamboResult;

static inline
RoshamboResult GetRoshamboResult(Roshambo r1, Roshambo r2)
{
    if (r1 == r2)
    {
        return RoshamboResultDraw;
    }
    
    if ((r1 == RoshamboRock && r2 == RoshamboScissors)
        || (r1 == RoshamboScissors && r2 == RoshamboPaper)
        || (r1 == RoshamboPaper && r2 == RoshamboRock))
    {
        return RoshamboResultWin;
    }
    else
    {
        return RoshamboResultLost;
    }
}

static inline
Roshambo GetRandomRoshambo()
{
    int random = arc4random() % 3;
    
    Roshambo roshambo;
    if (random == 0)
    {
        roshambo = RoshamboRock;
    }
    else if (random == 1)
    {
        roshambo = RoshamboScissors;
    }
    else
    {
        roshambo = RoshamboPaper;
    }
    
    return roshambo;
}

static inline
Roshambo GetRoshamboFromResult(Roshambo defenseRoshambo, RoshamboResult result)
{
    if (defenseRoshambo == RoshamboInvalid || result == RoshamboResultInvalid)
    {
        return RoshamboInvalid;
    }
    
    if (GetRoshamboResult(RoshamboPaper, defenseRoshambo) == result)
    {
        return RoshamboPaper;
    }
    else if (GetRoshamboResult(RoshamboRock, defenseRoshambo) == result)
    {
        return RoshamboRock;
    }
    else
    {
        return RoshamboScissors;
    }
}

#endif
