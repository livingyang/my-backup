//
//  csvParser.cpp
//  study_CSV
//
//  Created by 青宝 中 on 11-11-28.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#include <iostream>
using std::cout;
using std::endl;

#include <fstream>
using std::ifstream;

#include <algorithm>
using std::for_each;

#include "csvParser.h"

void csvline_populate(CSV_LINE &record, const string& line, char delimiter)
{
    int linepos=0;
    int inquotes=false;
    char c;
    //int i;
    int linemax=line.length();
    string curstring;
    record.clear();
    
    while(line[linepos]!=0 && linepos < linemax)
    {
        
        c = line[linepos];
        
        if (!inquotes && curstring.length()==0 && c=='"')
        {
            //beginquotechar
            inquotes=true;
        }
        else if (inquotes && c=='"')
        {
            //quotechar
            if ( (linepos+1 <linemax) && (line[linepos+1]=='"') ) 
            {
                //encountered 2 double quotes in a row (resolves to 1 double quote)
                curstring.push_back(c);
                linepos++;
            }
            else
            {
                //endquotechar
                inquotes=false; 
            }
        }
        else if (!inquotes && c==delimiter)
        {
            //end of field
            record.push_back( curstring );
            curstring="";
        }
        else if (!inquotes && (c=='\r' || c=='\n') )
        {
            record.push_back( curstring );
            return;
        }
        else
        {
            curstring.push_back(c);
        }
        linepos++;
    }
    record.push_back( curstring );
    return;
}

void csv_populate(CSV_RECORDS &records, const char* fileName, char delimiter)
{
    records.clear();
    
    CSV_LINE row;
    string line;
    ifstream in(fileName);
    if (in.fail())
    {
        cout << "File not found" <<endl;
        return;
    }
    
    while(getline(in, line)  && in.good() )
    {
        csvline_populate(row, line, delimiter);
        
        records.push_back(row);
    }
    in.close();
}

void print_csv_line(CSV_LINE &csvLine)
{
    for(int i=0, leng=csvLine.size(); i<leng; i++)
    {
        cout << csvLine[i] << "\t";
    }
    cout << endl;
}

void print_csv_records(CSV_RECORDS &records)
{
    std::for_each(records.begin(), records.end(), print_csv_line);
}

std::vector<string> splitEx(const string& src, string sep)  
{  
    std::vector<string> strs;  
    
    int seplen = sep.size();//分割字符串的长度,这样就可以支持如“,,”多字符串的分隔符  
    int lastpos= 0, index = -1;  
    while (-1 != (index = src.find(sep,lastpos)))  
    {   
        strs.push_back(src.substr(lastpos,index - lastpos));  
        lastpos= index + seplen;  
    }  
    string laststr = src.substr(lastpos);//截取最后一个分隔符后的内容  
    if (!laststr.empty())  
        strs.push_back(laststr);//如果最后一个分隔符后还有内容就入队  
    return strs;  
}

string& trim(string &str)
{  
    if (str.empty())  
    {  
        return str;  
    }  
    str.erase(0,str.find_first_not_of(" ")); //去除左边空格  
    str.erase(str.find_last_not_of(" ") + 1);//去除右边空格  
    return str;  
}

