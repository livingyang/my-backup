/*
 *  FightSystem.h
 *  BeatDevils
 *
 *  Created by 青宝 中 on 11-12-3.
 *  Copyright 2011年 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef BeatDevils_FightSystem_cpp
#define BeatDevils_FightSystem_cpp

#include "BeatDevilsDef.h"
#include <map>

struct IFightSystemDelegate
{
    // 回合判定回调
    virtual void OnAddFightSystemRoshamboResult(RoshamboResult result) = 0;
    
    // 攻击回调
    virtual void OnPlayerFightNpc(DDamageContext damageContext) = 0;
    virtual void OnNpcFightPlayer(DDamageContext damageContext) = 0;
    
    // 玩家被击倒或npc被击倒
    virtual void OnPlayerDown() = 0;
    virtual void OnNpcDown() = 0;
    
    // 技能相关回调
    virtual void OnSkillCountChanged(SkillCode skillCode, int skillCount) = 0;
    virtual void OnUseSkillFreezeTime(float freezeTime) = 0;
    virtual void OnUseSkillMagic(int magicCount) = 0;
    virtual void OnUseSkillBoom(int boomCount) = 0;
    
    // 信息改变函数
    virtual void OnFuryChanged(int fury) = 0;
    virtual void OnHitsChanged(int hits) = 0;
};

class FightSystem
{
public:
    FightSystem(IFightSystemDelegate *delegate);
    virtual ~FightSystem();
    
    void ResetFightSystem();
    
    // 角色设置
    void SetPlayerProp(DRoleProperty playerProp);
    DRoleProperty GetNpcProp() const;
    void SetNpcProp(DRoleProperty npcProp);
    DRoleProperty GetPlayerPropFromSkill() const;
    int GetCurPlayerHP() const;
    int GetCurNpcHP() const;
    
    // 回合结束时的操作
    void AddRoshamboResult(RoshamboResult result);
    void OnAllTurnEnd();
    void OnRoundTimeOver();
    
    // 怒气相关
    int GetMaxFury() const;
    int GetFury() const;
    void SetSkillCostFury(SkillCode skillCode, int costFury);
    int GetSkillCostFury(SkillCode skillCode) const;
    
    // 技能相关
    bool UseSkill(SkillCode skillCode);
    void SetSkillCount(SkillCode skillCode, int count);
    int GetSkillCount(SkillCode skillCode) const;
    void SetSkillUpValue(SkillCode skillCode, int upValue);
    int GetSkillUpValue(SkillCode skillCode) const;
    
    // 暴击率相关
    int GetBaseCriticalRate() const;
    void SetBaseCriticalRate(int baseCriticalRate);
    int GetCriticalRate() const;
    
    // 连击相关
    int GetHits() const;
    
    // 连胜相关
    int GetPlayerWinCombo() const;

private:
    void PlayerFightNpc();
    void NpcFightPlayer();
    
    void SetFury(int fury);
    void SetHits(int hits);
    void SetPlayerWinCombo(int playerWinCombo);
    
    void SetCurPlayerHP(int playerHP);
    void SetCurNpcHP(int npcHP);
    
    AttackModel GetPlayerAttackModel() const;
    int GetPlayerAttackCount() const;
    int GetNpcAttackCount() const;
    int GetDamage(const DRoleProperty &attacker, const DRoleProperty &defenser, int attackCount) const;
    int GetIncreaseFury() const;
    
    bool UseFuryRecover();
    bool UseHealthRecover();
    bool UseResistMistake();
    
    bool UseFreezeTime();
    bool UseMagic();
    bool UseBoom();
    void UpdateFurySkillCount(SkillCode skillCode);
    
    int GetFreezeTimeFromSkill() const;
    int GetMagicCountFromSkill() const;
    int GetBoomCountFromSkill() const;
    
private:
    IFightSystemDelegate *m_FightSystemDelegate;
    
    DRoleProperty mPlayerProp;
    DRoleProperty mNpcProp;
    int mCurPlayerHP;
    int mCurNpcHP;
    
    int mHits;
    int mPlayerWinCombo;
    int mFury;
    
    int mBaseCriticalRate;
    
    // 技能与其对应消耗的怒气
    std::map<SkillCode, int /*cost fury*/> mSkillCostFuryMap;
    
    // 技能与其对应的等级或者消耗次数
    std::map<SkillCode, int /*count*/> mSkillCountMap;
    
    // 技能与其对应的增加数值
    std::map<SkillCode, int /*up value*/> mSkillUpValueMap;
    
    // 技能与其对应的处理函数
    typedef bool (FightSystem::*SkillHandleFuc)();
    std::map<SkillCode, SkillHandleFuc> mSkillHandleList;
};

#endif //BeatDevils_FightSystem_cpp