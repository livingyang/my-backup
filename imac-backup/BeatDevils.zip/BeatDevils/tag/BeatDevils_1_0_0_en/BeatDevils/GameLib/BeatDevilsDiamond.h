//
//  BeatDevilsDiamond.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-20.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#ifndef BeatDevils_BeatDevilsDiamond_h
#define BeatDevils_BeatDevilsDiamond_h

#include "RoshamboDef.h"

enum
{
    DiamondTypeInvalid = -1,
    
    DiamondTypeNormalRock,
    DiamondTypeNormalPaper,
    DiamondTypeNormalScissors,
    
    DiamondTypeReverseRock,
    DiamondTypeReversePaper,
    DiamondTypeReverseScissors,
    
    DiamondTypeStar,
    
    DiamondTypeBox1Rock,
    DiamondTypeBox1Paper,
    DiamondTypeBox1Scissors,
    
    DiamondTypeBox2Rock,
    DiamondTypeBox2Paper,
    DiamondTypeBox2Scissors,
    
    DiamondTypeMax,
};
typedef int DiamondType;

static const Roshambo DiamondTypeRoshambo[DiamondTypeMax] = 
{
    RoshamboRock, //DiamondTypeNormalRock,
    RoshamboPaper, //DiamondTypeNormalPaper,
    RoshamboScissors, //DiamondTypeNormalScissors,
    
    RoshamboPaper, //DiamondTypeReverseRock,
    RoshamboScissors, //DiamondTypeReversePaper,
    RoshamboRock, //DiamondTypeReverseScissors,
    
    RoshamboInvalid, //DiamondTypeStar,
    
    RoshamboRock, //DiamondTypeBox1Rock,
    RoshamboPaper, //DiamondTypeBox1Paper,
    RoshamboScissors, //DiamondTypeBox1Scissors,
    
    RoshamboRock, //DiamondTypeBox2Rock,
    RoshamboPaper, //DiamondTypeBox2Paper,
    RoshamboScissors, //DiamondTypeBox2Scissors,
};

// roshambo 攻击 diamond 之后，产生的结果
static inline
RoshamboResult GetDiamondResult(Roshambo roshambo, DiamondType diamond)
{
    if (diamond == DiamondTypeInvalid)
    {
        return RoshamboInvalid;
    }
    
    if (diamond == DiamondTypeStar)
    {
        return RoshamboResultWin;
    }
    
    return GetRoshamboResult(roshambo, DiamondTypeRoshambo[diamond]);
}

// 获取随机的类型

static inline
DiamondType GetRandomDiamond(DiamondType numArray[], int numCount)
{
    if (numArray == NULL || numCount <= 0)
    {
        return -1;
    }
    
    return numArray[arc4random() % numCount];
}

static inline
bool IsNormalDiamond(DiamondType diamondType)
{
    return (diamondType == DiamondTypeNormalPaper
            || diamondType == DiamondTypeNormalRock
            || diamondType == DiamondTypeNormalScissors);
}

static inline
bool IsReverseDiamond(DiamondType diamondType)
{
    return (diamondType == DiamondTypeReversePaper
            || diamondType == DiamondTypeReverseRock
            || diamondType == DiamondTypeReverseScissors);
}

static inline
bool IsBox1Diamond(DiamondType diamondType)
{
    return (diamondType == DiamondTypeBox1Paper
            || diamondType == DiamondTypeBox1Rock
            || diamondType == DiamondTypeBox1Scissors);
}

static inline
bool IsBox2Diamond(DiamondType diamondType)
{
    return (diamondType == DiamondTypeBox2Paper
            || diamondType == DiamondTypeBox2Rock
            || diamondType == DiamondTypeBox2Scissors);
}

// 根据结果和被攻击方块类型，获取攻击类型
static inline
Roshambo GetRoshamboFromDiamondTypeResult(DiamondType defenseDiamondType, RoshamboResult result)
{
    if (defenseDiamondType == DiamondTypeStar && result == RoshamboResultWin)
    {
        return RoshamboScissors;
    }
    
    return GetRoshamboFromResult(DiamondTypeRoshambo[defenseDiamondType], result);
}

static inline
bool GetSelectionCount(const int selectionPer[],
                       int outSelectionCount[],
                       const int arrayCount,
                       const int totalCount)
{
    // 首先检查是否有误
    int totalPer = 0;
    for (int i = 0; i < arrayCount; ++i)
    {
        if (selectionPer[i] < 0)
        {
            return false;
        }
        
        totalPer += selectionPer[i];
    }
    
    if (totalPer != 100)
    {
        return false;
    }
    
    // 最后生成数量
    // 1 根据概率生成数量
    for (int i = 0; i < arrayCount; ++i)
    {
        outSelectionCount[i] = selectionPer[i] * totalCount / 100;
    }
    
    // 2 确定剩余数量的归属
    int surplusCount = totalCount;
    for (int i = 0; i < arrayCount; ++i)
    {
        surplusCount -= outSelectionCount[i];
    }
    
    if (surplusCount > 0)
    {
        int maxPerIndex = 0;
        for (int i = 1; i < arrayCount; ++i)
        {
            maxPerIndex = (selectionPer[maxPerIndex] > selectionPer[i]) ? maxPerIndex : i;
        }
        
        outSelectionCount[maxPerIndex] += surplusCount;
    }
    
    return true;
}

#endif
