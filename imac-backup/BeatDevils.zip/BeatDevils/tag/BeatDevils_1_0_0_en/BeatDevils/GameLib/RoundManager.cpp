/*
 *  RoundManager.cpp
 *  BeatDevils
 *
 *  Created by 青宝 中 on 11-11-29.
 *  Copyright 2011年 __MyCompanyName__. All rights reserved.
 *
 */

#include "RoundManager.h"
#include <algorithm>

RoundManager::RoundManager(IRoundManagerDelegate *delegate):
m_delegate(delegate)
{
    mBox1OpenDiamondList.push_back(DiamondTypeNormalRock);
    mBox1OpenDiamondList.push_back(DiamondTypeNormalPaper);
    mBox1OpenDiamondList.push_back(DiamondTypeNormalScissors);
    
    mBox2OpenDiamondList.push_back(DiamondTypeNormalRock);
    mBox2OpenDiamondList.push_back(DiamondTypeNormalPaper);
    mBox2OpenDiamondList.push_back(DiamondTypeNormalScissors);
    mBox2OpenDiamondList.push_back(DiamondTypeReverseRock);
    mBox2OpenDiamondList.push_back(DiamondTypeReversePaper);
    mBox2OpenDiamondList.push_back(DiamondTypeReverseScissors);
}

RoundManager::~RoundManager()
{
}

bool RoundManager::Restart(DiamondType npcDiamondArray[], int npcDiamondCount)
{
    if (npcDiamondCount <= 0)
    {
        printf("RoundManager::Restart param error!");
        return false;
    }
    
    mNpcDiamondList.clear();
    mPlayerRoshamboList.clear();
    
    for (int i = 0; i < npcDiamondCount; ++i)
    {
        AddNpcDiamond(npcDiamondArray[i]);
    }
    
    return true;
}

bool RoundManager::Restart(int npcDiamondCount, RandomDiamondParam param)
{
    if (npcDiamondCount <= 0)
    {
        printf("RoundManager::Restart param error!");
        return false;
    }
    
    mNpcDiamondList.clear();
    mPlayerRoshamboList.clear();
    
    int diamondPer[5] =
    {
        param.normalPercent,
        param.reversePercent,
        param.box1Percent,
        param.box2Percent,
        param.starPercent,
    };
    
    int diamondCount[5];
    
    if (GetSelectionCount(diamondPer, diamondCount, 5, npcDiamondCount) == false)
    {
        printf("RoundManager::Restart param error!");
        return false;
    }
    
    std::vector<CreateDiamondFuc> createFunc;
    for (int i = 0; i < diamondCount[0]; ++i)
    {
        createFunc.push_back(&RoundManager::AddNormalDiamond);
    }
    for (int i = 0; i < diamondCount[1]; ++i)
    {
        createFunc.push_back(&RoundManager::AddReverseDiamond);
    }
    for (int i = 0; i < diamondCount[2]; ++i)
    {
        createFunc.push_back(&RoundManager::AddBox1Diamond);
    }
    for (int i = 0; i < diamondCount[3]; ++i)
    {
        createFunc.push_back(&RoundManager::AddBox2Diamond);
    }
    for (int i = 0; i < diamondCount[4]; ++i)
    {
        createFunc.push_back(&RoundManager::AddStarDiamond);
    }
    
    std::random_shuffle(createFunc.begin(), createFunc.end());
    
    for (int i = 0; i < createFunc.size(); ++i)
    {
        (this->*createFunc[i])();
    }
    
    return true;
}

void RoundManager::ChangeRoshamboToSame(int count)
{
    if (GetCurNpcDiamondIndex() >= mNpcDiamondList.size())
    {
        return;
    }
    
    count = (mNpcDiamondList.size() - GetCurNpcDiamondIndex()) < count ? (mNpcDiamondList.size() - GetCurNpcDiamondIndex()) : count;
    
    for (int i = 0; i < count; ++i)
    {
        SetNpcDiamondAtIndex(GetCurNpcDiamond(), GetCurNpcDiamondIndex() + i);
    }
    
    if (m_delegate != NULL)
    {
        m_delegate->OnChangeDiamondToSame(GetCurNpcDiamond(), count);
    }
}

void RoundManager::AddPlayerRoshambo(Roshambo roshambo)
{
    if (GetNpcDiamondCount() <= 0)
    {
        return;
    }
    
    if (m_delegate != NULL)
    {
        m_delegate->OnAddPlayerRoshambo(roshambo);
        m_delegate->OnPlayerVsNpc(GetDiamondResult(roshambo, GetCurNpcDiamond()));
    }
    
    if (IsBox1Diamond(GetCurNpcDiamond()) || IsBox2Diamond(GetCurNpcDiamond()))
    {
        SetNpcDiamondAtIndex(IsBox1Diamond(GetCurNpcDiamond()) ? GetBox1OpenDiamond() : GetBox2OpenDiamond(),
                             GetCurNpcDiamondIndex());
        
        if (m_delegate != NULL)
        {
            m_delegate->OnBreakBox(GetCurNpcDiamond());
        }
    }
    else
    {
        mPlayerRoshamboList.push_back(roshambo);
        
        if (m_delegate != NULL)
        {
            m_delegate->OnRemoveFirstDiamond();
        }
    }
    
    if (m_delegate != NULL && GetNpcDiamondCount() == 0)
    {
        m_delegate->OnPlayerRoshamboFull();
    }
}

void RoundManager::BoomOneDiamond()
{
    if (GetNpcDiamondCount() <= 0)
    {
        return;
    }
    
    mPlayerRoshamboList.push_back(RoshamboInvalid);
    
    if (m_delegate != NULL)
    {
        m_delegate->OnPlayerVsNpc(RoshamboResultWin);
        m_delegate->OnBoomFirstDiamond();
        
        if (GetNpcDiamondCount() == 0)
        {
            m_delegate->OnPlayerRoshamboFull();
        }
    }

}

void RoundManager::AddNpcDiamond(DiamondType diamond)
{
    mNpcDiamondList.push_back(diamond);
    
    if (m_delegate != NULL)
    {
        m_delegate->OnAddNpcRoshambo(diamond);
    }
}

int RoundManager::GetNpcDiamondCount() const
{
    return mNpcDiamondList.size() - mPlayerRoshamboList.size();
}

DiamondType RoundManager::GetCurNpcDiamond() const
{
    if (GetCurNpcDiamondIndex() >= mNpcDiamondList.size())
    {
        return RoshamboInvalid;
    }
    
    return mNpcDiamondList[GetCurNpcDiamondIndex()];
}

int RoundManager::GetCurNpcDiamondIndex() const
{
    return mPlayerRoshamboList.size();
}

void RoundManager::SetNpcDiamondAtIndex(DiamondType diamondType, int index)
{
    if (index < mNpcDiamondList.size())
    {
        mNpcDiamondList[index] = diamondType;
    }
}

void RoundManager::AddNormalDiamond()
{
    AddNpcDiamond(GetRandomDiamond((int [3]){DiamondTypeNormalRock, DiamondTypeNormalPaper, DiamondTypeNormalScissors}, 3));
}

void RoundManager::AddReverseDiamond()
{
    AddNpcDiamond(GetRandomDiamond((int [3]){DiamondTypeReverseRock, DiamondTypeReversePaper, DiamondTypeReverseScissors}, 3));
}

void RoundManager::AddStarDiamond()
{
    AddNpcDiamond(DiamondTypeStar);
}

void RoundManager::AddBox1Diamond()
{
    AddNpcDiamond(GetRandomDiamond((int [3]){DiamondTypeBox1Rock, DiamondTypeBox1Paper, DiamondTypeBox1Scissors}, 3));
}

void RoundManager::AddBox2Diamond()
{
    AddNpcDiamond(GetRandomDiamond((int [3]){DiamondTypeBox2Rock, DiamondTypeBox2Paper, DiamondTypeBox2Scissors}, 3));
}

DiamondType RoundManager::GetBox1OpenDiamond()
{
    return mBox1OpenDiamondList[arc4random() % mBox1OpenDiamondList.size()];
}

DiamondType RoundManager::GetBox2OpenDiamond()
{
    return mBox2OpenDiamondList[arc4random() % mBox2OpenDiamondList.size()];
}

void RoundManager::SetBox1OpenDiamondList(DiamondType diamondArray[], int diamondCount)
{
    if (diamondCount <= 0)
    {
        return;
    }
    
    mBox1OpenDiamondList.clear();
    
    for (int i = 0; i < diamondCount; ++i)
    {
        mBox1OpenDiamondList.push_back(diamondArray[i]);
    }
}

void RoundManager::SetBox2OpenDiamondList(DiamondType diamondArray[], int diamondCount)
{
    if (diamondCount <= 0)
    {
        return;
    }
    
    mBox2OpenDiamondList.clear();
    
    for (int i = 0; i < diamondCount; ++i)
    {
        mBox2OpenDiamondList.push_back(diamondArray[i]);
    }
}
