//
//  NpcAnimationManager.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-12.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface NpcAnimationManager : NSObject
{
    NSMutableArray *actionArray;
    
    CCSprite *animationSprite_;
}

@property (nonatomic, assign) CCSprite *animationSprite;

- (void)addSpriteAction:(NSString *)animationName
                 target:(id)target
               callback:(SEL)sel
                  delay:(ccTime)delay;

- (void)addSpriteAction:(NSString *)animationName
                  delay:(ccTime)delay;

- (void)pauseActions;
- (void)resumeActions;

- (void)cleanSpriteActions;

@end
