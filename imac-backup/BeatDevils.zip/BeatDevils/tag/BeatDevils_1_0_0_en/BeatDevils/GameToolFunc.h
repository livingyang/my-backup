//
//  GameToolFunc.h
//  BeatDevils
//
//  Created by 青宝 中 on 12-1-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BeatDevilsDef.h"
#import "cocos2d.h"

@interface GameToolFunc : NSObject

+ (void)SetGameModel:(BeatDevilsModel)model;
+ (BeatDevilsModel)GetGameModel;

+ (CCLabelAtlas *)getHitNumberLabel:(CCLabelTTF *)parentLabel
                        anchorPoint:(CGPoint)anchorPoint;

+ (CCLabelAtlas *)getUINumberLabel:(CCLabelTTF *)parentLabel
                       anchorPoint:(CGPoint)anchorPoint;

+ (CCLabelAtlas *)getScoreNumberLabel:(CCLabelTTF *)parentLabel
                          anchorPoint:(CGPoint)anchorPoint;

+ (CCLabelAtlas *)getStageNumberLabel:(CCLabelTTF *)parentLabel
                          anchorPoint:(CGPoint)anchorPoint;

+ (CCTexture2D *)getModelTexture:(BeatDevilsModel)model;

// 粒子效果相关

+ (void)removeParticle:(CCNode *)node;
+ (void)showSnow:(CCNode *)node;
+ (void)showRain:(CCNode *)node;
+ (void)showLeaf:(CCNode *)node;

@end
