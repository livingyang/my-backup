//
//  PlayerGuideLayer.h
//  BeatDevils
//
//  Created by 青宝 中 on 12-1-6.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class GameLayer;
@interface PlayerGuideLayer : CCLayer
{
    GameLayer *_gameLayer;
    
    NSMutableArray *guidePicArray;
    int curPicIndex;
}

@property (nonatomic, assign) CCSprite *sprGuide;
@property BOOL isSwallowTouch;

+ (BOOL)isGuided;
+ (PlayerGuideLayer *)layerWithGameLayer:(GameLayer *)gameLayer;
- (void)startGuide;

- (void)updateSkillButtonWithDiamondCount:(int)diamondCount;
- (void)updateSkillButtonWithRoundTime:(float)roundTime totalTime:(float)totalTime;
- (void)updateSkillButtonWithCurHp:(int)curHp maxHp:(int)maxHp;
- (void)updateSkillButtonWithFury:(int)fury;
- (void)clearFlashSkillButton;

@end
