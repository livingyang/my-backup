//
//  TimeSpriteBarManager.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-29.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "TimeSpriteBarManager.h"
#import "SimpleAudioEngine.h"

#define TAG_WARNING_ACTION (124)

const float RED_PER = (0.67f);

@implementation TimeSpriteBarManager

@synthesize normalPic, warningPic;

- (BOOL)isTimeWarning
{
    return [barSprite getActionByTag:TAG_WARNING_ACTION] != nil;
}

- (void)setTimeWarning:(BOOL)isWarning
{
    if (isWarning == self.isTimeWarning)
    {
        return;
    }
    
    if (isWarning)
    {
        CCAction *action = [CCRepeatForever actionWithAction:[CCBlink actionWithDuration:1 blinks:4]];
        action.tag = TAG_WARNING_ACTION;
        [barSprite runAction:action];
        
        [[SimpleAudioEngine sharedEngine] playEffect:@"warning.wav"];
    }
    else
    {
        [barSprite stopActionByTag:TAG_WARNING_ACTION];
        barSprite.visible = YES;
    }
    
    barSprite.texture = [[CCTextureCache sharedTextureCache]
                         addImage:isWarning ? self.warningPic : self.normalPic];
}

- (void)setFollowSprite:(CCSprite *)sprite
{
    followSprite = sprite;
    initFollowPoint = sprite.position;
}

- (void)increaseValue:(ccTime)dt
{
    if (curValue <= 0)
    {
        [[CCScheduler sharedScheduler] unscheduleSelector:@selector(increaseValue:)
                                                forTarget:self];
    }
    
    curValue -= maxValue * dt;
    curValue = (curValue > 0) ? curValue : 0;
    
    [self updateData];
}

- (void)setNormalPic:(NSString *)normalPicName
          warningPic:(NSString *)warningPicName
{
    self.normalPic = normalPicName;
    self.warningPic = warningPicName;
    
    barSprite.texture = [[CCTextureCache sharedTextureCache] addImage:self.normalPic];
}

- (void)recoverTime
{
    [[CCScheduler sharedScheduler] scheduleSelector:@selector(increaseValue:) forTarget:self interval:0 paused:NO];
}

- (void)updateData
{
    [super updateData];
    
    if (curValue <= RED_PER * maxValue)
    {
        //barSprite.color = ccYELLOW;
        
        [self setTimeWarning:NO];
    }
    else
    {
        //barSprite.color = ccRED;
        
        [self setTimeWarning:YES];
    }
    
    // 更新followSprite位置
    float dWidth = barSprite.textureRect.size.width;
    followSprite.position = ccp(initFollowPoint.x - dWidth, initFollowPoint.y);
}

- (void)setBarSprite:(CCSprite *)sprite decreaseDirection:(DecreaseDirection)d
{
    //sprite.color = ccYELLOW;
    [super setBarSprite:sprite decreaseDirection:d];
}

- (void)dealloc
{
    self.normalPic = nil;
    self.warningPic = nil;
    
	[super dealloc];
}

@end
