//
//  SelectModelLayer.h
//  BeatDevils
//
//  Created by 青宝 中 on 12-1-4.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class CCMenuItemButton;
@interface SelectModelLayer : CCLayer
{
}

@property (nonatomic, assign) CCLayer *modelInfoLayer;

@property BOOL isBlock;

+(CCScene *) scene;

@end
