//
//  SpriteBarManager.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-2.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "SpriteBarManager.h"

/* DecreaseDirectionPoint
    1
    ^
    |
-1----->1
    |
    -1
*/

const CGPoint DecreaseDirectionPoint[kMaxDecreaseDirection] =
{
    {-1, 0}, //kDecreaseFromLeft = 0,
    {1, 0},  //kDecreaseFromRight,
    {0, 1},  //kDecreaseFromTop,
    {0, -1}, //kDecreaseFromBottom,
};

@implementation SpriteBarManager

@synthesize labBar;

- (id) init
{
	self = [super init];
	if (self != nil)
	{
	}
	return self;
}

// 必须重构
- (void)updateData
{
    if (maxValue <= 0)
    {
        return;
    }
    
    CGRect rect = barSprite.textureRect;
    
    if (direction == kDecreaseFromLeft)
    {
        rect.size.width = (barSprite.texture.contentSize.width * ((float)curValue / maxValue));
        
        float dWidth = barSprite.texture.contentSize.width - rect.size.width;
        
        barSprite.position = ccpAdd(initPosition, ccp(dWidth / 2, 0));
        
        rect.origin = ccp(dWidth, 0);
    }
    else if (direction == kDecreaseFromRight)
    {
        rect.size.width = (barSprite.texture.contentSize.width * ((float)curValue / maxValue));
        
        float dWidth = barSprite.texture.contentSize.width - rect.size.width;
        
        barSprite.position = ccpSub(initPosition, ccp(dWidth / 2, 0)); 
    }
    else if (direction == kDecreaseFromTop)
    {
        rect.size.height = (barSprite.texture.contentSize.height * ((float)curValue / maxValue));
        
        float dHeight = barSprite.texture.contentSize.height - rect.size.height;
        
        barSprite.position = ccpSub(initPosition, ccp(0, dHeight / 2));
        
        rect.origin = ccp(0, dHeight);
    }
    else if (direction == kDecreaseFromBottom)
    {
        rect.size.height = (barSprite.texture.contentSize.height * ((float)curValue / maxValue));
        
        float dHeight = barSprite.texture.contentSize.height - rect.size.height;
        
        barSprite.position = ccpAdd(initPosition, ccp(0, dHeight / 2)); 
    }
    
    barSprite.textureRect = rect;
    
    if (self.labBar != nil)
    {
        self.labBar.string = [NSString stringWithFormat:@"%.0f/%.0f", curValue, maxValue];
    }
}

- (void)setBarSprite:(CCSprite *)sprite decreaseDirection:(DecreaseDirection)d
{
    barSprite = sprite;
    initPosition = sprite.position;
    direction = d;
}

- (void)setCurValue:(float)value
{
    if (value < 0)
    {
        value = 0;
    }
    
    curValue = value;
    
    [self updateData];
}

- (void)updateValueCallback:(NSNumber *)number
{
    [self addDamage:[number floatValue]];
}

- (void)updateValue:(float)value count:(int)count withDelay:(float)delay interval:(float)interval
{
    if (barSprite == nil)
    {
        return;
    }
    
    NSMutableArray *actionArray = [NSMutableArray array];
    [actionArray addObject:[CCDelayTime actionWithDuration:delay]];
    for (int i = 0; i < count; ++i)
    {
        [actionArray addObject:[CCCallFuncO actionWithTarget:self
                                                    selector:@selector(updateValueCallback:)
                                                      object:[NSNumber numberWithFloat:value]]];
        [actionArray addObject:[CCDelayTime actionWithDuration:interval]];
    }

    [barSprite runAction:[CCSequence actionsWithArray:actionArray]];
}

- (void)clearUpdateValueAction
{
    [barSprite stopAllActions];
}

- (void)addDamage:(float)damage
{
    [self setCurValue:curValue - damage];
}

- (void)setMaxValue:(float)value
{
    maxValue = value;
    
    [self updateData];
}

@end
