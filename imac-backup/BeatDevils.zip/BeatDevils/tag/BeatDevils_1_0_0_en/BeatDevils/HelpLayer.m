//
//  HelpLayer.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-15.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "HelpLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCMenuItemButton.h"

const NSString *HelpImgDir = @"UI/5-help";

@implementation HelpLayer

@synthesize imgHelpArray, sprHelp, btnPrev, btnNext;

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	[scene addChild:[self node]];
	
	return scene;
}

- (void)setHelpImageIndex:(int)index
{
    if (index < 0 || index >= imgHelpArray.count)
    {
        return;
    }
    
    if (index == 0)
    {
        self.btnPrev.visible = NO;
        self.btnNext.visible = YES;
    }
    else if (index == imgHelpArray.count - 1)
    {
        self.btnPrev.visible = YES;
        self.btnNext.visible = NO;
    }
    else
    {
        self.btnPrev.visible = YES;
        self.btnNext.visible = YES;
    }
    
    self.sprHelp.texture = [imgHelpArray objectAtIndex:index];
    self.sprHelp.textureRect = (CGRect){{0, 0}, self.sprHelp.texture.contentSize};
}

- (void)onCloseClick:(id)sender
{
    [[CCDirector sharedDirector] popScene];
}

- (void)onPrevClick:(id)sender
{
    int index = [imgHelpArray indexOfObject:self.sprHelp.texture];
    if (index > 0)
    {
        [self setHelpImageIndex:--index];
    }
}

- (void)onNextClick:(id)sender
{
    int index = [imgHelpArray indexOfObject:self.sprHelp.texture];
    if (index < imgHelpArray.count - 1)
    {
        [self setHelpImageIndex:++index];
    }
}

-(id) init
{
	if( (self=[super init]))
	{
        self.imgHelpArray = [NSMutableArray array];
        for (int i = 1; i <= 10; ++i)
        {
            NSString *fileName = [NSString stringWithFormat:NSLocalizedString(@"img-help%d.png", nil), i];
            CCTexture2D *texture = [[CCTextureCache sharedTextureCache] addImage:[HelpImgDir stringByAppendingPathComponent:fileName]];
            [self.imgHelpArray addObject:texture];
        }
        
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"5-help.bmml"
                                                            eventHandle:self];
		[self addChild:layer];
        
        self.sprHelp = [layer.nameAndControlDic objectForKey:@"image_help"];
        self.btnPrev = [layer.nameAndControlDic objectForKey:@"Prev"];
        self.btnNext = [layer.nameAndControlDic objectForKey:@"Next"];
        [self setHelpImageIndex:0];
	}
	return self;
}

- (void) dealloc
{
    self.imgHelpArray = nil;
	[super dealloc];
}

@end
