//
//  SelectModelLayer.m
//  BeatDevils
//
//  Created by 青宝 中 on 12-1-4.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "SelectModelLayer.h"
#import "CCBalsamiqLayer.h"
#import "BeatDevilsDef.h"
#import "GameModelLockManager.h"
#import "CCMenuItemButton.h"
#import "GameLayer.h"
#import "GameRecordManager.h"
#import "GameToolFunc.h"
#import "SimpleAudioEngine.h"

@interface SelectModelLayer (Private)

- (CCLayer *)createModelLayer:(BeatDevilsModel)model;

- (void)inBlock;
- (void)unBlock;

- (void)updateToModel:(BeatDevilsModel)model
       moveInPosition:(CGPoint)inPos
      moveOutPosition:(CGPoint)outPos
               curPos:(CGPoint)curPos;
@end

@implementation SelectModelLayer

@synthesize modelInfoLayer, isBlock;

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	[scene addChild:[self node]];
	
	return scene;
}

- (id)init
{
	self = [super init];
	if (self != nil)
	{
        [self addChild:[CCBalsamiqLayer layerWithBalsamiqFile:@"7.1-model-select-bg.bmml"
                                                  eventHandle:self]];
        
        
        [self updateToModel:BeatDevilsModelNormal
             moveInPosition:ccp([CCDirector sharedDirector].winSize.width, 0)
            moveOutPosition:ccp(-[CCDirector sharedDirector].winSize.width, 0)
                     curPos:ccp(0, 0)];
	}
	return self;
}

- (void)dealloc
{
	[super dealloc];
}

- (void)inBlock
{
    self.isBlock = YES;
}

- (void)unBlock
{
    self.isBlock = NO;
}

- (CCLayer *)createModelLayer:(BeatDevilsModel)model
{
    [GameToolFunc SetGameModel:model];
    
    CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:NSLocalizedString(@"7-model-select.bmml", nil)
                                                        eventHandle:self];
    // 设置关卡图片
    NSString *modelImages[BeatDevilsModelMax] =
    {
        NSLocalizedString(@"UI/7-model-select/img-model-normal.png", nil),
        NSLocalizedString(@"UI/7-model-select/img-model-hard.png", nil),
        NSLocalizedString(@"UI/7-model-select/img-model-expert.png", nil),
        NSLocalizedString(@"UI/7-model-select/img-model-hell.png", nil),
    };
    
    [[layer getControlByName:@"image_model"] setTexture:
     [[CCTextureCache sharedTextureCache] addImage:modelImages[model]]];
    
    if ([[GameModelLockManager instance] isUnlocked:model])
    {
        [[layer getControlByName:@"image_lock_info"] setVisible:NO];
        
        // 设置锁图片
        CCTexture2D *stage = [[CCTextureCache sharedTextureCache] addImage:NSLocalizedString(@"UI/7-model-select/img-total-stage.png", nil)];
        
        [[layer getControlByName:@"image_lock"] setTexture:stage];
        [[layer getControlByName:@"image_lock"] setTextureRect:(CGRect){{0, 0}, stage.contentSize}];
        
        // 设置分数和连击数
        if ([[GameRecordManager instance] getModelHighScore:model] > 0)
        {
            [GameToolFunc getUINumberLabel:[layer getControlByName:@"high_score"]
                               anchorPoint:ccp(0, 0.5f)].string = [NSString stringWithFormat:@"%d",
                                        [[GameRecordManager instance] getModelHighScore:model]];
        }
        else
        {
            [[layer getControlByName:@"image_high_score"] setVisible:NO];
            [[layer getControlByName:@"high_score"] setVisible:NO];
        }
        
        if ([[GameRecordManager instance] getModelHighHits:model] > 0)
        {
            [GameToolFunc getUINumberLabel:[layer getControlByName:@"high_hits"]
                               anchorPoint:ccp(0, 0.5f)].string = [NSString stringWithFormat:@"%d",
                                       [[GameRecordManager instance] getModelHighHits:model]];
        }
        else
        {
            [[layer getControlByName:@"image_high_hits"] setVisible:NO];
            [[layer getControlByName:@"high_hits"] setVisible:NO];
        }
    }
    else
    {
        [[layer getControlByName:@"image_high_score"] setVisible:NO];
        [[layer getControlByName:@"image_high_hits"] setVisible:NO];
        [[layer getControlByName:@"high_score"] setVisible:NO];
        [[layer getControlByName:@"high_hits"] setVisible:NO];
        [[layer getControlByName:@"Start"] setVisible:NO];
        
        // 解锁提示
        NSString *lockInfoImages[BeatDevilsModelMax] =
        {
            NSLocalizedString(@"UI/7-model-select/img-lockinfo-hard.png", nil),
            NSLocalizedString(@"UI/7-model-select/img-lockinfo-hard.png", nil),
            NSLocalizedString(@"UI/7-model-select/img-lockinfo-expert.png", nil),
            NSLocalizedString(@"UI/7-model-select/img-lockinfo-hell.png", nil),
        };
        
        [[layer getControlByName:@"image_lock_info"] setTexture:
         [[CCTextureCache sharedTextureCache] addImage:lockInfoImages[model]]];
    }
    
    return layer;
}

#pragma mark -
#pragma mark 按钮函数

- (void)updateToModel:(BeatDevilsModel)model
       moveInPosition:(CGPoint)inPos
      moveOutPosition:(CGPoint)outPos
               curPos:(CGPoint)curPos
{
    CCLayer *layer = [self createModelLayer:model];
    
    layer.position = inPos;
    [self addChild:layer];
    
    [self inBlock];
    [layer runAction:[CCSequence actions:
                      [CCEaseElasticOut actionWithAction:[CCMoveTo actionWithDuration:0.5f position:curPos]],
                      [CCCallFunc actionWithTarget:self selector:@selector(unBlock)],
                      nil]];
    
    [self.modelInfoLayer runAction:[CCSequence actions:
                                    [CCEaseElasticOut actionWithAction:[CCMoveTo actionWithDuration:0.5f position:outPos]],
                                    [CCCallFunc actionWithTarget:self.modelInfoLayer selector:@selector(removeFromParentAndCleanup:)], nil]];
    
    self.modelInfoLayer = layer;
}

- (void)onPrevClick:(id)sender
{
    if (self.isBlock)
    {
        return;
    }
    
    [[SimpleAudioEngine sharedEngine] playEffect:@"button.wav"];
    
    BeatDevilsModel model = [GameToolFunc GetGameModel] - 1;
    model = (model >= 0) ? model : BeatDevilsModelMax - 1;
    
    [self updateToModel:model
         moveInPosition:ccp(-[CCDirector sharedDirector].winSize.width, 0)
        moveOutPosition:ccp([CCDirector sharedDirector].winSize.width, 0)
                 curPos:ccp(0, 0)];
}

- (void)onNextClick:(id)sender
{
    if (self.isBlock)
    {
        return;
    }
    
    [[SimpleAudioEngine sharedEngine] playEffect:@"button.wav"];
    
    BeatDevilsModel model = [GameToolFunc GetGameModel] + 1;
    model = (model < BeatDevilsModelMax) ? model : 0;
    
    [self updateToModel:model
         moveInPosition:ccp([CCDirector sharedDirector].winSize.width, 0)
        moveOutPosition:ccp(-[CCDirector sharedDirector].winSize.width, 0)
                 curPos:ccp(0, 0)];
}

- (void)onStartClick:(id)sender
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"button.wav"];
    
    [[CCDirector sharedDirector] replaceScene:[GameLayer scene]];
}

@end
