//
//  TimeSpriteBarManager.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-29.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SpriteBarManager.h"

@interface TimeSpriteBarManager : SpriteBarManager
{
    CGPoint initFollowPoint;
    CCSprite *followSprite;
}

@property (nonatomic, copy) NSString *normalPic;
@property (nonatomic, copy) NSString *warningPic;

- (void)setFollowSprite:(CCSprite *)sprite;

- (void)setNormalPic:(NSString *)normalPicName warningPic:(NSString *)warningPicName;

- (void)recoverTime;

@end
