//
//  HelloWorldLayer.m
//  BalsamiqXmlReader
//
//  Created by lee living on 11-7-20.
//  Copyright LieHuo Tech 2011. All rights reserved.
//


// Import the interfaces
#import "MainLayer.h"

#import "BalsamiqControlData.h"
#import "CCBalsamiqLayer.h"
#import "CCAlertLayer.h"
#import "CCBalsamiqScene.h"
#import "SimpleAudioEngine.h"

#import "BalsamiqReaderConfig.h"
#import "HelpLayer.h"
#import "SelectModelLayer.h"
#import "GameCenterFacade.h"

@implementation MainLayer

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCBalsamiqScene node];
	
	// add layer as a child to scene
	[scene addChild:[MainLayer node]];
	
	// return the scene
	return scene;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
	
	NSLog(@"textField text = %@", textField.text);
}

// 主界面函数

- (void)onStartClick:(id)sender
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"button.wav"];
    
    [[CCDirector sharedDirector] replaceScene:[SelectModelLayer scene]];
}

- (void)onScoreClick:(id)sender
{
    if ([GameCenterFacade instance].isGameCenterAvailable)
    {
        [[GameCenterFacade instance] showLeaderboard];
    }
    else
    {
        NSLog(@"MainLayer#onScoreClick isGameCenterAvailable = NO");
    }
}

- (void)onHelpClick:(id)sender
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"button.wav"];
    
    [[CCDirector sharedDirector] pushScene:[HelpLayer scene]];
}

-(id) init
{
	if( (self=[super init]))
	{
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:NSLocalizedString(@"1-main.bmml", nil)
                                                            eventHandle:self];
        [self addChild:layer];
        
        [[SimpleAudioEngine sharedEngine] playBackgroundMusic:@"bg.m4a"];
        [SimpleAudioEngine sharedEngine].backgroundMusicVolume = 0.3f;
	}
	return self;
}

- (void) dealloc
{
	[super dealloc];
}

@end
