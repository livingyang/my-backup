//
//  TestSkillPanelLayer.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-30.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "TestSkillPanelLayer.h"
#import "CCBalsamiqLayer.h"
#import "BalsamiqReaderConfig.h"
#import "GameToolFunc.h"

@implementation TestSkillPanelLayer

@synthesize sprBg;

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	
	[scene addChild:[self node]];
	
	return scene;
}

#pragma mark -
#pragma mark 按钮单击函数

- (void)onAddClick:(id)sender
{
    //[diamondQueueLayer addDiamondSprite:DiamondTypeBox2Scissors];DiamondTypeNormalRock
    
    NSDictionary *info = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSNumber numberWithInt:DiamondTypeNormalRock], @"DiamondType", nil];
    [skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeAddDiamond info:info];
}

- (void)onTurnSightClick:(id)sender
{
    //skillPanelLayer.sprSight.visible = !skillPanelLayer.sprSight.visible;
}

- (void)onHintSkillClick:(id)sender
{
    [skillPanelLayer setButton:skillPanelLayer.btnHp
                        isHint:![skillPanelLayer isHint:skillPanelLayer.btnHp]];
}

- (void)onRemoveFirstClick:(id)sender
{
    [skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeRemoveFirstDiamond info:nil];
}

- (void)onRemoveAllClick:(id)sender
{
    [skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeRemoveAllDiamondDyWrong info:nil];
}

- (void)onBoomClick:(id)sender
{
    [skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeBoomDiamond info:nil];
}

- (void)onMagicClick:(id)sender
{
    NSDictionary *info = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSNumber numberWithInt:DiamondTypeReverseScissors], @"DiamondType",
                          [NSNumber numberWithInt:1], @"Count", nil];
    [skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeMagicChangeDiamond info:info];
}

- (void)onCleanClick:(id)sender
{
    [skillPanelLayer cleanAllDiamond];
}

- (void)onSwitchParticleClick:(id)sender
{
    static int particleSelIndex = 0;
    const int selCount = 3;
    SEL particleSelectors[selCount] = 
    {
        @selector(removeParticle:),
        @selector(showSnow:),
        @selector(showRain:),
    };
    
    ++particleSelIndex;
    particleSelIndex = (particleSelIndex < selCount) ? particleSelIndex : 0;
    
    [GameToolFunc performSelector:particleSelectors[particleSelIndex] withObject:self.sprBg];
}

- (void)onBreakBoxClick:(id)sender
{
    NSDictionary *info = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSNumber numberWithInt:DiamondTypeStar], @"DiamondType", nil];
    [skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeBreakBox info:info];
}

#pragma mark -
#pragma mark SkillPanelLayerDelegate

- (void)onRecoverHpClick
{}
- (void)onRecoverFuryClick
{}

- (void)onSkillTimeClick
{}
- (void)onSkillMagicClick
{
    NSDictionary *info = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSNumber numberWithInt:DiamondTypeReverseScissors], @"DiamondType",
                          [NSNumber numberWithInt:7], @"Count", nil];
    [skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeMagicChangeDiamond info:info];
}
- (void)onSkillBoomClick
{
    for (int i = 0; i < 5; ++i)
    {
        [skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeBoomDiamond info:nil];
    }
}

- (void)onShopClick
{}

- (id) init
{
	self = [super init];
	if (self != nil)
	{
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"2.1.1-test-layer.bmml" eventHandle:self];
        [self addChild:layer];
        self.sprBg = [layer getControlByName:@"image_bg"];
        
        skillPanelLayer = [SkillPanelLayer node];
        skillPanelLayer.delegate = self;
        [self addChild:skillPanelLayer];
	}
	return self;
}

- (void) dealloc
{
	[super dealloc];
}

@end
