//
//  SkillPanelLayer.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-30.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "SkillPanelLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCMenuItemButton.h"
#import "SimpleAudioEngine.h"

#define REVOTE_TIME (0.3f)
#define DIAMOND_TAG (222)
#define TAG_HINT_SPRITE (123)
#define TAG_HINT_ACTION (123)

static NSString *diamondTypePics[DiamondTypeMax] = 
{
    @"UI/2-game/img-rock.png", //DiamondTypeNormalRock,
    @"UI/2-game/img-paper.png", //DiamondTypeNormalPaper,
    @"UI/2-game/img-scissors.png", //DiamondTypeNormalScissors,
    
    @"UI/2-game/img-rock-reverse.png", //DiamondTypeReverseRock,
    @"UI/2-game/img-paper-reverse.png", //DiamondTypeReversePaper,
    @"UI/2-game/img-scissors-reverse.png", //DiamondTypeReverseScissors,
    
    @"UI/2-game/img-star.png", //DiamondTypeStar,
    
    @"UI/2-game/img-rock-box1.png", //DiamondTypeBox1Rock,
    @"UI/2-game/img-paper-box1.png", //DiamondTypeBox1Paper,
    @"UI/2-game/img-scissors-box1.png", //DiamondTypeBox1Scissors,
    
    @"UI/2-game/img-rock-box1.png", //DiamondTypeBox2Rock,
    @"UI/2-game/img-paper-box1.png", //DiamondTypeBox2Paper,
    @"UI/2-game/img-scissors-box1.png", //DiamondTypeBox2Scissors,
};

@implementation SkillPanelLayer

@synthesize delegate;
@synthesize btnTime, btnMagic, btnBoom, btnHp, btnFury;
@synthesize initRoshamboMenuPos, diamondDisplaySpriteArray, animeBlockCount;
@synthesize labRecoverHpCount, labRecoverFuryCount, labResistCount, labFury;
@synthesize sprFreeze, sprTimeBar, sprDevilHead, sprWrong, sprSlot, sprFury;

+(void)initialize
{
	if (self == [SkillPanelLayer class])
	{
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"skill-effect.plist"];
	}
}

- (CCAnimation *)getBoomAnimation
{
    CCAnimation *animation = [CCAnimation animation];
    for (int i = 1; i <= 3; ++i)
    {
        NSString *name = [NSString stringWithFormat:@"boom%05d.png", i];
        [animation addFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:name]];
    }
    
    [animation addFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"boom00003.png"]];
    [animation addFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"boom00003.png"]];
    [animation addFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:@"boom00003.png"]];
    
    return animation;
}

- (CCAnimation *)getMagicAnimation
{
    CCAnimation *animation = [CCAnimation animation];
    for (int i = 1; i <= 3; ++i)
    {
        NSString *name = [NSString stringWithFormat:@"magic%05d.png", i];
        [animation addFrame:[[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:name]];
    }
    
    return animation;
}

- (CCSprite *)lastDisplaySprite
{
    return [self.diamondDisplaySpriteArray lastObject];
}

- (CGPoint)lastDiamondPosition
{
    return self.lastDisplaySprite.position;
}

- (float)getMoveTime:(CCSprite *)sprite spriteEnd:(CCSprite *)spriteEnd
{
    return ccpDistance(sprite.position, spriteEnd.position) / 1000.0f;
}

- (void)checkAnimeFunc
{
    if (self.animeBlockCount != 0 || animeFuncDataArray.count <= 0)
    {
        return;
    }
    
    NSDictionary *dic = [animeFuncDataArray objectAtIndex:0];
    NSString *selString = [animeFuncDic objectForKey:[dic objectForKey:@"SkillPanelLayerAnimeType"]];
    
    [self performSelector:NSSelectorFromString(selString)
               withObject:dic];
    [animeFuncDataArray removeObjectAtIndex:0];
}

#pragma mark -
#pragma mark animeBlock函数

- (void)inBlock
{
    NSAssert(self.animeBlockCount >= 0, @"SkillPanelLayer#inBlock");
    
    ++self.animeBlockCount;
    
    NSLog(@"inBlock self.animeBlockCount = %d", self.animeBlockCount);
}

- (void)unBlock
{
    --self.animeBlockCount;
    
    NSLog(@"unBlock self.animeBlockCount = %d", self.animeBlockCount);
    
    NSAssert(self.animeBlockCount >= 0, @"SkillPanelLayer#unBlock");
}

// 动画播放函数

- (void)updateRoshamboSpritePosition:(int)spriteIndex
{
    if (spriteIndex >= diamondSpriteQueue.count)
    {
        return;
    }
    
    CCSprite *updateDisplaySprite = (spriteIndex < self.diamondDisplaySpriteArray.count) ?
    [self.diamondDisplaySpriteArray objectAtIndex:spriteIndex] : [self.diamondDisplaySpriteArray lastObject];
    
    CGPoint roshamboPosition = updateDisplaySprite.position;
    
    float moveTime = [self getMoveTime:updateDisplaySprite
                             spriteEnd:[diamondSpriteQueue objectAtIndex:spriteIndex]];
    
    [self inBlock];
    [[diamondSpriteQueue objectAtIndex:spriteIndex] runAction:[CCSequence actions:
                                                               [CCMoveTo actionWithDuration:moveTime position:roshamboPosition],
                                                               [CCCallFunc actionWithTarget:self selector:@selector(unBlock)],
                                                               [CCCallFunc actionWithTarget:self selector:@selector(checkAnimeFunc)],
                                                               nil]];
    
    // 第一个精灵需要放大
    return;
    if (spriteIndex == 0)
    {
        [self inBlock];
        id actions = [CCSequence actions:
                      [CCDelayTime actionWithDuration:moveTime],
                      [CCScaleBy actionWithDuration:0.1f scale:1.2f],
                      [CCCallFunc actionWithTarget:self selector:@selector(unBlock)],
                      [CCCallFunc actionWithTarget:self selector:@selector(checkAnimeFunc)],
                      nil];
        [[diamondSpriteQueue objectAtIndex:0] runAction:actions];
    }
}

- (void)addDiamondSprite:(DiamondType)diamondType
{
    [diamondSpriteQueue addObject:[CCSprite spriteWithFile:diamondTypePics[diamondType]]];
    [[diamondSpriteQueue lastObject] setPosition:self.lastDiamondPosition];
    [self addChild:[diamondSpriteQueue lastObject]
                 z:self.sprWrong.zOrder - 1
               tag:DIAMOND_TAG];
    
    [self updateRoshamboSpritePosition:diamondSpriteQueue.count - 1];
}

- (void)showExploding:(CCSprite *)diamond
{
    CCParticleSystem *emitter = [CCParticleSystemQuad particleWithFile:@"ExplodingRing.plist"];
    [diamond.parent addChild:emitter z:diamond.zOrder + 1];
    emitter.position = diamond.position;
    
    //emitter.position = ccp(diamond.contentSize.width / 2, diamond.contentSize.height / 2);//self.initRoshamboMenuPos;
    
    [emitter runAction:[CCSequence actions:
                        [CCDelayTime actionWithDuration:1.0f],
                        [CCCallFunc actionWithTarget:emitter selector:@selector(removeFromParentAndCleanup:)], nil]];
}

- (void)removeFirstDiamondSprite
{
    if (diamondSpriteQueue.count <= 0)
    {
        return;
    }
    
    CCSprite *firstSprite = [diamondSpriteQueue objectAtIndex:0];
    [diamondSpriteQueue removeObject:firstSprite];
    
    [self inBlock];
    id action = [CCSpawn actionOne:[CCFadeOut actionWithDuration:REVOTE_TIME]
                                              two:[CCCallFuncO actionWithTarget:self selector:@selector(showExploding:) object:firstSprite]];
    
    id actions = [CCSequence actions:
                  action,
                  [CCCallFunc actionWithTarget:firstSprite selector:@selector(removeFromParentAndCleanup:)],
                  [CCCallFunc actionWithTarget:self selector:@selector(unBlock)],
                  [CCCallFunc actionWithTarget:self selector:@selector(checkAnimeFunc)],
                  nil];
    
    [firstSprite runAction:actions];
    
    int updateCount = MIN(diamondSpriteQueue.count, self.diamondDisplaySpriteArray.count);
    
    for (int i = 0; i < updateCount; ++i)
    {
        [self updateRoshamboSpritePosition:i];
    }
}

- (void)removeFirstDiamondSpriteWithBoom
{
    // 爆炸效果
    CCAnimation *boomAnimation = [self getBoomAnimation];
    CCSprite *sprite = [CCSprite spriteWithSpriteFrame:[boomAnimation.frames objectAtIndex:0]];
    sprite.position = self.sprWrong.position;
    [self.sprWrong.parent addChild:sprite z:self.sprWrong.zOrder];
    
    [sprite runAction:[CCSequence actions:
                       [CCCallFuncO actionWithTarget:[SimpleAudioEngine sharedEngine] selector:@selector(playEffect:) object:@"boom.wav"],
                       [CCAnimate actionWithDuration:0.3f animation:boomAnimation restoreOriginalFrame:NO],
                       [CCCallFunc actionWithTarget:sprite selector:@selector(removeFromParentAndCleanup:)],
                       [CCCallFunc actionWithTarget:self selector:@selector(checkAnimeFunc)],
                       nil]];
    
    if (diamondSpriteQueue.count <= 0)
    {
        return;
    }
    
    CCSprite *firstSprite = [diamondSpriteQueue objectAtIndex:0];
    [diamondSpriteQueue removeObject:firstSprite];
    
    [self inBlock];
    id actions = [CCSequence actions:
                  [CCFadeOut actionWithDuration:0.3f],
                  [CCCallFunc actionWithTarget:firstSprite selector:@selector(removeFromParentAndCleanup:)],
                  [CCCallFunc actionWithTarget:self selector:@selector(unBlock)],
                  [CCCallFunc actionWithTarget:self selector:@selector(checkAnimeFunc)],
                  nil];
    [firstSprite runAction:actions];
    
    int updateCount = MIN(diamondSpriteQueue.count, self.diamondDisplaySpriteArray.count);
    
    for (int i = 0; i < updateCount; ++i)
    {
        [self updateRoshamboSpritePosition:i];
    }
}

- (void)removeAllDiamondSprite
{
    int removeCount = MIN(diamondSpriteQueue.count, self.diamondDisplaySpriteArray.count);
    
    for (int i = 0; i < removeCount; ++i)
    {
        CCSprite *sprite = [diamondSpriteQueue objectAtIndex:i];
        float delayTime = (self.diamondDisplaySpriteArray.count - i) * 0.1f;
        
        [self inBlock];
        id actions = [CCSequence actions:
                      [CCDelayTime actionWithDuration:delayTime],
                      [CCMoveTo actionWithDuration:[self getMoveTime:sprite spriteEnd:[self.diamondDisplaySpriteArray lastObject]] position:self.lastDiamondPosition],
                      [CCCallFunc actionWithTarget:sprite selector:@selector(removeFromParentAndCleanup:)],
                      [CCCallFunc actionWithTarget:self selector:@selector(unBlock)],
                      [CCCallFunc actionWithTarget:self selector:@selector(checkAnimeFunc)],
                      nil];
        [sprite runAction:actions];
    }
    
    [diamondSpriteQueue removeAllObjects];
}

- (void)setRoshamboPic:(CCSprite *)sprite toDiamondType:(DiamondType)diamondType
{
    if (sprite == nil)
    {
        return;
    }
    
    sprite.texture = [[CCTextureCache sharedTextureCache] addImage:diamondTypePics[diamondType]];
}

- (void)changeSpritesToDiamond:(DiamondType)diamondType count:(int)count
{
    for (int i = 0; i < count && i < diamondSpriteQueue.count; ++i)
    {
        CCSprite *diamondSprite = [diamondSpriteQueue objectAtIndex:i];
        [self setRoshamboPic:diamondSprite toDiamondType:diamondType];
        
        if (diamondSprite.parent != nil)
        {
            // 魔法效果
            CCAnimation *magicAnimation = [self getMagicAnimation];
            CCSprite *sprite = [CCSprite spriteWithSpriteFrame:[magicAnimation.frames objectAtIndex:0]];
            sprite.position = diamondSprite.position;
            [diamondSprite.parent addChild:sprite z:self.sprWrong.zOrder - 1];
            
            [sprite runAction:[CCSequence actions:
                               [CCAnimate actionWithDuration:0.3f animation:magicAnimation restoreOriginalFrame:NO],
                               [CCCallFunc actionWithTarget:sprite selector:@selector(removeFromParentAndCleanup:)],
                               nil]];
        }
    }
}

- (void)changeBoxToDiamond:(DiamondType)diamondType
{
    if (diamondSpriteQueue.count <= 0)
    {
        return;
    }
    
    CCSprite *boxSprite = [diamondSpriteQueue objectAtIndex:0];
    
    [self inBlock];
    [boxSprite runAction:[CCSequence actions:
                          [CCCallFuncO actionWithTarget:[SimpleAudioEngine sharedEngine] selector:@selector(playEffect:) object:@"destroy-right.wav"],
                          [CCScaleTo actionWithDuration:0.1 scaleX:0 scaleY:boxSprite.scale],
                          [CCCallFuncO actionWithTarget:boxSprite selector:@selector(setTexture:) object:[[CCTextureCache sharedTextureCache] addImage:diamondTypePics[diamondType]]],
                          [CCScaleTo actionWithDuration:0.1 scaleX:boxSprite.scale scaleY:boxSprite.scale],
                          [CCCallFunc actionWithTarget:self selector:@selector(unBlock)],
                          [CCCallFunc actionWithTarget:self selector:@selector(checkAnimeFunc)],
                          nil]];
}

// 下面是增加动画接口
- (void)addDiamond:(NSDictionary *)dic
{
    DiamondType diamondType = [[dic objectForKey:@"DiamondType"] intValue];
    
    [self addDiamondSprite:diamondType];
}

- (void)changeFirstDiamondByBreakBox:(NSDictionary *)dic
{
    DiamondType diamondType = [[dic objectForKey:@"DiamondType"] intValue];
    
    [self changeBoxToDiamond:diamondType];
}

- (void)removeFirstDiamond:(NSDictionary *)dic
{
    [self removeFirstDiamondSprite];
}

- (void)magicChangeDiamond:(NSDictionary *)dic
{
    DiamondType diamondType = [[dic objectForKey:@"DiamondType"] intValue];
    int count = [[dic objectForKey:@"Count"] intValue];
    
    [self changeSpritesToDiamond:diamondType count:count];
}

- (void)boomDiamond:(NSDictionary *)dic
{
    [self removeFirstDiamondSpriteWithBoom];
}

- (void)removeAllDiamondDyWrong:(NSDictionary *)dic
{
    [self removeAllDiamondSprite];
    
    // 加入错误动画
    [self.sprWrong runAction:[CCSequence actions:
                              [CCEaseElasticOut actionWithAction:[CCScaleTo actionWithDuration:0.5f scale:1.0f]],
                              [CCScaleTo actionWithDuration:0 scale:0.0f],
                              nil]];
}

// button的提示操作

- (BOOL)isHint:(CCMenuItemButton *)button
{
    return [button getActionByTag:TAG_HINT_ACTION] != nil;
    return [button getChildByTag:TAG_HINT_SPRITE] != nil;
}

- (void)setButton:(CCMenuItemButton *)button isHint:(BOOL)isHint
{
    [self setButton:button isHint:isHint interval:0];
}

- (void)setButton:(CCMenuItemButton *)button isHint:(BOOL)isHint interval:(float)interval
{
    // 若button不可用，则不能进行提示
    if (button.isEnabled == NO)
    {
        return;
    }
    
    if (isHint == [self isHint:button])
    {
        return;
    }
    
    if (isHint)
    {
        id action = [CCSequence actions:
                     [CCJumpBy actionWithDuration:2 position:ccp(0,0) height:5 jumps:4],
                     [CCDelayTime actionWithDuration:interval], nil];
        
        CCAction *jumpAction = [CCRepeatForever actionWithAction:action];
        jumpAction.tag = TAG_HINT_ACTION;
        [button runAction:jumpAction];
    }
    else
    {
        [button stopActionByTag:TAG_HINT_ACTION];
        
        NSString *posStr = [buttonAndInitPointDic objectForKey:[NSValue valueWithNonretainedObject:button]];
        button.position = CGPointFromString(posStr);
    }
    
    return;
    NSString *hintPicName = [buttonAndHintDic objectForKey:[NSValue valueWithNonretainedObject:button]];
    if (hintPicName == nil)
    {
        return;
    }
    
    if (isHint)
    {
        CCAction *action = nil;
        if (interval > 0)
        {
            action = [CCRepeatForever actionWithAction:[CCSequence actions:
                                                        [CCFadeIn actionWithDuration:0.5f],
                                                        [CCFadeOut actionWithDuration:0.5f],
                                                        [CCDelayTime actionWithDuration:interval], nil]];
        }
        else
        {
            action = [CCRepeatForever actionWithAction:[CCSequence actions:
                                                        [CCFadeIn actionWithDuration:0.5f],
                                                        [CCFadeOut actionWithDuration:0.5f], nil]];
        }
        
        CCSprite *sprite = [CCSprite spriteWithFile:hintPicName];
        sprite.tag = TAG_HINT_SPRITE;
        [sprite runAction:action];
        sprite.anchorPoint = ccp(0, 0);
        
        [button addChild:sprite];
    }
    else
    {
        [button removeChildByTag:TAG_HINT_SPRITE cleanup:YES];
    }
}

// 其它操作接口
// 增加回调接口，当之前的动画播放完毕时，会进行此回调
- (void)addAnimeAction:(SkillPanelLayerAnimeType)animeType info:(NSDictionary *)dic
{
    NSMutableDictionary *animeDataDic = [NSMutableDictionary dictionary];
    [animeDataDic setObject:[NSNumber numberWithInt:animeType] forKey:@"SkillPanelLayerAnimeType"];
    
    if (dic != nil)
    {
        [animeDataDic addEntriesFromDictionary:dic];
    }
    
    [animeFuncDataArray addObject:animeDataDic];
    
    [self checkAnimeFunc];
}

- (void)addCallBack:(id)target sel:(SEL)sel
{}

- (void)cleanAllDiamond
{
    for (CCSprite *diamond in diamondSpriteQueue)
    {
        [diamond removeFromParentAndCleanup:YES];
    }
    
    CCNode *diamondSprite = [self getChildByTag:DIAMOND_TAG];
    while (diamondSprite != nil)
    {
        [diamondSprite removeFromParentAndCleanup:YES];
        diamondSprite = [self getChildByTag:DIAMOND_TAG];
    }
    
    [diamondSpriteQueue removeAllObjects];
    
    self.animeBlockCount = 0;
    [animeFuncDataArray removeAllObjects];
}

#pragma mark -
#pragma mark 按钮函数

- (void)onRecoverHpClick:(id)sender
{
    [self.delegate onRecoverHpClick];
}

- (void)onRecoverFuryClick:(id)sender
{
    [self.delegate onRecoverFuryClick];
}

- (void)onSkillTimeClick:(id)sender
{
    [self.delegate onSkillTimeClick];
}

- (void)onSkillMagicClick:(id)sender
{
    [self.delegate onSkillMagicClick];
}

- (void)onSkillBoomClick:(id)sender
{
    [self.delegate onSkillBoomClick];
}

- (void)onShopClick:(id)sender
{
}

#pragma mark -
#pragma mark 控件创建函数

- (void)loadDisplaySpriteArray:(CCBalsamiqLayer *)layer
{
    NSMutableArray *roshamboSprites = [NSMutableArray array];
    for (NSString *name in [layer.nameAndControlDic.allKeys sortedArrayUsingSelector:@selector(compare:)])
    {
        if ([name hasPrefix:@"image_roshambo"])
        {
            CCSprite *image = [layer getControlByName:name];
            
            image.visible = NO;
            
            [roshamboSprites addObject:image];
        }
    }
    
    self.diamondDisplaySpriteArray = roshamboSprites;
}

- (void)loadControls:(CCBalsamiqLayer *)layer
{
    self.initRoshamboMenuPos = layer.position;
    
    self.sprFreeze = [layer getControlByName:@"image_freeze"];
    self.sprFreeze.visible = NO;
    
    // 绑定各个按钮
    self.btnTime = [layer getControlByName:@"SkillTime"];
    self.btnMagic = [layer getControlByName:@"SkillMagic"];
    self.btnBoom = [layer getControlByName:@"SkillBoom"];
    self.btnHp = [layer getControlByName:@"RecoverHp"];
    self.btnFury = [layer getControlByName:@"RecoverFury"];
    
    self.labRecoverHpCount = [layer getControlByName:@"count-recover-hp"];
    self.labRecoverFuryCount = [layer getControlByName:@"count-recover-fury"];
    self.labResistCount = [layer getControlByName:@"count-resist"];
    self.labResistCount.visible = NO;
    
    self.sprTimeBar = [layer getControlByName:@"image_timebar"];
    self.sprDevilHead = [layer getControlByName:@"image_devil_head"];
    self.sprWrong = [layer getControlByName:@"image_wrong"];
    self.sprWrong.scale = 0;
    
    [self.sprWrong removeFromParentAndCleanup:YES];
    [self addChild:self.sprWrong z:self.sprWrong.zOrder];
    
    self.sprSlot = [layer getControlByName:@"image_slot"];
    
    self.labFury = [layer getControlByName:@"fury"];
    self.sprFury = [layer getControlByName:@"image_fury"];
}

- (id)init
{
	self = [super init];
	if (self != nil)
	{
        self.animeBlockCount = 0;
        animeFuncDataArray = [[NSMutableArray alloc] init];
        diamondSpriteQueue = [[NSMutableArray alloc] init];
        
        {
            animeFuncDic = [[NSMutableDictionary alloc] init];
            [animeFuncDic setObject:NSStringFromSelector(@selector(addDiamond:))
                             forKey:[NSNumber numberWithInt:SkillPanelLayerAnimeTypeAddDiamond]];
            [animeFuncDic setObject:NSStringFromSelector(@selector(removeFirstDiamond:))
                             forKey:[NSNumber numberWithInt:SkillPanelLayerAnimeTypeRemoveFirstDiamond]];
            [animeFuncDic setObject:NSStringFromSelector(@selector(removeAllDiamondDyWrong:))
                             forKey:[NSNumber numberWithInt:SkillPanelLayerAnimeTypeRemoveAllDiamondDyWrong]];
            [animeFuncDic setObject:NSStringFromSelector(@selector(boomDiamond:))
                             forKey:[NSNumber numberWithInt:SkillPanelLayerAnimeTypeBoomDiamond]];
            [animeFuncDic setObject:NSStringFromSelector(@selector(magicChangeDiamond:))
                             forKey:[NSNumber numberWithInt:SkillPanelLayerAnimeTypeMagicChangeDiamond]];
            [animeFuncDic setObject:NSStringFromSelector(@selector(changeFirstDiamondByBreakBox:))
                             forKey:[NSNumber numberWithInt:SkillPanelLayerAnimeTypeBreakBox]];
        }
        
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"2.1-roshambo-layer.bmml"
                                                            eventHandle:self];
        [self addChild:layer];
        
        [self loadControls:layer];
        [self loadDisplaySpriteArray:layer];
        
        {
            buttonAndHintDic = [[NSMutableDictionary alloc] init];
            [buttonAndHintDic setObject:@"UI/2-game/img-hint-health.png"
                                 forKey:[NSValue valueWithNonretainedObject:self.btnHp]];
            [buttonAndHintDic setObject:@"UI/2-game/img-hint-fury.png"
                                 forKey:[NSValue valueWithNonretainedObject:self.btnFury]];
            [buttonAndHintDic setObject:@"UI/2-game/img-hint-time.png"
                                 forKey:[NSValue valueWithNonretainedObject:self.btnTime]];
            [buttonAndHintDic setObject:@"UI/2-game/img-hint-boom.png"
                                 forKey:[NSValue valueWithNonretainedObject:self.btnBoom]];
            [buttonAndHintDic setObject:@"UI/2-game/img-hint-magic.png"
                                 forKey:[NSValue valueWithNonretainedObject:self.btnMagic]];
        }
        
        {
            buttonAndInitPointDic = [[NSMutableDictionary alloc] init];
            [buttonAndInitPointDic setObject:NSStringFromCGPoint(self.btnHp.position)
                                      forKey:[NSValue valueWithNonretainedObject:self.btnHp]];
            [buttonAndInitPointDic setObject:NSStringFromCGPoint(self.btnFury.position)
                                      forKey:[NSValue valueWithNonretainedObject:self.btnFury]];
            [buttonAndInitPointDic setObject:NSStringFromCGPoint(self.btnTime.position)
                                      forKey:[NSValue valueWithNonretainedObject:self.btnTime]];
            [buttonAndInitPointDic setObject:NSStringFromCGPoint(self.btnBoom.position)
                                      forKey:[NSValue valueWithNonretainedObject:self.btnBoom]];
            [buttonAndInitPointDic setObject:NSStringFromCGPoint(self.btnMagic.position)
                                      forKey:[NSValue valueWithNonretainedObject:self.btnMagic]];
        }
	}
	return self;
}

- (void) dealloc
{
    self.diamondDisplaySpriteArray = nil;
    [buttonAndHintDic release];
    [buttonAndInitPointDic release];
    [diamondSpriteQueue release];
    [animeFuncDataArray release];
    [animeFuncDic release];
    
	[super dealloc];
}

@end
