//
//  TestParticleLayer.m
//  BeatDevils
//
//  Created by 青宝 中 on 12-1-11.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "TestParticleLayer.h"
#import "CCBalsamiqLayer.h"

@implementation TestParticleLayer

@synthesize sprBg, sprSlot, sprRoshamboBg;

+(CCScene *) scene
{
	CCScene *scene = [CCScene node];
	
	[scene addChild:[self node]];
	
	return scene;
}

- (id) init
{
	self = [super init];
	if (self != nil)
	{
        {
            CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"2-game.bmml" eventHandle:self];
            [self addChild:layer];
            self.sprBg = [layer getControlByName:@"image_bg"];
        }
        
        {
            CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"2.1-roshambo-layer.bmml" eventHandle:self];
            [self addChild:layer];
        }
	}
	return self;
}

@end
