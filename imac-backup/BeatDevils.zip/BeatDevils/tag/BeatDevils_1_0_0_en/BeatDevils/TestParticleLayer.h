//
//  TestParticleLayer.h
//  BeatDevils
//
//  Created by 青宝 中 on 12-1-11.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface TestParticleLayer : CCLayer
{
    
}

@property (nonatomic, assign) CCSprite *sprBg;
@property (nonatomic, assign) CCSprite *sprSlot;
@property (nonatomic, assign) CCSprite *sprRoshamboBg;

+(CCScene *) scene;

@end
