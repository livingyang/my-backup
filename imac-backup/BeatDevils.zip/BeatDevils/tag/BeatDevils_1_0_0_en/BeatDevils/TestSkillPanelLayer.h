//
//  TestSkillPanelLayer.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-30.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "SkillPanelLayer.h"

@class CCBalsamiqLayer;
@class SkillPanelLayer;
@interface TestSkillPanelLayer : CCLayer <SkillPanelLayerDelegate>
{
    SkillPanelLayer *skillPanelLayer;
}

@property (nonatomic, assign) CCSprite *sprBg;

+(CCScene *) scene;

@end
