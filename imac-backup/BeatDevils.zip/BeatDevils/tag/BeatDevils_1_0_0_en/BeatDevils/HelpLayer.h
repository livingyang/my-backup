//
//  HelpLayer.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-15.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class CCMenuItemButton;
@interface HelpLayer : CCLayer
{
}

@property (nonatomic, retain) NSMutableArray *imgHelpArray;
@property (nonatomic, assign) CCSprite *sprHelp;
@property (nonatomic, assign) CCMenuItemButton *btnPrev;
@property (nonatomic, assign) CCMenuItemButton *btnNext;

+(CCScene *) scene;

@end
