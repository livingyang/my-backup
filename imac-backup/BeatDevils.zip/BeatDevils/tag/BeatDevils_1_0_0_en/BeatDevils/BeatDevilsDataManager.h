//
//  BeatDevilsDataManager.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-16.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BeatDevilsDef.h"

@interface BeatDevilsDataManager : NSObject
{}

+ (void)saveGameData:(BeatDevilsGameData)gameData;
+ (BOOL)getGameData:(BeatDevilsGameData *)gameData;

@end
