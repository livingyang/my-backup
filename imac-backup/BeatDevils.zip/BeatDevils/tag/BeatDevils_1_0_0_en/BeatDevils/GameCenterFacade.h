//
//  GameCenterFacade.h
//  CutTheChain
//
//  Created by lee living on 11-6-13.
//  Copyright 2011 LieHuo Tech. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "BeatDevilsDef.h"

@interface GameCenterFacade : NSObject
{

}

@property (nonatomic, readonly) BOOL isGameCenterAvailable;

+ (GameCenterFacade *)instance;

- (BOOL)isAvailableVersion;
- (void)showLeaderboard;
- (void)authenticateLocalPlayer;

- (void)submitScore:(int)score toModel:(BeatDevilsModel)model;
- (void)submitHits:(int)hits toModel:(BeatDevilsModel)model;

@end
