//
//  GameRecordManager.m
//  BeatDevils
//
//  Created by 青宝 中 on 12-1-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "GameRecordManager.h"
#import "GameCenterFacade.h"

@implementation GameRecordManager

+ (GameRecordManager *)instance
{
    static GameRecordManager *mgr = nil;
    if (mgr == nil)
    {
        mgr = [[GameRecordManager alloc] init];
    }
    
    return mgr;
}

- (NSString *)getHighScoreKey:(BeatDevilsModel)model
{
    return [NSString stringWithFormat:@"getHighScoreKey%d", model];
}

- (void)setModelHighScore:(int)score model:(BeatDevilsModel)model
{
    if ([self getModelHighScore:model] >= score)
    {
        return;
    }
    
    [[NSUserDefaults standardUserDefaults] setInteger:score
                                               forKey:[self getHighScoreKey:model]];
    
    [[GameCenterFacade instance] submitScore:score toModel:model];
}

- (int)getModelHighScore:(BeatDevilsModel)model
{
    if ([[NSUserDefaults standardUserDefaults]
         objectForKey:[self getHighScoreKey:model]] == nil)
    {
        return 0;
    }
    
    return [[NSUserDefaults standardUserDefaults] integerForKey:[self getHighScoreKey:model]];
}

- (NSString *)getHighHitsKey:(BeatDevilsModel)model
{
    return [NSString stringWithFormat:@"getHighHitsKey%d", model];
}

- (void)setModelHighHits:(int)hits model:(BeatDevilsModel)model
{
    if ([self getModelHighHits:model] >= hits)
    {
        return;
    }
    
    [[NSUserDefaults standardUserDefaults] setInteger:hits
                                               forKey:[self getHighHitsKey:model]];
    
    [[GameCenterFacade instance] submitHits:hits toModel:model];
}

- (int)getModelHighHits:(BeatDevilsModel)model
{
    if ([[NSUserDefaults standardUserDefaults]
         objectForKey:[self getHighHitsKey:model]] == nil)
    {
        return 0;
    }
    
    return [[NSUserDefaults standardUserDefaults] integerForKey:[self getHighHitsKey:model]];
}

@end
