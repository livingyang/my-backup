//
//  ShopLayer.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-6.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "BeatDevilsDef.h"

#import "ShopItemManager.h"

@class GameLayer;
@class CCBalsamiqLayer;
@class CCAlertLayer;
@interface ShopLayer : CCLayer <ShopItemManagerDelegate>
{
    CGPoint itemLeftBottomPos;
    CGPoint itemRightTopPos;
    
    CCBalsamiqLayer *shopBalsamiqLayer;
    GameLayer *gamaLayer_;
    
    NSMutableDictionary *skillCodeAndItemDic;
    
    NSMutableDictionary *skillCodeAndSkillButtonDic;
    
    ShopItemManager *shopItemManager;
}

@property (nonatomic, assign) GameLayer *gamaLayer;
@property (nonatomic, retain) CCAlertLayer *shopLoadingAlert;

+(CCScene *) scene:(GameLayer *)layer;

@end
