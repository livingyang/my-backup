//
//  LogoLayer.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-29.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class MPMoviePlayerController;
@interface LogoLayer : CCLayer {
    
}

@property (retain) MPMoviePlayerController *moviePlayerController;

+ (CCScene *)scene;

@end
