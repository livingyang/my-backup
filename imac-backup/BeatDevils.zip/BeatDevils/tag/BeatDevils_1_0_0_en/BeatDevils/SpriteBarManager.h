//
//  SpriteBarManager.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-2.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

enum
{
    kDecreaseFromLeft = 0,
    kDecreaseFromRight,
    kDecreaseFromTop,
    kDecreaseFromBottom,
    kMaxDecreaseDirection,
};
typedef short DecreaseDirection;

@interface SpriteBarManager : NSObject
{
    float maxValue;
    float curValue;
    
    CCSprite *barSprite;
    CCLabelTTF *labBar;
    CGPoint initPosition;
    DecreaseDirection direction;
}

@property (nonatomic, assign) CCLabelTTF *labBar;

- (void)setBarSprite:(CCSprite *)sprite decreaseDirection:(DecreaseDirection)d;

- (void)setCurValue:(float)value;

- (void)updateValue:(float)value count:(int)count withDelay:(float)delay interval:(float)interval;
- (void)clearUpdateValueAction;

- (void)addDamage:(float)damage;

- (void)setMaxValue:(float)value;

- (void)updateData;

@end
