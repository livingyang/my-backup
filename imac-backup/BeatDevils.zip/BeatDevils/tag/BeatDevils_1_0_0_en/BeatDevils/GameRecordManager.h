//
//  GameRecordManager.h
//  BeatDevils
//
//  Created by 青宝 中 on 12-1-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BeatDevilsDef.h"

@interface GameRecordManager : NSObject

+ (GameRecordManager *)instance;

- (void)setModelHighScore:(int)score model:(BeatDevilsModel)model;
- (int)getModelHighScore:(BeatDevilsModel)model;

- (void)setModelHighHits:(int)hits model:(BeatDevilsModel)model;
- (int)getModelHighHits:(BeatDevilsModel)model;

@end
