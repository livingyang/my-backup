//
//  ShopLayer.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-6.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "ShopLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCAlertLayer.h"
#import "CCMenuItemButton.h"
#import "GameLayer.h"

#define SKILL_PIC_DIR @"UI/3-shop"

typedef struct
{
    NSString *skillName;
    NSString *skillPicName;
} SkillInfo;

@interface ShopLayer (Private)

- (id) initWithGameLayer:(GameLayer *)gameLayer;
- (void)updateSkillCount:(SkillCode)skillCode;
- (void)updateMoney;
- (SkillInfo)getSkillInfo:(SkillCode)skillCode;

@end

@implementation ShopLayer

@synthesize gamaLayer, shopLoadingAlert;

+(CCScene *) scene:(GameLayer *)layer
{
	CCScene *scene = [CCScene node];
	[scene addChild:[[[ShopLayer alloc] initWithGameLayer:layer] autorelease]];
	
	return scene;
}

- (void)onBackClick:(id)sender
{
    [[CCDirector sharedDirector] popScene];
}

- (void)onPurcharseClick:(id)sender
{
    [CCAlertLayer showAlert:@"3.1-purchase.bmml" parentNode:self showModal:kNormalShowModal];
}

- (void)onItemClick:(id)sender
{
    SkillCode skillCode = [sender tag];
    
    [self.gamaLayer buySkill:skillCode];
    [self updateSkillCount:skillCode];
    [self updateMoney];
}

// 弹出框操作

- (void)onCloseClick:(id)sender
{
    [CCAlertLayer removeAlertFromNode:sender];
}

- (void)onBuy1000Click:(id)sender
{
    [shopItemManager purchaseItem:ITEM_1000_COINS];
    self.shopLoadingAlert = [CCAlertLayer showAlert:@"3.3-shop-loading.bmml"
                                         parentNode:self];
}

- (void)onBuy2100Click:(id)sender
{
    [shopItemManager purchaseItem:ITEM_2100_COINS];
    self.shopLoadingAlert = [CCAlertLayer showAlert:@"3.3-shop-loading.bmml"
                                         parentNode:self];
}

- (void)onBuy5000Click:(id)sender
{
    [shopItemManager purchaseItem:ITEM_5000_COINS];
    self.shopLoadingAlert = [CCAlertLayer showAlert:@"3.3-shop-loading.bmml"
                                         parentNode:self];
}

- (void)onBuy12000Click:(id)sender
{
    [self.gamaLayer addMoney:12000];
    [self updateMoney];
    return;
    [shopItemManager purchaseItem:ITEM_12000_COINS];
    self.shopLoadingAlert = [CCAlertLayer showAlert:@"3.3-shop-loading.bmml"
                                         parentNode:self];
}

- (CGPoint)getItemPositionFromLeftBottomPos:(CGPoint)leftBottomPos
                                rightTopPos:(CGPoint)rightTopPos
                                     maxRow:(int)maxRow
                                     maxCol:(int)maxCol
                                        row:(int)row
                                        col:(int)col
{
    CGPoint offsetPos = ccp((rightTopPos.x - leftBottomPos.x) / (maxCol - 1),
                            (rightTopPos.y - leftBottomPos.y) / (maxRow - 1));
    
    return ccpAdd(leftBottomPos, ccp(offsetPos.x * col, offsetPos.y * row));
}

- (SkillInfo)getSkillInfo:(SkillCode)skillCode
{
    if (skillCode < 0 || skillCode >= S_MAX_PURCHASE_SKILL_CODE)
    {
        return (SkillInfo){@"无效技能", @"img-boom-up.png"};
    }
    
    static SkillInfo skillInfo[S_MAX_PURCHASE_SKILL_CODE] =
    {
        {@"lab-attack-up.png", @"img-attack-up.png"},    //S_ATTACK_UP
        {@"lab-defense-up.png", @"img-defense-up.png"},    //S_DEFENSE_UP
        {@"lab-max-fury-up.png", @"img-max-fury-up.png"},    //S_MAX_FURY_UP
        {@"lab-high-score-up.png", @"img-high-score-up.png"},    //S_HIGH_SCORE_RATE_UP
        {@"lab-time-up.png", @"img-time-up.png"},    //S_FREEZE_TIME_UP
        {@"lab-critical-rate-up.png", @"img-critical-rate-up.png"},    //S_CRITICAL_RATE_UP
        {@"lab-magic-up.png", @"img-magic-up.png"},    //S_MAGIC_UP
        {@"lab-boom-up.png", @"img-boom-up.png"},    //S_BOOM_UP
        
        {@"lab-recover-fury.png", @"img-recover-fury.png"},     //S_RECOVER_FURY
        {@"lab-recover-hp.png", @"img-recover-hp.png"},     //S_RECOVER_HEALTH
        {@"lab-resist.png", @"img-resist.png"},     //S_RESIST_MISTAKE
    };
    
    return skillInfo[skillCode];
}

- (BOOL)isCanBuy:(SkillCode)skillCode money:(int)curMoney
{
    int skillPrice = [self.gamaLayer getSkillPrice:skillCode];
    
    if (skillPrice > curMoney
        || [self.gamaLayer getSkillCount:skillCode] >= [self.gamaLayer getSkillMaxCount:skillCode])
    {
        return NO;
    }
    else
    {
        return YES;
    }
}

- (void)setSkillButtonState:(SkillCode)skillCode money:(int)curMoney
{
    CCMenuItemButton *button = [skillCodeAndSkillButtonDic objectForKey:[NSNumber numberWithInt:skillCode]];
    
    if (button == nil)
    {
        return;
    }
    
    button.isEnabled = [self isCanBuy:skillCode money:curMoney];
}

- (void)updateTotalSkillButtonState
{
    for (NSNumber *skillCodeNum in [skillCodeAndSkillButtonDic allKeys])
    {
        [self setSkillButtonState:[skillCodeNum intValue] money:self.gamaLayer.curMoney];
    }
}

- (void)updateMoney
{
    [[shopBalsamiqLayer.nameAndControlDic objectForKey:@"money"]
     setString:[NSString stringWithFormat:@"%d", self.gamaLayer.curMoney]];
    
    [self updateTotalSkillButtonState];
}

- (void)updateSkillCount:(SkillCode)skillCode
{
    CCBalsamiqLayer *itemLayer = [skillCodeAndItemDic objectForKey:[NSNumber numberWithInt:skillCode]];
    
    [[itemLayer.nameAndControlDic objectForKey:@"price"]
     setString:[NSString stringWithFormat:@"%d", [self.gamaLayer getSkillPrice:skillCode]]];
    
    [[itemLayer.nameAndControlDic objectForKey:@"count"]
     setString:[NSString stringWithFormat:@"%d/%d", [self.gamaLayer getSkillCount:skillCode], [self.gamaLayer getSkillMaxCount:skillCode]]];
}

- (CCBalsamiqLayer *)getShopItem:(SkillCode)skillCode
{
    CCBalsamiqLayer *itemLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"3.2-shop-item.bmml"
                                                            eventHandle:self];
    [skillCodeAndItemDic setObject:itemLayer forKey:[NSNumber numberWithInt:skillCode]];
    
    [[itemLayer.nameAndControlDic objectForKey:@"item-name"]
     setString:[self getSkillInfo:skillCode].skillName];
    
    NSString *labPicPath = [SKILL_PIC_DIR stringByAppendingPathComponent:[self getSkillInfo:skillCode].skillName];
    CCSprite *sprite = [itemLayer.nameAndControlDic objectForKey:@"image_skillname"];
    sprite.opacity = 0;
    CCSprite *sprLab = [CCSprite spriteWithFile:labPicPath];
    sprLab.position = ccp(sprite.contentSize.width / 2, sprite.contentSize.height / 2);
    [sprite addChild:sprLab];
    
    CCMenuItemButton *button = [itemLayer.nameAndControlDic objectForKey:@"Item"];
    NSString *filePath = [SKILL_PIC_DIR stringByAppendingPathComponent:[self getSkillInfo:skillCode].skillPicName];
    button.normalImage = [CCSprite spriteWithFile:filePath];
    button.selectedImage = [CCSprite spriteWithFile:filePath];
    button.disabledImage = [CCSprite spriteWithFile:filePath];
    [button.disabledImage setOpacity:150];
    [skillCodeAndSkillButtonDic setObject:button forKey:[NSNumber numberWithInt:skillCode]];
    button.tag = skillCode;

    [self updateSkillCount:skillCode];
    [self updateTotalSkillButtonState];
    
    return itemLayer;
}

- (void)loadShopItems
{
    int maxRow = 3;
    int maxCol = 4;
    
    for (int row = 0; row < maxRow; ++row)
    {
        for (int col = 0; col < maxCol; ++col)
        {
            SkillCode skillCode = row * maxCol + col;
            
            if (skillCode < S_MAX_PURCHASE_SKILL_CODE)
            {
                CCBalsamiqLayer *itemLayer = [self getShopItem:skillCode];
                itemLayer.position = [self getItemPositionFromLeftBottomPos:itemLeftBottomPos
                                                                rightTopPos:itemRightTopPos
                                                                     maxRow:maxRow
                                                                     maxCol:maxCol
                                                                        row:row
                                                                        col:col];
                itemLayer.anchorPoint = ccp(0.5f, 0.5f);
                [self addChild:itemLayer];
            }
        }
    }
}

- (void)onPurchaseItem:(NSString *)item success:(BOOL)isSuccess
{
    [CCAlertLayer removeAlertFromNode:self.shopLoadingAlert];
    self.shopLoadingAlert = nil;
    
    if (isSuccess)
    {
        if ([item isEqualToString:ITEM_1000_COINS])
        {
            [self.gamaLayer addMoney:1000];
            [self updateMoney];
        }
        else if ([item isEqualToString:ITEM_2100_COINS])
        {
            [self.gamaLayer addMoney:2100];
            [self updateMoney];
        }
        else if ([item isEqualToString:ITEM_5000_COINS])
        {
            [self.gamaLayer addMoney:5000];
            [self updateMoney];
        }
        else if ([item isEqualToString:ITEM_12000_COINS])
        {
            [self.gamaLayer addMoney:12000];
            [self updateMoney];
        }
    }
}

- (void)onPurchaseCancle
{
    [CCAlertLayer removeAlertFromNode:self.shopLoadingAlert];
    self.shopLoadingAlert = nil;
}

- (void)onPurchaseTimeOut:(NSString *)item
{
    [CCAlertLayer removeAlertFromNode:self.shopLoadingAlert];
    self.shopLoadingAlert = nil;
}

- (id) initWithGameLayer:(GameLayer *)layer
{
	self = [super init];
	if (self != nil)
	{
        skillCodeAndItemDic = [[NSMutableDictionary alloc] init];
        skillCodeAndSkillButtonDic = [[NSMutableDictionary alloc] init];
        
        self.gamaLayer = layer;
        
        shopBalsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"3-shop.bmml"
                                                       eventHandle:self];
        [self addChild:shopBalsamiqLayer];
        
        [[shopBalsamiqLayer.nameAndControlDic objectForKey:@"money"]
         setString:[NSString stringWithFormat:@"%d", self.gamaLayer.curMoney]];
        
        [[shopBalsamiqLayer.nameAndControlDic objectForKey:@"image_item_leftbottom"] setVisible:NO];
        [[shopBalsamiqLayer.nameAndControlDic objectForKey:@"image_item_righttop"] setVisible:NO];
        itemLeftBottomPos = [[shopBalsamiqLayer.nameAndControlDic objectForKey:@"image_item_leftbottom"] position];
        itemRightTopPos = [[shopBalsamiqLayer.nameAndControlDic objectForKey:@"image_item_righttop"] position];
        
        [self loadShopItems];
        
        shopItemManager = [[ShopItemManager alloc] initWithShopItemManagerDelegate:self];
	}
	return self;
}

- (void) dealloc
{
    [skillCodeAndItemDic release];
    [skillCodeAndSkillButtonDic release];
    [shopItemManager release];
    
    // 注销inapp通知
	[super dealloc];
}

@end
