//
//  GameModelLockManager.h
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-23.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "BeatDevilsDef.h"

@interface GameModelLockManager : NSObject

+ (GameModelLockManager *)instance;

- (BOOL)isUnlocked:(BeatDevilsModel)model;
- (void)unlockGameModel:(BeatDevilsModel)model;

@end
