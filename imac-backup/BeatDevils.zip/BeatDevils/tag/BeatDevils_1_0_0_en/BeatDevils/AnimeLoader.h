//
//  AnimeLoader.h
//  study_loadanime
//
//  Created by 青宝 中 on 11-12-26.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface AnimeLoader : NSObject
{
    // key csv文件名, value csv内容，包含在NSArray中
    NSMutableDictionary *animeInfoDic;
}

+ (AnimeLoader *)instance;

- (CCAnimation *)getAnimationFromFileName:(NSString *)fileName;

@end
