/*
 *  BeatDevilsServerDelegate.cpp
 *  BeatDevils
 *
 *  Created by 青宝 中 on 11-11-24.
 *  Copyright 2011年 __MyCompanyName__. All rights reserved.
 *
 */

#include "BeatDevilsServerDelegate.h"
#import "GameLayer.h"
#import "SkillPanelLayer.h"
#import "PlayerGuideLayer.h"
#import "NpcAnimationManager.h"
#import "SpriteBarManager.h"
#import "CCMenuItemButton.h"
#import "BeatDevilsDataManager.h"
#import "SimpleAudioEngine.h"
#import "GameModelLockManager.h"
#import "GameToolFunc.h"
#import "GameRecordManager.h"

#define LOCK_STAGE (8)
#define WARNING_AREA_PER (0.66f)

BeatDevilsServerDelegate::BeatDevilsServerDelegate(GameLayer *gameLayer):
m_GameLayer(gameLayer),
m_Server(NULL),
mLastHighHits(0)
{
}

BeatDevilsServerDelegate::~BeatDevilsServerDelegate()
{
    if (m_Server != NULL)
    {
        DeleteBeatDevilsServer(m_Server);
        m_Server = NULL;
    }
}

void BeatDevilsServerDelegate::OnAddNpcRoshambo(DiamondType diamondType)
{
    NSLog(@"OnAddNpcRoshambo : %d", diamondType);
    
    NSDictionary *info = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSNumber numberWithInt:diamondType], @"DiamondType", nil];
    [m_GameLayer.skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeAddDiamond info:info];
    
    [m_GameLayer.npcAnimationMgr addSpriteAction:GetRoshamboAnimeName(diamondType, m_Server->GetCurNpcHP() , m_Server->GetMaxNpcHP()) delay:0];
    //[m_GameLayer addNPCRoshambo:roshambo];
}

void BeatDevilsServerDelegate::OnAddPlayerRoshambo(Roshambo roshambo)
{
    NSLog(@"OnAddPlayerRoshambo : %d", roshambo);
}

void BeatDevilsServerDelegate::OnPlayerVSNpc(RoshamboResult result)
{
    NSLog(@"OnPlayerVSNpc : %d", result);
    
    if (result == RoshamboResultWin)
    {
        //[[SimpleAudioEngine sharedEngine] playEffect:@"destroy-right.wav"];
    }
    else
    {
        //[[SimpleAudioEngine sharedEngine] playEffect:@"destroy-wrong.wav"];
    }
}

void BeatDevilsServerDelegate::OnRemoveFirstDiamond()
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"destroy-right.wav"];
    [m_GameLayer.skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeRemoveFirstDiamond info:nil];
    
    [m_GameLayer.playerGuideLayer updateSkillButtonWithDiamondCount:m_Server->GetNpcDiamondCount()];
}

void BeatDevilsServerDelegate::OnRemoveAllDiamondWithWrong()
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"destroy-wrong.wav"];
    [m_GameLayer.skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeRemoveAllDiamondDyWrong info:nil];
    
    [m_GameLayer.playerGuideLayer updateSkillButtonWithDiamondCount:m_Server->GetNpcDiamondCount()];
}

void BeatDevilsServerDelegate::OnBreakBox(DiamondType changeType)
{
    NSDictionary *info = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSNumber numberWithInt:changeType], @"DiamondType", nil];
    [m_GameLayer.skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeBreakBox info:info];
}

void BeatDevilsServerDelegate::OnRoundStep(float roundTime, float totalTime)
{
    [m_GameLayer setRoundTime:roundTime totalTime:totalTime];
    
    [m_GameLayer.playerGuideLayer updateSkillButtonWithRoundTime:roundTime totalTime:totalTime];
}

void BeatDevilsServerDelegate::OnRoundTimeOver()
{
}

void BeatDevilsServerDelegate::OnNpcFightPlayer(DDamageContext damageContext)
{
    [m_GameLayer playBeatPlayer:damageContext];
    
    [m_GameLayer.playerGuideLayer updateSkillButtonWithCurHp:m_Server->GetCurPlayerHP()
                                                       maxHp:m_Server->GetPlayerPropFromSkill().maxHP];
}

void BeatDevilsServerDelegate::OnPlayerFightNpc(DDamageContext damageContext)
{
    [m_GameLayer playBeatNpc:damageContext];
}

void BeatDevilsServerDelegate::OnStageBegin()
{
    mGameState = kGameContinue;
    
    [m_GameLayer setPlayerHP:m_Server->GetCurPlayerHP() maxHP:m_Server->GetPlayerPropFromSkill().maxHP];
    [m_GameLayer setNpcHP:m_Server->GetCurNpcHP() maxHP:m_Server->GetMaxNpcHP()];
    
    LoadInitData();
    [m_GameLayer cleanupNpcAnimeAndPlayWaitingAnime];
    [m_GameLayer showReadeyGoAnime];
    
    int highScore = [[GameRecordManager instance] getModelHighScore:[GameToolFunc GetGameModel]];
    m_GameLayer.labHighScore.string = [NSString stringWithFormat:@"%d", highScore];
}

void BeatDevilsServerDelegate::OnStageEnd()
{
    m_GameLayer.lastStageScore = m_Server->GetScore();
    m_GameLayer.lastStageHits = mLastHighHits;
    
    // 在这里解锁关卡
    if (m_Server->GetCurrentStage() >= LOCK_STAGE)
    {
        [[GameModelLockManager instance] unlockGameModel:GetUnlockGameModel([GameToolFunc GetGameModel])];
    }
}

void BeatDevilsServerDelegate::OnRoundBegin()
{}
void BeatDevilsServerDelegate::OnRoundEnd()
{}

void BeatDevilsServerDelegate::OnStagePlayerLose()
{
    [[GameRecordManager instance] setModelHighScore:m_Server->GetScore()
                                              model:[GameToolFunc GetGameModel]];
    
    mGameState = kStageLose;
}

void BeatDevilsServerDelegate::OnStagePlayerWin()
{
    [[GameRecordManager instance] setModelHighScore:m_Server->GetScore()
                                              model:[GameToolFunc GetGameModel]];
    
    mGameState = kStageWin;
}

void BeatDevilsServerDelegate::OnStageClear()
{
    mGameState = kGameClear;
}

void BeatDevilsServerDelegate::OnSkillCountChanged(SkillCode skillCode, int skillCount)
{
    if (skillCode == S_RECOVER_HEALTH)
    {
        m_GameLayer.skillPanelLayer.labRecoverHpCount.string = [NSString stringWithFormat:@"%d", skillCount];
        
        //m_GameLayer.skillPanelLayer.btnHp.isEnabled = (skillCount > 0);
        
        [m_GameLayer.playerHpMgr setCurValue:m_Server->GetCurPlayerHP()];
        
        [m_GameLayer.playerGuideLayer updateSkillButtonWithCurHp:m_Server->GetCurPlayerHP()
                                                           maxHp:m_Server->GetPlayerPropFromSkill().maxHP];
    }
    else if (skillCode == S_RECOVER_FURY)
    {
        m_GameLayer.skillPanelLayer.labRecoverFuryCount.string = [NSString stringWithFormat:@"%d", skillCount];
        
        //m_GameLayer.skillPanelLayer.btnFury.isEnabled = (skillCount > 0);
    }
    else if (skillCode == S_RESIST_MISTAKE)
    {
        m_GameLayer.skillPanelLayer.labResistCount.string = [NSString stringWithFormat:@"%d", skillCount];
        
        [BeatDevilsDataManager saveGameData:m_Server->GetGameData()];
    }
    else if (skillCode == S_SKILL_FREEZE_TIME)
    {
        m_GameLayer.skillPanelLayer.btnTime.isEnabled = (skillCount > 0);
    }
    else if (skillCode == S_SKILL_MAGIC)
    {
        m_GameLayer.skillPanelLayer.btnMagic.isEnabled = (skillCount > 0);
    }
    else if (skillCode == S_SKILL_BOOM)
    {
        m_GameLayer.skillPanelLayer.btnBoom.isEnabled = (skillCount > 0);
    }
    else if (skillCode == S_MAX_FURY_UP)
    {
        [m_GameLayer.furyMgr setMaxValue:m_Server->GetMaxFury()];
    }
}

void BeatDevilsServerDelegate::OnMoneyChanged(int money)
{}
void BeatDevilsServerDelegate::OnHitsChanged(int hits)
{
    mLastHighHits = (mLastHighHits > hits) ? mLastHighHits : hits;
    
    [m_GameLayer setHits:hits];
    
    [[GameRecordManager instance] setModelHighHits:hits model:[GameToolFunc GetGameModel]];
}
void BeatDevilsServerDelegate::OnFuryChanged(int fury)
{
    [m_GameLayer setFury:fury];
    
    [m_GameLayer.playerGuideLayer updateSkillButtonWithFury:fury];
}

void BeatDevilsServerDelegate::OnAddScore(int addScore, ScoreType scoreType)
{
    m_GameLayer.labTotalScore.string = [NSString stringWithFormat:@"%d", m_Server->GetScore()];
}

// 技能相关
void BeatDevilsServerDelegate::OnFreezeTimeStart()
{
    m_GameLayer.skillPanelLayer.sprFreeze.visible = YES;
}

void BeatDevilsServerDelegate::OnFreezeTimeStop()
{
    m_GameLayer.skillPanelLayer.sprFreeze.visible = NO;
}

void BeatDevilsServerDelegate::OnFreezeTimeStep(float freezeTime, float totalFreezeTime)
{}
void BeatDevilsServerDelegate::OnUseMagicSkill(Roshambo sameRoshambo, int count)
{
    NSDictionary *info = [NSDictionary dictionaryWithObjectsAndKeys:
                          [NSNumber numberWithInt:sameRoshambo], @"DiamondType",
                          [NSNumber numberWithInt:count], @"Count", nil];
    [m_GameLayer.skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeMagicChangeDiamond info:info];
}

void BeatDevilsServerDelegate::OnBoomFirstDiamond()
{
    [m_GameLayer.skillPanelLayer addAnimeAction:SkillPanelLayerAnimeTypeBoomDiamond info:nil];
    
    [m_GameLayer.playerGuideLayer updateSkillButtonWithDiamondCount:m_Server->GetNpcDiamondCount()];
}

// 技能购买相关
void BeatDevilsServerDelegate::OnBuyFoodSuccess()
{
    m_Server->SetSkillCount(S_RECOVER_HEALTH, 10);
    [BeatDevilsDataManager saveGameData:m_Server->GetGameData()];
}

void BeatDevilsServerDelegate::OnBuyBeerSuccess()
{
    m_Server->SetSkillCount(S_RECOVER_FURY, 10);
    [BeatDevilsDataManager saveGameData:m_Server->GetGameData()];
}

//GameLayer操作函数

void BeatDevilsServerDelegate::InitGame()
{
    mGameState = kGameContinue;
    
    m_Server = CreateBeatDevilsServer(this);
    m_Server->ResetBeatDevilsServer([GameToolFunc GetGameModel]);
    
    NSString *csvPath = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"stage_info.csv"];
    m_Server->LoadStageInfo(csvPath.UTF8String);
    
    // 读取保存数据
    BeatDevilsGameData gameData;
    if ([BeatDevilsDataManager getGameData:&gameData] != NO)
    {
        m_Server->SetGameData(gameData);
    }
    
    [m_GameLayer showStageStartLayer:m_Server->GetCurrentStage() + 1];
    
    if (m_GameLayer.isGuided == NO)
    {
        [m_GameLayer attachPlayerGuide];
    }
}

void BeatDevilsServerDelegate::OnRestartClick()
{
    mGameState = kGameContinue;
    
    m_Server->ResetBeatDevilsServer([GameToolFunc GetGameModel]);
    m_Server->StartNextStage();
}

void BeatDevilsServerDelegate::OnStartNextStageClick()
{
    [m_GameLayer showStageStartLayer:m_Server->GetCurrentStage() + 1];
}

void BeatDevilsServerDelegate::RoundStep(float dTime)
{
    m_Server->RoundStep(dTime);
}

void BeatDevilsServerDelegate::OnStageLoadingCompleted()
{
    m_Server->StartNextStage();
    
    mLastHighHits = 0;
}

void BeatDevilsServerDelegate::OnReadeyGoAnimeOver()
{
    StartNextRound();
    
    // 在某个时刻进行新手引导
    if (m_GameLayer.isGuided == NO)
    {
        id action = [CCSequence actions:
                     [CCDelayTime actionWithDuration:1.0f],
                     [CCCallFunc actionWithTarget:m_GameLayer selector:@selector(startPlayerGuide)],
                     nil];
        [m_GameLayer runAction:action];
        OnSkillClick(S_RECOVER_FURY);
    }
}

void BeatDevilsServerDelegate::OnRoshamboClick(Roshambo roshambo)
{
    if (m_Server->IsRoundStart() == false)
    {
        return;
    }
    
    m_Server->AddPlayerRoshambo(roshambo);
}

void BeatDevilsServerDelegate::OnSkillClick(SkillCode skillCode)
{
    if (skillCode == S_RECOVER_HEALTH
        && m_Server->GetSkillCount(S_RECOVER_HEALTH) == 0)
    {
        [m_GameLayer buyFood];
    }
    else if (skillCode == S_RECOVER_FURY
             && m_Server->GetSkillCount(S_RECOVER_FURY) == 0)
    {
        [m_GameLayer buyBeer];
    }
    else
    {
        m_Server->UseSkill(skillCode);
        
        [BeatDevilsDataManager saveGameData:m_Server->GetGameData()];
    }
}

void BeatDevilsServerDelegate::OnBuySkill(SkillCode skillCode)
{
    m_Server->BuySkill(skillCode);
    
    [BeatDevilsDataManager saveGameData:m_Server->GetGameData()];
}

int BeatDevilsServerDelegate::GetSkillCount(SkillCode skillCode)
{
    return m_Server->GetSkillCount(skillCode);
}

void BeatDevilsServerDelegate::OnAddMoney(int money)
{
    if (money <= 0)
    {
        return;
    }
    
    m_Server->SetMoney(m_Server->GetMoney() + money);
    
    [BeatDevilsDataManager saveGameData:m_Server->GetGameData()];
}

int BeatDevilsServerDelegate::GetCurMoney()
{
    return m_Server->GetMoney();
}

void BeatDevilsServerDelegate::OnBeatAnimeDone()
{
    switch (mGameState)
    {
        case kGameContinue:
        {
            [m_GameLayer moveMenuUp];
        }break;
        case kStageWin:
        {
            [m_GameLayer showBeatAnimeAndNextStageLayer];
        }break;
        case kStageLose:
        {
            [m_GameLayer showBeatAnimeAndGameOverLayer];
        }break;
        case kGameClear:
        {
            [m_GameLayer showBeatAnimeAndClearStageLayer];
        }break;
        default:
            break;
    }
}

void BeatDevilsServerDelegate::OnMenuBack()
{
    if (m_Server->IsStageStart())
    {
        StartNextRound();
    }
}

void BeatDevilsServerDelegate::LoadInitData()
{
    m_GameLayer.skillPanelLayer.labResistCount.string = [NSString stringWithFormat:@"%d", m_Server->GetSkillCount(S_RESIST_MISTAKE)];
    m_GameLayer.skillPanelLayer.labRecoverHpCount.string = [NSString stringWithFormat:@"%d", m_Server->GetSkillCount(S_RECOVER_HEALTH)];
    m_GameLayer.skillPanelLayer.labRecoverFuryCount.string = [NSString stringWithFormat:@"%d", m_Server->GetSkillCount(S_RECOVER_FURY)];
    
    m_GameLayer.skillPanelLayer.btnTime.isEnabled = (m_Server->GetSkillCount(S_SKILL_FREEZE_TIME) > 0);
    m_GameLayer.skillPanelLayer.btnMagic.isEnabled = (m_Server->GetSkillCount(S_SKILL_MAGIC) > 0);
    m_GameLayer.skillPanelLayer.btnBoom.isEnabled = (m_Server->GetSkillCount(S_SKILL_BOOM) > 0);
    
    [m_GameLayer.furyMgr setMaxValue:m_Server->GetMaxFury()];
    [m_GameLayer.furyMgr setCurValue:0];
    
    m_GameLayer.labTotalScore.string = [NSString stringWithFormat:@"%d", m_Server->GetScore()];
}

void BeatDevilsServerDelegate::StartNextRound()
{
    [m_GameLayer addDevilBeforeRoshamboAnime];
    m_Server->StartNextRound();
    [m_GameLayer addDevilAfterRoshamboAnime];
}

NSString *BeatDevilsServerDelegate::GetRoshamboAnimeName(DiamondType diamondType, int curNpcHp, int maxNpcHp)
{
    NSString *result = @"paper-normal.csv";
    switch (diamondType)
    {
        case DiamondTypeNormalPaper:
        {
            result = @"paper-normal.csv";
        }break;
        case DiamondTypeNormalRock:
        {
            result = @"rock-normal.csv";
        }break;
        case DiamondTypeNormalScissors:
        {
            result = @"scissors-normal.csv";
        }break;
        default:
            break;
    }
    
    if (maxNpcHp * 0.33f > curNpcHp)
    {
        return [result stringByReplacingOccurrencesOfString:@"normal" withString:@"fear"];
    }
    else if (maxNpcHp * 0.66f > curNpcHp)
    {
        return [result stringByReplacingOccurrencesOfString:@"normal" withString:@"jump"];
    }
    else
    {
        return result;
    }
}

BeatDevilsModel BeatDevilsServerDelegate::GetUnlockGameModel(BeatDevilsModel model)
{
    if (model == BeatDevilsModelNormal)
    {
        return BeatDevilsModelHard;
    }
    else if (model == BeatDevilsModelHard)
    {
        return BeatDevilsModelExpert;
    }
    else if (model == BeatDevilsModelExpert)
    {
        return BeatDevilsModelHell;
    }
    
    return BeatDevilsModelNormal;
}
