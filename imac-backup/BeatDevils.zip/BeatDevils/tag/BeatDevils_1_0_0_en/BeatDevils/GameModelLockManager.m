//
//  GameModelLockManager.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-23.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "GameModelLockManager.h"

@implementation GameModelLockManager

+ (GameModelLockManager *)instance
{
    static GameModelLockManager *mgr = nil;
    if (mgr == nil)
    {
        mgr = [[GameModelLockManager alloc] init];
    }
    
    return mgr;
}

- (NSString *)getGameModelKey:(BeatDevilsModel)model
{
    return [NSString stringWithFormat:@"BeatDevilsModelKey%d", model];
}

- (BOOL)isUnlocked:(BeatDevilsModel)model
{
    if (model == BeatDevilsModelNormal)
    {
        return YES;
    }
    
    if ([[NSUserDefaults standardUserDefaults] objectForKey:[self getGameModelKey:model]] == nil)
    {
        return NO;
    }
    
    return [[NSUserDefaults standardUserDefaults] boolForKey:[self getGameModelKey:model]];
}

- (void)unlockGameModel:(BeatDevilsModel)model
{
    [[NSUserDefaults standardUserDefaults] setBool:YES forKey:[self getGameModelKey:model]];
}

@end
