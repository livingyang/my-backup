//
//  BeatDevilsDataManager.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-16.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "BeatDevilsDataManager.h"

#define SAVE_GAME_KEY @"SAVE_GAME_KEY"

@implementation BeatDevilsDataManager

+ (void)saveGameData:(BeatDevilsGameData)gameData
{
    NSData *data = [NSData dataWithBytes:&gameData length:sizeof(BeatDevilsGameData)];
    [[NSUserDefaults standardUserDefaults] setObject:data forKey:SAVE_GAME_KEY];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (BOOL)getGameData:(BeatDevilsGameData *)gameData
{
    if (gameData == NULL)
    {
        return NO;
    }
    
    NSData *data = [[NSUserDefaults standardUserDefaults] objectForKey:SAVE_GAME_KEY];
    if (data == nil)
    {
        memset(gameData, 0, sizeof(BeatDevilsGameData));
        gameData->totalSkillCount[S_RECOVER_FURY] = 2;
        gameData->totalSkillCount[S_RECOVER_HEALTH] = 1;
        [BeatDevilsDataManager saveGameData:*gameData];
        return YES;
    }
    
    [data getBytes:gameData length:sizeof(BeatDevilsGameData)];
    
    gameData->totalSkillCount[S_SKILL_BOOM] = 0;
    gameData->totalSkillCount[S_SKILL_MAGIC] = 0;
    gameData->totalSkillCount[S_SKILL_FREEZE_TIME] = 0;
    
    return YES;
}

@end
