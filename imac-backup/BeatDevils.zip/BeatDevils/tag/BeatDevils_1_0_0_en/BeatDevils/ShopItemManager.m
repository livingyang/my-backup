//
//  ShopItemManager.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-23.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "ShopItemManager.h"
#import "InAppPurchaseManager.h"

@implementation ShopItemManager

@synthesize shopItemManagerDelegate;

- (void)onPurchaseTimeOut:(NSString *)itemName
{
    [self.shopItemManagerDelegate onPurchaseTimeOut:itemName];
}

- (BOOL)canBuyShopItem
{
    return [[InAppPurchaseManager instance] canMakePurchases];
}

- (void)purchaseItem:(NSString *)itemName
{
    [[InAppPurchaseManager instance] loadStore:itemName];
    
    [self performSelector:@selector(onPurchaseTimeOut:) withObject:itemName afterDelay:20];
}

- (void)onTransactionSuccess:(NSNotification *)notification
{
    SKPaymentTransaction *transaction = [notification.userInfo objectForKey:kTransactionKey];
    
    [self.shopItemManagerDelegate onPurchaseItem:transaction.payment.productIdentifier success:YES];
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self
                                             selector:@selector(onPurchaseTimeOut:)
                                               object:transaction.payment.productIdentifier];
}

- (void)onTransactionFail:(NSNotification *)notification
{
    SKPaymentTransaction *transaction = [notification.userInfo objectForKey:kTransactionKey];
    
    [self.shopItemManagerDelegate onPurchaseItem:transaction.payment.productIdentifier success:NO];
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self
                                             selector:@selector(onPurchaseTimeOut:)
                                               object:transaction.payment.productIdentifier];
}

- (void)onTransactionCancle:(NSNotification *)notification
{
    [self.shopItemManagerDelegate onPurchaseCancle];
    
    SKPaymentTransaction *transaction = [notification.userInfo objectForKey:kTransactionKey];
    [NSObject cancelPreviousPerformRequestsWithTarget:self
                                             selector:@selector(onPurchaseTimeOut:)
                                               object:transaction.payment.productIdentifier];
}

- (id)initWithShopItemManagerDelegate:(id<ShopItemManagerDelegate>)delegate
{
	self = [super init];
	if (self != nil)
	{
        self.shopItemManagerDelegate = delegate;
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(onTransactionSuccess:)
                                                     name:kInAppPurchaseManagerTransactionSucceededNotification
                                                   object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(onTransactionFail:)
                                                     name:kInAppPurchaseManagerTransactionFailedNotification
                                                   object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(onTransactionCancle:)
                                                     name:kInAppPurchaseManagerTransactionCancleNotification
                                                   object:nil];
	}
    
	return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:kInAppPurchaseManagerTransactionSucceededNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:kInAppPurchaseManagerTransactionFailedNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:kInAppPurchaseManagerTransactionCancleNotification
                                                  object:nil];
	[super dealloc];
}

@end
