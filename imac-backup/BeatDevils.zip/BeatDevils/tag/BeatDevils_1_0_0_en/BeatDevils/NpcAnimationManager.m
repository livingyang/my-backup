//
//  NpcAnimationManager.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-12.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "NpcAnimationManager.h"
#import "AnimeLoader.h"

#define ANIME_PER_SECOND (30.0f)

@implementation NpcAnimationManager

@synthesize animationSprite;

- (void)onActionDone
{
    if (actionArray.count <= 0)
    {
        return;
    }
    
    [self.animationSprite runAction:[actionArray objectAtIndex:0]];
    [actionArray removeObjectAtIndex:0];
}

- (void)checkRunAction
{
    if (actionArray.count == 1 && self.animationSprite.numberOfRunningActions == 0)
    {
        [self onActionDone];
    }
}

- (void)addSpriteAction:(NSString *)animationName
                 target:(id)target
               callback:(SEL)sel
                  delay:(ccTime)delay
{
    CCAnimation *animation = [[AnimeLoader instance] getAnimationFromFileName:animationName];
    //CCAnimation *animation = [dirAndAnimationDic objectForKey:animationName];
    id action = [CCAnimate actionWithDuration:(float)animation.frames.count / ANIME_PER_SECOND
                                    animation:animation
                         restoreOriginalFrame:NO];
    
    [actionArray addObject:[CCSequence actions:
                            [CCDelayTime actionWithDuration:delay],
                            action,
                            [CCCallFunc actionWithTarget:target selector:sel],
                            [CCCallFunc actionWithTarget:self selector:@selector(onActionDone)],
                            nil]];
    
    [self checkRunAction];
}

- (void)addFakeCallback
{}

- (void)addSpriteAction:(NSString *)animationName
                  delay:(ccTime)delay
{
    [self addSpriteAction:animationName target:self callback:@selector(addFakeCallback) delay:delay];
}

- (void)pauseActions
{
    [self.animationSprite pauseSchedulerAndActions];
}

- (void)resumeActions
{
    [self.animationSprite resumeSchedulerAndActions];
}

- (void)cleanSpriteActions
{
    [self.animationSprite stopAllActions];
    [actionArray removeAllObjects];
}

- (id)init
{
	self = [super init];
	if (self != nil)
	{
        actionArray = [[NSMutableArray alloc] init];
	}
	return self;
}

- (void)dealloc
{
    [actionArray release];
    
	[super dealloc];
}

@end
