//
//  HpSpriteBarManager.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-26.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "HpSpriteBarManager.h"

const float GREEN_PER = (0.67f);
const float YELLOW_PER = (0.34f);
// RED_PER = (0.00f);

@implementation HpSpriteBarManager

- (void)updateData
{
    [super updateData];
    
    if (curValue / maxValue > GREEN_PER)
    {
        barSprite.color = ccGREEN;
    }
    else if (curValue / maxValue > YELLOW_PER)
    {
        barSprite.color = ccYELLOW;
    }
    else
    {
        barSprite.color = ccRED;
    }
}

@end
