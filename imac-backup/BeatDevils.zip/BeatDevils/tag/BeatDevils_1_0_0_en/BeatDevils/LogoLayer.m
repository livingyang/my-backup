//
//  LogoLayer.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-29.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import "LogoLayer.h"
#import "MainLayer.h"
#import <MediaPlayer/MediaPlayer.h>

@implementation LogoLayer
@synthesize moviePlayerController;

+ (CCScene *)scene
{
	CCScene *scene = [CCScene node];
	[scene addChild:[self node]];
	
	return scene;
}

- (void) moviePlayBackDidFinish:(NSNotification*)notification
{
    NSNumber *reason = [[notification userInfo] objectForKey:MPMoviePlayerPlaybackDidFinishReasonUserInfoKey]; 
	
    if ([reason integerValue] == MPMovieFinishReasonPlaybackEnded)
    {
        
        [self.moviePlayerController.view removeFromSuperview];
        [[CCDirector sharedDirector] replaceScene:[MainLayer scene]];
    }
    else
    {
        NSLog(@"notification = %@", reason);
    }
}

- (void)playMovie:(NSString *)moviePath
{
	[[NSNotificationCenter defaultCenter] addObserver:self 
                                             selector:@selector(moviePlayBackDidFinish:) 
                                                 name:MPMoviePlayerPlaybackDidFinishNotification 
                                               object:nil];
    
    self.moviePlayerController = [[[MPMoviePlayerController alloc]
                                   initWithContentURL:[NSURL fileURLWithPath:moviePath]] autorelease];
    
    [self.moviePlayerController setMovieSourceType:MPMovieSourceTypeFile];
    [[CCDirector sharedDirector].openGLView addSubview:self.moviePlayerController.view];    

    self.moviePlayerController.view.frame = [CCDirector sharedDirector].openGLView.frame;
    self.moviePlayerController.controlStyle = MPMovieControlStyleNone;
    [self.moviePlayerController play];
}

- (id)init
{
	self = [super init];
	if (self != nil)
	{
        //[[CCDirector sharedDirector] performSelector:@selector(replaceScene:) withObject:[MainLayer scene] afterDelay:0.1f];
		NSString *moviePath = [[NSBundle mainBundle] pathForResource:@"logo" ofType:@"mp4"];
        [self playMovie:moviePath];
	}
	return self;
}

- (void)dealloc
{
    self.moviePlayerController = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:MPMoviePlayerPlaybackDidFinishNotification
                                                  object:nil];
	[super dealloc];
}

@end
