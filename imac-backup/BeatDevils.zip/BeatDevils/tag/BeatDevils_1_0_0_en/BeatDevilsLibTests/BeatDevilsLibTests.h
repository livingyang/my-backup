//
//  BeatDevilsLibTests.h
//  BeatDevilsLibTests
//
//  Created by 青宝 中 on 11-11-24.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

class IBeatDevilsServer;
class BeatDevilsServerDelegate;

@interface BeatDevilsLibTests : SenTestCase
{
    IBeatDevilsServer *server;
    //BeatDevilsServerDelegate *delegate;
}

@end
