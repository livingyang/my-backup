//
//  BeatDevilsDiamondTests.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-20.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "BeatDevilsDiamondTests.h"
#import "BeatDevilsDiamond.h"

@implementation BeatDevilsDiamondTests

- (void)testGetDiamondResult
{
    STAssertTrue(GetDiamondResult(RoshamboPaper, DiamondTypeNormalPaper) == RoshamboResultDraw, @"");
    STAssertTrue(GetDiamondResult(RoshamboPaper, DiamondTypeNormalRock) == RoshamboResultWin, @"");
    STAssertTrue(GetDiamondResult(RoshamboRock, DiamondTypeNormalScissors) == RoshamboResultWin, @"");
    
    STAssertTrue(GetDiamondResult(RoshamboRock, DiamondTypeReversePaper) == RoshamboResultWin, @"");
    STAssertTrue(GetDiamondResult(RoshamboScissors, DiamondTypeReverseRock) == RoshamboResultWin, @"");
    
    STAssertTrue(GetDiamondResult(RoshamboPaper, DiamondTypeBox1Rock) == RoshamboResultWin, @"");
    STAssertTrue(GetDiamondResult(RoshamboPaper, DiamondTypeBox1Paper) == RoshamboResultDraw, @"");
    STAssertTrue(GetDiamondResult(RoshamboPaper, DiamondTypeBox2Paper) == RoshamboResultDraw, @"");
}

- (void)testGetRoshamboFromDiamondTypeResult
{
    STAssertTrue(GetRoshamboFromDiamondTypeResult(DiamondTypeNormalRock, RoshamboResultWin) == RoshamboPaper, @"");
    STAssertTrue(GetRoshamboFromDiamondTypeResult(DiamondTypeNormalPaper, RoshamboResultDraw) == RoshamboPaper, @"");
    STAssertTrue(GetRoshamboFromDiamondTypeResult(DiamondTypeNormalRock, RoshamboResultLost) == RoshamboScissors, @"");
    
    STAssertTrue(GetRoshamboFromDiamondTypeResult(DiamondTypeReversePaper, RoshamboResultWin) == RoshamboRock, @"");
    STAssertTrue(GetRoshamboFromDiamondTypeResult(DiamondTypeReverseRock, RoshamboResultWin) == RoshamboScissors, @"");
    
    STAssertTrue(GetRoshamboFromDiamondTypeResult(DiamondTypeStar, RoshamboResultWin) == RoshamboScissors, @"");
}

- (void)testCheckDiamondType
{
    STAssertTrue(IsNormalDiamond(DiamondTypeNormalRock) == true, @"");
    STAssertTrue(IsNormalDiamond(DiamondTypeNormalPaper) == true, @"");
    STAssertTrue(IsNormalDiamond(DiamondTypeReverseRock) == false, @"");
    STAssertTrue(IsNormalDiamond(DiamondTypeBox2Scissors) == false, @"");
    STAssertTrue(IsNormalDiamond(DiamondTypeStar) == false, @"");
    
    STAssertTrue(IsReverseDiamond(DiamondTypeReverseScissors) == true, @"");
    STAssertTrue(IsReverseDiamond(DiamondTypeReverseRock) == true, @"");
    STAssertTrue(IsReverseDiamond(DiamondTypeBox2Paper) == false, @"");
    STAssertTrue(IsReverseDiamond(DiamondTypeNormalRock) == false, @"");
    STAssertTrue(IsReverseDiamond(DiamondTypeStar) == false, @"");
    
    STAssertTrue(IsBox1Diamond(DiamondTypeBox1Paper) == true, @"");
    STAssertTrue(IsBox1Diamond(DiamondTypeBox1Rock) == true, @"");
    STAssertTrue(IsBox1Diamond(DiamondTypeBox2Paper) == false, @"");
    STAssertTrue(IsBox1Diamond(DiamondTypeNormalRock) == false, @"");
    STAssertTrue(IsBox1Diamond(DiamondTypeStar) == false, @"");
    
    STAssertTrue(IsBox2Diamond(DiamondTypeBox2Paper) == true, @"");
    STAssertTrue(IsBox2Diamond(DiamondTypeBox2Scissors) == true, @"");
    STAssertTrue(IsBox2Diamond(DiamondTypeBox1Paper) == false, @"");
    STAssertTrue(IsBox2Diamond(DiamondTypeNormalRock) == false, @"");
    STAssertTrue(IsBox2Diamond(DiamondTypeStar) == false, @"");
}

@end
