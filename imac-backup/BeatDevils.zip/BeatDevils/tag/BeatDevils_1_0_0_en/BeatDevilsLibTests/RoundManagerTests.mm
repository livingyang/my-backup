//
//  RoundManagerTests.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-5.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "RoundManagerTests.h"

#import "RoundManager.h"

class RoundManagerDelegate : public IRoundManagerDelegate
{
public:
    Roshambo lastPlayerRoshambo;
    DiamondType lastNpcDiamond;
    
    RoshamboResult lastResult;
    
    DiamondType lastSameDiamond;
    int lastCount;
    
    bool playerRoshamboFullCalled;
    
    bool removeFirstDiamondCalled;
    bool boomFirstDiamondCalled;
    DiamondType lastBoxChangeDiamondType;
    
public:
    RoundManagerDelegate():
    playerRoshamboFullCalled(false),
    removeFirstDiamondCalled(false),
    boomFirstDiamondCalled(false),
    lastBoxChangeDiamondType(DiamondTypeInvalid)
    {}
    
    virtual void OnAddPlayerRoshambo(Roshambo roshambo) { lastPlayerRoshambo = roshambo; }
    virtual void OnAddNpcRoshambo(DiamondType diamondType) { lastNpcDiamond = diamondType; }
    
    virtual void OnPlayerRoshamboFull() { playerRoshamboFullCalled = true; }
    virtual void OnPlayerVsNpc(RoshamboResult result)
    {
        lastResult = result;
    }
    
    virtual void OnRemoveFirstDiamond()
    {
        removeFirstDiamondCalled = true;
    }
    
    virtual void OnChangeDiamondToSame(DiamondType sameDiamond, int count)
    {
        lastSameDiamond = sameDiamond;
        lastCount = count;
    }
    
    virtual void OnBoomFirstDiamond()
    {
        boomFirstDiamondCalled = true;
    }
    
    virtual void OnBreakBox(DiamondType changeDiamondType)
    {
        lastBoxChangeDiamondType = changeDiamondType;
    }
};

@implementation RoundManagerTests

- (void)setUp
{
    delegate = new RoundManagerDelegate();
}

- (void)tearDown
{
    delete delegate;
}

#pragma mark -
#pragma mark 测试回合管理

- (void)testRoundManager
{
    const int count = 5;
    DiamondType npcDiamondArray[count] =
    {
        DiamondTypeNormalPaper,
        DiamondTypeNormalPaper,
        DiamondTypeNormalRock,
        DiamondTypeNormalScissors,
        DiamondTypeNormalPaper,
    };
    
    RoundManager roundManager(NULL);
    
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(roundManager.GetCurNpcDiamond() == RoshamboInvalid, @"");
    
    STAssertTrue(roundManager.Restart(npcDiamondArray, 5) == true, @"");
    STAssertTrue(roundManager.GetNpcDiamondCount() == 5, @"");
    
    STAssertTrue(roundManager.GetCurNpcDiamond() == DiamondTypeNormalPaper, @"");
    
    roundManager.AddPlayerRoshambo(RoshamboPaper);
    STAssertTrue(roundManager.GetNpcDiamondCount() == 4, @"");
    STAssertTrue(roundManager.GetCurNpcDiamond() == DiamondTypeNormalPaper, @"");
    
    roundManager.AddPlayerRoshambo(RoshamboRock);
    STAssertTrue(roundManager.GetCurNpcDiamond() == DiamondTypeNormalRock, @"");
    
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    roundManager.AddPlayerRoshambo(RoshamboPaper);
    STAssertTrue(roundManager.GetNpcDiamondCount() == 1, @"");
    STAssertTrue(roundManager.GetCurNpcDiamond() == DiamondTypeNormalPaper, @"");
    
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(roundManager.GetNpcDiamondCount() == 0, @"");
    STAssertTrue(roundManager.GetCurNpcDiamond() == RoshamboInvalid, @"");
}

- (void)testRoundManagerDelegate
{
    RoundManager roundManager(delegate);
    
    const int count = 5;
    DiamondType npcDiamondArray[count] =
    {
        DiamondTypeNormalPaper,
        DiamondTypeNormalPaper,
        DiamondTypeNormalRock,
        DiamondTypeNormalScissors,
        DiamondTypeNormalPaper,
    };
    
    roundManager.Restart(npcDiamondArray, count);
    STAssertTrue(delegate->lastNpcDiamond == DiamondTypeNormalPaper, @"");
    STAssertTrue(roundManager.GetNpcDiamondCount() == 5, @"");
    
    STAssertTrue(delegate->removeFirstDiamondCalled == false, @"");
    roundManager.AddPlayerRoshambo(RoshamboPaper);
    STAssertTrue(delegate->removeFirstDiamondCalled == true, @"");
    STAssertTrue(delegate->lastPlayerRoshambo == RoshamboPaper, @"");
    STAssertTrue(delegate->lastResult == RoshamboResultDraw, @"");
    STAssertTrue(roundManager.GetNpcDiamondCount() == 4, @"");
    
    roundManager.AddPlayerRoshambo(RoshamboRock);
    STAssertTrue(delegate->lastPlayerRoshambo == RoshamboRock, @"");
    STAssertTrue(delegate->lastResult == RoshamboResultLost, @"");
    STAssertTrue(roundManager.GetNpcDiamondCount() == 3, @"");
    
    roundManager.AddPlayerRoshambo(RoshamboPaper);
    roundManager.AddPlayerRoshambo(RoshamboPaper);
    
    STAssertTrue(delegate->playerRoshamboFullCalled == false, @"");
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->playerRoshamboFullCalled == true, @"");
    STAssertTrue(delegate->lastPlayerRoshambo == RoshamboScissors, @"");
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    STAssertTrue(roundManager.GetNpcDiamondCount() == 0, @"");
}

- (void)testSetSameRoshambo
{
    RoundManager roundManager(delegate);
    
    const int count = 11;
    DiamondType npcRoshamboArray[count] =
    {
        DiamondTypeNormalPaper,
        DiamondTypeNormalPaper,
        DiamondTypeNormalRock,
        DiamondTypeNormalScissors,
        DiamondTypeNormalPaper,
        DiamondTypeNormalScissors,
        DiamondTypeNormalScissors,
        DiamondTypeNormalScissors,
        DiamondTypeNormalScissors,
        DiamondTypeNormalScissors,
        DiamondTypeNormalScissors,
    };
    
    roundManager.Restart(npcRoshamboArray, count);
    roundManager.ChangeRoshamboToSame(6);
    STAssertTrue(delegate->lastSameDiamond == DiamondTypeNormalPaper, @"");
    STAssertTrue(delegate->lastCount == 6, @"");
    
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
}

- (void)testReverseDiamond
{
    RoundManager roundManager(delegate);
    
    const int count = 5;
    DiamondType npcDiamondArray[count] =
    {
        DiamondTypeReverseRock,
        DiamondTypeReverseScissors,
        DiamondTypeReverseRock,
        DiamondTypeReverseRock,
        DiamondTypeReversePaper,
    };
    
    roundManager.Restart(npcDiamondArray, count);
    
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult != RoshamboResultWin, @"");
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    roundManager.AddPlayerRoshambo(RoshamboRock);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
}

- (void)testStarDiamond
{
    RoundManager roundManager(delegate);
    
    const int count = 5;
    DiamondType npcDiamondArray[count] =
    {
        DiamondTypeStar,
        DiamondTypeStar,
        DiamondTypeStar,
        DiamondTypeStar,
        DiamondTypeStar,
    };
    
    roundManager.Restart(npcDiamondArray, count);
    
    STAssertTrue(delegate->removeFirstDiamondCalled == false, @"");
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->removeFirstDiamondCalled == true, @"");
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    roundManager.AddPlayerRoshambo(RoshamboPaper);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    roundManager.AddPlayerRoshambo(RoshamboRock);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
}

- (void)testBox1Diamond
{
    RoundManager roundManager(delegate);
    
    const int count = 5;
    DiamondType npcDiamondArray[count] =
    {
        DiamondTypeBox1Rock,
        DiamondTypeBox1Paper,
        DiamondTypeBox2Paper,
        DiamondTypeBox2Scissors,
        DiamondTypeBox1Rock,
    };
    
    roundManager.Restart(npcDiamondArray, count);
    roundManager.SetBox1OpenDiamondList((DiamondType [1]){ DiamondTypeNormalPaper }, 1);
    
    STAssertTrue(roundManager.GetCurNpcDiamond() == DiamondTypeBox1Rock, @"");
    roundManager.AddPlayerRoshambo(RoshamboPaper);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");    
    STAssertTrue(roundManager.GetCurNpcDiamond() == DiamondTypeNormalPaper, @"");
    STAssertTrue(delegate->removeFirstDiamondCalled == false, @"");
    
    STAssertTrue(delegate->lastBoxChangeDiamondType == DiamondTypeNormalPaper, @"");
    
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");    
    STAssertTrue(roundManager.GetCurNpcDiamond() == DiamondTypeBox1Paper, @"");
    
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");    
    STAssertTrue(roundManager.GetCurNpcDiamond() == DiamondTypeNormalPaper, @"");
}

- (void)testBox2Diamond
{
    RoundManager roundManager(delegate);
    
    const int count = 5;
    DiamondType npcDiamondArray[count] =
    {
        DiamondTypeBox2Rock,
        DiamondTypeBox1Paper,
        DiamondTypeBox2Paper,
        DiamondTypeBox2Scissors,
        DiamondTypeBox1Rock,
    };
    
    roundManager.Restart(npcDiamondArray, count);
    roundManager.SetBox2OpenDiamondList((DiamondType [1]){ DiamondTypeReverseRock }, 1);
    
    STAssertTrue(roundManager.GetCurNpcDiamond() == DiamondTypeBox2Rock, @"");
    roundManager.AddPlayerRoshambo(RoshamboPaper);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");    
    STAssertTrue(roundManager.GetCurNpcDiamond() == DiamondTypeReverseRock, @"");
    
    STAssertTrue(delegate->lastBoxChangeDiamondType == DiamondTypeReverseRock, @"");
    
    roundManager.AddPlayerRoshambo(RoshamboScissors);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");    
    STAssertTrue(roundManager.GetCurNpcDiamond() == DiamondTypeBox1Paper, @"");
}

- (void)testBoomDiamond
{
    RoundManager roundManager(delegate);
    
    const int count = 5;
    DiamondType npcDiamondArray[count] =
    {
        DiamondTypeBox2Rock,
        DiamondTypeBox1Paper,
        DiamondTypeBox2Paper,
        DiamondTypeBox2Scissors,
        DiamondTypeBox1Rock,
    };
    
    roundManager.Restart(npcDiamondArray, count);
    
    STAssertTrue(delegate->boomFirstDiamondCalled == false, @"");
    roundManager.BoomOneDiamond();
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");  
    STAssertTrue(delegate->boomFirstDiamondCalled == true, @"");
    STAssertTrue(roundManager.GetNpcDiamondCount() == 4, @"");
}

@end
