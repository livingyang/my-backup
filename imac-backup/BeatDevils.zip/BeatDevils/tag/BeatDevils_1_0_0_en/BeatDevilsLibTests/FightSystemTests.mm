//
//  FightSystemTests.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-3.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "FightSystemTests.h"

#import "FightSystem.h"

class FightSystemDelegate : public IFightSystemDelegate
{
public:
    RoshamboResult lastResult;
    
    DDamageContext lastDamage;
    
    int lastSkillCode;
    int lastSkillCount;
    
    float lastFreezeTime;
    int lastMagicCount;
    int lastBoomCount;
    
    bool playerDownCalled;
    bool npcDownCalled;
    
    int lastFury;
    int lastHits;
    
public:
    
    // 回合判定回调
    virtual void OnAddFightSystemRoshamboResult(RoshamboResult result) { lastResult = result; }
    
    // 攻击回调
    virtual void OnPlayerFightNpc(DDamageContext damageContext) { lastDamage = damageContext; }
    virtual void OnNpcFightPlayer(DDamageContext damageContext) { lastDamage = damageContext; }
    
    // 玩家被击倒或npc被击倒
    virtual void OnPlayerDown() { playerDownCalled = true; }
    virtual void OnNpcDown() { npcDownCalled = true; }
    
    // 技能使用回调
    virtual void OnSkillCountChanged(SkillCode skillCode, int skillCount)
    {
        lastSkillCode = skillCode;
        lastSkillCount = skillCount;
    }
    
    virtual void OnUseSkillFreezeTime(float freezeTime) { lastFreezeTime = freezeTime; }
    virtual void OnUseSkillMagic(int magicCount) { lastMagicCount = magicCount; }
    virtual void OnUseSkillBoom(int boomCount) { lastBoomCount = boomCount; }
    
    // 信息改变函数
    virtual void OnFuryChanged(int fury) { lastFury = fury; }
    virtual void OnHitsChanged(int hits) { lastHits = hits; }
    
    FightSystemDelegate():
    playerDownCalled(false),
    npcDownCalled(false),
    lastSkillCode(0),
    lastSkillCount(0),
    lastFreezeTime(0),
    lastMagicCount(0),
    lastBoomCount(0)
    {}
};

@implementation FightSystemTests

- (void)setUp
{
    delegate = new FightSystemDelegate();
}

- (void)tearDown
{
    delete delegate;
}

#pragma mark -
#pragma mark 测试攻击运算

- (void)damageContextTest:(DDamageContext)context1 context2:(DDamageContext)context2
{
    STAssertTrue(context1.isPlayerUnderAttack == context2.isPlayerUnderAttack, @"");
    STAssertTrue(context1.attackCount == context2.attackCount, @"");
    STAssertTrue(context1.attackDamage == context2.attackDamage, @"");
}
//
//- (void)testFightSimulator
//{
//    FightSystem fightSimulator(NULL);
//    fightSimulator.SetPlayerProp((DRoleProperty){100, 10, 0});
//    fightSimulator.SetNpcProp((DRoleProperty){100, 10, 5});
//    
//    STAssertTrue(fightSimulator.GetCurPlayerHP() == 100, @"");
//    STAssertTrue(fightSimulator.GetCurNpcHP() == 100, @"");
//    
//    [self damageContextTest:fightSimulator.PlayerAttack(1) context2:(DDamageContext){true, 1, 5}];
//    
//    STAssertTrue(fightSimulator.GetCurNpcHP() == 95, @"");
//    
//    [self damageContextTest:fightSimulator.NpcAttack(5) context2:(DDamageContext){false, 5, 50}];
//    
//    STAssertTrue(fightSimulator.GetCurPlayerHP() == 50, @"");
//    
//    [self damageContextTest:fightSimulator.PlayerAttack(10) context2:(DDamageContext){true, 10, 50}];
//    STAssertTrue(fightSimulator.GetCurNpcHP() == 45, @"");
//}

- (void)testSkillInfo
{
    FightSystem fightSystem(NULL);
    
    STAssertTrue(fightSystem.GetSkillCount(S_ATTACK_UP) == 0, @"");
    
    fightSystem.SetSkillCount(S_ATTACK_UP, 4);
    STAssertTrue(fightSystem.GetSkillCount(S_ATTACK_UP) == 4, @"");
    
    fightSystem.SetSkillCount(S_ATTACK_UP, 20);
    STAssertTrue(fightSystem.GetSkillCount(S_ATTACK_UP) == 4, @"");
    
    
    STAssertTrue(fightSystem.GetSkillCount(S_RECOVER_FURY) == 0, @"");
    
    fightSystem.SetSkillCount(S_RECOVER_FURY, 4);
    STAssertTrue(fightSystem.GetSkillCount(S_RECOVER_FURY) == 4, @"");
    
    fightSystem.SetSkillCount(S_RECOVER_FURY, 20);
    STAssertTrue(fightSystem.GetSkillCount(S_RECOVER_FURY) == 20, @"");
    
    fightSystem.SetSkillCount(S_RECOVER_FURY, 99);
    STAssertTrue(fightSystem.GetSkillCount(S_RECOVER_FURY) == 99, @"");
    
    fightSystem.SetSkillCount(S_RECOVER_FURY, 100);
    STAssertTrue(fightSystem.GetSkillCount(S_RECOVER_FURY) == 99, @"");
}

- (void)testUseFuryRecover
{
    FightSystem fightSystem(NULL);
    
    fightSystem.SetSkillCount(S_RECOVER_FURY, 4);
    fightSystem.UseSkill(S_RECOVER_FURY);
    STAssertTrue(fightSystem.GetSkillCount(S_RECOVER_FURY) == 3, @"");
    fightSystem.SetSkillCount(S_RECOVER_HEALTH, 4);
    fightSystem.UseSkill(S_RECOVER_HEALTH);
    STAssertTrue(fightSystem.GetSkillCount(S_RECOVER_HEALTH) == 3, @"");
    fightSystem.SetSkillCount(S_RESIST_MISTAKE, 4);
    fightSystem.UseSkill(S_RESIST_MISTAKE);
    STAssertTrue(fightSystem.GetSkillCount(S_RESIST_MISTAKE) == 3, @"");
}

- (void)testUseFurySkill
{
    FightSystem fightSystem(NULL);
    
    STAssertTrue(fightSystem.GetFury() == 0, @"");
    STAssertTrue(fightSystem.GetMaxFury() == MAX_BASE_FURY, @"");
    
    fightSystem.SetSkillCount(S_MAX_FURY_UP, 2);
    STAssertTrue(fightSystem.GetMaxFury() == MAX_BASE_FURY, @"");
    fightSystem.SetSkillUpValue(S_MAX_FURY_UP, 50);
    STAssertTrue(fightSystem.GetMaxFury() == MAX_BASE_FURY + 100, @"");
    
    fightSystem.SetSkillCount(S_RECOVER_FURY, 1);
    fightSystem.UseSkill(S_RECOVER_FURY);
    STAssertTrue(fightSystem.GetFury() == fightSystem.GetMaxFury(), @"");
    
    fightSystem.SetSkillCostFury(S_SKILL_FREEZE_TIME, 50);
    fightSystem.UseSkill(S_SKILL_FREEZE_TIME);
    STAssertTrue(fightSystem.GetFury() == 550, @"");
}

- (void)testIncreaseFury
{
    FightSystem fightSystem(NULL);
    fightSystem.SetPlayerProp((DRoleProperty){5000, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){5000, 100, 0});
    
    fightSystem.SetSkillCostFury(S_SKILL_FREEZE_TIME, 50);
    fightSystem.SetSkillCostFury(S_SKILL_MAGIC, 70);
    fightSystem.SetSkillCostFury(S_SKILL_BOOM, 90);
    
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_FREEZE_TIME) == 0, @"");
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_MAGIC) == 0, @"");
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_BOOM) == 0, @"");
    
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetFury() == 5, @"");//+5
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetFury() == 15, @"");//+10
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetFury() == 30, @"");//+15
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetFury() == 50, @"");//+20
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_BOOM) == 0, @"");
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_FREEZE_TIME) == 1, @"");
    
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetFury() == 75, @"");//+25
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_BOOM) == 0, @"");
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_MAGIC) == 1, @"");
    
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetFury() == 100, @"");//+25
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_BOOM) == 1, @"");
    
    fightSystem.SetSkillCostFury(S_SKILL_BOOM, 101);
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_BOOM) == 0, @"");
    
    fightSystem.UseSkill(S_SKILL_FREEZE_TIME);
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_FREEZE_TIME) == 1, @"");
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_MAGIC) == 0, @"");
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_BOOM) == 0, @"");
    
    fightSystem.UseSkill(S_SKILL_FREEZE_TIME);
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_FREEZE_TIME) == 0, @"");
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_MAGIC) == 0, @"");
    STAssertTrue(fightSystem.GetSkillCount(S_SKILL_BOOM) == 0, @"");
}

- (void)testUseSkill
{
    FightSystem fightSystem(NULL);
    
    fightSystem.SetSkillCount(S_RECOVER_FURY, 4);
    fightSystem.UseSkill(S_RECOVER_FURY);
    
    fightSystem.SetSkillCostFury(S_SKILL_FREEZE_TIME, 50);
    fightSystem.SetSkillCostFury(S_SKILL_MAGIC, 70);
    fightSystem.SetSkillCostFury(S_SKILL_BOOM, 90);
    
    STAssertTrue(fightSystem.GetFury() == 500, @"");
    
    fightSystem.UseSkill(S_SKILL_FREEZE_TIME);
    STAssertTrue(fightSystem.GetFury() == 450, @"");
    fightSystem.UseSkill(S_SKILL_MAGIC);
    STAssertTrue(fightSystem.GetFury() == 380, @"");
    fightSystem.UseSkill(S_SKILL_BOOM);
    STAssertTrue(fightSystem.GetFury() == 290, @"");
}

- (void)testSetRoleProp
{
    FightSystem fightSystem(NULL);
    
    fightSystem.SetPlayerProp((DRoleProperty){1000, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){1800, 100, 0});
    
    STAssertTrue(fightSystem.GetCurPlayerHP() == 1000, @"");
    STAssertTrue(fightSystem.GetCurNpcHP() == 1800, @"");
}

- (void)testGetPlayerPropFromSkill
{
    FightSystem fightSystem(NULL);
    fightSystem.SetSkillUpValue(S_ATTACK_UP, 10);
    fightSystem.SetSkillUpValue(S_DEFENSE_UP, 5);
    
    fightSystem.SetPlayerProp((DRoleProperty){1000, 100, 0});
    
    STAssertTrue(fightSystem.GetPlayerPropFromSkill().attack == 100, @"");
    fightSystem.SetSkillCount(S_ATTACK_UP, 4);
    STAssertTrue(fightSystem.GetPlayerPropFromSkill().attack == 140, @"");
    
    STAssertTrue(fightSystem.GetPlayerPropFromSkill().defense == 0, @"");
    fightSystem.SetSkillCount(S_DEFENSE_UP, 7);
    STAssertTrue(fightSystem.GetPlayerPropFromSkill().defense == 35, @"");
}

- (void)testAddRoshamboResult
{
    FightSystem fightSystem(NULL);
    fightSystem.SetPlayerProp((DRoleProperty){1000, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){1800, 100, 0});
    
    fightSystem.AddRoshamboResult(RoshamboResultWin);
    STAssertTrue(fightSystem.GetCurPlayerHP() == 1000, @"");
    fightSystem.AddRoshamboResult(RoshamboResultDraw);
    STAssertTrue(fightSystem.GetCurPlayerHP() == 400, @"");
    fightSystem.AddRoshamboResult(RoshamboResultLost);
    STAssertTrue(fightSystem.GetCurPlayerHP() == 0, @"");
}

- (void)testCriticalRate
{
    FightSystem fightSystem(NULL);
    
    // 设置暴击率
    STAssertTrue(fightSystem.GetBaseCriticalRate() == 0, @"");
    STAssertTrue(fightSystem.GetCriticalRate() == 0, @"");
    
    fightSystem.SetBaseCriticalRate(20);
    STAssertTrue(fightSystem.GetBaseCriticalRate() == 20, @"");
    
    fightSystem.SetSkillUpValue(S_CRITICAL_RATE_UP, 10);
    fightSystem.SetSkillCount(S_CRITICAL_RATE_UP, 4);
    STAssertTrue(fightSystem.GetCriticalRate() == 60, @"");
    fightSystem.SetSkillCount(S_CRITICAL_RATE_UP, 8);
    STAssertTrue(fightSystem.GetCriticalRate() == 100, @"");
}

- (void)testNoCriticalRateAttack
{
    FightSystem fightSystem(NULL);
    fightSystem.SetPlayerProp((DRoleProperty){1000, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){3000, 100, 0});
    
    // 攻击一次
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 2900, @"");
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 2800, @"");
    
    // 连击大于3次，攻击三次
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 2500, @"");
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 2200, @"");
    
    // 连击大于5次，攻击五次，不过没有暴击率，仍然打三次
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 1900, @"");
}

- (void)testOnAllTurnEnd
{
    FightSystem fightSystem(NULL);
    fightSystem.SetPlayerProp((DRoleProperty){1000, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){3000, 100, 0});
    
    fightSystem.SetBaseCriticalRate(20);
    fightSystem.SetSkillUpValue(S_CRITICAL_RATE_UP, 10);
    fightSystem.SetSkillCount(S_CRITICAL_RATE_UP, 8);
    STAssertTrue(fightSystem.GetCriticalRate() == 100, @"");
    
    // 攻击一次
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 2900, @"");
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 2800, @"");
    
    // 连击大于3次，攻击三次
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 2500, @"");
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 2200, @"");
    
    // 连击大于5次，攻击五次
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 1700, @"");
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 1200, @"");
    
    // 连击断开
    fightSystem.AddRoshamboResult(RoshamboResultLost);
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 1100, @"");
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 1000, @"");
    
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 700, @"");
    
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 400, @"");
    fightSystem.AddRoshamboResult(RoshamboResultLost);
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetCurNpcHP() == 300, @"");
}

- (void)testHits
{
    FightSystem fightSystem(NULL);
    fightSystem.SetPlayerProp((DRoleProperty){1000, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){3000, 100, 0});
    
    STAssertTrue(fightSystem.GetHits() == 0, @"");
    fightSystem.AddRoshamboResult(RoshamboResultWin);
    STAssertTrue(fightSystem.GetHits() == 1, @"");
    
    fightSystem.AddRoshamboResult(RoshamboResultWin);
    fightSystem.AddRoshamboResult(RoshamboResultWin);
    STAssertTrue(fightSystem.GetHits() == 3, @"");
    
    fightSystem.AddRoshamboResult(RoshamboResultDraw);
    STAssertTrue(fightSystem.GetHits() == 0, @"");
    
    fightSystem.AddRoshamboResult(RoshamboResultWin);
    fightSystem.AddRoshamboResult(RoshamboResultWin);
    STAssertTrue(fightSystem.GetHits() == 2, @"");
    
    fightSystem.OnRoundTimeOver();
    STAssertTrue(fightSystem.GetHits() == 0, @"");
}

- (void)testPlayerWinCombo
{
    FightSystem fightSystem(NULL);
    fightSystem.SetPlayerProp((DRoleProperty){1000, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){3000, 100, 0});
    
    STAssertTrue(fightSystem.GetPlayerWinCombo() == 0, @"");
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetPlayerWinCombo() == 1, @"");
    
    fightSystem.OnAllTurnEnd();
    fightSystem.OnAllTurnEnd();
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetPlayerWinCombo() == 4, @"");
    
    fightSystem.OnRoundTimeOver();
    STAssertTrue(fightSystem.GetPlayerWinCombo() == 0, @"");
    
    fightSystem.OnAllTurnEnd();
    fightSystem.OnAllTurnEnd();
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetPlayerWinCombo() == 3, @"");
}

- (void)testOnRoundTimeOver
{
    FightSystem fightSystem(NULL);
    fightSystem.SetPlayerProp((DRoleProperty){1000, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){1800, 100, 0});
    
    STAssertTrue(fightSystem.GetCurPlayerHP() == 1000, @"");
    fightSystem.OnRoundTimeOver();
    STAssertTrue(fightSystem.GetCurPlayerHP() == 400, @"");
    fightSystem.OnRoundTimeOver();
    STAssertTrue(fightSystem.GetCurPlayerHP() == 0, @"");
}

- (void)testUseHealthRecover
{
    FightSystem fightSystem(NULL);
    
    fightSystem.SetPlayerProp((DRoleProperty){1000, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){3000, 100, 0});
    
    fightSystem.AddRoshamboResult(RoshamboResultLost);
    STAssertTrue(fightSystem.GetCurPlayerHP() == 400, @"");
    
    fightSystem.SetSkillCount(S_RECOVER_HEALTH, 1);
    fightSystem.UseSkill(S_RECOVER_HEALTH);
    
    STAssertTrue(fightSystem.GetCurPlayerHP() == 1000, @"");
    STAssertTrue(fightSystem.GetSkillCount(S_RECOVER_HEALTH) == 0, @"");
}

- (void)testUseResistMistake
{
    FightSystem fightSystem(NULL);
    fightSystem.SetPlayerProp((DRoleProperty){1000, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){3000, 100, 0});
    
    fightSystem.SetSkillCount(S_RESIST_MISTAKE, 1);
    fightSystem.AddRoshamboResult(RoshamboResultLost);
    STAssertTrue(fightSystem.GetCurPlayerHP() == 1000, @"");
    STAssertTrue(fightSystem.GetSkillCount(S_RESIST_MISTAKE) == 0, @"");
    STAssertTrue(fightSystem.GetHits() == 1, @"");
}

- (void)testUseFreezeTime
{
    FightSystem fightSystem(delegate);
    fightSystem.SetSkillCount(S_RECOVER_FURY, 1);
    fightSystem.UseSkill(S_RECOVER_FURY);
    
    fightSystem.UseSkill(S_SKILL_FREEZE_TIME);
    STAssertTrue(delegate->lastFreezeTime == BASE_FREEZE_TIME, @"");
    
    fightSystem.SetSkillUpValue(S_FREEZE_TIME_UP, 1);
    fightSystem.SetSkillCount(S_FREEZE_TIME_UP, 2);
    fightSystem.UseSkill(S_SKILL_FREEZE_TIME);
    STAssertTrue(delegate->lastFreezeTime == BASE_FREEZE_TIME + 2, @"");
}

- (void)testUseMagic
{
    FightSystem fightSystem(delegate);
    fightSystem.SetSkillCount(S_RECOVER_FURY, 1);
    fightSystem.UseSkill(S_RECOVER_FURY);
    
    fightSystem.UseSkill(S_SKILL_MAGIC);
    STAssertTrue(delegate->lastMagicCount == MAX_BASE_MAGIC_COUNT, @"");
    
    fightSystem.SetSkillUpValue(S_MAGIC_UP, 3);
    fightSystem.SetSkillCount(S_MAGIC_UP, 2);
    fightSystem.UseSkill(S_SKILL_MAGIC);
    STAssertTrue(delegate->lastMagicCount == MAX_BASE_MAGIC_COUNT + 6, @"");
}

- (void)testUseBoom
{
    FightSystem fightSystem(delegate);
    fightSystem.SetSkillCount(S_RECOVER_FURY, 1);
    fightSystem.UseSkill(S_RECOVER_FURY);
    
    fightSystem.UseSkill(S_SKILL_BOOM);
    STAssertTrue(delegate->lastBoomCount == MAX_BASE_BOOM_COUNT, @"");
    
    fightSystem.SetSkillUpValue(S_BOOM_UP, 3);
    fightSystem.SetSkillCount(S_BOOM_UP, 2);
    fightSystem.UseSkill(S_SKILL_BOOM);
    STAssertTrue(delegate->lastBoomCount == MAX_BASE_BOOM_COUNT + 6, @"");
}

- (void)testSkillCountChanged
{
    FightSystem fightSystem(delegate);
    
    fightSystem.SetSkillCount(S_RECOVER_FURY, 1);
    STAssertTrue(delegate->lastSkillCode == S_RECOVER_FURY, @"");
    STAssertTrue(delegate->lastSkillCount == 1, @"");
    
    fightSystem.SetSkillCount(S_ATTACK_UP, 4);
    STAssertTrue(delegate->lastSkillCode == S_ATTACK_UP, @"");
    STAssertTrue(delegate->lastSkillCount == 4, @"");
    
    // 测试使用
    fightSystem.SetSkillCount(S_RECOVER_HEALTH, 6);
    fightSystem.UseSkill(S_RECOVER_HEALTH);
    STAssertTrue(delegate->lastSkillCode == S_RECOVER_HEALTH, @"");
    STAssertTrue(delegate->lastSkillCount == 5, @"");
    
    // 测试被动使用
    fightSystem.SetSkillCount(S_RESIST_MISTAKE, 4);
    fightSystem.AddRoshamboResult(RoshamboResultDraw);
    STAssertTrue(delegate->lastSkillCode == S_RESIST_MISTAKE, @"");
    STAssertTrue(delegate->lastSkillCount == 3, @"");
    
    // 测试怒气技能使用
    fightSystem.UseSkill(S_RECOVER_FURY);
    fightSystem.UseSkill(S_SKILL_FREEZE_TIME);
    STAssertTrue(delegate->lastSkillCode == S_SKILL_FREEZE_TIME, @"");
    STAssertTrue(delegate->lastSkillCount == 1, @"");
    fightSystem.UseSkill(S_SKILL_FREEZE_TIME);
    STAssertTrue(delegate->lastSkillCode == S_SKILL_FREEZE_TIME, @"");
    STAssertTrue(delegate->lastSkillCount == 1, @"");
    
    // 设置暂停功能只能使用一次
    fightSystem.SetSkillCostFury(S_SKILL_FREEZE_TIME, fightSystem.GetMaxFury() / 1.5);
    fightSystem.UseSkill(S_SKILL_FREEZE_TIME);
    STAssertTrue(delegate->lastSkillCode == S_SKILL_FREEZE_TIME, @"");
    STAssertTrue(delegate->lastSkillCount == 0, @"");
}

- (void)testDamageContext
{
    FightSystem fightSystem(delegate);
    fightSystem.SetPlayerProp((DRoleProperty){1000, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){3000, 100, 0});
    
    {
        fightSystem.OnAllTurnEnd();
        
        STAssertTrue(delegate->lastDamage.attackModel == AttackModelPlayerAttackNpc_1, @"");
        STAssertTrue(delegate->lastDamage.attackDamage == 100, @"");
    }
    
    {
        fightSystem.OnRoundTimeOver();
        
        STAssertTrue(delegate->lastDamage.attackModel == AttackModelNpcAttackPlayer, @"");
        STAssertTrue(delegate->lastDamage.attackDamage == 600, @"");
    }
}

- (void)testPlayerAndNpcDown
{
    FightSystem fightSystem(delegate);
    fightSystem.SetPlayerProp((DRoleProperty){100, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){100, 100, 0});
    
    STAssertTrue(delegate->npcDownCalled == false, @"");
    fightSystem.OnAllTurnEnd();
    STAssertTrue(delegate->npcDownCalled == true, @"");
    
    STAssertTrue(delegate->playerDownCalled == false, @"");
    fightSystem.OnRoundTimeOver();
    STAssertTrue(delegate->playerDownCalled == true, @"");
}

- (void)testInfoChanged
{
    FightSystem fightSystem(delegate);
    fightSystem.SetPlayerProp((DRoleProperty){100, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){100, 100, 0});
    
    fightSystem.AddRoshamboResult(RoshamboResultWin);
    STAssertTrue(delegate->lastHits == 1, @"");
    fightSystem.AddRoshamboResult(RoshamboResultWin);
    fightSystem.AddRoshamboResult(RoshamboResultWin);
    fightSystem.AddRoshamboResult(RoshamboResultWin);
    STAssertTrue(delegate->lastHits == 4, @"");
    fightSystem.AddRoshamboResult(RoshamboResultDraw);
    STAssertTrue(delegate->lastHits == 0, @"");
    
    fightSystem.OnAllTurnEnd();
    STAssertTrue(fightSystem.GetFury() == 5, @"");//+5
    STAssertTrue(delegate->lastFury == 5, @"");
}

- (void)testAddFightSystemRoshamboResult
{
    FightSystem fightSystem(delegate);
    fightSystem.AddRoshamboResult(RoshamboResultWin);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    
    fightSystem.SetSkillCount(S_RESIST_MISTAKE, 1);
    fightSystem.AddRoshamboResult(RoshamboResultDraw);
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    
    fightSystem.AddRoshamboResult(RoshamboResultDraw);
    STAssertTrue(delegate->lastResult == RoshamboResultDraw, @"");
}

- (void)testMaxHpAndFuryCannotUse
{
    FightSystem fightSystem(delegate);
    fightSystem.SetPlayerProp((DRoleProperty){100, 100, 0});
    fightSystem.SetNpcProp((DRoleProperty){100, 100, 0});
    
    // 测试血量状态，无法使用血量恢复技能
    fightSystem.SetSkillCount(S_RECOVER_HEALTH, 2);
    
    STAssertTrue(fightSystem.GetCurPlayerHP() == fightSystem.GetPlayerPropFromSkill().maxHP, @"");
    fightSystem.UseSkill(S_RECOVER_HEALTH);
    STAssertTrue(fightSystem.GetSkillCount(S_RECOVER_HEALTH) == 2, @"");
    
    // 测试满怒气状态
    fightSystem.SetSkillCount(S_RECOVER_FURY, 2);
    fightSystem.UseSkill(S_RECOVER_FURY);
    STAssertTrue(fightSystem.GetSkillCount(S_RECOVER_FURY) == 1, @"");
    
    STAssertTrue(fightSystem.GetMaxFury() == fightSystem.GetFury(), @"");
    fightSystem.UseSkill(S_RECOVER_FURY);
    STAssertTrue(fightSystem.GetSkillCount(S_RECOVER_FURY) == 1, @"");
}

@end
