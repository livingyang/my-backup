//
//  BeatDevilsServerTests.m
//  BeatDevils
//
//  Created by 青宝 中 on 11-12-5.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "BeatDevilsServerTests.h"
#import "BeatDevilsServer.h"

class BeatDevilsServerDelegate : public IBeatDevilsServerDelegate
{
public:
    int npcRoshamboCount;
    Roshambo lastNPCRoshambo;
    Roshambo lastPlayerRoshambo;
    
    bool timeOverCalled;
    bool roundPlayerLoseCalled;
    bool roundPlayerWinCalled;
    
    bool stageLoseCalled;
    bool stageWinCalled;
    
    bool stageBeginCalled;
    bool stageEndCalled;
    bool roundBeginCalled;
    bool roundEndCalled;
    
    bool stageClearCalled;
    
    RoshamboResult lastResult;
    DDamageContext lastDamageContext;
    
    bool removeFirstDiamondCalled;
    bool removeAllDiamondWithWrongCalled;
    
    SkillCode lastSkillCode;
    int lastSkillCount;
    
    int lastMoney;
    int lastHits;
    int lastFury;
    int lastAddScore;
    
    bool freezeTimeStartCalled;
    bool freezeTimeStopCalled;
    float lastFreezeTime;
    float lastTotalFreezeTime;
    bool magicSkillUseCalled;
    int boomCount;
    
public:
    BeatDevilsServerDelegate():
    npcRoshamboCount(0),
    timeOverCalled(false),
    roundPlayerLoseCalled(false),
    roundPlayerWinCalled(false),
    stageLoseCalled(false),
    stageWinCalled(false),
    stageBeginCalled(false),
    stageEndCalled(false),
    roundBeginCalled(false),
    roundEndCalled(false),
    stageClearCalled(false),
    freezeTimeStartCalled(false),
    freezeTimeStopCalled(false),
    magicSkillUseCalled(false),
    boomCount(0),
    removeFirstDiamondCalled(false),
    removeAllDiamondWithWrongCalled(false)
    { 
    }
    
    void OnAddNpcRoshambo(DiamondType diamondType)
    {
        ++npcRoshamboCount;
        
        lastNPCRoshambo = diamondType;
    }
    
    void OnAddPlayerRoshambo(Roshambo roshambo) { lastPlayerRoshambo = roshambo; }
    
    void OnPlayerVSNpc(RoshamboResult result) { lastResult = result; }
    virtual void OnRemoveFirstDiamond() { removeFirstDiamondCalled = true; }
    virtual void OnRemoveAllDiamondWithWrong() { removeAllDiamondWithWrongCalled = true; }
    virtual void OnBreakBox(DiamondType changeType) {}
    
    void OnRoundStep(float roundTime, float totalTime) { }
    
    void OnRoundTimeOver() { timeOverCalled = true; }
    
    void OnNpcFightPlayer(DDamageContext damageContext)
    {
        roundPlayerLoseCalled = true;
        
        lastDamageContext = damageContext;
    }
    
    void OnPlayerFightNpc(DDamageContext damageContext)
    {
        roundPlayerWinCalled = true;
        
        lastDamageContext = damageContext;
    }
    
    void OnStageBegin() { stageBeginCalled = true; }
    void OnStageEnd() { stageEndCalled = true; }
    void OnRoundBegin() { roundBeginCalled = true; }
    void OnRoundEnd() { roundEndCalled = true; }
    
    void OnStagePlayerLose() { stageLoseCalled = true; }
    
    void OnStagePlayerWin() { stageWinCalled = true; }
    
    void OnStageClear() { stageClearCalled = true; }
    
    void OnSkillCountChanged(SkillCode skillCode, int skillCount) { lastSkillCode = skillCode; lastSkillCount = skillCount; }
    
    void OnMoneyChanged(int money) { lastMoney = money; }
    
    void OnHitsChanged(int hits) { lastHits = hits; }
    
    void OnFuryChanged(int fury) { lastFury = fury; }
    
    virtual void OnAddScore(int addScore, ScoreType scoreType) { lastAddScore = addScore; }
    
    // 技能相关
    virtual void OnFreezeTimeStart() { freezeTimeStartCalled = true; }
    virtual void OnFreezeTimeStop() { freezeTimeStopCalled = true; }
    virtual void OnFreezeTimeStep(float freezeTime, float totalFreezeTime)
    {
        lastFreezeTime = freezeTime;
        lastTotalFreezeTime = totalFreezeTime;
    }
    
    void OnUseMagicSkill(Roshambo sameRoshambo, int count) { magicSkillUseCalled = true; }
    
    virtual void OnBoomFirstDiamond() { ++boomCount; }
};

@implementation BeatDevilsServerTests

- (void)setUp
{
    delegate = new BeatDevilsServerDelegate();
}

- (void)tearDown
{
    delete delegate;
}

- (void)testBuySkill
{
    BeatDevilsServer server(delegate);
    
    STAssertTrue(server.GetMoney() == 0, @"");
    server.SetMoney(1000);
    STAssertTrue(server.GetMoney() == 1000, @"");
    
    STAssertTrue(GetSkillPrice(S_BOOM_UP) > 0, @"");
    
    STAssertTrue(server.GetSkillCount(S_BOOM_UP) == 0, @"");
    server.BuySkill(S_BOOM_UP);
    STAssertTrue(server.GetSkillCount(S_BOOM_UP) == 1, @"");
    STAssertTrue(delegate->lastSkillCode == S_BOOM_UP, @"");
    STAssertTrue(delegate->lastSkillCount == 1, @"");
    
    STAssertTrue(delegate->lastMoney == 1000 - GetSkillPrice(S_BOOM_UP), @"");
    
    server.SetMoney(50);
    server.BuySkill(S_BOOM_UP);
    STAssertTrue(server.GetSkillCount(S_BOOM_UP) == 1, @"");
}

- (void)testSetStageInfo
{
    DStageInfo info = 
    {
        // 方块数
        {1, 2, 3, 4, 5, 6},
        
        // 每回合时间
        {10.0f},
        
        // npc属性
        {100, 10, 5},
    };
    
    BeatDevilsServer server(delegate);
    server.AddStageInfo(info);
    
    STAssertTrue(server.GetMaxStageCount() == 1, @"");
    
    STAssertTrue(server.IsStageStart() == false, @"");
    STAssertTrue(server.IsRoundStart() == false, @"");
    
    STAssertTrue(server.GetCurrentStage() == 0, @"");
    server.StartNextStage();
    STAssertTrue(server.GetCurrentStage() == 1, @"");
    
    STAssertTrue(server.IsStageStart() == true, @"");
    STAssertTrue(server.IsRoundStart() == false, @"");
    
    STAssertTrue(server.GetCurrentRoundDiamondCount() == 0, @"");
    
    STAssertTrue(server.GetCurrentRound() == 0, @"");
    server.StartNextRound();
    STAssertTrue(server.GetCurrentRound() == 1, @"");
    
    STAssertTrue(server.IsStageStart() == true, @"");
    STAssertTrue(server.IsRoundStart() == true, @"");
    STAssertTrue(server.GetCurrentRoundDiamondCount() == 1, @"");
}

- (void)testClearStage1
{
    BeatDevilsServer server(delegate);
    DStageInfo stage1Info = 
    {
        { 1, 2, 4, 7, 10, 14, },
        {10.0f},
        { 200, 100, 0, },
    };
    
    server.AddStageInfo(stage1Info);
    server.StartNextStage();
    server.StartNextRound();
    
    // 回合1
    STAssertTrue(delegate->roundPlayerWinCalled == false, @"");
    STAssertTrue(server.GetNpcDiamondCount() == 1, @"");
    
    server.AddPlayerWinRoshambo();
    STAssertTrue(delegate->lastHits == 1, @"");
    STAssertTrue(delegate->roundPlayerWinCalled == true, @"");
    STAssertTrue(server.IsRoundStart() == false, @"");
    STAssertTrue(delegate->stageWinCalled == false, @"");
    
    // 回合2
    server.StartNextRound();
    STAssertTrue(server.GetNpcDiamondCount() == 2, @"");
    server.AddPlayerWinRoshambo();
    server.AddPlayerWinRoshambo();
    STAssertTrue(delegate->lastHits == 3, @"");
    STAssertTrue(server.IsStageStart() == false, @"");
    STAssertTrue(server.IsRoundStart() == false, @"");
    STAssertTrue(delegate->stageWinCalled == true, @"");
    
    STAssertTrue(delegate->stageClearCalled == true, @"");
}

- (void)testStage1Lost
{
    BeatDevilsServer server(delegate);
    DStageInfo stage1Info = 
    {
        { 1, 2, 4, 7, 10, 14, },
        {10.0f},
        { 200, 100, 0, },
    };
    
    server.AddStageInfo(stage1Info);
    server.StartNextStage();
    server.StartNextRound();
    
    STAssertTrue(delegate->roundPlayerLoseCalled == false, @"");
    STAssertTrue(delegate->removeAllDiamondWithWrongCalled == false, @"");
    server.AddPlayerLostRoshambo();
    STAssertTrue(delegate->roundPlayerLoseCalled == true, @"");
    STAssertTrue(delegate->removeAllDiamondWithWrongCalled == true, @"");

    STAssertTrue(server.GetCurNpcHP() == 200, @"");
    
    server.StartNextRound();
    server.AddPlayerLostRoshambo();
    
    server.StartNextRound();
    server.AddPlayerLostRoshambo();
    
    STAssertTrue(server.IsStageStart() == false, @"");
    STAssertTrue(server.IsRoundStart() == false, @"");
    STAssertTrue(delegate->stageLoseCalled == true, @"");
}

- (void)testTimeOver
{
    DStageInfo info = 
    {
        // 方块数
        {1, 2, 3, 4, 5, 6},
        
        // 每回合时间
        {10.0f},
        
        // npc属性
        {100, 10, 5},
    };
    
    BeatDevilsServer server(delegate);
    
    server.AddStageInfo(info);
    server.StartNextStage();
    server.StartNextRound();
    
    for (int i = 0; i < 10; ++i)
    {
        STAssertTrue(delegate->timeOverCalled == false, @"");
        server.RoundStep(1);
    }
    
    STAssertTrue(delegate->timeOverCalled == true, @"");
    STAssertTrue(server.IsRoundStart() == false, @"");
}

- (void)testUseSkillFreezeTime
{
    DStageInfo info = 
    {
        {2, 2, 4, 7, 10, 14},
        {10, 10, 7, 6},
        {200, 100, 0},
        {0, 10, 7, 5},
        {0, 30, 18, 10},
        {0, 0, 0, 25},
    };
    
    BeatDevilsServer server(delegate);
    
    server.AddStageInfo(info);
    server.StartNextStage();
    server.StartNextRound();
    server.SetMoney(1000);
    server.BuySkill(S_RECOVER_FURY);
    server.UseSkill(S_RECOVER_FURY);
    
    STAssertTrue(delegate->freezeTimeStartCalled == false, @"");
    STAssertTrue(delegate->freezeTimeStopCalled == false, @"");
    server.UseSkill(S_SKILL_FREEZE_TIME);
    STAssertTrue(delegate->freezeTimeStartCalled == true, @"");
    
    for (int i = 0; i < BASE_FREEZE_TIME; ++i)
    {
        STAssertTrue(delegate->freezeTimeStopCalled == false, @"");
        server.RoundStep(1);
    }
    STAssertTrue(delegate->freezeTimeStopCalled == true, @"");
    
    for (int i = 0; i < 10; ++i)
    {
        STAssertTrue(delegate->timeOverCalled == false, @"");
        server.RoundStep(1);
    }
    
    STAssertTrue(delegate->timeOverCalled == true, @"");
    STAssertTrue(server.IsRoundStart() == false, @"");
}

- (void)testUseSkillMagic
{
    DStageInfo info = 
    {
        {2, 2, 4, 7, 10, 14},
        {9, 8, 7, 6},
        {200, 100, 0},
        {0, 10, 7, 5},
        {0, 30, 18, 10},
        {0, 0, 0, 25},
    };
    
    BeatDevilsServer server(delegate);
    
    server.AddStageInfo(info);
    server.StartNextStage();
    server.StartNextRound();
    server.SetMoney(1000);
    server.BuySkill(S_RECOVER_FURY);
    server.UseSkill(S_RECOVER_FURY);
    
    STAssertTrue(delegate->magicSkillUseCalled == false, @"");
    server.UseSkill(S_SKILL_MAGIC);
    STAssertTrue(delegate->magicSkillUseCalled == true, @"");
}

- (void)testUseSkillBoom
{
    DStageInfo info = 
    {
        {10, 2, 4, 7, 10, 14},
        {9, 8, 7, 6},
        {200, 100, 0},
        {0, 10, 7, 5},
        {0, 30, 18, 10},
        {0, 0, 0, 25},
    };
    
    BeatDevilsServer server(delegate);
    
    server.AddStageInfo(info);
    server.StartNextStage();
    server.StartNextRound();
    server.SetMoney(1000);
    server.BuySkill(S_RECOVER_FURY);
    server.UseSkill(S_RECOVER_FURY);
    
    STAssertTrue(delegate->freezeTimeStopCalled == false, @"");
    server.UseSkill(S_SKILL_BOOM);
    for (int step = 0; step < 10; ++step)
    {
        server.RoundStep(BOOM_TIME);
    }
    STAssertTrue(delegate->boomCount == MAX_BASE_BOOM_COUNT, @"");

    STAssertTrue(delegate->freezeTimeStopCalled == true, @"");
    STAssertTrue(delegate->lastHits == MAX_BASE_BOOM_COUNT, @"");
}

- (void)testAddScore
{
    BeatDevilsServer server(delegate);
    DStageInfo stage1Info = 
    {
        {2, 2, 4, 7, 10, 14},
        {9, 8, 7, 6},
        {200, 100, 0},
        {0, 10, 7, 5},
        {0, 30, 18, 10},
        {0, 0, 0, 25},
    };
    
    server.AddStageInfo(stage1Info);
    server.StartNextStage();
    server.StartNextRound();
    
    server.AddPlayerWinRoshambo();
    STAssertTrue(delegate->lastAddScore == 10, @"");
    STAssertTrue(server.GetScore() == 10, @"");
    
    server.AddPlayerWinRoshambo();
    STAssertTrue(server.GetScore() > 20, @"");
}

- (void)testSaveAndLoadGame
{
    BeatDevilsServer server(NULL);
    
    // save
    {
        server.SetMoney(100);
        server.SetSkillCount(S_BOOM_UP, 5);
        
        BeatDevilsGameData gameData = server.GetGameData();
        STAssertTrue(gameData.money == 100, @"");
        STAssertTrue(gameData.totalSkillCount[S_BOOM_UP] == 5, @"");
        STAssertTrue(gameData.totalSkillCount[S_ATTACK_UP] == 0, @"");
    }
    
    // load
    {
        BeatDevilsGameData gameData = {};
        gameData.money = 199;
        gameData.totalSkillCount[S_ATTACK_UP] = 3;
        
        server.SetGameData(gameData);
        
        STAssertTrue(gameData.money == 199, @"");
        STAssertTrue(gameData.totalSkillCount[S_ATTACK_UP] == 3, @"");
    }
}

// 测试关卡文件读取
static NSString *stageInfoFilePath = @"/Users/ZQP/Desktop/apple/Projects/BeatDevils/trunk/BeatDevils/BeatDevils/test_stage_info.csv";
//static NSString *stageInfoFilePath = @"/Users/apple/Downloads/BeatDevils/BeatDevils/test_stage_info.csv";

- (void)testStageInfoFileExist
{
    STAssertTrue([[NSFileManager defaultManager] fileExistsAtPath:stageInfoFilePath], @"务必使文件存在，否则关卡信息测试无法通过");
}

- (void)testLoadStageInfo
{
    BeatDevilsServer server(NULL);
    server.LoadStageInfo(stageInfoFilePath.UTF8String);
    
    STAssertTrue(server.GetStageInfo(-1) == NULL, @"");
    STAssertTrue(server.GetStageInfo(10) == NULL, @"");
    
    STAssertTrue(server.GetStageInfo(0) != NULL, @"");
    STAssertTrue(server.GetStageInfo(9) != NULL, @"");
    
    const DStageInfo *info = server.GetStageInfo(0);
    
    DStageInfo stageInfo = 
    {
        {1, 2, 4, 7, 12, 16},
        {12, 12, 12, 12},
        {1800, 100, 0},
        {0, 10, 10, 10},
        {0, 20, 15, 10},
        {0, 0, 0, 10},
        {0, 0, 15, 15},
    };
    
    STAssertTrue(memcmp(info->diamondCount, stageInfo.diamondCount, sizeof(stageInfo.diamondCount)) == 0, @"");
    STAssertTrue(memcmp(info->modelRoundTime, stageInfo.modelRoundTime, sizeof(stageInfo.modelRoundTime)) == 0, @"");
    STAssertTrue(memcmp(&info->npcProp, &stageInfo.npcProp, sizeof(stageInfo.npcProp)) == 0, @"");
    STAssertTrue(memcmp(info->starPercent, stageInfo.starPercent, sizeof(stageInfo.starPercent)) == 0, @"");
    STAssertTrue(memcmp(info->box1Percent, stageInfo.box1Percent, sizeof(stageInfo.box1Percent)) == 0, @"");
    STAssertTrue(memcmp(info->box2Percent, stageInfo.box2Percent, sizeof(stageInfo.box2Percent)) == 0, @"");
    STAssertTrue(memcmp(info->reversePercent, stageInfo.reversePercent, sizeof(stageInfo.reversePercent)) == 0, @"");
}

- (void)testResetBeatDevilsServer
{
    BeatDevilsServer server(delegate);
    DStageInfo stage1Info = 
    {
        {2, 2, 4, 7, 10, 14},
        {9, 8, 7, 6},
        {200, 100, 0},
        {0, 10, 7, 5},
        {0, 30, 18, 10},
        {0, 0, 0, 25},
    };
    
    server.AddStageInfo(stage1Info);
    server.StartNextStage();
    server.StartNextRound();
    
    server.AddPlayerWinRoshambo();
    server.AddPlayerWinRoshambo();
    
    server.StartNextRound();
    server.AddPlayerWinRoshambo();
    
    STAssertTrue(server.IsStageStart() == true, @"");
    STAssertTrue(server.IsRoundStart() == true, @"");
    STAssertTrue(server.GetScore() != 10, @"");
    STAssertTrue(server.GetCurrentStage() != 0, @"");
    STAssertTrue(server.GetCurrentRound() != 0, @"");
    STAssertTrue(delegate->lastHits != 0, @"");
    
    server.ResetBeatDevilsServer(BeatDevilsModelNormal);
    
    STAssertTrue(server.IsStageStart() == false, @"");
    STAssertTrue(server.IsRoundStart() == false, @"");
    STAssertTrue(server.GetScore() == 0, @"");
    STAssertTrue(server.GetCurrentStage() == 0, @"");
    STAssertTrue(server.GetCurrentRound() == 0, @"");
    STAssertTrue(delegate->lastHits == 0, @"");
}

- (void)testStageAndRoundBeginEndCall
{
    BeatDevilsServer server(delegate);
    DStageInfo stage1Info = 
    {
        {1, 2, 4, 7, 10, 14},
        {9, 8, 7, 6},
        {100, 100, 0},
        {0, 10, 7, 5},
        {0, 30, 18, 10},
        {0, 0, 0, 25},
    };
    
    server.AddStageInfo(stage1Info);
    
    STAssertTrue(delegate->stageBeginCalled == false, @"");
    STAssertTrue(delegate->roundBeginCalled == false, @"");
    server.StartNextStage();
    STAssertTrue(delegate->stageBeginCalled == true, @"");
    STAssertTrue(delegate->roundBeginCalled == false, @"");
    server.StartNextRound();
    STAssertTrue(delegate->stageBeginCalled == true, @"");
    STAssertTrue(delegate->roundBeginCalled == true, @"");
}

- (void)testCreateDiamondPerCount
{
    // 测试错误条件1
    {
        int selections[2] = {49, 50};
        int selectionCount[2];
        
        STAssertTrue(GetSelectionCount(selections, selectionCount, 2, 3) == false, @"");
    }
    
    // 测试错误条件2
    {
        int selections[2] = {-1, 101};
        int selectionCount[2];
        
        STAssertTrue(GetSelectionCount(selections, selectionCount, 2, 3) == false, @"");
    }
    
    // 测试两个选项
    {
        int selections[2] = {49, 51};
        int selectionCount[2];
        
        {
            int correctCount[2] = {1, 2};
            GetSelectionCount(selections, selectionCount, 2, 3);
            
            STAssertTrue(memcmp(selectionCount, correctCount, sizeof(correctCount)) == 0, @"");
        }
        
        {
            int correctCount[2] = {1, 3};
            GetSelectionCount(selections, selectionCount, 2, 4);
            
            STAssertTrue(memcmp(selectionCount, correctCount, sizeof(correctCount)) == 0, @"");
        }
    }
    
    // 测试三个选项
    {
        int selections[3] = {50, 20, 30};
        int selectionCount[3];
        
        {
            int correctCount[3] = {5, 2, 3};
            GetSelectionCount(selections, selectionCount, 3, 10);
            
            STAssertTrue(memcmp(selectionCount, correctCount, sizeof(correctCount)) == 0, @"");
        }
        
        {
            int correctCount[3] = {6, 2, 3};
            GetSelectionCount(selections, selectionCount, 3, 11);
            
            STAssertTrue(memcmp(selectionCount, correctCount, sizeof(correctCount)) == 0, @"");
        }
        
        {
            int correctCount[3] = {8, 2, 4};
            GetSelectionCount(selections, selectionCount, 3, 14);
            
            STAssertTrue(memcmp(selectionCount, correctCount, sizeof(correctCount)) == 0, @"");
        }
    }
}

@end
