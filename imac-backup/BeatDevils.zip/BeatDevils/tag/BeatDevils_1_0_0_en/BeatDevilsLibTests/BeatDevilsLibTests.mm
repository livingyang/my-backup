//
//  BeatDevilsLibTests.m
//  BeatDevilsLibTests
//
//  Created by 青宝 中 on 11-11-24.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "BeatDevilsLibTests.h"
#import "BeatDevilsDef.h"
#import "BeatDevilsServer.h"

@implementation BeatDevilsLibTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
    //delegate = new BeatDevilsServerDelegate();
    server = CreateBeatDevilsServer(NULL);
}

- (void)tearDown
{
    // Tear-down code here.
    
    DeleteBeatDevilsServer(server);
    server = NULL;
    
    //delete delegate;
    [super tearDown];
}

- (void)testRoshamboFromResult
{
    STAssertTrue(GetRoshamboFromResult(RoshamboPaper, RoshamboResultInvalid) == RoshamboInvalid, @"");
    STAssertTrue(GetRoshamboFromResult(RoshamboInvalid, RoshamboResultDraw) == RoshamboInvalid, @"");
    STAssertTrue(GetRoshamboFromResult(RoshamboInvalid, RoshamboResultInvalid) == RoshamboInvalid, @"");
    
    STAssertTrue(GetRoshamboFromResult(RoshamboPaper, RoshamboResultWin) == RoshamboScissors, @"");
    STAssertTrue(GetRoshamboFromResult(RoshamboPaper, RoshamboResultDraw) == RoshamboPaper, @"");
    STAssertTrue(GetRoshamboFromResult(RoshamboPaper, RoshamboResultLost) == RoshamboRock, @"");
    
    STAssertTrue(GetRoshamboFromResult(RoshamboScissors, RoshamboResultWin) == RoshamboRock, @"");
    STAssertTrue(GetRoshamboFromResult(RoshamboRock, RoshamboResultDraw) == RoshamboRock, @"");
    STAssertTrue(GetRoshamboFromResult(RoshamboScissors, RoshamboResultLost) == RoshamboPaper, @"");
}

#pragma mark -
#pragma mark 测试关卡管理

/*
- (void)testStageManagerNextTurn
{
    DStageInfo info = 
    {
        // 方块数
        {1, 2, 3, 4, 5, 6},
        
        // 每回合时间
        10.0f,
        
        // npc属性
        {100, 10, 5},
    };
    
    StageManager stageManager(delegate);
    
    stageManager.StartStage(info);
    stageManager.StartNextRound();
    
    stageManager.AddPlayerWinRoshambo();
    STAssertTrue(delegate->lastResult == RoshamboResultWin, @"");
    STAssertTrue(stageManager.IsStageStart() == true, @"");
    STAssertTrue(stageManager.IsRoundStart() == false, @"");
    
    stageManager.StartNextRound();
    
    stageManager.AddPlayerLostRoshambo();
    STAssertTrue(delegate->lastResult == RoshamboResultLost, @"");
    STAssertTrue(stageManager.IsStageStart() == true, @"");
    STAssertTrue(stageManager.IsRoundStart() == false, @"");
}

- (void)testStageManagerTimeOver
{
    DStageInfo info = 
    {
        // 方块数
        {1, 2, 3, 4, 5, 6},
        
        // 每回合时间
        10.0f,
        
        // npc属性
        {100, 10, 5},
    };
    
    StageManager stageManager(delegate);
    
    stageManager.StartStage(info);
    stageManager.StartNextRound();
    
    for (int i = 0; i < 10; ++i)
    {
        STAssertTrue(delegate->timeOverCalled == false, @"");
        stageManager.RoundStep(1);
    }
    
    STAssertTrue(delegate->timeOverCalled == true, @"");
    STAssertTrue(stageManager.IsRoundStart() == false, @"");
    
    //STAssertTrue(stageManager.IsRoundStart() == true, @"");
}
*/

#pragma mark -
#pragma mark 测试游戏接口

- (void)testNextStage
{
}

/*
- (void)testMatchHits
{
    const int count = 5;
    Roshambo npcRoshamboArray[count] =
    {
        RoshamboPaper,
        RoshamboPaper,
        RoshamboRock,
        RoshamboScissors,
        RoshamboPaper,
    };
    
    {
        STAssertTrue(server->TurnRestart(npcRoshamboArray, count, 10) == true, @"");
        STAssertTrue(server->GetHits() == 0, @"");
        
        server->AddPlayerRoshambo(RoshamboScissors);
        STAssertTrue(server->GetHits() == 1, @"");
        server->AddPlayerRoshambo(RoshamboScissors);
        server->AddPlayerRoshambo(RoshamboPaper);
        server->AddPlayerRoshambo(RoshamboRock);
        server->AddPlayerRoshambo(RoshamboScissors);
        STAssertTrue(server->GetHits() == 5, @"");
    }
    
    {
        STAssertTrue(server->TurnRestart(npcRoshamboArray, count, 10) == true, @"");
        
        server->AddPlayerRoshambo(RoshamboScissors);
        server->AddPlayerRoshambo(RoshamboScissors);
        server->AddPlayerRoshambo(RoshamboPaper);
        server->AddPlayerRoshambo(RoshamboRock);
        server->AddPlayerRoshambo(RoshamboScissors);
        STAssertTrue(server->GetHits() == 10, @"");
    }
    
    {
        STAssertTrue(server->TurnRestart(npcRoshamboArray, count, 10) == true, @"");
        
        server->AddPlayerRoshambo(RoshamboPaper);
        STAssertTrue(server->GetHits() == 0, @"");
        server->AddPlayerRoshambo(RoshamboScissors);
        server->AddPlayerRoshambo(RoshamboPaper);
        server->AddPlayerRoshambo(RoshamboRock);
        server->AddPlayerRoshambo(RoshamboScissors);
        STAssertTrue(server->GetHits() == 4, @"");
    }
}
*/
@end
