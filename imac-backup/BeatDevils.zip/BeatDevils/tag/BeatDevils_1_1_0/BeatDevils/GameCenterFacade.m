//
//  GameCenterFacade.m
//  CutTheChain
//
//  Created by lee living on 11-6-13.
//  Copyright 2011 LieHuo Tech. All rights reserved.
//

#import "GameCenterFacade.h"

#import "GameKitHelper.h"

@implementation GameCenterFacade

+ (GameCenterFacade *)instance
{
	static GameCenterFacade *ins = nil;

	if (ins == nil)
	{
		ins = [[GameCenterFacade alloc] init];
	}
	
	return ins;
}

- (BOOL)isGameCenterAvailable
{
    return [GameKitHelper sharedGameKitHelper].isGameCenterAvailable == true;
}

- (BOOL)isAvailableVersion
{
	NSString* reqSysVer = @"4.1";
	NSString* currSysVer = [[UIDevice currentDevice] systemVersion];
	BOOL isOSVer41 = ([currSysVer compare:reqSysVer options:NSNumericSearch] != NSOrderedAscending);
	
	NSLog(@"GameCenter available = %@", isOSVer41 ? @"YES" : @"NO");
	return isOSVer41;
}

- (void)showLeaderboard
{
    [[GameKitHelper sharedGameKitHelper] showLeaderboard];
}

- (void)authenticateLocalPlayer
{
    [[GameKitHelper sharedGameKitHelper] authenticateLocalPlayer];
}

- (void)submitScore:(int)score toModel:(BeatDevilsModel)model
{
    static NSString *scoreId[BeatDevilsModelMax] =
    {
        @"score_normal",
        @"score_hard",
        @"score_expert",
        @"score_hell",
    };
    
    [[GameKitHelper sharedGameKitHelper] submitScore:score category:scoreId[model]];
}

- (void)submitHits:(int)hits toModel:(BeatDevilsModel)model
{
    static NSString *hitsId[BeatDevilsModelMax] =
    {
        @"hits_normal",
        @"hits_hard",
        @"hits_expert",
        @"hits_hell",
    };
    
    [[GameKitHelper sharedGameKitHelper] submitScore:hits category:hitsId[model]];
}

/*
- (void)submitStageScore:(NSString *)stageFlag score:(int)score
{
	NSString *categoryStr = [NSString stringWithFormat:@"Stage%@_Score", stageFlag];
	
#ifdef LITE_VERSION
	categoryStr = [categoryStr stringByAppendingString:@"_Lite"];
#endif
	
	if (IS_PAD())
	{
		categoryStr = [categoryStr stringByAppendingString:@"_IPad"];
	}
	
	[[GameKitHelper sharedGameKitHelper] submitScore:score category:categoryStr];
}

- (void)submitTotalScore:(int)score
{
	NSString *totalScoreStr = @"Total_Score";
	
#ifdef LITE_VERSION
	totalScoreStr = [totalScoreStr stringByAppendingString:@"_Lite"];
#endif
	
	if (IS_PAD())
	{
		totalScoreStr = [totalScoreStr stringByAppendingString:@"_IPad"];
	}
	
	[[GameKitHelper sharedGameKitHelper] submitScore:score category:totalScoreStr];
}
*/
@end
