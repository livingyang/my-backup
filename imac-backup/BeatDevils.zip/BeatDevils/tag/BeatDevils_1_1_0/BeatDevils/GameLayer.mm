//
//  NextLayer.m
//  BalsamiqXmlReader
//
//  Created by lee living on 11-8-15.
//  Copyright 2011 LieHuo Tech. All rights reserved.
//

#import "GameLayer.h"

#import "BalsamiqControlData.h"
#import "CCBalsamiqLayer.h"
#import "CCAlertLayer.h"
#import "CCBalsamiqScene.h"
#import "BalsamiqReaderConfig.h"
#import "CCMenuItemButton.h"

#import "MainLayer.h"
#import "GameToolFunc.h"
#import "BeatDevilsServerDelegate.h"
#import "SpriteBarManager.h"
#import "HpSpriteBarManager.h"
#import "TimeSpriteBarManager.h"
#import "ShopLayer.h"
#import "HelpLayer.h"
#import "SelectModelLayer.h"
#import "NpcAnimationManager.h"
#import "SimpleAudioEngine.h"
#import "GameRecordManager.h"
#import "PlayerGuideLayer.h"

enum
{
    zBackground,            //背景在此
    zBalsamiqLayer,
    zDiamondQueueLayer,
    zSkillPanelLayer,
    zGuideLayer,
    zShopLayer,
    zStageLayer,            //前景在此
};

#define TAG_FREEZE_BLINK_ACTION (123)

#define TAG_WARNING_ACTION (1234)

@interface GameLayer (Private)
    
- (BeatDevilsServerDelegate *)beatDevilsDelegate;

- (void)showStageStart:(int)stage;
- (void)startNextRound;
- (void)startNextStage;

- (void)playNpcWaiting;
- (void)playBeatNpc:(CCSprite *)sprite;

@end

@implementation GameLayer

@synthesize skillPanelLayer, playerGuideLayer, shopLoadingAlert;
@synthesize sprReady, sprHitBg;
@synthesize labHits, labStage, labTotalScore, labHighScore, initRoshamboMenuPos;
@synthesize lastStageScore, lastStageHits;
@synthesize beatDevilsDelegateValue, playerHpMgr, npcHpMgr, timeBarMgr, furyMgr, npcAnimationMgr;

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];

	// add layer as a child to scene
	[scene addChild:[GameLayer node]];
	
	// return the scene
	return scene;
}

#pragma mark -
#pragma mark 暂停效果

- (void)pauseBeatDevils
{
    [self pauseSchedulerAndActions];
    [self.npcAnimationMgr pauseActions];
}

- (void)resumeBeatDevils
{
    [self resumeSchedulerAndActions];
    [self.npcAnimationMgr resumeActions];
}

#pragma mark -
#pragma mark 鬼子动画播放

- (void)beatAnimeDone
{
    self.beatDevilsDelegate->OnBeatAnimeDone();
}

- (void)onMenuUp
{
    self.beatDevilsDelegate->OnMenuBack();
}

- (void)moveMenuDown
{
    id move = [CCMoveBy actionWithDuration:1 position:ccp(0, -80)];
    
    [skillPanelLayer runAction:[CCSequence actions:
                                  [CCDelayTime actionWithDuration:0.3f],
                                  move,
                                  nil]];
    
    [[SimpleAudioEngine sharedEngine] playEffect:@"menu-move.wav"];
    
    [self.timeBarMgr recoverTime];
}

- (void)moveMenuUp
{
    [skillPanelLayer runAction:[CCSequence actions:
                                  [CCMoveTo actionWithDuration:1 position:self.initRoshamboMenuPos],
                                  [CCCallFunc actionWithTarget:self selector:@selector(onMenuUp)],
                                  nil]];
    
    [[SimpleAudioEngine sharedEngine] playEffect:@"menu-move.wav"];
}

- (void)cleanAnimeAction
{
    [skillPanelLayer cleanAllDiamond];
    [skillPanelLayer stopAllActions];
    skillPanelLayer.position = self.initRoshamboMenuPos;
    [self.npcAnimationMgr cleanSpriteActions];
    
    [self.npcHpMgr clearUpdateValueAction];
    [self.playerHpMgr clearUpdateValueAction];
}

- (void)playNpcWaiting
{
    [npcAnimationMgr addSpriteAction:@"npc-waiting.csv"
                              target:self
                            callback:@selector(playNpcWaiting)
                               delay:0.5f];
}

#pragma mark -
#pragma mark 按钮事件

- (void)onPauseClick:(id)sender
{
    CCScene *scene = [CCScene node];
    [scene addChild:[CCBalsamiqLayer layerWithBalsamiqFile:NSLocalizedString(@"4-game-pause.bmml", nil)
                                               eventHandle:self]];
    
    [[CCDirector sharedDirector] pushScene:scene];
}

- (void)onRockClick:(id)sender
{
    self.beatDevilsDelegate->OnRoshamboClick(RoshamboRock);
}

- (void)onScissorsClick:(id)sender
{
    self.beatDevilsDelegate->OnRoshamboClick(RoshamboScissors);
}

- (void)onPaperClick:(id)sender
{
    self.beatDevilsDelegate->OnRoshamboClick(RoshamboPaper);
}

// 暂停界面

- (void)onResumeClick:(id)sender
{
    [[CCDirector sharedDirector] popScene];
}

- (void)onReplayClick:(id)sender
{
    [[CCDirector sharedDirector] popScene];
    
    [self cleanAnimeAction];
    self.beatDevilsDelegate->OnRestartClick();
}

- (void)onHelpClick:(id)sender
{
    [[CCDirector sharedDirector] pushScene:[HelpLayer scene]];
}

- (void)onMainClick:(id)sender
{
    [[CCDirector sharedDirector] popScene];
	[[CCDirector sharedDirector] replaceScene:[MainLayer scene]];
}

// 胜利界面

- (void)onNextStageClick:(id)sender
{
    [CCAlertLayer removeAlertFromNode:sender];
    
    self.beatDevilsDelegate->OnStartNextStageClick();
}

// 失败界面

- (void)onLoseReplayClick:(id)sender
{
    [CCAlertLayer removeAlertFromNode:sender];
    
    [self cleanAnimeAction];
    self.beatDevilsDelegate->OnRestartClick();
}

- (void)onLoseMainClick:(id)sender
{
	[[CCDirector sharedDirector] replaceScene:[MainLayer scene]];
}

// 通关界面

- (void)onMoreClick:(id)sender
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"button.wav"];
    
    [[CCDirector sharedDirector] replaceScene:[SelectModelLayer scene]];
}

#pragma mark -
#pragma mark SkillPanelLayerDelegate

- (void)onRecoverHpClick
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"health.wav"];
    
    self.beatDevilsDelegate->OnSkillClick(S_RECOVER_HEALTH);
}
- (void)onRecoverFuryClick
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"fury.wav"];
    
    self.beatDevilsDelegate->OnSkillClick(S_RECOVER_FURY);
}

- (void)onSkillTimeClick
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"alert.wav"];
    
    self.beatDevilsDelegate->OnSkillClick(S_SKILL_FREEZE_TIME);
}
- (void)onSkillMagicClick
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"magic.wav"];
    
    self.beatDevilsDelegate->OnSkillClick(S_SKILL_MAGIC);
}
- (void)onSkillBoomClick
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"backup.wav"];
    
    self.beatDevilsDelegate->OnSkillClick(S_SKILL_BOOM);
}

- (void)onShopClick
{
    [[CCDirector sharedDirector] pushScene:[ShopLayer scene:self]];
}

#pragma mark -
#pragma mark BeatDevilsServerDelegate

- (BeatDevilsServerDelegate *)beatDevilsDelegate
{
    return (BeatDevilsServerDelegate *)self.beatDevilsDelegateValue.pointerValue;
}

- (void)setRoundTime:(float)roundTime totalTime:(float)totalTime
{
//    [timeMgr setCurValue:totalTime - roundTime];
//    [timeMgr setMaxValue:totalTime];
    
    [self.timeBarMgr setMaxValue:totalTime];
    [self.timeBarMgr setCurValue:roundTime];
}

- (void)setPlayerHP:(int)curHP maxHP:(int)maxHP
{
    [self.playerHpMgr setCurValue:curHP];
    [self.playerHpMgr setMaxValue:maxHP];
}

- (void)setNpcHP:(int)curHP maxHP:(int)maxHP
{
    [self.npcHpMgr setCurValue:curHP];
    [self.npcHpMgr setMaxValue:maxHP];
}

- (void)setFury:(int)curFury
{
    [self.furyMgr setCurValue:curFury];
}

- (void)setGameDoneLayerData:(CCBalsamiqLayer *)layer score:(int)score highHits:(int)hits
{
    [[layer getControlByName:@"image_model"] setTexture:
     [GameToolFunc getModelTexture:[GameToolFunc GetGameModel]]];
    
    [GameToolFunc getUINumberLabel:[layer getControlByName:@"score"]
                       anchorPoint:ccp(0, 0.5f)].string = [NSString stringWithFormat:@"%d", score];
    [GameToolFunc getUINumberLabel:[layer getControlByName:@"hits"]
                       anchorPoint:ccp(0, 0.5f)].string = [NSString stringWithFormat:@"%d", hits];
    
    [[layer getControlByName:@"image_record_score"]
     setVisible:(score >= [[GameRecordManager instance] getModelHighScore:[GameToolFunc GetGameModel]])];
    [[layer getControlByName:@"image_record_hits"]
     setVisible:(hits >= [[GameRecordManager instance] getModelHighHits:[GameToolFunc GetGameModel]])];
}

- (void)showKoAnime
{
    self.sprReady.texture = [[CCTextureCache sharedTextureCache] addImage:@"UI/2-game/img-ko.png"];
    [self.sprReady runAction:[CCSequence actions:
                              [CCCallFuncO actionWithTarget:[SimpleAudioEngine sharedEngine] selector:@selector(playEffect:) object:@"KO.wav"],
                              [CCScaleTo actionWithDuration:0.3f scale:1.0f],
                              [CCDelayTime actionWithDuration:0.5f],
                              [CCScaleTo actionWithDuration:0 scale:0],
                              nil]];
}

- (void)onShowNextStageCallback
{
    CCAlertLayer *alert = [CCAlertLayer showAlert:NSLocalizedString(@"6.1-stage-win.bmml", nil)
                                       parentNode:self
                                        showModal:kNormalShowModal];
    
    [self setGameDoneLayerData:alert.balsamiqLayer
                         score:self.lastStageScore
                      highHits:self.lastStageHits];
    
    skillPanelLayer.position = self.initRoshamboMenuPos;
    [self playNpcWaiting];
}
- (void)showBeatAnimeAndNextStageLayer
{
    [npcAnimationMgr cleanSpriteActions];
    [npcAnimationMgr addSpriteAction:@"devil-down.csv" target:self callback:@selector(onShowNextStageCallback) delay:0];
    [[SimpleAudioEngine sharedEngine] performSelector:@selector(playEffect:) withObject:@"npc-down.wav" afterDelay:0.2f];
    
    [self showKoAnime];
}

- (void)onShowGameOverCallback
{
    CCAlertLayer *alert = [CCAlertLayer showAlert:NSLocalizedString(@"6-game-over.bmml", nil)
                                       parentNode:self
                                        showModal:kNormalShowModal];
    
    [self setGameDoneLayerData:alert.balsamiqLayer
                         score:self.lastStageScore
                      highHits:self.lastStageHits];
}
- (void)showBeatAnimeAndGameOverLayer
{
    [self onShowGameOverCallback];
}

- (void)onShowClearStageCallback
{
    CCAlertLayer *alert = [CCAlertLayer showAlert:NSLocalizedString(@"6.2-stage-clear.bmml", nil)
                                       parentNode:self
                                        showModal:kNormalShowModal];
    
    [self setGameDoneLayerData:alert.balsamiqLayer
                         score:self.lastStageScore
                      highHits:self.lastStageHits];
}
- (void)showBeatAnimeAndClearStageLayer
{
    [npcAnimationMgr cleanSpriteActions];
    [npcAnimationMgr addSpriteAction:@"devil-down.csv" target:self callback:@selector(onShowClearStageCallback) delay:0];
    [[SimpleAudioEngine sharedEngine] performSelector:@selector(playEffect:) withObject:@"npc-down.wav" afterDelay:0.2f];
    
    [self showKoAnime];
}

- (void)updateMatchTime:(ccTime)dt
{
    self.beatDevilsDelegate->RoundStep(dt);
}

- (void)buyFood
{
    [shopItemManager purchaseItem:@"10_foods"];
    self.shopLoadingAlert = [CCAlertLayer showAlert:@"3.3-shop-loading.bmml"
                                         parentNode:self];
    
    [self pauseBeatDevils];
}
- (void)buyBeer
{
    [shopItemManager purchaseItem:@"10_beer"];
    self.shopLoadingAlert = [CCAlertLayer showAlert:@"3.3-shop-loading.bmml"
                                         parentNode:self];
    
    [self pauseBeatDevils];
}

// 新手帮助

- (BOOL)isGuided
{
    return [PlayerGuideLayer isGuided];
}

- (void)attachPlayerGuide
{
    if (self.isGuided)
    {
        return;
    }
    
    self.playerGuideLayer.isSwallowTouch = YES;
}

- (void)startPlayerGuide
{
    if (self.isGuided)
    {
        return;
    }
    
    [self.playerGuideLayer startGuide];
    
    [self pauseBeatDevils];
}

- (void)closePlayerGuide
{
    self.playerGuideLayer.isSwallowTouch = NO;
    
    [self resumeBeatDevils];
}

#pragma mark -
#pragma mark 动画播放函数

- (void)onStageStartLoaded
{
    self.beatDevilsDelegate->OnStageLoadingCompleted();
}

- (void)showStageStartLayer:(int)stageNumber
{
    CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:NSLocalizedString(@"2.2-stage-loading.bmml", nil)
                                                        eventHandle:self];
    
    [GameToolFunc getStageNumberLabel:[layer getControlByName:@"stage"]
                          anchorPoint:ccp(0.5f, 0.5f)].string = [NSString stringWithFormat:@"%d", stageNumber];
    [self addChild:layer z:zStageLayer];
    
    [layer runAction:[CCSequence actions:
                      [CCDelayTime actionWithDuration:1.0f],
                      [CCCallFunc actionWithTarget:self selector:@selector(onStageStartLoaded)],
                      [CCCallFunc actionWithTarget:layer selector:@selector(removeFromParentAndCleanup:)],
                      nil]];
    
    //暂时去除粒子效果
//    if (stageNumber % 3 == 0)
//    {
//        [GameToolFunc showRain:self.labParticle];
//    }
//    else if (stageNumber % 3 == 1)
//    {
//        [GameToolFunc showSnow:self.labParticle];
//    }
//    else
//    {
//        [GameToolFunc showLeaf:self.labParticle];
//    }
}

- (void)onReadeyGoAnimeOver
{
    self.beatDevilsDelegate->OnReadeyGoAnimeOver();
}

- (void)showReadeyGoAnime
{
    self.sprReady.texture = [[CCTextureCache sharedTextureCache] addImage:@"UI/2-game/img-ready.png"];
    CCTexture2D *goTexture = [[CCTextureCache sharedTextureCache] addImage:@"UI/2-game/img-go.png"];
    
    [self.sprReady runAction:[CCSequence actions:
                              [CCCallFuncO actionWithTarget:[SimpleAudioEngine sharedEngine] selector:@selector(playEffect:) object:@"ready.wav"],
                              [CCScaleTo actionWithDuration:0.3f scale:1.0f],
                              [CCDelayTime actionWithDuration:0.5f],
                              [CCScaleTo actionWithDuration:0 scale:0],
                              [CCCallFuncO actionWithTarget:self.sprReady selector:@selector(setTexture:) object:goTexture],
                              [CCCallFuncO actionWithTarget:[SimpleAudioEngine sharedEngine] selector:@selector(playEffect:) object:@"go.wav"],
                              [CCScaleTo actionWithDuration:0.3f scale:1.0f],
                              [CCDelayTime actionWithDuration:0.5f],
                              [CCScaleTo actionWithDuration:0 scale:0],
                              [CCCallFunc actionWithTarget:self selector:@selector(onReadeyGoAnimeOver)],
                              nil]];
}

- (void)addDevilBeforeRoshamboAnime
{
    [npcAnimationMgr cleanSpriteActions];
    [npcAnimationMgr addSpriteAction:@"devil-before-roshambo.csv" delay:0];
}

- (void)addDevilAfterRoshamboAnime
{
    [npcAnimationMgr addSpriteAction:@"devil-after-roshambo.csv" target:self callback:@selector(playNpcWaiting) delay:0.5f];
}

- (void)setHits:(int)hits
{
    if (hits <= 0)
    {
        return;
    }
    
    self.labHits.string = [NSString stringWithFormat:@"%d", hits];
    
    [self.labHits stopAllActions];
    [self.sprHitBg stopAllActions];
    
    [self.labHits runAction:[CCSequence actions:
                             [CCFadeIn actionWithDuration:0],
                             [CCDelayTime actionWithDuration:0.5f],
                             [CCFadeOut actionWithDuration:0],
                             nil]];
    
    self.sprHitBg.scale = 0;
    [self.sprHitBg runAction:[CCSequence actions:
                              [CCFadeIn actionWithDuration:0],
                              [CCEaseElasticOut actionWithAction:[CCScaleTo actionWithDuration:0.5f scale:1]],
                              [CCFadeOut actionWithDuration:0],
                              nil]];
}

// 动画播放函数
- (void)playBeatNpc:(DDamageContext)damageContext
{
    [self moveMenuDown];
    
    [npcAnimationMgr cleanSpriteActions];
    
    if (damageContext.attackModel == AttackModelPlayerAttackNpc_1)
    {
        [self.npcHpMgr updateValue:damageContext.attackDamage / (float)damageContext.attackCount
                             count:damageContext.attackCount
                         withDelay:1.0f
                          interval:0.3f];
        
        [npcAnimationMgr addSpriteAction: @"1-beat-npc.csv" target:self callback:@selector(beatAnimeDone) delay:0];
        [[SimpleAudioEngine sharedEngine] performSelector:@selector(playEffect:) withObject:@"beat-1.wav" afterDelay:0.1f];
    }
    else if (damageContext.attackModel == AttackModelPlayerAttackNpc_3)
    {
        [self.npcHpMgr updateValue:damageContext.attackDamage / (float)damageContext.attackCount
                             count:damageContext.attackCount
                         withDelay:1.1f
                          interval:0.3f];
        
        [npcAnimationMgr addSpriteAction:@"3-beat-npc.csv" target:self callback:@selector(beatAnimeDone) delay:0];
        [[SimpleAudioEngine sharedEngine] performSelector:@selector(playEffect:) withObject:@"beat-3.wav" afterDelay:0.0f];
        [[SimpleAudioEngine sharedEngine] performSelector:@selector(playEffect:) withObject:@"npc-lose.wav" afterDelay:3.0f];
    }
    else
    {
        [self.npcHpMgr updateValue:damageContext.attackDamage / (float)damageContext.attackCount
                             count:damageContext.attackCount
                         withDelay:1.0f
                          interval:0.3f];
        
        [npcAnimationMgr addSpriteAction:@"5-beat-npc.csv" target:self callback:@selector(beatAnimeDone) delay:0];
        [[SimpleAudioEngine sharedEngine] performSelector:@selector(playEffect:) withObject:@"beat-5.wav" afterDelay:0.1f];
        [[SimpleAudioEngine sharedEngine] performSelector:@selector(playEffect:) withObject:@"npc-lose1.wav" afterDelay:3.6f];
    }

    [npcAnimationMgr addSpriteAction:@"npc-waiting.csv" delay:0];
}

- (void)playBeatPlayer:(DDamageContext)damageContext
{
    [self moveMenuDown];
    
    //[self.playerHpMgr addDamage:damageContext.attackDamage];
    [self.playerHpMgr updateValue:damageContext.attackDamage / (float)damageContext.attackCount
                            count:damageContext.attackCount
                        withDelay:1.5f
                         interval:0.3f];
    
    [npcAnimationMgr cleanSpriteActions];
    
    [npcAnimationMgr addSpriteAction:@"npc-beat-player.csv" target:self callback:@selector(beatAnimeDone) delay:0];
    [npcAnimationMgr addSpriteAction:@"npc-waiting.csv" delay:0];
    [[SimpleAudioEngine sharedEngine] performSelector:@selector(playEffect:) withObject:@"beat-6.wav" afterDelay:0.3f];
}

- (void)cleanupNpcAnimeAndPlayWaitingAnime
{
    [npcAnimationMgr cleanSpriteActions];
    
    [self playNpcWaiting];
}

- (void)buySkill:(SkillCode)skillCode
{
    self.beatDevilsDelegate->OnBuySkill(skillCode);
}

- (int)getSkillCount:(SkillCode)skillCode
{
    return self.beatDevilsDelegate->GetSkillCount(skillCode);
}

- (int)getSkillMaxCount:(SkillCode)skillCode
{
    return GetSkillMaxCount(skillCode);
}

- (int)getSkillPrice:(SkillCode)skillCode
{
    return GetSkillPrice(skillCode);
}

- (void)addMoney:(int)money
{
    self.beatDevilsDelegate->OnAddMoney(money);
}

- (int)curMoney
{
    return self.beatDevilsDelegate->GetCurMoney();
}

#pragma mark -
#pragma mark ShopItemManagerDelegate

- (void)onPurchaseItem:(NSString *)item success:(BOOL)isSuccess
{
    [CCAlertLayer removeAlertFromNode:self.shopLoadingAlert];
    self.shopLoadingAlert = nil;
    
    [self resumeBeatDevils];
    
    if (isSuccess)
    {
        if ([item isEqualToString:@"10_foods"])
        {
            self.beatDevilsDelegate->OnBuyFoodSuccess();
        }
        else if ([item isEqualToString:@"10_beer"])
        {
            self.beatDevilsDelegate->OnBuyBeerSuccess();
        }
    }
}

- (void)onPurchaseCancle
{
    [CCAlertLayer removeAlertFromNode:self.shopLoadingAlert];
    self.shopLoadingAlert = nil;
    
    [self resumeBeatDevils];
}

- (void)onPurchaseTimeOut:(NSString *)item
{
    [CCAlertLayer removeAlertFromNode:self.shopLoadingAlert];
    self.shopLoadingAlert = nil;
    
    [self resumeBeatDevils];
}

#pragma mark -
#pragma mark 初始化

- (void)loadGameControls
{
    CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"2-game.bmml"
                                                        eventHandle:self];
    [self addChild:layer z:zBalsamiqLayer];
    
    self.labStage = [layer getControlByName:@"stage"];
    self.labStage.opacity = 0;
    
    // 使用自定义字体
    {
        self.labHits = [GameToolFunc getHitNumberLabel:[layer getControlByName:@"hits"]
                                           anchorPoint:ccp(0.5f, 0.5f)];
        
        self.labHits.opacity = 0;
        
        self.labTotalScore = [GameToolFunc getScoreNumberLabel:[layer getControlByName:@"total-score"]
                                                   anchorPoint:ccp(0.0f, 0.5f)];
        
        self.labHighScore = [GameToolFunc getScoreNumberLabel:[layer getControlByName:@"high-score"]
                                                   anchorPoint:ccp(0.0f, 0.5f)];
    }
    
    [self.playerHpMgr setBarSprite:[layer getControlByName:@"image_player_hp"] decreaseDirection:kDecreaseFromLeft];
    [self.npcHpMgr setBarSprite:[layer getControlByName:@"image_npc_hp"] decreaseDirection:kDecreaseFromRight];
    
    CCSprite *npcSprite = [layer getControlByName:@"image_npc"];
    npcSprite.position = ccpAdd(npcSprite.position, ccp(0, 40));
    npcAnimationMgr.animationSprite = npcSprite;
    
    self.sprReady = [layer getControlByName:@"image_ready"];
    self.sprReady.scale = 0;
    
    self.sprHitBg = [layer getControlByName:@"image_hit"];
    self.sprHitBg.opacity = 0;
}

- (void)loadSkillPanelLayer
{
    self.skillPanelLayer = [SkillPanelLayer node];
    self.skillPanelLayer.delegate = self;
    [self addChild:self.skillPanelLayer z:zSkillPanelLayer];
    self.initRoshamboMenuPos = self.skillPanelLayer.position;
    
    [self.timeBarMgr setBarSprite:self.skillPanelLayer.sprTimeBar decreaseDirection:kDecreaseFromLeft];
    // 设置图片
    [self.timeBarMgr setNormalPic:@"UI/2-game/background/img-time-normal.png"
                       warningPic:@"UI/2-game/background/img-time-warning.png"];
    // 重置为0
    [self.timeBarMgr setMaxValue:10];
    [self.timeBarMgr setCurValue:0];
    [self.timeBarMgr setFollowSprite:self.skillPanelLayer.sprDevilHead];

    // 设置不可用
    self.skillPanelLayer.btnBoom.isEnabled = NO;
    self.skillPanelLayer.btnTime.isEnabled = NO;
    self.skillPanelLayer.btnMagic.isEnabled = NO;
    
    if ([GameToolFunc GetGameModel] == BeatDevilsModelHell)
    {
        // 火星上需要特殊设置些图片
        [self.timeBarMgr setNormalPic:@"UI/2-game/background/img-time-normal-mars.png"
                           warningPic:@"UI/2-game/background/img-time-warning-mars.png"];
        
        self.skillPanelLayer.sprFury.texture = [[CCTextureCache sharedTextureCache] addImage:@"UI/2-game/background/img-fury-mars.png"];
        
        self.skillPanelLayer.sprFury.position = ccpAdd(self.skillPanelLayer.sprFury.position, ccp(3, -1));
        self.skillPanelLayer.labFury.position = ccpAdd(self.skillPanelLayer.labFury.position, ccp(2, -2));
    }
    
    [self.furyMgr setBarSprite:self.skillPanelLayer.sprFury decreaseDirection:kDecreaseFromRight];
    self.furyMgr.labBar = self.skillPanelLayer.labFury;
}

- (void)loadBackground
{
    NSString *backgroundFile[BeatDevilsModelMax] =
    {
        @"2-bg-battle.bmml",
        @"2-bg-greatwall.bmml",
        @"2-bg-fuji.bmml",
        @"2-bg-mars.bmml",
    };
    
    // 加上背景
    [self addChild:[CCBalsamiqLayer layerWithBalsamiqFile:backgroundFile[[GameToolFunc GetGameModel]]
                                              eventHandle:self]
                 z:zBackground];
    
    NSString *textureName[BeatDevilsModelMax] =
    {
        @"UI/2-game/img-slot.png",
        @"UI/2-game/background/img-slot-greatwall.png",
        @"UI/2-game/background/img-slot-fuji.png",
        @"UI/2-game/background/img-slot-mars.png",
    };
    
    // 修改技能盘图片
    self.skillPanelLayer.sprSlot.texture =
    [[CCTextureCache sharedTextureCache] addImage:textureName[[GameToolFunc GetGameModel]]];
}

-(id) init
{
	if( (self=[super init]))
	{
        npcHpMgr = [[HpSpriteBarManager alloc] init];
        playerHpMgr = [[HpSpriteBarManager alloc] init];
        furyMgr = [[SpriteBarManager alloc] init];
        npcAnimationMgr = [[NpcAnimationManager alloc] init];
        timeBarMgr = [[TimeSpriteBarManager alloc] init];
        shopItemManager = [[ShopItemManager alloc] initWithShopItemManagerDelegate:self];
        
        // 1 创建界面数据
        [self loadGameControls];
        [self loadSkillPanelLayer];
        self.playerGuideLayer = [PlayerGuideLayer layerWithGameLayer:self];
        [self addChild:self.playerGuideLayer
                     z:zGuideLayer];
        [self loadBackground];
        
        // 2 绑定游戏数据
        BeatDevilsServerDelegate *delegate = new BeatDevilsServerDelegate(self);        
        self.beatDevilsDelegateValue = [NSValue valueWithPointer:delegate];
        self.beatDevilsDelegate->InitGame();

        [self schedule:@selector(updateMatchTime:)];
        
        // 播放音效
        [[SimpleAudioEngine sharedEngine] playBackgroundMusic:@"fight-bg.m4a"];
	}
	return self;
}

- (void) dealloc
{
    delete self.beatDevilsDelegate;
    self.beatDevilsDelegateValue = nil;
    
    [playerHpMgr release];
    [npcHpMgr release];
    [furyMgr release];
    [npcAnimationMgr release];
    [timeBarMgr release];
    [shopItemManager release];
    
	[super dealloc];
}

@end
