//
//  NSString+csvParserToNSArray.h
//  TabReader
//
//  Created by 青宝 中 on 11-11-9.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (csvParserToNSArray)

- (NSArray *)csvParser;

@end
