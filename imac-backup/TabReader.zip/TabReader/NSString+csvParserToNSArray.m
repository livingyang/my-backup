//
//  NSString+csvParserToNSArray.m
//  TabReader
//
//  Created by 青宝 中 on 11-11-9.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "NSString+csvParserToNSArray.h"

@implementation NSString (csvParserToNSArray)

- (NSArray *)csvParser
{
    NSArray *array = [self componentsSeparatedByString:@"\n"];
    
    int column = [[[array objectAtIndex:0] componentsSeparatedByString:@","] count];
    
    NSMutableArray *result = [NSMutableArray array];
    for (NSString *lineStr in array)
    {
        NSString *clearStr = [lineStr stringByReplacingOccurrencesOfString:@"\""
                                                                withString:@""];
        
        NSArray *lineArray = [clearStr componentsSeparatedByString:@","];
        if (lineArray.count == column)
        {
            [result addObject:lineArray];
        }
    }
    
    return result;
}

@end
