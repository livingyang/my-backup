//
//  WeiboBingViewController.m
//  TabReader
//
//  Created by 青宝 中 on 11-11-11.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "WeiboBindViewController.h"
#import "WeiboViewController.h"
#import "QWeiboHelper.h"
#import "SinaWeiboHelper.h"

@implementation WeiboBindViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)loadWeiboState
{
    btnQWeibo.titleLabel.text = [QWeiboHelper instance].isLogin ? @"已绑定" : @"未绑定";
    btnSinaWeibo.titleLabel.text = [SinaWeiboHelper instance].isLogin ? @"已绑定" : @"未绑定";
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    // Do any additional setup after loading the view from its nib.
    
    [self loadWeiboState];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)showWeiboViewController:(WeiboHelper *)helper
{
    [self.navigationController pushViewController:[WeiboViewController controllerWithWeiboHelper:helper]
                                         animated:YES];
}

- (IBAction)onQWeiboBind:(id)sender
{
    if ([QWeiboHelper instance].isLogin)
    {
        [[QWeiboHelper instance] logout];
    }
    else
    {
        [self showWeiboViewController:[QWeiboHelper instance]];
    }
}

- (IBAction)onSinaWeiboBind:(id)sender
{
    if ([SinaWeiboHelper instance].isLogin)
    {
        [[SinaWeiboHelper instance] logout];
    }
    else
    {
        [self showWeiboViewController:[SinaWeiboHelper instance]];
    }
}

@end
