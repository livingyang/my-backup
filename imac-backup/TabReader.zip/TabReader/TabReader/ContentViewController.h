//
//  ContentViewController.h
//  TabReader
//
//  Created by 青宝 中 on 11-10-28.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class UIPageViewCell;
@class UIContentViewCell;
@interface ContentViewController : UITableViewController
{
	UIPageViewCell *tmpPageCell;
	UIContentViewCell *tmpContentCell;
    
	UINib *pageCellNib;
	UINib *contentCellNib;
    
    int curPage;
}

@property (nonatomic, retain) IBOutlet UIPageViewCell *tmpPageCell;
@property (nonatomic, retain) IBOutlet UIContentViewCell *tmpContentCell;
@property (nonatomic, retain) UINib *pageCellNib;
@property (nonatomic, retain) UINib *contentCellNib;

- (IBAction)onFirstClick:(id)sender;
- (IBAction)onLastClick:(id)sender;
- (IBAction)onPrevClick:(id)sender;
- (IBAction)onNextClick:(id)sender;

@end
