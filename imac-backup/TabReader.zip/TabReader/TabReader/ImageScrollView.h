//
//  ImageScrollView.h
//  ScrollImageView
//
//  Created by 青宝 中 on 11-11-3.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#define IMAGE_CACHE (3)
@interface ImageScrollView : UIScrollView
{
    NSArray *picPathArray;
    
    int curPicIndex;
    
    // 0 - prevImageView
    // 1 - curImageView
    // 2 - nextImageView
    UIImageView *imageViews[IMAGE_CACHE];
}

@property (nonatomic, retain) NSArray *picPathArray;
@property (readonly) int curPicIndex;

- (void)setPicIndex:(int)picIndex;

- (void)updatePicCache;

@end
