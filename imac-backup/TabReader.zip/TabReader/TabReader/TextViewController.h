//
//  TextViewController.h
//  TabReader
//
//  Created by 青宝 中 on 11-11-1.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SwitchViewController.h"

@interface TextViewController : SwitchViewController <UIScrollViewDelegate>
{
    IBOutlet UIWebView *webView;
    
    IBOutlet UIButton *prevButton;
    IBOutlet UIButton *nextButton;
    
    int curBookIndex;
}

@property int curBookIndex;

@end
