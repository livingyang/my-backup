//
//  ImageScrollView.m
//  ScrollImageView
//
//  Created by 青宝 中 on 11-11-3.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "ImageScrollView.h"

@implementation ImageScrollView

@synthesize picPathArray, curPicIndex;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        // Initialization code
        [self setBackgroundColor:[UIColor blackColor]];
        [self setCanCancelContentTouches:NO];
        self.indicatorStyle = UIScrollViewIndicatorStyleWhite;
        self.clipsToBounds = YES;		// default is NO, we want to restrict drawing within our scrollview
        self.scrollEnabled = YES;
        
        // pagingEnabled property default is NO, if set the scroller will stop or snap at each photo
        // if you want free-flowing scroll, don't set this property.
        self.pagingEnabled = YES;
        
    }
    return self;
}

- (void)setScrollProperty
{
    [self setBackgroundColor:[UIColor blackColor]];
    [self setCanCancelContentTouches:NO];
    self.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    self.clipsToBounds = YES;
    self.scrollEnabled = YES;
    self.showsHorizontalScrollIndicator = NO;
    
    self.pagingEnabled = YES;
}

- (void)loadImagesAtMidView:(int)picIndex
{
    if (picIndex < 0 || picIndex >= self.picPathArray.count - 1)
    {
        NSLog(@"图片索引越界");
        return;
    }
    
    const CGRect maxRect = self.bounds;
    float widthDivHeight = maxRect.size.width / maxRect.size.height;
    
    for (int i = 0; i < IMAGE_CACHE; ++i)
    {
        UIImage *image = [UIImage imageWithContentsOfFile:[self.picPathArray objectAtIndex:picIndex + i - 1]];
        imageViews[i].image = image;
        
        if (image.size.width / image.size.height > widthDivHeight)
        {
            CGRect newBounds = maxRect;
            newBounds.size.height = image.size.height * maxRect.size.width / image.size.width;
            
            imageViews[i].bounds = newBounds;
        }
        else
        {
            CGRect newBounds = maxRect;
            newBounds.size.width = image.size.width * maxRect.size.height / image.size.height;
            
            imageViews[i].bounds = newBounds;
        }
    }
}

- (void)setPicIndex:(int)picIndex
{
    NSAssert(self.picPathArray.count >= 3, @"图片太少");
    
    [self setScrollProperty];
    
	[self setContentSize:CGSizeMake((IMAGE_CACHE * self.bounds.size.width), self.bounds.size.height)];
    
    for (int i = 0; i < IMAGE_CACHE; ++i)
    {
        CGRect rect = self.bounds;
        rect.origin.x = i * self.bounds.size.width;
        
        UIImageView *imageView = [[[UIImageView alloc] initWithFrame:rect] autorelease];
        [self addSubview:imageView];
        
        imageViews[i] = imageView;
    }
    
    if (picIndex == self.picPathArray.count - 1)
    {
        [self loadImagesAtMidView:picIndex - 1];
        
        self.contentOffset = CGPointMake(self.bounds.size.width * 2, 0);
    }
    else if (picIndex == 0)
    {
        [self loadImagesAtMidView:picIndex + 1];
        
        self.contentOffset = CGPointMake(self.bounds.size.width * 0, 0);
    }
    else
    {
        [self loadImagesAtMidView:picIndex];
        
        self.contentOffset = CGPointMake(self.bounds.size.width * 1, 0);
    }
    
    curPicIndex = picIndex;
}

- (void)updatePicCache
{
    if (self.contentOffset.x > self.bounds.size.width + 1)
    {
        //NSLog(@"move to right"); // 停留在右边，1 从中间移动到右边，2 在右边徘徊
        if (curPicIndex == self.picPathArray.count - 2) 
        {
            ++curPicIndex;
        }
        else if (curPicIndex < self.picPathArray.count - 2)
        {
            ++curPicIndex;
            
            self.contentOffset = CGPointMake(self.bounds.size.width * 1, 0);
            [self loadImagesAtMidView:curPicIndex];
        }
    }
    else if (self.contentOffset.x < self.bounds.size.width - 1)
    {
        //NSLog(@"move to left");
        if (curPicIndex == 1)
        {
            --curPicIndex;
        }
        else if (curPicIndex > 1)
        {
            --curPicIndex;
            
            self.contentOffset = CGPointMake(self.bounds.size.width * 1, 0);
            [self loadImagesAtMidView:curPicIndex];
        }
    }
    else
    {
        //NSLog(@"move to middle");
        if (curPicIndex == 0)
        {
            ++curPicIndex;
        }
        else if (curPicIndex == self.picPathArray.count - 1)
        {
            --curPicIndex;
        }
    }
    
    //NSLog(@"curPicIndex = %d", curPicIndex);
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

@end
