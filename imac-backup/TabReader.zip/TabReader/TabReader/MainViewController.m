//
//  MainViewController.m
//  TabReader
//
//  Created by 青宝 中 on 11-10-28.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "MainViewController.h"

#import "ContentViewController.h"
#import "AlbumViewController.h"

#import "AdManager.h"
#import "BooksManager.h"
#import "LinkManager.h"
#import "ShareManager.h"
#import "SettingManager.h"

@implementation MainViewController

@synthesize contentViewController, albumViewController;

- (void)dealloc
{
    self.contentViewController = nil;
    
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [BooksManager instance];
    [LinkManager instance];
	// Do any additional setup after loading the view, typically from a nib.
    
    //tabBar.delegate = self;
    
    for (UIViewController *viewController in self.childViewControllers)
    {
        NSLog(@"%@, title = %@", viewController, viewController.title);
    }
    
    for (UIView *view in self.view.subviews)
    {
        NSLog(@"%@, tag = %d", view, view.tag);
    }
    
    [[AdManager instance] addAdViewToNavigationController:self.navigationController];
    
    NSString *index = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"index.html"];
    NSURL *url = [NSURL fileURLWithPath:index];
    [webView loadRequest:[NSURLRequest requestWithURL:url]];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    tabBar.selectedItem = nil;
    
    self.navigationController.toolbarHidden = YES;
    
    self.title = @"爱爱无穷技";
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
    
    self.title = @"首页";
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (void)tabBar:(UITabBar *)bar didSelectItem:(UITabBarItem *)item
{
    switch ([bar.items indexOfObject:item])
    {
        case 0:
        {
            if (self.contentViewController == nil)
            {
                self.contentViewController = [[[ContentViewController alloc] initWithNibName:nil bundle:nil] autorelease];
            }
            
            [self.navigationController pushViewController:self.contentViewController animated:YES];
        }break;
        case 1:
        {
            if (self.albumViewController == nil)
            {
                self.albumViewController = [[[AlbumViewController alloc] initWithNibName:nil bundle:nil] autorelease];
            }
            
            [self.navigationController pushViewController:self.albumViewController animated:YES];
        }break;
        case 2:
        {
            [[ShareManager instance] openShareActionSheetFromController:self.navigationController];
        }break;
        default:
            break;
    }
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return UIInterfaceOrientationIsPortrait(interfaceOrientation);
    // Return YES for supported orientations
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSURL *url = request.URL;
    
    if ([url.absoluteString rangeOfString:@"userpub.itunes.apple.com"].length > 0)
    {
        NSString *m_appleID = @"481225375";
        NSString *str = [NSString stringWithFormat: 
                      @"itms-apps://ax.itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?type=Purple+Software&id=%@", 
                      m_appleID];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:str]];
        return NO;
    }
    
    if (navigationType == UIWebViewNavigationTypeLinkClicked)
    {
        [[UIApplication sharedApplication] openURL:url];
        return NO;
    }
    
    return YES;
}

@end
