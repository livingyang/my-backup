//
//  PostTextViewController.h
//  TabReader
//
//  Created by 青宝 中 on 11-11-11.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WeiboHelper;
@interface PostTextViewController : UIViewController
{
    IBOutlet UITextView *textView;
    
    IBOutlet UILabel *labBind;
    
    WeiboHelper *curHelper;
}

@property (nonatomic, assign) WeiboHelper *curHelper;

@end
