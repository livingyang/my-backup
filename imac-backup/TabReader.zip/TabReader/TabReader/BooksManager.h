//
//  BooksManager.h
//  TabReader
//
//  Created by 青宝 中 on 11-10-31.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BooksManager : NSObject
{
    NSMutableArray *totalBookInfo;
    NSMutableDictionary *configInfo;
    
    NSMutableArray *totalImageInfo;
}

@property (nonatomic, readonly) NSMutableArray *totalBookInfo;
@property (nonatomic, readonly) NSMutableDictionary *configInfo;

@property (nonatomic, readonly) NSMutableArray *totalImageInfo;


@property (nonatomic, readonly) NSString *totalBookDir;
@property (nonatomic, readonly) NSMutableArray *totalImagePath;

+ (BooksManager *)instance;

- (NSString *)getBookTitle:(NSUInteger)bookIndex;
- (NSString *)getBookFilePath:(NSUInteger)bookIndex;
- (NSString *)getBookThumbPath:(NSUInteger)bookIndex;
- (NSArray *)getBookImages:(NSUInteger)bookIndex;

- (NSString *)getImageFilePath:(NSUInteger)imageIndex;
- (NSString *)getImageTitle:(NSUInteger)imageIndex;

- (NSUInteger)getImageIndex:(NSUInteger)bookIndex;
- (NSUInteger)getBookIndex:(NSUInteger)imageIndex;

@end
