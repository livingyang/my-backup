//
//  AlbumViewCell.h
//  TabReader
//
//  Created by 青宝 中 on 11-11-1.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#define ALBUM_CELL_BTN_COUNT (3)
#define ALBUM_CELL_HEIGHT (68)

@interface AlbumViewCell : UITableViewCell
{
    UIButton *btn1;
    UIButton *btn2;
    UIButton *btn3;
}

@property (nonatomic, retain) IBOutlet UIButton *btn1;
@property (nonatomic, retain) IBOutlet UIButton *btn2;
@property (nonatomic, retain) IBOutlet UIButton *btn3;

@end
