//
//  NSString+SearchTextIndex.m
//  GetHtmlPic
//
//  Created by 青宝 中 on 11-11-7.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "NSString+SearchTextIndex.h"

@implementation NSString (SearchTextIndex)

- (NSArray *)getSearchStringIndexes:(NSString *)searchString
{
    NSRange searchRange = 
    {
        0,
        self.length,
    };
    
    NSMutableArray *result = [NSMutableArray array];
    
    
    for (NSRange findRange = [self rangeOfString:searchString
                                               options:NSCaseInsensitiveSearch
                                                 range:searchRange];
         findRange.length != 0;
         findRange = [self rangeOfString:searchString
                                       options:NSCaseInsensitiveSearch
                                         range:searchRange])
    {
        searchRange.location = findRange.location + findRange.length;
        searchRange.length = self.length - searchRange.location;
        
        [result addObject:[NSNumber numberWithInt:searchRange.location]];
    }
    
    return result;
}

- (NSString *)getStringFromIndex:(int)index stopAt:(NSString *)stopStr
{
    if (index >= self.length)
    {
        return nil;
    }
    
    NSRange range = [self rangeOfString:stopStr
                                options:NSCaseInsensitiveSearch
                                  range:NSMakeRange(index, self.length - index)];
    
    if (range.length == 0)
    {
        return nil;
    }
    
    return [self substringWithRange:NSMakeRange(index, range.location - index)];
}

@end
