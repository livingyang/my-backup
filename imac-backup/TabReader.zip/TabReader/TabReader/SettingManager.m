//
//  SettingManager.m
//  TabReader
//
//  Created by 青宝 中 on 11-11-4.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "SettingManager.h"

#define KEY_TEXT_SIZE @"KEY_TEXT_SIZE"
#define KEY_BG_INDEX @"KEY_BG_INDEX"

@interface SettingManager (Private)

- (void)loadConfig;

@end

@implementation SettingManager

@synthesize configDic;

+ (SettingManager *)instance
{
    static SettingManager *mgr = nil;
    if (mgr == nil)
    {
        mgr = [[SettingManager alloc] init];
    }
    
    return mgr;
}

- (id)init
{
    self = [super init];
    if (self)
    {
        [self loadConfig];
    }
    return self;
}

- (void)loadConfig
{
    NSString *configPath = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"books/config.plist"];
    self.configDic = [NSDictionary dictionaryWithContentsOfFile:configPath];
    
    NSLog(@"%@", self.configDic);
}

- (TEXT_SIZE)textSize
{
    if ([[NSUserDefaults standardUserDefaults] objectForKey:KEY_TEXT_SIZE] == nil)
    {
        return kNormalSize;
    }
    
    return [[NSUserDefaults standardUserDefaults] integerForKey:KEY_TEXT_SIZE];
}

- (void)setTextSize:(TEXT_SIZE)textSize
{
    [[NSUserDefaults standardUserDefaults] setInteger:textSize forKey:KEY_TEXT_SIZE];
}

- (BG_INDEX)bgIndex
{
    if ([[NSUserDefaults standardUserDefaults] objectForKey:KEY_BG_INDEX] == nil)
    {
        return kBg1;
    }
    
    return [[NSUserDefaults standardUserDefaults] integerForKey:KEY_BG_INDEX];
}

- (void)setBgIndex:(BG_INDEX)bgIndex
{
    [[NSUserDefaults standardUserDefaults] setInteger:bgIndex forKey:KEY_BG_INDEX];
}

- (NSString *)curCssFilePath
{
    NSString *cssString = nil;
    switch (self.textSize)
    {
        case kBigSize:
        {
            cssString = [[configDic objectForKey:@"TextSize"] objectForKey:@"big"];
        }break;
        case kSmallSize:
        {
            cssString = [[configDic objectForKey:@"TextSize"] objectForKey:@"small"];
        }break;
        default:
        {
            cssString = [[configDic objectForKey:@"TextSize"] objectForKey:@"normal"];
        }break;
    }
    
    cssString = [@"books" stringByAppendingPathComponent:cssString];
    
    return [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:cssString];
}

- (NSString *)curBgFilePath
{
    NSString *bgString = nil;
    switch (self.bgIndex)
    {
        case kBg1:
        {
            bgString = [[configDic objectForKey:@"BackgroundImage"] objectForKey:@"bg1"];
        }break;
        case kBg2:
        {
            bgString = [[configDic objectForKey:@"BackgroundImage"] objectForKey:@"bg2"];
        }break;
        case kBg3:
        {
            bgString = [[configDic objectForKey:@"BackgroundImage"] objectForKey:@"bg3"];
        }break;
        default:
        {
            bgString = nil;//[[configDic objectForKey:@"BackgroundImage"] objectForKey:@"old"];
        }break;
    }
    
    bgString = [@"books" stringByAppendingPathComponent:bgString];
    
    return [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:bgString];
}

- (NSString *)curCssFileName
{
    switch (self.textSize)
    {
        case kBigSize:
        {
            return [[[configDic objectForKey:@"TextSize"] objectForKey:@"big"] lastPathComponent];
        }break;
        case kSmallSize:
        {
            return [[[configDic objectForKey:@"TextSize"] objectForKey:@"small"] lastPathComponent];
        }break;
        default:
        {
            return [[[configDic objectForKey:@"TextSize"] objectForKey:@"normal"] lastPathComponent];
        }break;
    }
}

- (NSString *)replaceCssFilePath
{
    NSString *replaceFilePath = [configDic objectForKey:@"ReplaceCssFile"];
    replaceFilePath = [@"books" stringByAppendingPathComponent:replaceFilePath];
    
    return [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:replaceFilePath];
}

- (void)dealloc
{
    self.configDic = nil;
    
    [super dealloc];
}

@end
