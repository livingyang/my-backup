//
//  ContentViewController.m
//  TabReader
//
//  Created by 青宝 中 on 11-10-28.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "ContentViewController.h"
#import "BooksManager.h"
#import "SettingManager.h"

#import "UIPageViewCell.h"
#import "UIContentViewCell.h"
#import "TextViewController.h"
#import "AdManager.h"
#import "SettingViewController.h"

#define MAX_CONTENT_COUNT_PAGE (20)

@implementation ContentViewController

@synthesize tmpPageCell, tmpContentCell, pageCellNib, contentCellNib;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"目录";
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    curPage = 1;
    
	self.pageCellNib = [UINib nibWithNibName:@"UIPageViewCell" bundle:nil];
	self.contentCellNib = [UINib nibWithNibName:@"UIContentViewCell" bundle:nil];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.navigationController.toolbarHidden = NO;
    
    //设置背景
    UIImage *bg = [UIImage imageWithContentsOfFile:[SettingManager instance].curBgFilePath];
    [self.tableView setBackgroundView:[[[UIImageView alloc] initWithImage:bg] autorelease]];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    self.navigationController.navigationBar.topItem.rightBarButtonItem = 
    [[UIBarButtonItem alloc] initWithTitle:@"设置" style:UIBarButtonItemStyleBordered target:self action:@selector(onSettingClick:)];
}

- (void)onSettingClick:(id)sender
{
    [self.navigationController pushViewController:
     [[[SettingViewController alloc] initWithNibName:nil bundle:nil] autorelease] animated:YES];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (int)totalPage
{
    return 1 + ([BooksManager instance].totalBookInfo.count - 1) / MAX_CONTENT_COUNT_PAGE;
}

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    //多出来的一行，用于创建翻页控件
    if (curPage < self.totalPage || ([BooksManager instance].totalBookInfo.count % MAX_CONTENT_COUNT_PAGE == 0))
    {
        return MAX_CONTENT_COUNT_PAGE + 1;
    }
    else
    {
        return [BooksManager instance].totalBookInfo.count % MAX_CONTENT_COUNT_PAGE + 1;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (void)setPage
{
    [tmpPageCell setPage:curPage maxPage:self.totalPage];
}

- (int)getBookIndexFromSectionIndex:(int)sectionIndex
{
    return sectionIndex + (curPage - 1) * MAX_CONTENT_COUNT_PAGE;
}

// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) 
    {
        int bookIndex = [self getBookIndexFromSectionIndex:indexPath.section];
        if (bookIndex < [BooksManager instance].totalBookInfo.count && indexPath.section < MAX_CONTENT_COUNT_PAGE)
        {
            [self.contentCellNib instantiateWithOwner:self options:nil];
            
            // 初始化cell
            {
                [tmpContentCell setThumbPic:[[BooksManager instance] getBookThumbPath:bookIndex]];
                [tmpContentCell setTitleText:[[BooksManager instance] getBookTitle:bookIndex]];
            }
            
            cell = tmpContentCell;
            //cell.backgroundColor = [UIColor clearColor];
            self.tmpContentCell = nil;
        }
        else
        {
            // 创建翻页按钮，此处应该需要autorelease
            [self.pageCellNib instantiateWithOwner:self options:nil];
            cell = tmpPageCell;
            [self setPage];
        }
    }
    
    // Configure the cell.
    //cell.textLabel.text = NSLocalizedString(@"Detail", @"Detail");
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    int bookIndex = [self getBookIndexFromSectionIndex:indexPath.section];
    
    if (bookIndex < [BooksManager instance].totalBookInfo.count && indexPath.section < MAX_CONTENT_COUNT_PAGE)
    {
        TextViewController *textViewController = [[[TextViewController alloc] initWithNibName:nil bundle:nil] autorelease];
        
        textViewController.curBookIndex = bookIndex;
        
        //[textViewController loadFromText:[[BooksManager instance] getBookContentPath:bookIndex]];
        [self.navigationController pushViewController:textViewController animated:YES];
    }
}

// 翻页功能
- (void)refreshPage
{
    [self.tableView reloadData];
    
    [self.tableView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionTop];
    [self.tableView deselectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO];
}

- (IBAction)onFirstClick:(id)sender
{
    if (curPage != 1)
    {
        curPage = 1;
        [self refreshPage];
    }
}

- (IBAction)onLastClick:(id)sender
{
    if (curPage != self.totalPage)
    {
        curPage = self.totalPage;
        [self refreshPage];
    }
}

- (IBAction)onPrevClick:(id)sender
{
    if (curPage > 1)
    {
        --curPage;
        [self refreshPage];
    }
}

- (IBAction)onNextClick:(id)sender
{
    if (self.totalPage > curPage)
    {
        ++curPage;
        [self refreshPage];
    }
}


- (void)dealloc
{
	self.tmpPageCell = nil;
	self.pageCellNib = nil;
	
    [super dealloc];
}

@end
