//
//  UIContentViewCell.m
//  TabReader
//
//  Created by 青宝 中 on 11-10-31.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "UIContentViewCell.h"

@implementation UIContentViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setThumbPic:(NSString *)picPath
{
    thumb.image = [UIImage imageWithContentsOfFile:picPath];
}

- (void)setTitleText:(NSString *)text
{
    title.text = text;
}

@end
