//
//  ShareManager.h
//  TabReader
//
//  Created by 青宝 中 on 11-11-5.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>

@class WeiboHelper;
@interface ShareManager : NSObject <UIActionSheetDelegate, MFMailComposeViewControllerDelegate, MFMessageComposeViewControllerDelegate>
{
    UILabel *feedbackMsg;
    
    UINavigationController *navigationController;
    
    BOOL isSinaBinded;
}

@property (nonatomic, readonly) BOOL isSinaBinded;
@property (nonatomic, readonly) NSString *shareText;

+ (ShareManager *)instance;

- (void)openShareActionSheetFromController:(UINavigationController *)controller;

- (void)showPostView:(WeiboHelper *)weiboHelper;

@end
