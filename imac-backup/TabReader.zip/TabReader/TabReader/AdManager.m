//
//  AdManager.m
//  TabReader
//
//  Created by 青宝 中 on 11-11-4.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "AdManager.h"

@implementation AdManager

@synthesize adView;

+ (AdManager *)instance
{
    static AdManager *mgr = nil;
    if (mgr == nil)
    {
        mgr = [[AdManager alloc] init];
    }
    
    return mgr;
}

- (GADBannerView *)addAdView:(UIViewController *)viewController
{
    if (adView != nil)
    {
        return adView;
    }
    
    // Create a view of the standard size at the bottom of the screen.
    adView = [[[GADBannerView alloc]
               initWithFrame:CGRectMake(0.0,
                                        viewController.view.frame.size.height -
                                        GAD_SIZE_320x50.height + 5,
                                        GAD_SIZE_320x50.width,
                                        GAD_SIZE_320x50.height)] autorelease];
    
    // Specify the ad's "unit identifier." This is your AdMob Publisher ID.
    adView.adUnitID = @"a14e365a26a7b67";
    
    // Let the runtime know which UIViewController to restore after taking
    // the user wherever the ad goes and add it to the view hierarchy.
    adView.rootViewController = viewController;
    [viewController.view addSubview:adView];
    
    // Initiate a generic request to load it with an ad.
    [adView loadRequest:[GADRequest request]];
    
    return adView;
}

- (GADBannerView *)addAdViewToNavigationController:(UINavigationController *)navigationController
{
    if (adView != nil)
    {
        return adView;
    }
    
    // Create a view of the standard size at the bottom of the screen.
    adView = [[[GADBannerView alloc]
               initWithFrame:CGRectMake(0.0,
                                        0.0,
                                        GAD_SIZE_320x50.width,
                                        GAD_SIZE_320x50.height)] autorelease];
    
    // Specify the ad's "unit identifier." This is your AdMob Publisher ID.
    adView.adUnitID = @"a14e365a26a7b67";
    adView.delegate = self;
    
    // Let the runtime know which UIViewController to restore after taking
    // the user wherever the ad goes and add it to the view hierarchy.
    adView.rootViewController = navigationController;
    [navigationController.toolbar addSubview:adView];
    CGRect rect = navigationController.toolbar.bounds;
    rect.size.height = adView.bounds.size.height;
    navigationController.toolbar.bounds = rect;
    
    // Initiate a generic request to load it with an ad.
    [adView loadRequest:[GADRequest request]];
    
    return adView;
}

- (void)removeAdView
{
    [adView removeFromSuperview];
    adView = nil;
}

@end
