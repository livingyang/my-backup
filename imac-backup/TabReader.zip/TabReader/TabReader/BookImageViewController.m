//
//  TextImageViewController.m
//  TabReader
//
//  Created by 青宝 中 on 11-11-7.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "BookImageViewController.h"
#import "ImageScrollView.h"
#import "BooksManager.h"
#import "TextViewController.h"

@interface BookImageViewController (Private)

- (void)updateTitleAndPage:(int)imageIndex;

@end

@implementation BookImageViewController

@synthesize curImageIndex;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    sclImage.delegate = self;
    sclImage.picPathArray = [BooksManager instance].totalImagePath;
    
    [self updateTitleAndPage:curImageIndex];
    
    [sclImage setPicIndex:curImageIndex];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (NSString *)switchButtonTitle
{
    return @"正文";
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSLog(@"point = %@", NSStringFromCGPoint(scrollView.contentOffset));
    
    if (scrollView == sclImage)
    {
        [sclImage updatePicCache];
        
        [self updateTitleAndPage:sclImage.curPicIndex];
        
        curImageIndex = sclImage.curPicIndex;
    }
}

- (SwitchViewController *)switchTargetController
{
    TextViewController *viewController = [[[TextViewController alloc] initWithNibName:nil bundle:nil] autorelease];
    viewController.curBookIndex = [[BooksManager instance] getBookIndex:self.curImageIndex];
    return viewController;
}

- (void)updateTitleAndPage:(int)imageIndex
{
//    labTitle.text = [[BooksManager instance] getBookTitle:
//                     [[BooksManager instance] getBookIndex:imageIndex]];
    
    labTitle.text = [[BooksManager instance] getImageTitle:imageIndex];
    
    NSString *page = [NSString stringWithFormat:@"%d/%d", imageIndex + 1, [BooksManager instance].totalImageInfo.count];
    labPage.text = page;
}

@end
