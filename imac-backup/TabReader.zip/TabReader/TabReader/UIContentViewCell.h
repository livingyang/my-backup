//
//  UIContentViewCell.h
//  TabReader
//
//  Created by 青宝 中 on 11-10-31.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIContentViewCell : UITableViewCell
{
    IBOutlet UIImageView *thumb;
    IBOutlet UILabel *title;
}

- (void)setThumbPic:(NSString *)picPath;

- (void)setTitleText:(NSString *)text;

@end
