//
//  SettingManager.h
//  TabReader
//
//  Created by 青宝 中 on 11-11-4.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

enum
{
    kSmallSize,
    kNormalSize,
    kBigSize,
};
typedef NSInteger TEXT_SIZE;

enum
{
    kNoBg,
    kBg1,
    kBg2,
    kBg3,
};
typedef NSInteger BG_INDEX;

@interface SettingManager : NSObject
{
    NSDictionary *configDic;
}

@property (nonatomic, retain) NSDictionary *configDic;

@property (readwrite) TEXT_SIZE textSize;
@property (readwrite) BG_INDEX bgIndex;

@property (readonly) NSString *curCssFilePath;
@property (readonly) NSString *curBgFilePath;

@property (readonly) NSString *curCssFileName;

+ (SettingManager *)instance;

@end
