//
//  PostTextViewController.m
//  TabReader
//
//  Created by 青宝 中 on 11-11-11.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "PostTextViewController.h"
#import "WeiboHelper.h"
#import "ShareManager.h"
#import "WeiboViewController.h"

@interface PostTextViewController (Private)

- (void)showWeiboViewController:(WeiboHelper *)helper;

@end

@implementation PostTextViewController

@synthesize curHelper;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (curHelper.isLogin)
    {
        labBind.text = @"已绑定";
    }
    else
    {
        labBind.text = @"未绑定";
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    textView.text = [ShareManager instance].shareText;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)showWeiboViewController:(WeiboHelper *)helper
{
    [self.navigationController pushViewController:[WeiboViewController controllerWithWeiboHelper:helper]
                                         animated:YES];
}

- (IBAction)onPostMsg:(id)sender
{
    if (curHelper.isLogin == NO)
    {
        [self showWeiboViewController:curHelper];
        return;
    }
    
    if (textView.text.length == 0)
    {
        return;
    }
    
    [curHelper postTextMessage:textView.text];
}

@end
