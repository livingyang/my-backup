//
//  SwitchViewController.m
//  SwitchTwoView
//
//  Created by 青宝 中 on 11-11-7.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "SwitchViewController.h"
#import "UINavigationController+CustomPushView.h"
#import "ShareManager.h"

@interface SwitchViewController (Private)

- (NSString *)switchButtonTitle;

@end

@implementation SwitchViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    UISegmentedControl *segmentedControl = [[[UISegmentedControl alloc] initWithFrame:CGRectMake(80.0f, 8.0f, 100.0f, 30.0f)] autorelease];
    
    [segmentedControl insertSegmentWithTitle:@"分享" atIndex:0 animated:YES]; 
    [segmentedControl insertSegmentWithTitle:self.switchButtonTitle atIndex:1 animated:YES]; 
    segmentedControl.segmentedControlStyle = UISegmentedControlStyleBar; 
    segmentedControl.momentary = YES; 
    segmentedControl.multipleTouchEnabled=NO; 
    [segmentedControl addTarget:self action:@selector(onSegmentedControlPressed:) forControlEvents:UIControlEventValueChanged]; 
    
    
    self.navigationController.navigationBar.topItem.rightBarButtonItem =
    [[[UIBarButtonItem alloc] initWithCustomView:segmentedControl] autorelease];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (SwitchViewController *)switchTargetController
{
    NSAssert(0, @"override to create target viewcontroller");
    return nil;
}

- (NSString *)switchButtonTitle
{
    return @"switch";
}

- (void)onSegmentedControlPressed:(id)sender
{
    if ([sender selectedSegmentIndex] == 0)
    {
        // share
        [[ShareManager instance] openShareActionSheetFromController:self.navigationController];
    }
    else
    {
        // switch
        UINavigationController *navigationController = self.navigationController;
        
        [navigationController popViewControllerAnimated:NO];
        [navigationController pushViewController:self.switchTargetController
                          animatedWithTransition:UIViewAnimationTransitionFlipFromLeft];
    }
}

@end
