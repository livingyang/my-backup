//
//  BooksManager.m
//  TabReader
//
//  Created by 青宝 中 on 11-10-31.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "BooksManager.h"

#import "NSString+SearchTextIndex.h"
#import "NSString+csvParserToNSArray.h"

#define CONFIG_PLIST @"books/config.plist"
#define CONTENT_PLIST @"books/content.plist"

@interface BooksManager (Private)

- (void)loadTotalBookInfo:(NSMutableArray *)array;

- (void)loadImageInfo:(NSMutableArray *)array;

@end

@implementation BooksManager

@synthesize totalBookInfo, configInfo, totalImageInfo;

+ (BooksManager *)instance
{
    static BooksManager *mgr = nil;
    
    if (mgr == nil)
    {
        mgr = [[BooksManager alloc] init];
    }
    
    return mgr;
}

- (id)init
{
    self = [super init];
    if (self)
    {
        totalBookInfo = [[NSMutableArray alloc] init];
        [self loadTotalBookInfo:totalBookInfo];
        
        configInfo = [[NSMutableDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:CONFIG_PLIST]];
        
        totalImageInfo = [[NSMutableArray alloc] init];
        
        [self loadImageInfo:totalImageInfo];
        
//        NSLog(@"content = \n%@", totalBookInfo);
//        NSLog(@"config = \n%@", configInfo);
//        NSLog(@"imageInfo = \n%@", imageInfo);
//        NSLog(@"totalImagePath = \n%@", totalImagePath);
    }
    return self;
}

- (void)dealloc
{
    [totalBookInfo release];
    [configInfo release];
    [totalImageInfo release];
    
    [super dealloc];
}

- (void)loadImageInfo:(NSMutableArray *)array
{
    //1 读取image的csv信息
    NSString *filePath = [self.totalBookDir stringByAppendingPathComponent:@"album.csv"];
    NSString *str = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    NSArray *csvArray = [str csvParser];
    
    NSMutableDictionary *dic = [NSMutableDictionary dictionaryWithCapacity:csvArray.count];
    for (NSArray *lineArray in csvArray)
    {
        [dic setObject:[lineArray objectAtIndex:1]
                forKey:[lineArray objectAtIndex:0]];
    }
    
    for (int bookIndex = 0; bookIndex < totalBookInfo.count; ++bookIndex)
    {
        for (NSString *imagePath in [self getBookImages:bookIndex])
        {
            NSString *imageName = [imagePath lastPathComponent];
            
            NSMutableDictionary *info = [NSMutableDictionary dictionary];
            [info setObject:imagePath forKey:@"imagePath"];
            [info setObject:[NSNumber numberWithInt:bookIndex] forKey:@"bookIndex"];
            [info setObject:[dic objectForKey:imageName]
                     forKey:@"imageTitle"];
            [array addObject:info];
        }
    }
}

- (NSArray *)loadBookImagePath:(NSString *)htmlPath
{
    NSString *searchStr = @"src=\"";
    
    NSString *htmlStr = [NSString stringWithContentsOfFile:htmlPath encoding:NSUTF8StringEncoding error:nil];
    NSArray *searchedArray = [htmlStr getSearchStringIndexes:searchStr];
    
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSNumber *searchIndex in searchedArray)
    {
        NSString *picName = [htmlStr getStringFromIndex:[searchIndex intValue] stopAt:@"\""];
        NSString *picPath = [[htmlPath stringByDeletingLastPathComponent] stringByAppendingPathComponent:picName];
        [array addObject:picPath];
    }
    
    return array;
}

- (NSString *)totalBookDir
{
    static NSString *contentPath = nil;
    if (contentPath == nil)
    {
        contentPath = [[NSString alloc] initWithString:
                       [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"books/content"]];
    }
    
    return contentPath;
}

- (NSString *)totalPicDir
{
    static NSString *picDir = nil;
    if (picDir == nil)
    {
        picDir = [[NSString alloc] initWithString:
                  [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"books/content/pic"]];
    }
    
    return picDir;
}

- (void)loadTotalBookInfo:(NSMutableArray *)array
{
    NSString *filePath = [self.totalBookDir stringByAppendingPathComponent:@"content.csv"];
    
    NSString *str = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    
    NSArray *csvArray = [str csvParser];
    
    for (int i = 1; i < csvArray.count; ++i)
    {
        NSArray *lineArray = [csvArray objectAtIndex:i];
        
        NSString *fileName = [lineArray objectAtIndex:0];
        NSString *filePath = [self.totalBookDir stringByAppendingPathComponent:fileName];
        NSString *thumbPath = [self.totalPicDir stringByAppendingPathComponent:[lineArray objectAtIndex:2]];
        
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        
        [dic setObject:[lineArray objectAtIndex:1]
                forKey:@"title"];
        
        [dic setObject:filePath
                forKey:@"bookPath"];
        
        [dic setObject:thumbPath
                forKey:@"thumbPath"];
        
        [dic setObject:[self loadBookImagePath:filePath]
                forKey:@"images"];
        
        [array addObject:dic];
    }
}

- (NSArray *)totalImagePath
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (int i = 0; i < self.totalImageInfo.count; ++i)
    {
        NSString *picPath = [[self.totalImageInfo objectAtIndex:i] objectForKey:@"imagePath"];
        [array addObject:picPath];
    }
    
    return array;
}

- (NSString *)getBookTitle:(NSUInteger)bookIndex
{
    return [[self.totalBookInfo objectAtIndex:bookIndex] objectForKey:@"title"];
}

- (NSString *)getBookThumbPath:(NSUInteger)bookIndex
{
    return [[self.totalBookInfo objectAtIndex:bookIndex] objectForKey:@"thumbPath"];
}

- (NSString *)getBookFilePath:(NSUInteger)bookIndex
{
    return [[self.totalBookInfo objectAtIndex:bookIndex] objectForKey:@"bookPath"];
}

- (NSArray *)getBookImages:(NSUInteger)bookIndex
{
    return [[self.totalBookInfo objectAtIndex:bookIndex] objectForKey:@"images"];
}

- (NSString *)getImageFilePath:(NSUInteger)imageIndex
{
    return [[self.totalImageInfo objectAtIndex:imageIndex] objectForKey:@"imagePath"];;
}

- (NSString *)getImageTitle:(NSUInteger)imageIndex
{
    return [[self.totalImageInfo objectAtIndex:imageIndex] objectForKey:@"imageTitle"];;
}

- (NSUInteger)getImageIndex:(NSUInteger)bookIndex
{
    for (int imageIndex = 0; imageIndex < self.totalImageInfo.count; ++imageIndex)
    {
        if (bookIndex == [[[self.totalImageInfo objectAtIndex:imageIndex] objectForKey:@"bookIndex"] intValue])
        {
            return imageIndex;
        }
    }
    
    return 0;
}

- (NSUInteger)getBookIndex:(NSUInteger)imageIndex
{
    return [[[self.totalImageInfo objectAtIndex:imageIndex] objectForKey:@"bookIndex"] intValue];
}

@end
