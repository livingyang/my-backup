//
//  NSData+QBase64.h
//  QWeiboSDK4iOS
//
//  Created on 11-1-12.
//  
//

#import <Foundation/Foundation.h>


@interface NSData (QBase64)

- (NSString *) base64EncodedString;

@end
