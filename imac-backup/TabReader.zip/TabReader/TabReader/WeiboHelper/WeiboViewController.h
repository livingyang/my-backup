//
//  WeiboViewController.h
//  WeiboHelper
//
//  Created by 青宝 中 on 11-11-10.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WeiboHelper.h"

@interface WeiboViewController : UIViewController <WeiboHelperDelegate>
{
    IBOutlet UIWebView *webView;
    
    WeiboHelper *weiboHelper;
}

- (id)initWithWeiboHelper:(WeiboHelper *)helper;
+ (WeiboViewController *)controllerWithWeiboHelper:(WeiboHelper *)helper;

@end
