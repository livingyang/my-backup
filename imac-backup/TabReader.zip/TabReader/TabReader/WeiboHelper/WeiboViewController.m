//
//  WeiboViewController.m
//  WeiboHelper
//
//  Created by 青宝 中 on 11-11-10.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "WeiboViewController.h"
#import "WeiboHelper.h"

@implementation WeiboViewController

+ (WeiboViewController *)controllerWithWeiboHelper:(WeiboHelper *)helper
{
    return [[[WeiboViewController alloc] initWithWeiboHelper:helper] autorelease];
}

- (id)initWithWeiboHelper:(WeiboHelper *)helper
{
    self = [self initWithNibName:nil bundle:nil];
    if (self)
    {
        // Custom initialization
        weiboHelper = helper;
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    weiboHelper.delegate = self;
    [weiboHelper openLoginPage:webView];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)onLoginSuccess:(WeiboHelper *)helper
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)loadRequest:(NSURLRequest *)request
{
    [webView loadRequest:request];
}

@end
