//
//  MainViewController.h
//  TabReader
//
//  Created by 青宝 中 on 11-10-28.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ContentViewController;
@class AlbumViewController;
@interface MainViewController : UIViewController <UITabBarDelegate>
{
    IBOutlet UITabBar *tabBar;
    IBOutlet UIWebView *webView;
    
    ContentViewController *contentViewController;
    AlbumViewController *albumViewController;
}

@property (nonatomic, retain) ContentViewController* contentViewController;
@property (nonatomic, retain) AlbumViewController *albumViewController;

@end
