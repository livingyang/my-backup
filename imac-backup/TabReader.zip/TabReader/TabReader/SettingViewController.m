//
//  SettingViewController.m
//  TabReader
//
//  Created by 青宝 中 on 11-11-4.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "SettingViewController.h"

#import "SettingManager.h"
#import "WeiboBindViewController.h"

@implementation SettingViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)loadTextSize
{
    if ([SettingManager instance].textSize == kBigSize)
    {
        segSize.selectedSegmentIndex = 0;
    }
    else if ([SettingManager instance].textSize == kNormalSize)
    {
        segSize.selectedSegmentIndex = 1;
    }
    else
    {
        segSize.selectedSegmentIndex = 2;
    }
}

- (void)loadBgIndex
{
    NSAssert(kNoBg == 0, @"背景序号必须从0开始");
    
    segBg.selectedSegmentIndex = [SettingManager instance].bgIndex;
}

- (void)loadReviewResource
{
    NSString *filePath = nil;
    switch ([SettingManager instance].textSize)
    {
        case kBigSize:
        {
            filePath = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"books/config/style_big.html"];
        }break;
        case kSmallSize:
        {
            filePath = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"books/config/style_small.html"];
        }break;
        default:
        {
            filePath = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"books/config/style_normal.html"];
        }break;
    }
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL fileURLWithPath:filePath]];
    [webText loadRequest:request];
}

- (void)loadBackground
{
    imageView.image = [UIImage imageWithContentsOfFile:[SettingManager instance].curBgFilePath];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    imageView = [[[UIImageView alloc] initWithFrame:self.view.bounds] autorelease];
    [self.view addSubview:imageView];
    [self.view sendSubviewToBack:imageView];
    
	webText.opaque = NO;
    webText.backgroundColor = [UIColor clearColor];
    
    [self loadTextSize];
    
    [self loadBgIndex];
    
    [self loadReviewResource];
    
    [self loadBackground];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)onSegTextChanged:(UISegmentedControl *)sender
{
    if (sender.selectedSegmentIndex == 0)
    {
        [SettingManager instance].textSize = kBigSize;
    }
    else if (sender.selectedSegmentIndex == 1)
    {
        [SettingManager instance].textSize = kNormalSize;
    }
    else
    {
        [SettingManager instance].textSize = kSmallSize;
    }
    
    [self loadReviewResource];
}

- (IBAction)onSegBgChanged:(UISegmentedControl *)sender
{
    [SettingManager instance].bgIndex = sender.selectedSegmentIndex;
    
    [self loadBackground];
}

- (IBAction)onAccountClick:(id)sender
{
    [self.navigationController pushViewController:[[[WeiboBindViewController alloc] initWithNibName:nil bundle:nil] autorelease]
                                         animated:YES];
}

@end
