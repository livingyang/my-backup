//
//  AdManager.h
//  TabReader
//
//  Created by 青宝 中 on 11-11-4.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "GADBannerView.h"

@interface AdManager : NSObject <GADBannerViewDelegate>
{
    GADBannerView *adView;
}

@property (nonatomic, readonly) UIView *adView;

+ (AdManager *)instance;

- (GADBannerView *)addAdView:(UIViewController *)viewController;

- (GADBannerView *)addAdViewToNavigationController:(UINavigationController *)navigationController;

- (void)removeAdView;

@end
