//
//  TextViewController.m
//  TabReader
//
//  Created by 青宝 中 on 11-11-1.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "TextViewController.h"
#import "BooksManager.h"
#import "SettingManager.h"
#import "BookImageViewController.h"

#define kDuration (0.7f)   // 动画持续时间(秒)

@implementation TextViewController

@synthesize curBookIndex;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)loadResourceFromBookIndex:(int)bookIndex
{
    NSString *cssStr = [SettingManager instance].curCssFileName;
    
    NSString *htmlStr = [NSString stringWithContentsOfFile:[[BooksManager instance] getBookFilePath:bookIndex]
                                                  encoding:NSUTF8StringEncoding
                                                     error:nil];
    
    NSString *replace = @"style.css";
    
    [webView loadHTMLString:[htmlStr stringByReplacingOccurrencesOfString:replace withString:cssStr]
                    baseURL:[NSURL fileURLWithPath:[BooksManager instance].totalBookDir]];

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 150, 40)];
    label.text = [[BooksManager instance] getBookTitle:bookIndex];
    label.backgroundColor = [UIColor clearColor];
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:15.0f];
    self.navigationItem.titleView = label;
}

- (void)loadBackground:(UIWebView *)view
{
	view.opaque = NO;
    view.backgroundColor = [UIColor clearColor];
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:[[view.subviews objectAtIndex:0] frame]];
    imageView.image = [UIImage imageWithContentsOfFile:[SettingManager instance].curBgFilePath];
    [view insertSubview:imageView atIndex:0];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //设置背景图片
    [self loadBackground:webView];
    
    [self loadResourceFromBookIndex:curBookIndex];
    
    UIScrollView *webScrollView = nil;
    for (id subView in webView.subviews)
    {
        if ([subView isKindOfClass:[UIScrollView class]])
        {
            webScrollView = subView;
            break;
        }
    }
    
    webScrollView.delegate = self;
    [prevButton setTitle:@"" forState:UIControlStateNormal];
    [nextButton setTitle:@"" forState:UIControlStateNormal];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (NSString *)switchButtonTitle
{
    return @"图片";
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (SwitchViewController *)switchTargetController
{
    BookImageViewController *viewController = [[[BookImageViewController alloc] initWithNibName:nil bundle:nil] autorelease];
    viewController.curImageIndex = [[BooksManager instance] getImageIndex:self.curBookIndex];
    return viewController;
}

- (IBAction)onPrevTouchUp:(UIButton *)sender
{
    if (self.curBookIndex > 0)
    {
        --curBookIndex;
        
        [self loadResourceFromBookIndex:self.curBookIndex];
    }
    
}

- (IBAction)onNextTouchUp:(UIButton *)sender
{
    if (self.curBookIndex < [BooksManager instance].totalBookInfo.count - 1)
    {
        ++curBookIndex;
        
        [self loadResourceFromBookIndex:self.curBookIndex];
    }
    
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [prevButton setImage:[prevButton imageForState:UIControlStateHighlighted] forState:UIControlStateNormal];
    [nextButton setImage:[nextButton imageForState:UIControlStateHighlighted] forState:UIControlStateNormal];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    [prevButton setImage:nil forState:UIControlStateNormal];
    [nextButton setImage:nil forState:UIControlStateNormal];
}

//- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset
//{
//    [prevButton setImage:nil forState:UIControlStateNormal];
//    [nextButton setImage:nil forState:UIControlStateNormal];
//}

- (void)dealloc
{
    [super dealloc];
}

@end
