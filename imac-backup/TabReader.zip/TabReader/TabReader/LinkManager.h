//
//  LinkManager.h
//  TabReader
//
//  Created by 青宝 中 on 11-11-16.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LinkManager : NSObject
{
    NSString *appstoreLink;
    NSMutableData *receivedData;
}

@property (nonatomic, copy) NSString *appstoreLink;

+ (LinkManager *)instance;

@end
