//
//  ShareManager.m
//  TabReader
//
//  Created by 青宝 中 on 11-11-5.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "ShareManager.h"
#import "QWeiboHelper.h"
#import "SinaWeiboHelper.h"
#import "PostTextViewController.h"
#import "LinkManager.h"
#import <AddressBook/AddressBook.h>

@interface ShareManager (Private)

-(void)displayMailComposerSheet;

-(void)displaySMSComposerSheet;

@end

@implementation ShareManager

@synthesize isSinaBinded;

+ (ShareManager *)instance
{
    static ShareManager *mgr = nil;
    
    if (mgr == nil)
    {
        mgr = [[ShareManager alloc] init];
    }
    
    return mgr;
}

- (void)openShareActionSheetFromController:(UINavigationController *)controller
{
    navigationController = controller;
    
    UIActionSheet *actionSheet = [[[UIActionSheet alloc] initWithTitle:@"分享"
                                                              delegate:self
                                                     cancelButtonTitle:@"取消"
                                                destructiveButtonTitle:nil
                                                     otherButtonTitles:@"腾讯微博", @"新浪微博", @"邮箱", @"短信", nil] autorelease];

    [actionSheet showInView:navigationController.view];
}

- (void)showPostView:(WeiboHelper *)weiboHelper
{
    PostTextViewController *postViewController = [[[PostTextViewController alloc] initWithNibName:nil bundle:nil] autorelease];
    postViewController.curHelper = weiboHelper;
    
    [navigationController pushViewController:postViewController
                                    animated:YES];
}

- (NSString *)shareText
{
    return [NSString stringWithFormat:@"爱爱无穷技太给力了！图文并茂的各种招式你懂的...%@", [LinkManager instance].appstoreLink];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex)
    {
        case 0:
        {
            //腾讯微博
            [self showPostView:[QWeiboHelper instance]];
        }break;
        case 1:
        {
            //新浪微博
            [self showPostView:[SinaWeiboHelper instance]];
        }break;
        case 2:
        {
            //邮箱
            [self displayMailComposerSheet];
        }break;
        case 3:
        {
            //短信
            [self displaySMSComposerSheet];
        }break;
        default:
            break;
    }
}

-(void)displayMailComposerSheet 
{
	MFMailComposeViewController *picker = [[[MFMailComposeViewController alloc] init] autorelease];
	if (picker == nil)
    {
//        UIAlertView *alertView = [[[UIAlertView alloc] initWithTitle:@"无法打开邮箱服务"
//                                                             message:@"是否未设置邮箱账户？"
//                                                            delegate:nil
//                                                   cancelButtonTitle:@"取消"
//                                                   otherButtonTitles:nil] autorelease];
//        
//        [alertView show];
        return;
    }
    
    picker.mailComposeDelegate = self;
	
	[picker setSubject:@"推荐电子书"];
	
	
	// Set up recipients
	NSArray *toRecipients = [NSArray arrayWithObject:@"first@example.com"]; 
//	NSArray *ccRecipients = [NSArray arrayWithObjects:@"second@example.com", @"third@example.com", nil]; 
//	NSArray *bccRecipients = [NSArray arrayWithObject:@"fourth@example.com"]; 
	
	[picker setToRecipients:toRecipients];
//	[picker setCcRecipients:ccRecipients];	
//	[picker setBccRecipients:bccRecipients];
	
	// Attach an image to the email
//	NSString *path = [[NSBundle mainBundle] pathForResource:@"rainy" ofType:@"jpg"];
//	NSData *myData = [NSData dataWithContentsOfFile:path];
//	[picker addAttachmentData:myData mimeType:@"image/jpeg" fileName:@"rainy"];
	
	// Fill out the email body text
	NSString *emailBody = self.shareText;
	[picker setMessageBody:emailBody isHTML:NO];
	
	[navigationController presentModalViewController:picker animated:YES];
}

-(void)displaySMSComposerSheet 
{
    Class messageClass = (NSClassFromString(@"MFMessageComposeViewController"));
	
	if (messageClass == nil || [messageClass canSendText] == NO)
    {
        NSLog(@"ShareManager#displaySMSComposerSheet 不支持短信发送");
        return;
 	}
    
	MFMessageComposeViewController *picker = [[[MFMessageComposeViewController alloc] init] autorelease];
	picker.messageComposeDelegate = self;
    picker.body = self.shareText;
	
	[navigationController presentModalViewController:picker animated:YES];
}


#pragma mark -
#pragma mark Dismiss Mail/SMS view controller

// Dismisses the email composition interface when users tap Cancel or Send. Proceeds to update the 
// message field with the result of the operation.
- (void)mailComposeController:(MFMailComposeViewController*)controller 
          didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error {
	
	feedbackMsg.hidden = NO;
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
			feedbackMsg.text = @"Result: Mail sending canceled";
			break;
		case MFMailComposeResultSaved:
			feedbackMsg.text = @"Result: Mail saved";
			break;
		case MFMailComposeResultSent:
			feedbackMsg.text = @"Result: Mail sent";
			break;
		case MFMailComposeResultFailed:
			feedbackMsg.text = @"Result: Mail sending failed";
			break;
		default:
			feedbackMsg.text = @"Result: Mail not sent";
			break;
	}
	[navigationController dismissModalViewControllerAnimated:YES];
}

- (void)testGetInfo
{
    ABAddressBookRef addressBook = ABAddressBookCreate();
    
    CFArrayRef results = ABAddressBookCopyArrayOfAllPeople(addressBook);
    
    for(int i = 0; i < CFArrayGetCount(results); i++)
    {
        ABRecordRef person = CFArrayGetValueAtIndex(results, i);
        //读取firstname
        NSString *personName = (NSString*)ABRecordCopyValue(person, kABPersonFirstNameProperty);
        
        NSString *lastname = (NSString*)ABRecordCopyValue(person, kABPersonLastNameProperty);
        NSString *nickname = (NSString*)ABRecordCopyValue(person, kABPersonNicknameProperty);
        
        NSLog(@"personName = %@", personName);
        NSLog(@"lastname = %@", lastname);
        NSLog(@"nickname = %@", nickname);
        
        //读取电话多值
        ABMultiValueRef phone = ABRecordCopyValue(person, kABPersonPhoneProperty);
        for (int k = 0; k<ABMultiValueGetCount(phone); k++)
        {
            //获取电话Label
//            NSString * personPhoneLabel = (NSString*)ABAddressBookCopyLocalizedLabel(ABMultiValueCopyLabelAtIndex(phone, k));
//            //获取該Label下的电话值
//            NSString * personPhone = (NSString*)ABMultiValueCopyValueAtIndex(phone, k);
            
            int a;
            a = 1;
        }
    }  
}

// Dismisses the message composition interface when users tap Cancel or Send. Proceeds to update the 
// feedback message field with the result of the operation.
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller 
                 didFinishWithResult:(MessageComposeResult)result {
	
    [self testGetInfo];
    
	feedbackMsg.hidden = NO;
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MessageComposeResultCancelled:
			feedbackMsg.text = @"Result: SMS sending canceled";
			break;
		case MessageComposeResultSent:
			feedbackMsg.text = @"Result: SMS sent";
			break;
		case MessageComposeResultFailed:
			feedbackMsg.text = @"Result: SMS sending failed";
			break;
		default:
			feedbackMsg.text = @"Result: SMS not sent";
			break;
	}
	[navigationController dismissModalViewControllerAnimated:YES];
}

@end
