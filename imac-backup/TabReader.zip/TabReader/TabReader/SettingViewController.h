//
//  SettingViewController.h
//  TabReader
//
//  Created by 青宝 中 on 11-11-4.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingViewController : UIViewController
{
    IBOutlet UISegmentedControl *segSize;
    IBOutlet UISegmentedControl *segBg;
    
    IBOutlet UIWebView *webText;
    
    UIImageView *imageView;
}

@end
