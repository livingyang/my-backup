//
//  AlbumViewController.m
//  TabReader
//
//  Created by 青宝 中 on 11-11-1.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "AlbumViewController.h"
#import "AlbumViewCell.h"
#import "BooksManager.h"
#import "BookImageViewController.h"
#import "AdManager.h"
#import "AlbumPageViewCell.h"

#define ALBUM_PAGE_COUNT (6)

@implementation AlbumViewController

@synthesize tmpAlbumCell, albumCellNib, tmpPageCell, pageCellNib;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    curPage = 1;
    
	self.albumCellNib = [UINib nibWithNibName:@"AlbumViewCell" bundle:nil];
	self.pageCellNib = [UINib nibWithNibName:@"AlbumPageViewCell" bundle:nil];
    
    self.title = @"图册";
    
    self.tableView.backgroundColor = [UIColor colorWithRed:1.0f green:0.9f blue:1.0f alpha:1.0f];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.navigationController.toolbarHidden = NO;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (int)totalAlbumCell
{
    return ([BooksManager instance].totalImageInfo.count + 2) / ALBUM_CELL_BTN_COUNT;
}

- (int)totalPage
{
    return 1 + (self.totalAlbumCell - 1) / ALBUM_PAGE_COUNT;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (curPage < self.totalPage)
    {
        return ALBUM_PAGE_COUNT + 1;
    }
    else
    {
        return self.totalAlbumCell % ALBUM_PAGE_COUNT + 1;
    }
    
    // Return the number of sections.
    return ([BooksManager instance].totalImageInfo.count + 2)/ ALBUM_CELL_BTN_COUNT;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return 1;
}

- (void)setPage
{
    [tmpPageCell setPage:curPage maxPage:self.totalPage];
}

- (int)getImageIndexFromSectionIndex:(int)sectionIndex
{
    return (curPage - 1) * ALBUM_PAGE_COUNT * ALBUM_CELL_BTN_COUNT + sectionIndex * ALBUM_CELL_BTN_COUNT;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        int imageStartIndex = [self getImageIndexFromSectionIndex:indexPath.section];

        if (imageStartIndex < [BooksManager instance].totalImageInfo.count && indexPath.section < ALBUM_PAGE_COUNT)
        {
            [self.albumCellNib instantiateWithOwner:self options:nil];
            cell = tmpAlbumCell;

            for (int i = 0; i < ALBUM_CELL_BTN_COUNT; ++i)
            {
                UIButton *btn = [tmpAlbumCell performSelector:NSSelectorFromString([NSString stringWithFormat:@"btn%d", i + 1])];
                
                int imageIndex = imageStartIndex + i;
                if (imageIndex < [BooksManager instance].totalImageInfo.count)
                {
                    [btn setTag:imageIndex];
                    
                    UIImage *image = [UIImage imageWithContentsOfFile:[[BooksManager instance] getImageFilePath:imageIndex]];
                    [btn setBackgroundImage:image forState:UIControlStateNormal];
                }
                else
                {
                    [btn removeFromSuperview];
                }
            }
            
            cellHeight = tmpAlbumCell.frame.size.height;
            self.tmpAlbumCell = nil;
        }
        else
        {
            // 创建翻页按钮，此处应该需要autorelease
            
            [self.pageCellNib instantiateWithOwner:self options:nil];
            cell = tmpPageCell;
            [self setPage];
        }
    }
    
    // Configure the cell...
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return ALBUM_CELL_HEIGHT;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

- (IBAction)onAlbumClick:(id)sender
{
//    UIButton *btn = sender;
//    
//    NSLog(@"tag = %d", btn.tag);
    
    int imageIndex = [sender tag];
    
    if (imageIndex < [BooksManager instance].totalImageInfo.count)
    {
        BookImageViewController *imageViewController = [[[BookImageViewController alloc] initWithNibName:nil bundle:nil] autorelease];
        imageViewController.curImageIndex = imageIndex;
        [self.navigationController pushViewController:imageViewController animated:YES];
    }
}

- (IBAction)onPrevPageClick:(id)sender
{
    if (curPage > 1)
    {
        --curPage;
        [self.tableView reloadData];
    }
}

- (IBAction)onNextPageClick:(id)sender
{
    if (self.totalPage > curPage)
    {
        ++curPage;
        [self.tableView reloadData];
    }
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    
     //ImageViewController *imageViewController = [[[ImageViewController alloc] initWithNibName:nil bundle:nil] autorelease];
     // ...
     // Pass the selected object to the new view controller.
     //[self.navigationController pushViewController:imageViewController animated:YES];
}

@end
