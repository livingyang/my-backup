//
//  TextImageViewController.h
//  TabReader
//
//  Created by 青宝 中 on 11-11-7.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SwitchViewController.h"

@class ImageScrollView;
@interface BookImageViewController : SwitchViewController <UIScrollViewDelegate>
{
    IBOutlet UILabel *labTitle;
    IBOutlet UILabel *labPage;
    
    IBOutlet ImageScrollView *sclImage;
    int curImageIndex;
}

@property int curImageIndex;

@end
