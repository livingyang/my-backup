//
//  AlbumViewController.h
//  TabReader
//
//  Created by 青宝 中 on 11-11-1.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AlbumViewCell;
@class AlbumPageViewCell;
@interface AlbumViewController : UITableViewController
{
	AlbumViewCell *tmpAlbumCell;
	AlbumPageViewCell *tmpPageCell;
    
	UINib *albumCellNib;
	UINib *pageCellNib;
    
    CGFloat cellHeight;
    
    int curPage;
}

@property (nonatomic, retain) IBOutlet AlbumViewCell *tmpAlbumCell;
@property (nonatomic, retain) IBOutlet AlbumPageViewCell *tmpPageCell;
@property (nonatomic, retain) UINib *albumCellNib;
@property (nonatomic, retain) UINib *pageCellNib;

@end
