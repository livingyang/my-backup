//
//  CTwitterHelper.h
//  AmericanGangster
//
//  Created by zqgame zqgame on 12-7-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Twitter/Twitter.h>

@interface CTwitterHelper : UIViewController 
{
    TWTweetComposeViewController *_twitter;
    
    NSString *_name;
    NSString *_link;
    NSString *_picture;
    NSString *_description;
}

@property (nonatomic, retain) TWTweetComposeViewController *twitter;

/**
 *creatTwitter:  1、创建Twitter实例
 *              2、发送tweet
                3、判断是否注册
                4、关闭对话框回调
 @author: nanLi 
 @version: 1.0 
 @see: https://www.twitter.com/ 
 @param: link   -- appStore 的下载地址
         picture--图片名称
         name   --游戏主题
    description --游戏描述
 @return:  
 @exception: 
*/
-(void)creatTwitter:(NSString*)link 
            picture:(NSString*)picture
               name:(NSString*)name
        description:(NSString*)description;

@end
