//
//  CTwitterHelper.m
//  AmericanGangster
//
//  Created by zqgame zqgame on 12-7-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CTwitterHelper.h"

@implementation CTwitterHelper
@synthesize twitter=_twitter;
#pragma mark -
#pragma mark INIT_AND_DEALLOC
-(id)init
{
	if((self=[super init]))
	{
        _twitter = [[TWTweetComposeViewController alloc] init];
        // nanLi:设置图标、URL、描述信息
        [_twitter addImage:[UIImage imageNamed:@"Icon@2x.png"]];
        [_twitter addURL:[NSURL URLWithString:[NSString stringWithString:@"http://www.zqgame.com/"]]];
        [_twitter setInitialText:@"American gangster good game!!!!!"];
        
        // nanLi:显示视图控制器
        [self presentModalViewController:_twitter animated:YES];
        
        // nanLi:当Twitter对话框关闭时的回调
        _twitter.completionHandler = ^(TWTweetComposeViewControllerResult result) 
        {
            NSString *title = _name;
            NSString *msg; 
            
            if (result == TWTweetComposeViewControllerResultCancelled)
                msg = @"Tweet compostion was canceled.";
            else if (result == TWTweetComposeViewControllerResultDone)
                msg = @"Tweet composition completed.";
            
            UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:title message:msg delegate:self cancelButtonTitle:@"Okay" otherButtonTitles:nil];
            [alertView show];
            
            [self dismissModalViewControllerAnimated:YES];
        };
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}
#pragma mark -
#pragma mark TWITTERAPI

-(void)creatTwitter:(NSString*)link 
            picture:(NSString*)picture
               name:(NSString*)name
        description:(NSString*)description
{
    _link=link;
    _picture=picture;
    _name=name;
    _description=description;
    // nanLi:视图控制器创建
//    _twitter = [[TWTweetComposeViewController alloc] init];
    
    // nanLi:设置图标、URL、描述信息
    [_twitter addImage:[UIImage imageNamed:_picture]];
    [_twitter addURL:[NSURL URLWithString:[NSString stringWithString:_link]]];
    [_twitter setInitialText:_description];
    
//    // nanLi:显示视图控制器
    [self presentModalViewController:_twitter animated:YES];
//    
    // nanLi:当Twitter对话框关闭时的回调
    _twitter.completionHandler = ^(TWTweetComposeViewControllerResult result) 
    {
        NSString *title = _name;
        NSString *msg; 
        
        if (result == TWTweetComposeViewControllerResultCancelled)
            msg = @"Tweet compostion was canceled.";
        else if (result == TWTweetComposeViewControllerResultDone)
            msg = @"Tweet composition completed.";
        
        UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:title message:msg delegate:self cancelButtonTitle:@"Okay" otherButtonTitles:nil];
        [alertView show];
        
        [self dismissModalViewControllerAnimated:YES];
    };
}

#pragma mark -
@end
