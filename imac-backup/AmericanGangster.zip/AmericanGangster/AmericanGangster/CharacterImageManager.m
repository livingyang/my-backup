//
//  CharacterImageManager.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CharacterImageManager.h"
#import "cocos2d.h"

#define MAX_SEX_IMAGE_COUNT (7)

@implementation CharacterImageManager

+ (CharacterImageManager *)instance
{
    static CharacterImageManager *mgr = nil;
    if (mgr == nil)
    {
        mgr = [[CharacterImageManager alloc] init];
    }
    
    return mgr;
}

- (NSString *)getImagePathFromName:(NSString *)imageName
{
    return [@"character" stringByAppendingPathComponent:imageName];
}

- (NSArray *)manImageNameArray
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (int i = 1; i <= MAX_SEX_IMAGE_COUNT; ++i)
    {
        [array addObject:[NSString stringWithFormat:@"man%02d.png", i]];
    }
    
    return array;
}

- (NSArray *)womanImageNameArray
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (int i = 1; i <= MAX_SEX_IMAGE_COUNT; ++i)
    {
        [array addObject:[NSString stringWithFormat:@"woman%02d.png", i]];
    }
    
    return array;
}

- (CCTexture2D *)getTextureFromImageName:(NSString *)name
{
    return [[CCTextureCache sharedTextureCache] addImage:
            [self getImagePathFromName:name]];
}

+ (NSString *)headerImageFromCharacterImage:(NSString *)imageName
{
    return [@"character/header-" stringByAppendingString:imageName];
}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
    }
    
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

@end
