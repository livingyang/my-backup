//
//  AGArenaInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGArenaInfo : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *imageName;

@property int attack;
@property int level;
@property int rank;

@property int curChallengeCount;
@property int maxChallengeCount;
@property (nonatomic, readonly) float challengeCountPercent;

@property NSTimeInterval time;

+ (AGArenaInfo *)arenaInfoFromDic:(NSDictionary *)dic;

@end

@class AGStoreItemInfo;
@interface AGArenaChallengeResultInfo : NSObject

@property BOOL isWin;
@property int rank;
@property (nonatomic, copy) NSString *opponentName;
@property (nonatomic, retain) AGStoreItemInfo *rewardItem;

+ (AGArenaChallengeResultInfo *)resultFromInfo:(NSDictionary *)dic;

@end

@interface AGArenaRankingRewardInfo : NSObject

@property int gainCoins;
@property int rank;

+ (AGArenaRankingRewardInfo *)rewardInfoFromDic:(NSDictionary *)dic;

@end