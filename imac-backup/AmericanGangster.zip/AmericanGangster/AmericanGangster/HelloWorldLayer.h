//
//  HelloWorldLayer.h
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-4-26.
//  Copyright __MyCompanyName__ 2012年. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// HelloWorldLayer
@interface HelloWorldLayer : CCLayer
{
}

@property (nonatomic, retain) NSMutableDictionary *connectAndReciveDataDic;
// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;

@end
