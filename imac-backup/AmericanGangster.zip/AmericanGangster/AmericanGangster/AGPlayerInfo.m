//
//  AGPlayerInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGPlayerInfo.h"
#import "TimeLeftManager.h"

#define INVAILD_LEVEL (0)

@implementation AGPlayerInfo

@synthesize playerId;
@synthesize name, imageName, title, levelDetail, shareDetail;
@synthesize level, type, sex;
@synthesize coins, dollar;
@synthesize curExp, maxExp;
@synthesize curHealth, maxHealth, healthTimeLeft;
@synthesize curEnergy, maxEnergy, energyTimeLeft;
@synthesize curAttack, attachAttack, attackTimeLeft;
@synthesize curDefense, attachDefense, defenseTimeLeft;
@synthesize defenseItemCount;
@synthesize curServantCount, maxServantCount;
@synthesize isClearNewbieMission;
@synthesize hasLevelUp;
@synthesize upHealth, upEnergy, upAttack, upDefense, upCoin, upDollar;

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        self.healthTimeLeft = [TimeLeftManager managerWithTimeLeft:0];
        self.energyTimeLeft = [TimeLeftManager managerWithTimeLeft:0];
        self.attackTimeLeft = [TimeLeftManager managerWithTimeLeft:0];
        self.defenseTimeLeft = [TimeLeftManager managerWithTimeLeft:0];
        
        self.level = INVAILD_LEVEL;
        self.hasLevelUp = NO;
    }
    
    return self;
}

- (void)dealloc
{
    self.name = nil;
    self.imageName = nil;
    self.title = nil;
    self.levelDetail = nil;
    self.shareDetail = nil;
    
    self.healthTimeLeft = nil;
    self.energyTimeLeft = nil;
    self.attackTimeLeft = nil;
    self.defenseTimeLeft = nil;
    
	[super dealloc];
}

- (BOOL)isMan
{
    return self.sex == 1;
}

- (BOOL)isArenaOpen
{
    return self.level >= 30;
}

- (int)curHealth
{
    if (self.healthTimeLeft.curTimeLeft == 0)
    {
        return self.maxHealth;
    }
    
    float usedHealth = self.healthTimeLeft.curTimeLeft / RECOVER_CYCLE_HEALTH;
    
    return self.maxHealth - usedHealth;
}

- (NSTimeInterval)recoverHealthTime
{
    return (int)self.healthTimeLeft.curTimeLeft % RECOVER_CYCLE_HEALTH + 1;
}

- (BOOL)isFullHealth
{
    return self.curHealth == self.maxHealth;
}

- (int)curEnergy
{
    if (self.energyTimeLeft.curTimeLeft == 0)
    {
        return self.maxEnergy;
    }
    
    float usedEnergy = self.energyTimeLeft.curTimeLeft / RECOVER_CYCLE_ENERGY;
    
    return self.maxEnergy - usedEnergy;
}

- (NSTimeInterval)recoverEnergyTime
{
    return (int)self.energyTimeLeft.curTimeLeft % RECOVER_CYCLE_ENERGY + 1;
}

- (BOOL)isFullEnergy
{
    return self.curEnergy == self.maxEnergy;
}

- (int)maxAttack
{
    return self.curAttack + ((self.attackTimeLeft.curTimeLeft > 0) ? self.attachAttack : 0);
}

- (int)maxDefense
{
    return self.curDefense + ((self.defenseTimeLeft.curTimeLeft > 0) ? self.attachDefense : 0);
}

+ (AGPlayerInfo *)defaultPlayerInfo
{
    static AGPlayerInfo *playerInfo = nil;
    if (playerInfo == nil)
    {
        playerInfo = [[AGPlayerInfo alloc] init];
    }
    
    return playerInfo;
}

- (void)updateWithInfo:(NSDictionary *)dic
{
    NSDictionary *playerInfoDic = [dic objectForKey:@"playerInfo"];
    
    self.playerId = [[playerInfoDic objectForKey:@"playerId"] intValue];
    
    self.name = [playerInfoDic objectForKey:@"playerName"];
    self.imageName = [playerInfoDic objectForKey:@"imageId"];
    self.title = [[playerInfoDic objectForKey:@"levelInfo"] objectForKey:@"title"];
    self.levelDetail = [playerInfoDic objectForKey:@"level_Detail"];
    self.shareDetail = [[playerInfoDic objectForKey:@"levelInfo"] objectForKey:@"shareContent"];
    
    [self.healthTimeLeft resetWithTimeLeft:[[playerInfoDic objectForKey:@"recoveryHpTime"] intValue] / 1000.f];
    [self.energyTimeLeft resetWithTimeLeft:[[playerInfoDic objectForKey:@"recoveryEnergyTime"] intValue] / 1000.f];
    
    if (self.level != INVAILD_LEVEL && self.level < [[[playerInfoDic objectForKey:@"levelInfo"] objectForKey:@"levelId"] intValue])
    {
        self.hasLevelUp = YES;
        
        self.upHealth = [[playerInfoDic objectForKey:@"health"] intValue] - self.curHealth;
        self.upEnergy = [[playerInfoDic objectForKey:@"energy"] intValue] - self.curEnergy;
        self.upAttack = [[playerInfoDic objectForKey:@"attack"] intValue] - self.curAttack;
        self.upDefense = [[playerInfoDic objectForKey:@"defense"] intValue] - self.curDefense;
    }
    
    self.level = [[[playerInfoDic objectForKey:@"levelInfo"] objectForKey:@"levelId"] intValue];
    self.upCoin = [[[playerInfoDic objectForKey:@"levelInfo"] objectForKey:@"levelGainCoin"] intValue];
    self.upDollar = [[[playerInfoDic objectForKey:@"levelInfo"] objectForKey:@"levelGainDollar"] intValue];

    
    self.type = [[playerInfoDic objectForKey:@"type"] intValue];
    self.sex = [[playerInfoDic objectForKey:@"sex"] intValue];
    
    self.curHealth = [[playerInfoDic objectForKey:@"health"] intValue];
    self.curEnergy = [[playerInfoDic objectForKey:@"energy"] intValue];
    self.curAttack = [[playerInfoDic objectForKey:@"attack"] intValue];
    self.curDefense = [[playerInfoDic objectForKey:@"defense"] intValue];
    
    NSDictionary *attachAttackDic = [playerInfoDic objectForKey:@"attachAttack"];
    self.attachAttack = [[attachAttackDic objectForKey:@"value"] intValue];
    [self.attackTimeLeft resetWithTimeLeft:[[attachAttackDic objectForKey:@"time"] intValue] / 1000.f];
    
    NSDictionary *attachDefenseDic = [playerInfoDic objectForKey:@"attachDefense"];
    self.attachDefense = [[attachDefenseDic objectForKey:@"value"] intValue];
    [self.defenseTimeLeft resetWithTimeLeft:[[attachDefenseDic objectForKey:@"time"] intValue] / 1000.f];
    
    self.defenseItemCount = [[playerInfoDic objectForKey:@"shield"] intValue];
    
    self.maxHealth = [[[playerInfoDic objectForKey:@"levelInfo"] objectForKey:@"health"] intValue];
    self.maxEnergy = [[[playerInfoDic objectForKey:@"levelInfo"] objectForKey:@"energy"] intValue];
    
    self.maxServantCount = [[[playerInfoDic objectForKey:@"levelInfo"] objectForKey:@"servant"] intValue];
    self.curServantCount = [[playerInfoDic objectForKey:@"haveServant"] intValue];
    
    self.coins = [[[playerInfoDic objectForKey:@"customer"] objectForKey:@"coin"] intValue];
    self.dollar = [[[playerInfoDic objectForKey:@"customer"] objectForKey:@"tokens"] intValue];
    
    self.curExp = [[playerInfoDic objectForKey:@"exp"] intValue];
    self.maxExp = [[[playerInfoDic objectForKey:@"levelInfo"] objectForKey:@"exp"] intValue];
    
    self.isClearNewbieMission = [[playerInfoDic objectForKey:@"isFirstIn"] intValue];
}

@end
