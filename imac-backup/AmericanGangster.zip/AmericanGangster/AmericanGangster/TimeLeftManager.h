//
//  TimeLeftManager.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TimeLeftManager : NSObject
{
    NSTimeInterval targetTime;
}

// curTimeLeft = 0 or realTimeLeft (realTimeLeft > 0)

@property (nonatomic, readonly) NSTimeInterval realTimeLeft;
@property (nonatomic, readonly) NSTimeInterval curTimeLeft;

+ (TimeLeftManager *)managerWithTimeLeft:(NSTimeInterval)timeLeft;
- (void)resetWithTimeLeft:(NSTimeInterval)timeLeft;

@end
