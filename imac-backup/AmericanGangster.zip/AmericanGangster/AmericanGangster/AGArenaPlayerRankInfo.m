//
//  AGArenaPlayerRankInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGArenaPlayerRankInfo.h"

@implementation AGArenaPlayerRankInfo

@synthesize rank;

- (void)dealloc
{
    [super dealloc];
}

+ (NSArray *)playerRankListFromInfo:(NSDictionary *)info
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *dic in [info objectForKey:@"arenaRankList"])
    {
        AGArenaPlayerRankInfo *playerInfo = [[[AGArenaPlayerRankInfo alloc] init] autorelease];
        [array addObject:playerInfo];
        
        [playerInfo setPropertiesFromInfo:dic];
        
        playerInfo.level = [[dic objectForKey:@"level"] intValue];
        playerInfo.rank = [[dic objectForKey:@"rank"] intValue];
    }
    
    return array;
}

+ (NSArray *)arenaOpponentListFromInfo:(NSDictionary *)info
{
    return [self playerRankListFromInfo:info];
}

@end
