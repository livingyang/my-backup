//
//  AGChallengeResult.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-11.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGChallengeResult.h"
#import "AGOpponentInfo.h"

@implementation AGChallengeResult

@synthesize isWin;
@synthesize isCatchHeeler;
@synthesize gainCoin, gainExp;
@synthesize myTotalAttack, opponentTotalDefense;
@synthesize opponentInfo;
@synthesize myServentList, opponentServentList;

- (void)dealloc
{
    self.opponentInfo = nil;
    self.myServentList = nil;
    self.opponentServentList = nil;
    [super dealloc];
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
}

+ (AGChallengeResult *)challengeResultFromInfo:(NSDictionary *)info
{
    AGChallengeResult *result = [[[AGChallengeResult alloc] init] autorelease];
    
    result.isWin = [[info objectForKey:@"isWin"] boolValue];
    result.isCatchHeeler = [[info objectForKey:@"isCatchHeeler"] boolValue];
    
    result.gainCoin = [[info objectForKey:@"pk_get_coin"] intValue];
    result.gainExp = [[info objectForKey:@"pk_get_exp"] intValue];
    
    result.myTotalAttack = [[info objectForKey:@"myTotalAttack"] intValue];
    result.opponentTotalDefense = [[info objectForKey:@"oppTotalDefense"] intValue];
    
    NSMutableArray *myServentList = [NSMutableArray array];
    for (NSDictionary *myServentInfo in [[info objectForKey:@"myServants"] reverseObjectEnumerator])
    {
        AGOpponentInfo *opponent = [[[AGOpponentInfo alloc] init] autorelease];
        [myServentList addObject:opponent];
        
        [opponent setPropertiesFromInfo:myServentInfo];
    }
    result.myServentList = myServentList;
    
    NSMutableArray *opponentServentList = [NSMutableArray array];
    for (NSDictionary *opponentServentInfo in [[info objectForKey:@"oppServants"] reverseObjectEnumerator])
    {
        AGOpponentInfo *opponent = [[[AGOpponentInfo alloc] init] autorelease];
        [opponentServentList addObject:opponent];
        
        [opponent setPropertiesFromInfo:opponentServentInfo];
    }
    result.opponentServentList = opponentServentList;
    
    if (result.opponentServentList.count > 0)
    {
        result.opponentInfo = [result.opponentServentList lastObject];
    }
    else
    {
        NSLog(@"AGChallengeResult#challengeResultFromInfo opponentServentList count == 0");
    }
    
    return result;
}

@end
