//
//  CCTimeManageNode.h
//  study_TimeLabel
//
//  Created by 青宝 中 on 12-8-7.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@class TimeLeftManager;
@interface CCTimeManageNode : CCNode
{
}

@property (nonatomic, assign) CCLabelTTF *labTime;
@property (nonatomic, retain) TimeLeftManager *timeLeft;
@property (nonatomic, retain) CCFiniteTimeAction *finishAction;
@property BOOL isHHMMSS;  // otherwise MMSS 

+ (NSString *)timeStringWithHHMMSS:(NSTimeInterval)time;
+ (NSString *)timeStringWithMMSS:(NSTimeInterval)time;

+ (void)startCountDown:(CCLabelTTF *)label
              timeLeft:(NSTimeInterval)time
              isHHMMSS:(BOOL)isHHMMSS
        withStopAction:(CCFiniteTimeAction *)stopAction;

+ (void)stopCountDown:(CCLabelTTF *)label;

@end
