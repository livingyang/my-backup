//
//  AGChallengeResult.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-11.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCBalsamiqLayerDataSource.h"

@class AGOpponentInfo;
@interface AGChallengeResult : NSObject <CCBalsamiqLayerDataSource>

@property BOOL isWin;
@property BOOL isCatchHeeler;

@property int gainCoin;
@property int gainExp;

@property int myTotalAttack;
@property int opponentTotalDefense;

@property (nonatomic, retain) AGOpponentInfo *opponentInfo;

@property (nonatomic, retain) NSArray *myServentList;
@property (nonatomic, retain) NSArray *opponentServentList;

+ (AGChallengeResult *)challengeResultFromInfo:(NSDictionary *)info;

@end
