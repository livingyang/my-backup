//
//  AGPlayerInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#define RECOVER_CYCLE_HEALTH (1800)
#define RECOVER_CYCLE_ENERGY (240)

@class TimeLeftManager;
@interface AGPlayerInfo : NSObject

@property int playerId;

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, retain) NSString *levelDetail;
@property (nonatomic, retain) NSString *shareDetail;

@property int level;
@property int type;
@property int sex;
@property (nonatomic, readonly) BOOL isMan;

@property (nonatomic, readwrite) int curHealth;
@property int maxHealth;
@property (nonatomic, retain) TimeLeftManager *healthTimeLeft;
@property (nonatomic, readonly) NSTimeInterval recoverHealthTime;
@property (nonatomic, readonly) BOOL isFullHealth;

@property (nonatomic, readwrite) int curEnergy;
@property int maxEnergy;
@property (nonatomic, retain) TimeLeftManager *energyTimeLeft;
@property (nonatomic, readonly) NSTimeInterval recoverEnergyTime;
@property (nonatomic, readonly) BOOL isFullEnergy;

@property int curAttack;
@property (nonatomic, readonly) int maxAttack;
@property int attachAttack;
@property (nonatomic, retain) TimeLeftManager *attackTimeLeft;

@property int curDefense;
@property (nonatomic, readonly) int maxDefense;
@property int attachDefense;
@property (nonatomic, retain) TimeLeftManager *defenseTimeLeft;

@property int defenseItemCount;

@property int coins;
@property int dollar;

@property int curExp;
@property int maxExp;

@property int maxServantCount;
@property int curServantCount;

@property BOOL isClearNewbieMission;

// 是否有升级
@property BOOL hasLevelUp;
@property int upHealth;
@property int upEnergy;
@property int upAttack;
@property int upDefense;
@property int upCoin;
@property int upDollar;

@property (nonatomic, readonly) BOOL isArenaOpen;

+ (AGPlayerInfo *)defaultPlayerInfo;
- (void)updateWithInfo:(NSDictionary *)dic;

@end
