//
//  AGSettingInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGSettingInfo : NSObject

@property (nonatomic, copy) NSString *name;
@property BOOL isOn;

+ (NSArray *)settingListFromInfo:(NSDictionary *)dic;

@end
