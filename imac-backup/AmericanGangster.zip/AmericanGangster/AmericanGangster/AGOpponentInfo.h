//
//  AGOpponentInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CCBalsamiqLayer;
@interface AGOpponentInfo : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, readonly) NSString *headerImageName;

@property int uniqueId;

@property int level;

@property int attack;
@property int defense;

@property int sex;
@property (nonatomic, readonly) BOOL isMan;

@property BOOL isHeeler;

+ (NSArray *)getOpponentList:(NSDictionary *)info;
+ (NSArray *)getRevengeList:(NSDictionary *)info;

- (void)setPropertiesFromInfo:(NSDictionary *)info;
- (void)updateDataToLayer:(CCBalsamiqLayer *)layer;

@end

@interface AGOpponentInfoCache : NSObject
{
    NSMutableArray *opponentList_;
}

@property (nonatomic, readonly) NSMutableArray *opponentList;

+ (AGOpponentInfoCache *)instance;

- (void)clearOpponentList;
- (void)appendOpponentList:(NSArray *)array;
- (AGOpponentInfo *)getOpponentInfoFromId:(int)opponentId;

@end
