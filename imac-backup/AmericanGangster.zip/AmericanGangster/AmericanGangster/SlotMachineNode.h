//
//  SlotMachineNode.h
//  study_SlotMachine
//
//  Created by 青宝 中 on 12-7-11.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface SlotMachineNode : CCNode
{
    NSMutableArray *slotImages;
}

@property (nonatomic, readonly) NSString *randomImage;

- (void)setSlotImages:(NSArray *)images;
- (void)setInitImage:(NSString *)image;

- (void)startSlot;
- (void)stopSlot;
- (void)stopSlotAtSprite:(CCSprite *)sprite;
- (void)stopSlotAtImage:(NSString *)image;

@end


@interface CCNode (SlotMachineNodeBind)

@property (nonatomic, readonly) SlotMachineNode *slotMachine;

@end