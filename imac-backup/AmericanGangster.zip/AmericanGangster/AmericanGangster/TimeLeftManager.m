//
//  TimeLeftManager.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-2.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "TimeLeftManager.h"

@implementation TimeLeftManager

- (NSTimeInterval)realTimeLeft
{
    return targetTime - [NSDate timeIntervalSinceReferenceDate];
}

- (NSTimeInterval)curTimeLeft
{
    return (self.realTimeLeft > 0) ? self.realTimeLeft : 0;
}

+ (TimeLeftManager *)managerWithTimeLeft:(NSTimeInterval)timeLeft
{
    TimeLeftManager *mgr = [[[TimeLeftManager alloc] init] autorelease];
    [mgr resetWithTimeLeft:timeLeft];
    
    return mgr;
}

- (void)resetWithTimeLeft:(NSTimeInterval)timeLeft
{
    targetTime = [NSDate timeIntervalSinceReferenceDate] + timeLeft;
}

@end
