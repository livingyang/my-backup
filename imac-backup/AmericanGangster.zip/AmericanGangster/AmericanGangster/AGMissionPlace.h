//
//  AGMissionGroup.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCBalsamiqLayerDataSource.h"

@interface AGMissionPlace : NSObject <CCBalsamiqLayerDataSource>

@property int mapId;
@property (nonatomic, copy) NSString *mapName;

@end

@interface AGMissionPlaceList : NSObject

@property (nonatomic, retain) NSArray *unlockedPlaceArray;
@property (nonatomic, retain) NSArray *lockedPlaceArray;

+ (AGMissionPlaceList *)placeListFromInfo:(NSDictionary *)info;
+ (NSTimeInterval)getForbidDoMissionTime:(NSDictionary *)info;

@end

@interface AGMissionPlaceListCache : NSObject

@property (nonatomic, retain) NSArray *placeList;

+ (AGMissionPlaceListCache *)instance;
- (AGMissionPlace *)getPlaceFromMapId:(int)mapId;

@end
