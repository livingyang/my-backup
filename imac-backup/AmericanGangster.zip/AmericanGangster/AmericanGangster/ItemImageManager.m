//
//  ItemImageManager.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ItemImageManager.h"
#import "cocos2d.h"

@implementation ItemImageManager

+ (ItemImageManager *)instanse
{
    static ItemImageManager *mgr = nil;
    if (mgr == nil)
    {
        mgr = [[ItemImageManager alloc] init];
    }
    
    return mgr;
}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        [CCTexture2D setDefaultAlphaPixelFormat:kCCTexture2DPixelFormat_RGBA4444];
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"knife.plist"];
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"gun.plist"];
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"car.plist"];
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"armor.plist"];
        [CCTexture2D setDefaultAlphaPixelFormat:kCCTexture2DPixelFormat_Default];
    }
    
    return self;
}

- (CCTexture2D *)getTextureFromImageName:(NSString *)name
{
    return [[CCTextureCache sharedTextureCache] addImage:[@"item" stringByAppendingPathComponent:name]];
}

- (CCSpriteFrame *)getWeaponFrameFromImageName:(NSString *)name
{
    return [[CCSpriteFrameCache sharedSpriteFrameCache] spriteFrameByName:name];
}

@end
