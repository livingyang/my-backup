//
//  CCTouchCatchNode.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-28.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface CCTouchCatchNode : CCNode <CCStandardTouchDelegate, CCTargetedTouchDelegate>
{
    
}

@property (nonatomic, assign) CCNode *catchTarget;

+ (id)nodeWithCatchTarget:(CCNode *)target;

@end
