//
//  AGRefineItemInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGRefineItemInfo.h"
#import "AGStoreItemInfoCache.h"
#import "AGStoreItemInfo.h"
#import "CCBalsamiqLayer.h"
#import "TimeLeftManager.h"

@implementation AGEquipmentInfo (Refine)

+ (NSArray *)refineItemInfoArrayWithDictionaryInfo:(NSDictionary *)dic
{
    NSMutableArray *array = [NSMutableArray array];
    NSArray *refineList = [dic objectForKey:@"refineList"];
    
    for (NSDictionary *info in refineList)
    {
        AGEquipmentInfo *item = [[[AGEquipmentInfo alloc] init] autorelease];
        [item loadPropertiesFromDic:info];
        [array addObject:item];
    }
    
    return array;
}

+ (AGEquipmentInfo *)getRefineItemFromInfo:(NSDictionary *)dic
{
    AGEquipmentInfo *item = [[[AGEquipmentInfo alloc] init] autorelease];
    
    [item loadPropertiesFromDic:[dic objectForKey:@"item"]];
    
    return item;
}

@end

@implementation AGRefineInfo

@synthesize refineTime;
@synthesize canRefine;
@synthesize itemCount;
@synthesize refineRatio;

- (float)refinePercent
{
    float per = self.refineTime.curTimeLeft / (30.0f * 60.0f) * 100;
    return clampf(per, 0, 100);
}

+ (AGRefineInfo *)instance
{
    static AGRefineInfo *info = nil;
    if (info == nil)
    {
        info = [[AGRefineInfo alloc] init];
    }
    
    return info;
}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        self.refineTime = [TimeLeftManager managerWithTimeLeft:0];
    }
    
    return self;
}

- (void)dealloc
{
    self.refineTime = nil;
    
    [super dealloc];
}

- (void)updateWithRefineListInfo:(NSDictionary *)info
{
    if ([info objectForKey:@"refineInfo"] == nil)
    {
        return;
    }
    
    [self.refineTime resetWithTimeLeft:[[[info objectForKey:@"refineInfo"] objectForKey:@"cDTime"] intValue] / 1000];
    
    self.canRefine = ![[[info objectForKey:@"refineInfo"] objectForKey:@"canRefineFlag"] intValue];
    self.itemCount = [[[info objectForKey:@"refineInfo"] objectForKey:@"itemCount"] intValue];
    self.refineRatio = [[[info objectForKey:@"refineInfo"] objectForKey:@"refineRatio"] intValue];
}

- (void)updateWithRefineItemInfo:(NSDictionary *)info
{
    [self updateWithRefineListInfo:info];
}

@end

@implementation AGRefineTimeInfo

@synthesize minute;
@synthesize dollar;


+ (AGRefineTimeInfo *)timeInfoFromDic:(NSDictionary *)dic
{
    AGRefineTimeInfo *timeInfo = [[[AGRefineTimeInfo alloc] init] autorelease];
    
    timeInfo.minute = [[dic objectForKey:@"time"] intValue] / (1000 * 60);
    timeInfo.dollar = [[dic objectForKey:@"dollar"] intValue];
    return timeInfo;
}

@end