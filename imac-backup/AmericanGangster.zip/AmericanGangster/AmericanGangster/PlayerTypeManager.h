//
//  PlayerTypeManager.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PlayerTypeManager : NSObject

+ (NSString *)getTypeFromRadioName:(NSString *)str;
+ (NSString *)getTypeImageFromRadioName:(NSString *)str;
+ (NSString *)getTypeStringFromValue:(int)type;

@end
