//
//  CCVideoPlayer.h
//  study_PlayVideo
//
//  Created by 青宝 中 on 12-8-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MediaPlayer/MediaPlayer.h"
#import "cocos2d.h"

@interface CCVideoPlayer : MPMoviePlayerController
{
}

@property (nonatomic, retain) CCCallFunc *playDoneCallback;

- (void)playerVideo:(NSString *)videoName ofType:(NSString *)type;
- (void)playerVideo:(NSString *)videoName ofType:(NSString *)type callback:(CCCallFunc *)callbackAction;

+ (CCVideoPlayer *)instance;

@end
