//
//  AGPackItemInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCBalsamiqLayerDataSource.h"

@class AGStoreItemInfo;
@interface AGEquipmentInfo : NSObject <CCBalsamiqLayerDataSource>
{
}

@property (nonatomic, assign) AGStoreItemInfo *storeItemInfo;

@property int uniqueId;
@property int goodsId;
@property BOOL isEquiped;
@property int sellCoins;

@property int curUpCount;
@property int maxUpCount;
@property (nonatomic, readonly) float refinePercent;

// new property
@property (nonatomic, readonly) BOOL isMaxRefine;

@property (nonatomic, readonly) int baseAttack;
@property (nonatomic, readonly) int baseDefense;
@property int refineAttack;
@property int refineDefense;
@property (nonatomic, readonly) int totalAttack;
@property (nonatomic, readonly) int totalDefense;
@property (nonatomic, readonly) int nextRefineTotalAttack;
@property (nonatomic, readonly) int nextRefineTotalDefense;

@property int factor;
@property (nonatomic, readonly) int cost;

+ (AGEquipmentInfo *)packItemFromPosDic:(NSDictionary *)posDic;
+ (NSArray *)packItemInfoArrayWithDictionaryInfo:(NSDictionary *)dic;
+ (NSArray *)equipmentInfoFromDictionaryInfo:(NSDictionary *)dic;
+ (NSArray *)getIsNotUsingPackItemList:(NSArray *)packItemList;

// item slot machine
+ (AGEquipmentInfo *)getPackItemFromSpinSlotMachine:(NSDictionary *)info;

- (void)loadPropertiesFromDic:(NSDictionary *)dic;

@end
