//
//  AGAwardInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGAwardInfo : NSObject

@property (nonatomic, readonly) BOOL needsAward;

@property int curAwardCount;
@property int maxAwardCount;

@property int lastUpdatedItemIndex;

@property (nonatomic, retain) NSMutableArray *itemArray;

+ (AGAwardInfo *)instance;

- (void)updateAwardInfoFromInfo:(NSDictionary *)info;
- (void)updateAwardInfoFromLoginInfo:(NSDictionary *)info;

@end

@interface AGAwardItemInfo : NSObject

@property (nonatomic, retain) NSString *itemName;
@property int num;
@property BOOL isOpened;

- (void)loadPropertyFromInfo:(NSDictionary *)info;

@end
