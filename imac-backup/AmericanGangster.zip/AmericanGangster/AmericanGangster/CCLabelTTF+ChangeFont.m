//
//  CCLabelTTF+ChangeFont.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CCLabelTTF+ChangeFont.h"
#import "LanguageManager.h"

@implementation CCLabelTTF (ChangeFont)

- (void)changeToFont:(NSString *)fontName
{
    if (fontName_ != fontName)
    {
        [fontName_ release];
        fontName_ = [fontName retain];
    }
    
    self.string = self.string;
}

- (void)changeToBlackArialFont
{
    if ([[LanguageManager instance] isChineseVersion])
    {
        return;
    }
    
    [self changeToFont:@"ariblk"];
}

@end
