//
//  AGAwardInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGAwardInfo.h"

@implementation AGAwardInfo

@synthesize curAwardCount, maxAwardCount;
@synthesize itemArray;
@synthesize lastUpdatedItemIndex;

- (void)dealloc
{
    self.itemArray = nil;
    
    [super dealloc];
}

- (BOOL)needsAward
{
    return (curAwardCount > 0);
}

- (void)loadNumFromInfo:(NSDictionary *)info
{
    self.curAwardCount = [[info objectForKey:@"curNum"] intValue];
    self.maxAwardCount = [[info objectForKey:@"maxNum"] intValue];
}

- (void)loadAwardItemList:(NSDictionary *)itemList
{
    NSMutableArray *array = [NSMutableArray array];
    for (NSDictionary *itemDic in itemList)
    {
        AGAwardItemInfo *item = [[[AGAwardItemInfo alloc] init] autorelease];
        [array addObject:item];
        
        [item loadPropertyFromInfo:itemDic];
    }
    self.itemArray = array;
}

+ (AGAwardInfo *)instance
{
    static AGAwardInfo *info = nil;
    if (info == nil)
    {
        info = [[AGAwardInfo alloc] init];
    }
    
    return info;
}

- (void)updateAwardInfoFromLoginInfo:(NSDictionary *)info
{
    [self loadNumFromInfo:[info objectForKey:@"awardsInfo"]];
    [self loadAwardItemList:[[info objectForKey:@"awardsInfo"] objectForKey:@"itemList"]];
}

- (void)updateAwardInfoFromInfo:(NSDictionary *)info
{
    [self loadNumFromInfo:[info objectForKey:@"awardsInfo"]];
    [self loadAwardItemList:[[info objectForKey:@"awardsInfo"] objectForKey:@"itemList"]];
    
    self.lastUpdatedItemIndex = [[[info objectForKey:@"awardsInfo"] objectForKey:@"position"] intValue];
}

@end

@implementation AGAwardItemInfo

@synthesize itemName;
@synthesize num;
@synthesize isOpened;

- (void)dealloc
{
    self.itemName = nil;
    
    [super dealloc];
}

- (void)loadPropertyFromInfo:(NSDictionary *)info
{
    self.itemName = [info objectForKey:@"itemName"];
    self.num = [[info objectForKey:@"num"] intValue];
    self.isOpened = [[info objectForKey:@"opened"] intValue];
}

@end
