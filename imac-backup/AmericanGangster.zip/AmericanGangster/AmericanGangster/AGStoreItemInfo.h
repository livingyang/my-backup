//
//  AGStoreItemInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCBalsamiqLayerDataSource.h"

@class CCSprite;
@interface AGStoreItemInfo : NSObject <CCBalsamiqLayerDataSource>

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, readonly) NSString *equipmentImagePath;
@property int type;
@property int itemId;
@property int attack;
@property int defense;
@property int coin;
@property int dollar;
@property int star;
@property int limitLevel;

@property int unitCoin;
@property int unitAttack;
@property int unitDefense;

+ (AGStoreItemInfo *)itemInfoWithDictionaryInfo:(NSDictionary *)dic;
+ (NSArray *)itemInfoArrayWithDictionaryInfo:(NSDictionary *)dic;
+ (NSArray *)shopWeaponInfoListWithInfo:(NSDictionary *)dic;

@end
