//
//  CCTouchCatchNode.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-28.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "CCTouchCatchNode.h"

@implementation CCTouchCatchNode

@synthesize catchTarget;

- (void)onEnter
{
    [super onEnter];
    
    [[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self
                                                     priority:INT_MIN
                                              swallowsTouches:YES];
}

- (void)onExit
{
    [super onExit];
    
    [[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
}

+ (id)nodeWithCatchTarget:(CCNode *)target
{
    CCTouchCatchNode *node = [CCTouchCatchNode node];
    node.catchTarget = target;
    return node;
}

#pragma mark -
#pragma mark CCTargetedTouchDelegate

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
    if (self.catchTarget != nil)
    {
        return CGRectContainsPoint((CGRect){CGPointZero, self.catchTarget.contentSize},
                                   [self.catchTarget convertTouchToNodeSpace:touch]);
    }
    return NO;
}

@end
