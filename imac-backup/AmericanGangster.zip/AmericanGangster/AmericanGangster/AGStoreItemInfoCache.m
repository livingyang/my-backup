//
//  AGStoreItemInfoCache.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGStoreItemInfoCache.h"
#import "AGStoreItemInfo.h"

#define MAX_STORE_ITEM_STAR (2)
#define INCREASE_ITEM_LEVEL (10)

@implementation AGStoreItemInfoCache

@synthesize lastUpdateDate;
@synthesize storeItemInfoArray;

+ (AGStoreItemInfoCache *)instance
{
    static AGStoreItemInfoCache *cache = nil;
    if (cache == nil)
    {
        cache = [[AGStoreItemInfoCache alloc] init];
    }
    
    return cache;
}

- (NSArray *)getItemInfoFromType:(int)type playerLevel:(int)maxLevel
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (AGStoreItemInfo *info in self.storeItemInfoArray)
    {
        if (info.type == type
            && info.limitLevel <= (maxLevel + INCREASE_ITEM_LEVEL)
            && info.star <= MAX_STORE_ITEM_STAR)
        {
            [array addObject:info];
        }
    }
    
    return array;
}

- (AGStoreItemInfo *)getItemInfoFromEquipId:(int)equipId
{
    for (AGStoreItemInfo *info in self.storeItemInfoArray)
    {
        if (info.itemId == equipId)
        {
            return info;
        }
    }
    
    return nil;
}

- (void)updateCache:(NSDictionary *)jsonItemInfoDicArray
{
    NSArray *itemInfoDicArray = [jsonItemInfoDicArray objectForKey:@"totalStoreList"];
    
    self.lastUpdateDate = [NSDate date];
    
    NSMutableArray *newItemArray = [NSMutableArray array];
    
    for (NSDictionary *itemInfoDic in itemInfoDicArray)
    {
        AGStoreItemInfo *itemInfo = [AGStoreItemInfo itemInfoWithDictionaryInfo:itemInfoDic];
        [newItemArray addObject:itemInfo];
    }
    
    self.storeItemInfoArray = newItemArray;
}

- (void)dealloc
{
    self.storeItemInfoArray = nil;
    
    [super dealloc];
}

@end
