//
//  AGArenaInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGArenaInfo.h"
#import "AGStoreItemInfoCache.h"

@implementation AGArenaInfo

@synthesize name, imageName;
@synthesize attack, level, rank;
@synthesize curChallengeCount, maxChallengeCount;
@synthesize time;

- (void)dealloc
{
    self.name = nil;
    self.imageName = nil;
    
    [super dealloc];
}

- (float)challengeCountPercent
{
    return self.curChallengeCount * 100 / self.maxChallengeCount;
}

+ (AGArenaInfo *)arenaInfoFromDic:(NSDictionary *)dic
{
    AGArenaInfo *info = [[[AGArenaInfo alloc] init] autorelease];
    
    info.name = [[dic objectForKey:@"myArena"] objectForKey:@"playerName"];
    info.imageName = [[dic objectForKey:@"myArena"] objectForKey:@"imageId"];
    
    info.attack = [[[dic objectForKey:@"myArena"] objectForKey:@"attack"] intValue];
    info.level = [[[dic objectForKey:@"myArena"] objectForKey:@"level"] intValue];
    info.rank = [[[dic objectForKey:@"myArena"] objectForKey:@"rank"] intValue];
    
    info.curChallengeCount = [[[dic objectForKey:@"myArena"] objectForKey:@"pkNum"] intValue];
    info.maxChallengeCount = [[[dic objectForKey:@"myArena"] objectForKey:@"totalPkNum"] intValue];
    
    info.time = [[[dic objectForKey:@"myArena"] objectForKey:@"costTime"] intValue] / 1000.0f;
    
    return info;
}

@end

@implementation AGArenaChallengeResultInfo

@synthesize isWin;
@synthesize rank;
@synthesize opponentName;
@synthesize rewardItem;

- (void)dealloc
{
    self.opponentName = nil;
    self.rewardItem = nil;
    
    [super dealloc];
}

+ (AGArenaChallengeResultInfo *)resultFromInfo:(NSDictionary *)dic
{
    AGArenaChallengeResultInfo *info = [[[AGArenaChallengeResultInfo alloc] init] autorelease];
    
    info.isWin = [[dic objectForKey:@"isWin"] intValue];
    info.rank = [[dic objectForKey:@"myRank"] intValue];
    info.opponentName = [dic objectForKey:@"opponentName"];
    info.rewardItem = [[AGStoreItemInfoCache instance] getItemInfoFromEquipId:[[dic objectForKey:@"equipmentId"] intValue]];
    
    return info;
}

@end

@implementation AGArenaRankingRewardInfo

@synthesize gainCoins;
@synthesize rank;

+ (AGArenaRankingRewardInfo *)rewardInfoFromDic:(NSDictionary *)dic
{
    AGArenaRankingRewardInfo *info = [[[AGArenaRankingRewardInfo alloc] init] autorelease];
    
    info.rank = [[dic objectForKey:@"myRank"] intValue];
    info.gainCoins = [[dic objectForKey:@"gainCoins"] intValue];
    
    return info;
}

@end