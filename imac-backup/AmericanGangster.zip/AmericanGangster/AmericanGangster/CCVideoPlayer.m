//
//  CCVideoPlayer.m
//  study_PlayVideo
//
//  Created by 青宝 中 on 12-8-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CCVideoPlayer.h"

@interface CCVideoPlayer (Private)

@property (nonatomic, readonly) UIViewController *rootViewController;
@property (nonatomic, readonly) UIView *superView;

@end

@implementation CCVideoPlayer

@synthesize playDoneCallback;

- (id)init
{
    self = [super init];
    if (self != nil)
    {
        self.controlStyle = MPMovieControlStyleNone;
        
        self.view.frame = self.superView.frame;
        
        // 加入空的滑动窗口，抓住所有事件
        [self.view addSubview:[[[UIScrollView alloc] initWithFrame:self.view.frame] autorelease]];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(moviePlayerDidFinish:)
                                                     name:MPMoviePlayerPlaybackDidFinishNotification
                                                   object:self];
    }
    
    return self;
}

- (UIView *)superView
{
    return [CCDirector sharedDirector].openGLView;
}

- (void)startPlayerVideo
{
    if (self.view.superview != nil)
    {
        [self.view removeFromSuperview];
    }
    
    [self.superView addSubview:self.view];
    [self.superView bringSubviewToFront:self.view];
    
    [self play];
}

- (void)moviePlayerDidFinish:(NSNotification*) aNotification
{
    if (self != [aNotification object])
    {
        return;
    }
    
    if (self.playDoneCallback != nil)
    {
        [self.playDoneCallback.targetCallback runAction:self.playDoneCallback];
        self.playDoneCallback = nil;
    }
    
    [self.view removeFromSuperview];
    
	[self pause];
	[self stop];
}

- (void)dealloc
{
    self.playDoneCallback = nil;
    
	[[NSNotificationCenter defaultCenter]
	 removeObserver:self 
     name:MPMoviePlayerPlaybackDidFinishNotification
	 object:self];
    
    [super dealloc];
}

- (void)playerVideo:(NSString *)videoName ofType:(NSString *)type
{
    [[CCVideoPlayer instance] playerVideo:videoName ofType:type callback:nil];
}

- (void)playerVideo:(NSString *)videoName ofType:(NSString *)type callback:(CCCallFunc *)callbackAction
{
    NSURL *url = [NSURL fileURLWithPath:[[NSBundle mainBundle] pathForResource:videoName ofType:type]];

    self.contentURL = url;
    self.playDoneCallback = callbackAction;
    [self startPlayerVideo];
}

+ (CCVideoPlayer *)instance
{
    static CCVideoPlayer *videoPlayer = nil;
    if (videoPlayer == nil)
    {
        videoPlayer = [[CCVideoPlayer alloc] init];
    }
    
    return videoPlayer;
}

@end
