//
//  AGRefineItemInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "AGEquipmentInfo.h"

@class TimeLeftManager;
@class AGStoreItemInfo;
@interface AGEquipmentInfo (Refine)

+ (NSArray *)refineItemInfoArrayWithDictionaryInfo:(NSDictionary *)dic;
+ (AGEquipmentInfo *)getRefineItemFromInfo:(NSDictionary *)dic;

@end

@interface AGRefineInfo : NSObject

@property (nonatomic, retain) TimeLeftManager *refineTime;
@property BOOL canRefine;
@property int itemCount;
@property int refineRatio;

@property (nonatomic, readonly) float refinePercent;

+ (AGRefineInfo *)instance;

- (void)updateWithRefineListInfo:(NSDictionary *)info;
- (void)updateWithRefineItemInfo:(NSDictionary *)info;

@end

@interface AGRefineTimeInfo : NSObject

@property int minute;
@property int dollar;

+ (AGRefineTimeInfo *)timeInfoFromDic:(NSDictionary *)dic;

@end
