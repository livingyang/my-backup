//
//  HelloWorldLayer.m
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-4-26.
//  Copyright __MyCompanyName__ 2012年. All rights reserved.
//


// Import the interfaces
#import "HelloWorldLayer.h"

// HelloWorldLayer implementation
@implementation HelloWorldLayer

@synthesize connectAndReciveDataDic;

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldLayer *layer = [HelloWorldLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

- (void)onButtonClick:(id)sender
{
    NSURLRequest *request = [self loginRequest];
    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    [self.connectAndReciveDataDic setObject:[NSMutableData data] forKey:[NSValue valueWithNonretainedObject:connection]];
    [connection start];
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init])) {
		
        self.connectAndReciveDataDic = [NSMutableDictionary dictionary];
        
		// create and initialize a Label
		CCLabelTTF *label = [CCLabelTTF labelWithString:@"Hello World" fontName:@"Marker Felt" fontSize:64];

		// ask director the the window size
		CGSize size = [[CCDirector sharedDirector] winSize];
	
		// position the label on the center of the screen
		label.position =  ccp( size.width /2 , size.height/2 );
		
		// add the label as a child to this Layer
		[self addChild: label];
        
        CCMenu *menu = [CCMenu menuWithItems:nil];
        [self addChild:menu];
        
        [menu addChild:[CCMenuItemImage itemFromNormalImage:@"Icon.png"
                                              selectedImage:@"Icon.png"
                                                     target:self
                                                   selector:@selector(onButtonClick:)]];
	}
	return self;
}

// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	self.connectAndReciveDataDic = nil;
    
	// don't forget to call "super dealloc"
	[super dealloc];
}

- (NSURLRequest *)loginRequest
{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:
                                    [NSURL URLWithString:@"http://192.168.20.121:8080/gangster/RestServer"]];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-type"];
    NSString *param = [NSString stringWithFormat:@"devId=%@&format=JSON&method=login",
                       @"abc"];
    
    [request setHTTPBody:[param dataUsingEncoding:NSUTF8StringEncoding]];
    
    return request;
}
#pragma mark -
#pragma mark NSURLConnectionDataDelegate

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"error = %@", error);
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [[self.connectAndReciveDataDic objectForKey:[NSValue valueWithNonretainedObject:connection]] appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *info = [[[NSString alloc] initWithData:[self.connectAndReciveDataDic objectForKey:[NSValue valueWithNonretainedObject:connection]]
                                            encoding:NSUTF8StringEncoding] autorelease];
    
    [self.connectAndReciveDataDic removeObjectForKey:[NSValue valueWithNonretainedObject:connection]];
    
    NSLog(@"info = %@", info);
    
    return;
    [[[[UIAlertView alloc] initWithTitle:@"Result"
                                 message:info
                                delegate:self
                       cancelButtonTitle:@"OK"
                       otherButtonTitles:nil] autorelease] show];
}

@end
