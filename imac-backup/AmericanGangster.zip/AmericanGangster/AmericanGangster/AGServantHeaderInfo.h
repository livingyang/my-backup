//
//  AGServantHeaderInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCBalsamiqLayerDataSource.h"

@class CCBalsamiqLayer;
@interface AGServantHeaderInfo : NSObject <CCBalsamiqLayerDataSource>

@property int servantId;
@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, readonly) NSString *headerImageName;
@property int headerIndex;

+ (NSArray *)getServantListFromInfo:(NSDictionary *)info;

@end

@interface AGServantHeaderLockInfo : NSObject

@property BOOL hasLockHeader;
@property int nextUnlockLevel;

+ (AGServantHeaderLockInfo *)headerLockInfoFromDic:(NSDictionary *)dic;

@end


