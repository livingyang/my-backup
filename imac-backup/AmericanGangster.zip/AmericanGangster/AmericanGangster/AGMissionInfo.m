//
//  AGMissionInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGMissionInfo.h"
#import "AGMissionPlace.h"
#import "CCBalsamiqLayer.h"
#import "CCLabelTTF+ChangeFont.h"
#import "UIImage+Grayscale.h"

@implementation AGMissionInfo

@synthesize missionId, mapId;
@synthesize missionNumber, title, detail;
@synthesize rank;
@synthesize coin, exp, energy;
@synthesize doNum, maxDoNum;

- (void)dealloc
{
    self.title = nil;
    self.detail = nil;
    self.missionNumber = nil;
    
    [super dealloc];
}

- (void)loadPropertyFromInfo:(NSDictionary *)info
{
    self.missionId = [[info objectForKey:@"id"] intValue];
    self.mapId = [[[info objectForKey:@"taskInfo"] objectForKey:@"mapId"] intValue];
    
    self.missionNumber = [[info objectForKey:@"taskInfo"] objectForKey:@"taskNo"];
    self.title = [[info objectForKey:@"taskInfo"] objectForKey:@"taskName"];
    self.detail = [@"    " stringByAppendingString:[[info objectForKey:@"taskInfo"] objectForKey:@"description"]] ;
    
    self.rank = [[info objectForKey:@"difficulty"] intValue];
    
    self.coin = [[[info objectForKey:@"taskInfo"] objectForKey:@"coin"] intValue];
    self.exp = [[[info objectForKey:@"taskInfo"] objectForKey:@"exp"] intValue];
    self.energy = [[[info objectForKey:@"taskInfo"] objectForKey:@"energy"] intValue];
    
    self.doNum = [[info objectForKey:@"doNum"] intValue];
    self.maxDoNum = [[[info objectForKey:@"taskInfo"] objectForKey:@"numLimited"] intValue];
}

+ (AGMissionInfo *)missionInfoFromUpdateInfo:(NSDictionary *)dic
{
    AGMissionInfo *info = [[[AGMissionInfo alloc] init] autorelease];
    
    [info loadPropertyFromInfo:[dic objectForKey:@"curTask"]];
    
    return info;
}

+ (BOOL)needsRefleshTotalMissionListFromUpdateInfo:(NSDictionary *)dic
{
    return [[dic objectForKey:@"refreshTaskList"] intValue];
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    [[layer getControlByName:@"title"] setString:self.title];
    [[layer getControlByName:@"title"] changeToBlackArialFont];
    
    [[layer getControlByName:@"detail"] setString:self.detail];
    [[layer getControlByName:@"number"] setString:self.missionNumber];
    
    [[layer getControlByName:@"rank"] setString:
     [NSString stringWithFormat:@"%d", self.rank]];
    
    [[layer getControlByName:@"energy"] setString:
     [NSString stringWithFormat:@"%d", self.energy]];
    [[layer getControlByName:@"exp"] setString:
     [NSString stringWithFormat:@"%d", self.exp]];
    [[layer getControlByName:@"coin"] setString:
     [NSString stringWithFormat:@"%d", self.coin]];
    
    if (self.maxDoNum != 0)
    {
        CCProgressTimer *barNum = [layer getControlByName:@"bar_mission"];
        barNum.percentage = self.doNum / (float)self.maxDoNum * 100;
        
        [[layer getControlByName:@"percent"] setString:
         [NSString stringWithFormat:@"%d%%", self.doNum * 100 / self.maxDoNum]];
    }
    
    [[layer getControlByName:@"DoIt"] setIsEnabled:(self.doNum != self.maxDoNum)];
}

@end

@implementation AGMissionBossInfo

@synthesize bossId;
@synthesize imageName;
@synthesize name, detail;
@synthesize mapId;
@synthesize level, attack;
@synthesize maxDefense, minDefense;
@synthesize energy, coin, exp;
@synthesize needsServantCount;

- (void)dealloc
{
    self.name = nil;
    self.imageName = nil;
    self.detail = nil;
    
    [super dealloc];
}

- (NSString *)mapName
{
    AGMissionPlace *place = [[AGMissionPlaceListCache instance] getPlaceFromMapId:self.mapId];
    
    return (place == nil) ? @"" : place.mapName;
}

-(UIImage *) convertSpriteToImage:(CCSprite *)sprite
{
    CGPoint p = sprite.anchorPoint;   
    [sprite setAnchorPoint:ccp(0,0)];  
    CCRenderTexture *renderer = [CCRenderTexture renderTextureWithWidth:sprite.contentSize.width height:sprite.contentSize.height];
    [renderer begin];
    [sprite visit];  
    [renderer end];   
    [sprite setAnchorPoint:p];  
    return [UIImage imageWithData:[renderer getUIImageAsDataFromBuffer:kCCImageFormatPNG]];
}


- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    [[layer getControlByName:@"name"] setString:self.name];
    [[layer getControlByName:@"name"] changeToBlackArialFont];
    CCLabelTTF *labDetail = [layer getControlByName:@"detail"];
    labDetail.string = self.detail;
    labDetail.color = ccWHITE;
    
    [[layer getControlByName:@"image_boss"] setTexture:
     [[CCTextureCache sharedTextureCache] addImage:[@"boss" stringByAppendingPathComponent:self.imageName]]];
    
    {
        [[layer getControlByName:@"image_dead_boss"] setTexture:
         getGrayTextureFromPath([@"boss" stringByAppendingPathComponent:self.imageName])];
    }
    
    [[layer getControlByName:@"level"] setString:
     [NSString stringWithFormat:@"%d", self.level]];
    
    [[layer getControlByName:@"attack"] setString:
     [NSString stringWithFormat:@"%d", self.attack]];
    [[layer getControlByName:@"defense"] setString:
     [NSString stringWithFormat:@"%d ~ %d", self.minDefense, self.maxDefense]];
    [[layer getControlByName:@"energy"] setString:
     [NSString stringWithFormat:@"%d", self.energy]];
    [[layer getControlByName:@"exp"] setString:
     [NSString stringWithFormat:@"%d", self.exp]];
    [[layer getControlByName:@"coin"] setString:
     [NSString stringWithFormat:@"%d", self.coin]];
    
    [[layer getControlByName:@"servant-count"] setString:
     [NSString stringWithFormat:@"%d", self.needsServantCount]];
}

@end

@implementation AGMissionFightBossInfo

@synthesize rewardEquipId;
@synthesize isWin;
@synthesize deadServantCount;

+ (AGMissionFightBossInfo *)fightBossInfoFromInfo:(NSDictionary *)dic
{
    AGMissionFightBossInfo *info = [[[AGMissionFightBossInfo alloc] init] autorelease];
    
    info.rewardEquipId = [[dic objectForKey:@"equipId"] intValue];
    info.isWin = [[dic objectForKey:@"isWin"] intValue];
    info.deadServantCount = 4;
    
    return info;
}

@end

@implementation AGPlaceMissionInfo

@synthesize missionInfoArray;
@synthesize bossInfo;

- (void)dealloc
{
    self.missionInfoArray = nil;
    self.bossInfo = nil;
    [super dealloc];
}

+ (AGPlaceMissionInfo *)getTotalMissionAtPlaceInfo:(NSDictionary *)dic
{
    AGPlaceMissionInfo *totalMission = [[[AGPlaceMissionInfo alloc] init] autorelease];
    
    // 生成boss信息
    NSDictionary *bossDic = [[dic objectForKey:@"boss"] objectForKey:@"bossInfo"];
    if (bossDic != nil)
    {
        totalMission.bossInfo = [[[AGMissionBossInfo alloc] init] autorelease];
        
        totalMission.bossInfo.bossId = [[[dic objectForKey:@"boss"] objectForKey:@"id"] intValue];
        
        totalMission.bossInfo.name  = [bossDic objectForKey:@"bossName"];
        totalMission.bossInfo.imageName  = [bossDic objectForKey:@"imageId"];
        totalMission.bossInfo.detail  = [bossDic objectForKey:@"detail"];
        
        totalMission.bossInfo.mapId = [[bossDic objectForKey:@"mapId"] intValue];
        totalMission.bossInfo.level = [[bossDic objectForKey:@"level"] intValue];
        totalMission.bossInfo.attack = [[bossDic objectForKey:@"attack"] intValue];
        
        totalMission.bossInfo.maxDefense = [[bossDic objectForKey:@"maxDefense"] intValue];
        totalMission.bossInfo.minDefense = [[bossDic objectForKey:@"minDefense"] intValue];
        
        totalMission.bossInfo.energy = [[bossDic objectForKey:@"energy"] intValue];
        totalMission.bossInfo.coin = [[bossDic objectForKey:@"coin"] intValue];
        totalMission.bossInfo.exp = [[bossDic objectForKey:@"exp"] intValue];
        
        totalMission.bossInfo.needsServantCount = [[bossDic objectForKey:@"servantNum"] intValue];
    }
    
    NSMutableArray *missionArray = [NSMutableArray array];
    for (NSDictionary *missionDic in [dic objectForKey:@"missionList"])
    {
        AGMissionInfo *mission = [[[AGMissionInfo alloc] init] autorelease];
        [missionArray addObject:mission];
        
        [mission loadPropertyFromInfo:missionDic];
    }
    totalMission.missionInfoArray = missionArray;
    
    return totalMission;
}

@end

@implementation AGMissionEventInfo

@synthesize name;
@synthesize imageName;
@synthesize detail;

- (void)dealloc
{
    self.name = nil;
    self.imageName = nil;
    self.detail = nil;
    
    [super dealloc];
}

@end

@implementation AGMissionFinishInfo

@synthesize missionInfo;
@synthesize eventInfo;
@synthesize prizonTime;

@synthesize needsRefresh;
@synthesize rewardItem;

- (void)dealloc
{
    self.missionInfo = nil;
    self.eventInfo = nil;
    self.rewardItem = nil;
    [super dealloc];
}

+ (AGMissionFinishInfo *)missionFinishInfoFromInfo:(NSDictionary *)info
{
    AGMissionFinishInfo *finishInfo = [[[AGMissionFinishInfo alloc] init] autorelease];
    
    finishInfo.missionInfo = [[[AGMissionInfo alloc] init] autorelease];
    [finishInfo.missionInfo loadPropertyFromInfo:[info objectForKey:@"curTask"]];
    
    if ([info objectForKey:@"Event"] != nil)
    {
        finishInfo.eventInfo = [[[AGMissionEventInfo alloc] init] autorelease];
        
        finishInfo.eventInfo.name = [[info objectForKey:@"Event"] objectForKey:@"eventName"];
        finishInfo.eventInfo.imageName = [[info objectForKey:@"Event"] objectForKey:@"imageId"];
        finishInfo.eventInfo.detail = [[info objectForKey:@"Event"] objectForKey:@"description"];
        
        finishInfo.prizonTime = [[[info objectForKey:@"arrested"] objectForKey:@"createdTime"] intValue] / 1000.0f;
    }
    
    finishInfo.needsRefresh = [[info objectForKey:@"refreshTaskList"] intValue];
    finishInfo.rewardItem = [info objectForKey:@"rewardItem"];
    return finishInfo;
}

+ (NSArray *)totalSlotImages
{
    return [NSArray arrayWithObjects:
            @"slot-machine/img-slot-card.png",
            @"slot-machine/img-slot-event.png",
            @"slot-machine/img-slot-none.png",
            @"slot-machine/img-slot-exp.png",
            @"slot-machine/img-slot-coin.png",
            nil];
}

+ (NSString *)eventImage
{
    return @"slot-machine/img-slot-event.png";
}

+ (NSString *)noneImage
{
    return @"slot-machine/img-slot-none.png";
}

- (NSString *)rewardSlotImage
{
    if (self.isRewardNone)
    {
        return @"slot-machine/img-slot-none.png";
    }
    if (self.isRewardEvent)
    {
        return @"slot-machine/img-slot-event.png";
    }
    if (self.isRewardCoin)
    {
        return @"slot-machine/img-slot-coin.png";
    }
    if (self.isRewardExp)
    {
        return @"slot-machine/img-slot-exp.png";
    }
    
    return @"slot-machine/img-slot-card.png";
}

- (NSString *)rewardType
{
    return [[self.rewardItem componentsSeparatedByString:@":"] objectAtIndex:0];
}

- (int)rewardNum
{
    return [[[self.rewardItem componentsSeparatedByString:@":"] objectAtIndex:1] intValue];
}

#pragma mark -
#pragma mark reward type

- (BOOL)isRewardNone
{
    return [self.rewardItem hasPrefix:@"Lose"];
}

- (BOOL)isRewardCoin
{
    return [self.rewardItem hasPrefix:@"Coin"];
}

- (BOOL)isRewardExp
{
    return [self.rewardItem hasPrefix:@"Exp"];
}

- (BOOL)isRewardEvent
{
    return [self.rewardItem hasPrefix:@"Event"];
}

- (BOOL)isRewardCard
{
    return !self.isRewardNone && !self.isRewardCoin && !self.isRewardExp && !self.isRewardEvent;
}

@end

@implementation AGPrizonInfo

@synthesize prizonAtMapId;
@synthesize isInPrizon = isInPrizon_;

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        isInPrizon_ = NO;
    }
    
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

+ (AGPrizonInfo *)instance
{
    static AGPrizonInfo *info = nil;
    
    if (info == nil)
    {
        info = [[AGPrizonInfo alloc] init];
    }
    
    return info;
}

- (void)arrestAtMissionPlace:(int)mapId
{
    self.prizonAtMapId = mapId;
    isInPrizon_ = YES;
}

- (void)leavePrizon
{
    isInPrizon_ = NO;
}

@end

@implementation AGPrizonTimeInfo

@synthesize minute;
@synthesize dollar;

+ (AGPrizonTimeInfo *)prizonTimeInfoFromDic:(NSDictionary *)dic
{
    AGPrizonTimeInfo *timeInfo = [[[AGPrizonTimeInfo alloc] init] autorelease];
    
    timeInfo.minute = [[dic objectForKey:@"time"] intValue] / (1000 * 60);
    timeInfo.dollar = [[dic objectForKey:@"dollar"] intValue];
    return timeInfo;
}

@end