//
//  AGBusinessInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-13.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCBalsamiqLayerDataSource.h"

@interface AGBusinessInfo : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *imageName;
@property int level;
@property int type;

@property int maxLevel;
@property (nonatomic, readonly) int isMaxLevel;

@property int curCostServant;
@property int maxCostServant;
@property (nonatomic, readonly) int maxCanSendServantCount;

@property int gainCoins;
@property int nextGainCoins;
@property int increaseCoins;

@property int upCost;

@property NSTimeInterval startTime;
@property NSTimeInterval nextGainTime;
@property NSTimeInterval totalGainTime;

@property (nonatomic, readonly) NSTimeInterval curGainTime;
@property (nonatomic, readonly) BOOL canGain;

+ (NSArray *)businessListFromInfo:(NSDictionary *)dic;
+ (int)getCountOfGainBusiness:(NSArray *)businessList;

+ (AGBusinessInfo *)businessInfoFromCommercialInfo:(NSDictionary *)speedDic;

@end
