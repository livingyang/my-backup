//
//  AGShopItemInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGShopItemInfo.h"
#import "CCBalsamiqLayer.h"
#import "ItemImageManager.h"
#import "CCLabelTTF+ChangeFont.h"

@implementation AGShopItemInfo

@synthesize propsId, money, count;
@synthesize isCanUseDirect;
@synthesize name, imageName, detail;

- (void)dealloc
{
    self.name = nil;
    self.imageName = nil;
    self.detail = nil;
    
    [super dealloc];
}

- (NSString *)itemImagePath
{
    return [@"item" stringByAppendingPathComponent:self.imageName];
}

- (void)loadPropertyFromInfo:(NSDictionary *)info
{
    self.propsId = [[info objectForKey:@"propsId"] intValue];
    self.money = [[info objectForKey:@"money"] intValue];
    self.count = [[info objectForKey:@"haveNum"] intValue];
    
    self.isCanUseDirect = [[info objectForKey:@"isUse"] intValue];
    
    self.name = [info objectForKey:@"propsName"];
    self.imageName = [info objectForKey:@"image"];
    self.detail = [info objectForKey:@"description"];
}

+ (AGShopItemInfo *)shopItemFromInfo:(NSDictionary *)info
{
    AGShopItemInfo *item = [[[AGShopItemInfo alloc] init] autorelease];
    
    [item loadPropertyFromInfo:info];
    
    return item;
}

+ (NSArray *)shopItemListFromInfo:(NSDictionary *)info
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *itemInfo in [info objectForKey:@"propsList"])
    {
        [array addObject:[self shopItemFromInfo:itemInfo]];
    }
    
    return array;
}

+ (NSArray *)shopItemListFromAlertInfo:(NSDictionary *)info
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *itemInfo in [info objectForKey:@"alertPropsList"])
    {
        [array addObject:[self shopItemFromInfo:itemInfo]];
    }
    
    return array;
}

+ (AGShopItemInfo *)shopItemFromUseAndBuyInfo:(NSDictionary *)info
{
    return [self shopItemFromInfo:[info objectForKey:@"props"]];
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    [[layer getControlByName:@"image_icon"] setTexture:
     [[CCTextureCache sharedTextureCache] addImage:self.itemImagePath]];
    [[layer getControlByName:@"image_icon"] setTag:self.propsId];
    
    [[layer getControlByName:@"count"] setString:
     [NSString stringWithFormat:@"%d", self.count]];
    [[layer getControlByName:@"name"] setString:self.name];
    [[layer getControlByName:@"name"] changeToBlackArialFont];
    [[layer getControlByName:@"detail"] setString:self.detail];
    [[layer getControlByName:@"dollar"] setString:[NSString stringWithFormat:@"%d", self.money]];
}

@end

@implementation AGShopBagItemInfo

@synthesize itemInfo;
@synthesize bagItemInfo;

- (void)dealloc
{
    self.itemInfo = nil;
    self.bagItemInfo = nil;
    
    [super dealloc];
}

- (int)bagItemCount
{
    return 10;
}

- (int)costMoney
{
    return self.itemInfo.money * self.bagItemCount;
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    [self.itemInfo updateDataToLayer:layer];
    
    [[layer getControlByName:@"image_bag_icon"] setTexture:
     [[CCTextureCache sharedTextureCache] addImage:self.bagItemInfo.itemImagePath]];
    
    [[layer getControlByName:@"cost-money"] setString:
     [NSString stringWithFormat:@"%d", self.costMoney]];
    [[layer getControlByName:@"bag-dollar"] setString:
     [NSString stringWithFormat:@"%d", self.bagItemInfo.money]];
    [[layer getControlByName:@"bag-item-count"] setString:
     [NSString stringWithFormat:@"%d", self.bagItemCount]];
}

+ (AGShopBagItemInfo *)bagItemFromInfo:(NSDictionary *)info
{
    AGShopBagItemInfo *bagItem = [[[AGShopBagItemInfo alloc] init] autorelease];
    
    bagItem.itemInfo = [AGShopItemInfo shopItemFromInfo:[info objectForKey:@"item"]];
    bagItem.bagItemInfo = [AGShopItemInfo shopItemFromInfo:[info objectForKey:@"itemBag"]];
    
    return bagItem;
}

@end

@implementation AGShopSlotMachine

@synthesize slotId;
@synthesize dollar;
@synthesize title;
@synthesize detail;
@synthesize randomEquipmentIdList;
@synthesize displayEquipmentId;

- (void)dealloc
{
    self.detail = nil;
    self.randomEquipmentIdList = nil;
    
    [super dealloc];
}

@end

@implementation AGShopSlotMachineCache

@synthesize slotMachineList;

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        NSMutableArray *array = [NSMutableArray array];
        for (int i = 0; i < 8; ++i)
        {
            AGShopSlotMachine *slotMachine = [[[AGShopSlotMachine alloc] init] autorelease];
            [array addObject:slotMachine];
            
            slotMachine.slotId = i;
            slotMachine.dollar = i * 100;
            slotMachine.detail = @"test detail";
            slotMachine.randomEquipmentIdList = [NSArray arrayWithObjects:@"1", @"2", @"3", nil];
            slotMachine.displayEquipmentId = i + 1;
        }
        
        self.slotMachineList = array;
    }
    
    return self;
}

- (void)dealloc
{
    self.slotMachineList = nil;
    
    [super dealloc];
}

+ (AGShopSlotMachineCache *)instance
{
    static AGShopSlotMachineCache *cache = nil;
    if (cache == nil)
    {
        cache = [[AGShopSlotMachineCache alloc] init];
    }
    
    return cache;
}

- (void)updateSlotMachineWithDic:(NSDictionary *)dic
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *slotDic in [dic objectForKey:@"slotMachineList"])
    {
        AGShopSlotMachine *slotMachine = [[[AGShopSlotMachine alloc] init] autorelease];
        [array addObject:slotMachine];
        
        slotMachine.slotId = [[slotDic objectForKey:@"id"] intValue];
        slotMachine.dollar = [[slotDic objectForKey:@"dollar"] intValue];
        slotMachine.title = [slotDic objectForKey:@"title"];
        slotMachine.detail = [slotDic objectForKey:@"detail"];
        slotMachine.randomEquipmentIdList = [slotDic objectForKey:@"spinWeaponItems"];
        slotMachine.displayEquipmentId = [[slotDic objectForKey:@"displayEquipmentId"] intValue];
    }
    
    self.slotMachineList = array;
}

- (AGShopSlotMachine *)getSlotMachineFromId:(int)slotId
{
    for (AGShopSlotMachine *slotMachine in self.slotMachineList)
    {
        if (slotMachine.slotId == slotId)
        {
            return slotMachine;
        }
    }
    
    return nil;
}

@end

@implementation AGCardInfo

@synthesize cardId, count;
@synthesize exchangeCardNum, exchangeItemNum;
@synthesize name, imageName, detail;
@synthesize exchangeItem;

- (void)dealloc
{
    self.name = nil;
    self.imageName = nil;
    self.detail = nil;
    self.exchangeItem = nil;
    
    [super dealloc];
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"name = %@\n detail = %@"];
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    [self.exchangeItem updateDataToLayer:layer];
    
    [[layer getControlByName:@"count-card"] setString:[NSString stringWithFormat:@"%d", self.count]];
    [[layer getControlByName:@"name-card"] setString:self.name];
    [[layer getControlByName:@"name-card"] changeToBlackArialFont];
    [[layer getControlByName:@"detail-card"] setString:self.detail];
    
    [[layer getControlByName:@"exchange-count-card"] setString:
     [NSString stringWithFormat:@"%d", self.exchangeCardNum]];;
    [[layer getControlByName:@"exchange-count-item"] setString:
     [NSString stringWithFormat:@"%d", self.exchangeItemNum]];
    
    [[layer getControlByName:@"ExchangeCard"] setTag:self.cardId];
    [[layer getControlByName:@"ExchangeCard"] setIsEnabled:self.count >= self.exchangeCardNum];
    [[layer getControlByName:@"UseCard"] setTag:self.exchangeItem.propsId];
    [[layer getControlByName:@"UseCard"] setVisible:self.exchangeItem.isCanUseDirect];
    [[layer getControlByName:@"image_card"] setTexture:
     [[CCTextureCache sharedTextureCache] addImage:[@"card" stringByAppendingPathComponent:self.imageName]]];
}

- (void)loadPropertyFromInfo:(NSDictionary *)info
{
    self.cardId = [[info objectForKey:@"cardId"] intValue];
    self.count = [[info objectForKey:@"cardNum"] intValue];
    self.exchangeCardNum = [[info objectForKey:@"exchangeCardNum"] intValue];
    self.exchangeItemNum = [[info objectForKey:@"exchangePropsNum"] intValue];
    
    self.name = [info objectForKey:@"cardName"];
    self.imageName = [info objectForKey:@"image"];
    self.detail = [info objectForKey:@"description"];
    
    self.exchangeItem = [AGShopItemInfo shopItemFromInfo:[info objectForKey:@"props"]];
}

+ (NSArray *)cardListFromInfo:(NSDictionary *)info
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *cardDic in [info objectForKey:@"cardList"])
    {
        AGCardInfo *card = [[[AGCardInfo alloc] init] autorelease];
        [array addObject:card];
        
        [card loadPropertyFromInfo:cardDic];
    }
    
    return array;
}

+ (AGCardInfo *)cardInfoFromExchangeInfo:(NSDictionary *)info
{
    AGCardInfo *cardInfo = [[[AGCardInfo alloc] init] autorelease];
    [cardInfo loadPropertyFromInfo:[info objectForKey:@"card"]];
    return cardInfo;
}

@end

@implementation AGCardInfoCache

@synthesize cardInfoList;

+ (AGCardInfoCache *)instance
{
    static AGCardInfoCache *cache = nil;
    if (cache == nil)
    {
        cache = [[AGCardInfoCache alloc] init];
    }
    
    return cache;
}

- (void)loadTotalCardInfo:(NSDictionary *)info
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *cardDic in [info objectForKey:@"cardList"])
    {
        AGCardInfo *card = [[[AGCardInfo alloc] init] autorelease];
        [array addObject:card];
        
        [card loadPropertyFromInfo:cardDic];
    }
    
    self.cardInfoList = array;
}

- (AGCardInfo *)getCardInfoById:(int)cardId
{
    for (AGCardInfo *cardInfo in self.cardInfoList)
    {
        if (cardInfo.cardId == cardId)
        {
            return cardInfo;
        }
    }
    
    NSLog(@"AGCardInfoCache#getCardInfoById cannot find card id = %d", cardId);
    return nil;
}

- (AGCardInfo *)getCardInfoByName:(NSString *)cardName
{
    for (AGCardInfo *cardInfo in self.cardInfoList)
    {
        if ([cardInfo.name isEqualToString:cardName])
        {
            return cardInfo;
        }
    }
    
    NSLog(@"AGCardInfoCache#getCardInfoByName cannot find card name = %@", cardName);
    return nil;
}

@end

@implementation AGShopInfo

@synthesize reflashFinishTime;

+ (AGShopInfo *)instance
{
    static AGShopInfo *info = nil;
    if (info == nil)
    {
        info = [[AGShopInfo alloc] init];
    }
    
    return info;
}

- (NSTimeInterval)reflashLeftTime
{
    NSTimeInterval timeLeft = self.reflashFinishTime - [NSDate timeIntervalSinceReferenceDate];
    return (timeLeft > 0) ? timeLeft : 0;
}

- (void)updateFromInfo:(NSDictionary *)info
{
    self.reflashFinishTime = [NSDate timeIntervalSinceReferenceDate]
    + [[info objectForKey:@"refreshTime"] intValue] / 1000;
}

@end