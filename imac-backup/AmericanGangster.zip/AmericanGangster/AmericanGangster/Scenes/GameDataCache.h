//
//  GameDataCache.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-9-3.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol GameDataCacheDelegate <NSObject>

- (void)onTotalDataCached;

@end

@interface GameDataCache : NSObject
{
    id<GameDataCacheDelegate> delegate_;
    
    BOOL isTotalStoreCached;
    BOOL isTotalCardCached;
}

+ (GameDataCache *)gameDataCacheWithDelegate:(id<GameDataCacheDelegate>)delegate;

- (void)cacheTotalStore:(NSDictionary *)data;
- (void)cacheTotalCard:(NSDictionary *)data;

@end
