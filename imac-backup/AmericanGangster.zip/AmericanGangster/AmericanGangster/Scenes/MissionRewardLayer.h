//
//  MissionRewardLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-2.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@class CCBalsamiqLayer;
@class AGMissionBossInfo;
@class AGMissionFightBossInfo;
@interface MissionRewardLayer : BaseLayer
{
    CCBalsamiqLayer *bossLayer;
    CCBalsamiqLayer *rewardLayer;
}

+ (CCScene *)sceneWithRewardItem:(AGMissionFightBossInfo *)item withBossInfo:(AGMissionBossInfo *)bossInfo;

@end
