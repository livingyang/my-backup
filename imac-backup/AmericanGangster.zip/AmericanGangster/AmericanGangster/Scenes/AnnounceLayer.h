//
//  AnnounceLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-10-9.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@interface AnnounceLayer : BaseLayer
{
    CCBalsamiqLayer *balsamiqLayer;
}

@property (nonatomic, retain) NSDictionary *layerAndInfoDic;

@end
