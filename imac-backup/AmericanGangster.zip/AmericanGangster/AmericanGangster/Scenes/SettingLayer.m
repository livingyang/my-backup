//
//  SettingLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-25.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "SettingLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCTableLayer.h"
#import "AGSettingInfo.h"
#import "LocalSettingManager.h"

//#define NAME_BGM_SETTING @"Background Music"
//#define NAME_VIBRATE_SETTING @"Vibrate"

@implementation SettingLayer

- (id)init
{
    self = [super init];
    if (self != nil)
    {
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"13-setting.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        self.headerLayer = [balsamiqLayer getControlByName:@"header-property"];
        
        [self postGetSettings];
    }
    return self;
}

- (NSString *)NAME_BGM_SETTING
{
    return [self getLanguageString:@"13001"];
}

- (NSString *)NAME_VIBRATE_SETTING
{
    return [self getLanguageString:@"13002"];
}

- (void)saveSettingToServer
{
    NSMutableString *settingString = [NSMutableString string];
    
    for (CCBalsamiqLayer *layer in [[balsamiqLayer getControlByName:@"table"] cellContainer].children)
    {
        CCMenuItemToggle *toggle = [layer getControlByName:@"toggle_ok"];
        [settingString appendFormat:@"%d,", toggle.selectedIndex];
    }
    
    if (settingString.length <= 0)
    {
        return;
    }
    
    [self postUpdateSettings:[settingString substringToIndex:settingString.length - 5]];
}

- (void)onClick_toggle_ok:(CCMenuItemToggle *)toggle
{
    CCBalsamiqLayer *settingLayer = [CCBalsamiqLayer getBalsamiqLayerFromChild:toggle];
    NSString *settingName = [[settingLayer getControlByName:@"name"] string];
    if ([self.NAME_BGM_SETTING isEqualToString:settingName])
    {
        [LocalSettingManager instance].isBgmEnabled = toggle.selectedIndex;
    }
    else if ([self.NAME_VIBRATE_SETTING isEqualToString:settingName])
    {
        [LocalSettingManager instance].isVibrateEnabled = toggle.selectedIndex;
    }
    else
    {
        [self saveSettingToServer];   
    }
}

- (void)updateSettingList:(NSArray *)settingList
{
    CCNode *cellContainer = [CCNode node];
    for (int i = 0; i < settingList.count; ++i)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"13.1-setting-info.bmml"
                                                           eventHandle:self];
        cell.position = ccp(0, i * cell.contentSize.height);
        [cellContainer addChild:cell];
        
        AGSettingInfo *settingInfo = [settingList objectAtIndex:i];
        
        [[cell getControlByName:@"name"] setString:settingInfo.name];
        [[cell getControlByName:@"toggle_ok"] setSelectedIndex:(settingInfo.isOn) ? 1 : 0];
    }
    
    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_getSettings:(NSDictionary *)info
{
    NSMutableArray *settings = [NSMutableArray arrayWithArray:[AGSettingInfo settingListFromInfo:info]];
    
    // 加入本地设置
    {
        AGSettingInfo *bgmSetting = [[[AGSettingInfo alloc] init] autorelease];
        bgmSetting.name = self.NAME_BGM_SETTING;
        bgmSetting.isOn = [LocalSettingManager instance].isBgmEnabled;
        
        [settings addObject:bgmSetting];
        
        AGSettingInfo *vibrateSetting = [[[AGSettingInfo alloc] init] autorelease];
        vibrateSetting.name = self.NAME_VIBRATE_SETTING;
        vibrateSetting.isOn = [LocalSettingManager instance].isVibrateEnabled;
        
        [settings addObject:vibrateSetting];
    }
    
    [self updateSettingList:settings];
}

@end
