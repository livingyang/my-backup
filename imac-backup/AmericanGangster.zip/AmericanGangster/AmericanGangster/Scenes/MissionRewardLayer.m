//
//  MissionRewardLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-2.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "MissionRewardLayer.h"
#import "CCBalsamiqLayer.h"
#import "AGMissionInfo.h"
#import "AGStoreItemInfo.h"
#import "AGStoreItemInfoCache.h"

@implementation MissionRewardLayer

+ (CCScene *)sceneWithRewardItem:(AGMissionFightBossInfo *)fightBossInfo withBossInfo:(AGMissionBossInfo *)bossInfo
{
    CCScene *scene = [CCScene node];
    
    MissionRewardLayer *layer = [MissionRewardLayer node];
    [layer loadRewardItem:fightBossInfo andBossInfo:bossInfo];
    [scene addChild:layer];
    
    return scene;
}

- (void)loadRewardItem:(AGMissionFightBossInfo *)fightBossInfo andBossInfo:(AGMissionBossInfo *)bossInfo
{
    [bossInfo updateDataToLayer:bossLayer];
    CCLabelTTF *labDefeat = [bossLayer getControlByName:@"detail-defeat"];
    labDefeat.string = [NSString stringWithFormat:[self getLanguageString:@"4006"],
                        bossInfo.name, bossInfo.mapName, bossInfo.mapName];
    
    AGStoreItemInfo *rewardItem = [[AGStoreItemInfoCache instance] getItemInfoFromEquipId:fightBossInfo.rewardEquipId];
    [rewardItem updateDataToLayer:rewardLayer];   
    [[rewardLayer getControlByName:@"detail"] setString:
     [NSString stringWithFormat:[self getLanguageString:@"4007"],
      bossInfo.name, rewardItem.star, rewardItem.name, bossInfo.needsServantCount]];
}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"3.7-reward-border.bmml"
                                                            eventHandle:self];
        [self addChild:layer];
        
        self.isTouchEnabled = YES;
        
        bossLayer = [layer getControlByName:@"boss-info"];
        rewardLayer = [layer getControlByName:@"reward"];
        rewardLayer.visible = NO;
        
        CGPoint centerPoint = [bossLayer convertToWorldSpace:ccp(bossLayer.contentSize.width / 2,
                                                                 bossLayer.contentSize.height / 2)];
        centerPoint = [bossLayer.parent convertToNodeSpace:centerPoint];
        
        bossLayer.position = centerPoint;
        bossLayer.anchorPoint = ccp(0.5f, 0.5f);
    
        bossLayer.scale = 5;
        CCSpawn *spawn = [CCSpawn actions:
                          [CCScaleTo actionWithDuration:0.4 scale:1],
                          [CCRepeat actionWithAction:[CCRotateBy actionWithDuration:0.2f angle:360] times:2],
                          nil];
        
        
        CCSprite *sprDefeat = [bossLayer getControlByName:@"image_defeat"];
        
        sprDefeat.scale = 10;
        sprDefeat.opacity = 0;
        
        [bossLayer runAction:[CCSequence actions:
                              spawn,
                              [CCCallFuncO actionWithTarget:sprDefeat
                                                   selector:@selector(runAction:)
                                                     object:[CCSpawn actionOne:[CCFadeIn actionWithDuration:0.5f]
                                                                           two:[CCScaleTo actionWithDuration:0.5f scale:1]]],
                              nil]];
    }
    
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)onEnter
{
    [super onEnter];
    
    [[SoundManager instance] playEffectWinBoss];
}

- (void)onExit
{
    [super onExit];
    
    [[SoundManager instance] continuePlayBackgroundMusic];
}

- (void)onRewardClick:(id)sender
{
    [bossLayer removeFromParentAndCleanup:YES];
    
    rewardLayer.visible = YES;
}

- (void)onOkClick:(id)sender
{
    [self onSelect_radio_Tool_mission:nil];
}

- (void)registerWithTouchDispatcher
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self
                                                     priority:kCCMenuMousePriority - 1
                                              swallowsTouches:YES];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
    return YES;
}

- (void)ccTouchEnded:(UITouch *)touch withEvent:(UIEvent *)event
{
    if (rewardLayer.visible == NO)
    {
        [self onRewardClick:nil];
    }
    else
    {
        [self onOkClick:nil];
    }
}

@end
