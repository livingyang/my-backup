//
//  PlayerTypeSelectLayer.h
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-4-27.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "BaseLayer.h"
#import "GameDataCache.h"

@class CCBalsamiqLayer;
@class AGLoginInfo;
@interface PlayerTypeSelectLayer : BaseLayer <GameDataCacheDelegate>
{
    CCBalsamiqLayer *balsamiqLayer;
}

@property (nonatomic, retain) AGLoginInfo *loginInfo;
@property (nonatomic, retain) GameDataCache *gameDataCache;

+ (CCScene *)sceneWithLoginInfo:(AGLoginInfo *)info;
- (void)loadLoginInfo:(AGLoginInfo *)info;

@end
