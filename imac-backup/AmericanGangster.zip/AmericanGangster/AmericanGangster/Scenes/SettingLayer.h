//
//  SettingLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-25.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@interface SettingLayer : BaseLayer
{
    CCBalsamiqLayer *balsamiqLayer;
}

@property (nonatomic, readonly) NSString *NAME_BGM_SETTING;
@property (nonatomic, readonly) NSString *NAME_VIBRATE_SETTING;

@end
