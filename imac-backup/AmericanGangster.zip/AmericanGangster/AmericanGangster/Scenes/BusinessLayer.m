//
//  BusinessLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-11.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "BusinessLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCTableLayer.h"
#import "AGBusinessInfo.h"
#import "BusinessIncreaseLayer.h"
#import "CCAlertLayer.h"
#import "CCTimeManageNode.h"
#import "CCMenuItemButton.h"
#import "CCLabelTTF+ChangeFont.h"

#define TAG_FLASH_ACTION (234)

@implementation BusinessLayer

@synthesize curSpeedUpBusinessInfo;

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        layerAndInfoDic = [[NSMutableDictionary alloc] init];
        
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"8-business.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        self.headerLayer = [balsamiqLayer getControlByName:@"header-property"];
        
        [self postGetBusinessList];
    }
    
    return self;
}

- (void)dealloc
{
    [layerAndInfoDic release];
    
    [super dealloc];
}

- (AGBusinessInfo *)getInfoFromLayer:(CCBalsamiqLayer *)layer
{
    return [layerAndInfoDic objectForKey:[NSValue valueWithNonretainedObject:layer]];
}

- (CCBalsamiqLayer *)getLayerFromBusinessType:(AGBusinessInfo *)info
{
    for (NSValue *layerValue in [layerAndInfoDic allKeys])
    {
        AGBusinessInfo *layerInfo = [layerAndInfoDic objectForKey:layerValue];
        if (info.type == layerInfo.type)
        {
            return [layerValue nonretainedObjectValue];
        }
    }
    
    return nil;
}

- (void)onGainTimeFinish:(CCBalsamiqLayer *)layer
{
    CCMenuItemButton *btnGain = [layer getControlByName:@"Gain"];
    
    [CCTimeManageNode stopCountDown:btnGain.label];
    btnGain.label.string = [self getLanguageString:@"8001"];
    
    
    CCAction *actionFlash = [CCRepeatForever actionWithAction:[CCSequence actions:
                                                               [CCTintTo actionWithDuration:0 red:200 green:200 blue:200],
                                                               [CCDelayTime actionWithDuration:0.2f],
                                                               [CCTintTo actionWithDuration:0 red:255 green:255 blue:255],
                                                               [CCDelayTime actionWithDuration:0.2f],
                                                               nil]];
    actionFlash.tag = TAG_FLASH_ACTION;
    
    [btnGain stopActionByTag:TAG_FLASH_ACTION];
    [btnGain runAction:actionFlash];
}

- (void)updateBusinessInfo:(AGBusinessInfo *)info toLayer:(CCBalsamiqLayer *)layer
{
    if (layer == nil)
    {
        return;
    }
    
    [[layer getControlByName:@"name"] setString:info.name];
    [[layer getControlByName:@"image_icon"] setTexture:
     [[CCTextureCache sharedTextureCache] addImage:[@"business" stringByAppendingPathComponent:info.imageName]]];
    [[layer getControlByName:@"level"] setString:
     [NSString stringWithFormat:@"%d", info.level]];
    [[layer getControlByName:@"gainCoins"] setString:
     [NSString stringWithFormat:@"%d + %d", info.gainCoins, info.increaseCoins]];
    [[layer getControlByName:@"servantCount"] setString:
     [NSString stringWithFormat:@"%d/%d", info.curCostServant, info.maxCostServant]];
    
    [[layer getControlByName:@"Up"] setVisible:!info.isMaxLevel];
    [[layer getControlByName:@"UpMax"] setVisible:info.isMaxLevel];
    
    if (info.canGain)
    {
        [self onGainTimeFinish:layer];
    }
    else
    {
        CCMenuItemButton *btnGain = [layer getControlByName:@"Gain"];
        
        [btnGain stopActionByTag:TAG_FLASH_ACTION];
        
        id action = [CCCallFuncO actionWithTarget:self
                                         selector:@selector(onGainTimeFinish:)
                                           object:layer];
        
        [CCTimeManageNode startCountDown:btnGain.label
                                timeLeft:info.curGainTime
                                isHHMMSS:YES
                          withStopAction:action];
    }
}

- (void)updateBusinessInfoWithBusinessType:(AGBusinessInfo *)info
{
    CCBalsamiqLayer *layer = [self getLayerFromBusinessType:info];
    [self updateBusinessInfo:info toLayer:layer];
    
    [layerAndInfoDic setObject:info forKey:[NSValue valueWithNonretainedObject:layer]];
    
    [self checkTotalGain];
}

#pragma mark -
#pragma mark Up confirm

- (void)onOkUpClick:(id)sender
{
    int type = [self levelLabelAtUpAlert].tag;
    int level = [[self levelLabelAtUpAlert].string intValue];
    
    //[CCAlertLayer removeAlertFromNode:sender];
    [self postUpBusiness:type level:level];
}

- (void)onCloseUpClick:(id)sender
{
    [self onCommonAlertCloseClick:sender];
}

- (CCLabelTTF *)levelLabelAtUpAlert
{
    return [alertUpBusiness.balsamiqLayer getControlByName:@"level"];
}

- (void)updateUpAlertData:(AGBusinessInfo *)businessInfo
{
    if (businessInfo.isMaxLevel)
    {
        return;
    }
    
    [[alertUpBusiness.balsamiqLayer getControlByName:@"name"] setString:businessInfo.name];
    [self levelLabelAtUpAlert].string = [NSString stringWithFormat:@"%d", businessInfo.level];
    [self levelLabelAtUpAlert].tag = businessInfo.type;
    
    [[alertUpBusiness.balsamiqLayer getControlByName:@"image_icon"] setTexture:
     [[CCTextureCache sharedTextureCache] addImage:[@"business" stringByAppendingPathComponent:businessInfo.imageName]]];
    
    [[alertUpBusiness.balsamiqLayer getControlByName:@"cost-time"] setString:
     [CCTimeManageNode timeStringWithHHMMSS:businessInfo.totalGainTime]];
    [[alertUpBusiness.balsamiqLayer getControlByName:@"cur-gain-coins"] setString:
     [NSString stringWithFormat:@"%d", businessInfo.gainCoins]];
    [[alertUpBusiness.balsamiqLayer getControlByName:@"up-cost"] setString:
     [NSString stringWithFormat:@"%d", businessInfo.upCost]];
    [[alertUpBusiness.balsamiqLayer getControlByName:@"next-gain"] setString:
     [NSString stringWithFormat:@"%d", businessInfo.nextGainCoins]];
}

- (void)onUpClick:(id)sender
{
    alertUpBusiness = [CCAlertLayer showAlert:@"8.4-up-confirm.bmml"
                                   parentNode:self];
    
    [self updateUpAlertData:[self getInfoFromLayer:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]]];
}

- (void)onUpMaxClick:(id)sender
{
    [self showSystemTip:[self getLanguageString:@"8002"]];
}

- (void)onGainClick:(id)sender
{
    AGBusinessInfo *info = [self getInfoFromLayer:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]];
    
    if (info.canGain)
    {
        [self postGainBusiness:info.type level:info.level];
    }
    else
    {
        [self openItemAlert:[self getLanguageString:@"2"] withType:@"c"];
        
        self.curSpeedUpBusinessInfo = [self getInfoFromLayer:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]];
    }
}

#pragma mark -
#pragma mark speed up

- (void)playSpeedEffect:(CCBalsamiqLayer *)layer
{
    CCSprite *sprSpeedUp = [layer getControlByName:@"image_speed_up"];
    [sprSpeedUp runAction:
     [CCSequence actions:
      [CCFadeIn actionWithDuration:0.1f],
      [CCMoveBy actionWithDuration:0.3f position:ccp(30, 0)],
      [CCFadeOut actionWithDuration:0.1f],
      [sprSpeedUp runAction:[CCMoveTo actionWithDuration:0 position:sprSpeedUp.position]],
      nil]];
}

- (BOOL)onUseItem:(int)itemId itemType:(NSString *)type
{
    if ([type isEqualToString:@"c"])
    {
        [self postSpeedUpBusiness:self.curSpeedUpBusinessInfo.type
                            level:self.curSpeedUpBusinessInfo.level
                           itemId:itemId];
        return YES;
    }
    
    return [super onUseItem:itemId itemType:type];
}

- (void)onProductionClick:(id)sender
{
    AGBusinessInfo *info = [self getInfoFromLayer:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]];
//    if (info.curCostServant == info.maxCostServant)
//    {
//        [self showSystemTip:@"Max send number"];
//        return;
//    }
    
    [[CCDirector sharedDirector] replaceScene:[BusinessIncreaseLayer sceneWithInfo:info]];
}

- (void)updateBusinessList:(NSArray *)businessList
{
    [[balsamiqLayer getControlByName:@"count"] setString:
     [NSString stringWithFormat:@"%d", businessList.count]];
    
    CCNode *cellContainer = [CCNode node];
    [layerAndInfoDic removeAllObjects];
    
    for (AGBusinessInfo *info in businessList)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"8.1-business-info.bmml"
                                                           eventHandle:self];
        cell.position = ccp(0, cell.contentSize.height * [businessList indexOfObject:info]);
        
        [cellContainer addChild:cell];
        [layerAndInfoDic setObject:info forKey:[NSValue valueWithNonretainedObject:cell]];
        
        CCSprite *sprSpeedUp = [cell getControlByName:@"image_speed_up"];
        sprSpeedUp.opacity = 0;
        
        CCMenuItemButton *btnGain = [cell getControlByName:@"Gain"];
        [btnGain.label changeToBlackArialFont];
        
        [self updateBusinessInfo:info toLayer:cell];
    }
    
    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
    
    [self checkTotalGain];
}

- (void)checkTotalGain
{
    int totalGain = 0;
    
    for (AGBusinessInfo *businessInfo in [layerAndInfoDic allValues])
    {
        if (businessInfo.canGain)
        {
            totalGain += (businessInfo.gainCoins + businessInfo.increaseCoins);
        }
    }
    
    [[balsamiqLayer getControlByName:@"total-coins"] setString:
     [NSString stringWithFormat:@"%d", totalGain]];
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_getBusinessList:(NSDictionary *)info
{
    NSArray *businessList = [AGBusinessInfo businessListFromInfo:info];
    [self updateBusinessList:businessList];
}

- (void)onReceiveInfoWithType_upBusiness:(NSDictionary *)info
{
    AGBusinessInfo *businessInfo = [AGBusinessInfo businessInfoFromCommercialInfo:info];
    [self postGetPlayerInfoRequest];
    
    [self updateBusinessInfoWithBusinessType:businessInfo];
    
    id actionScale = [CCSequence actions:
                      [CCScaleTo actionWithDuration:0.1f scale:1.3f],
                      [CCScaleTo actionWithDuration:0.1f scale:1],
                      [CCScaleTo actionWithDuration:0.1f scale:1.1f],
                      [CCScaleTo actionWithDuration:0.1f scale:1],
                      nil];
    
    if (businessInfo.isMaxLevel)
    {
        [self onUpMaxClick:nil];
        [CCAlertLayer removeAlertFromNode:alertUpBusiness];
        alertUpBusiness = nil;
        
        CCBalsamiqLayer *layer = [self getLayerFromBusinessType:businessInfo];
        [[layer getControlByName:@"UpMax"] runAction:actionScale];
    }
    else
    {
        [self updateUpAlertData:businessInfo];
        
        CCSprite *sprIcon = [alertUpBusiness.balsamiqLayer getControlByName:@"image_icon"];
        [sprIcon stopAllActions];
        [sprIcon runAction:actionScale];   
    }
}

- (void)onReceiveInfoWithType_gainBusiness:(NSDictionary *)info
{
    int totalGainCoins = [[info objectForKey:@"totalGainCoins"] intValue];
    AGBusinessInfo *businessInfo = [AGBusinessInfo businessInfoFromCommercialInfo:info];
    [self showGainEffect:totalGainCoins];
    [self updateBusinessInfoWithBusinessType:businessInfo];
    [self postGetPlayerInfoRequest];
}

- (void)onReceiveInfoWithType_speedGainBusiness:(NSDictionary *)info
{
    AGBusinessInfo *businessInfo = [AGBusinessInfo businessInfoFromCommercialInfo:info];
    [self playSpeedEffect:[self getLayerFromBusinessType:businessInfo]];
    [self updateBusinessInfoWithBusinessType:businessInfo];
}

@end
