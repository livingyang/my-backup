//
//  ServerApiListLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-17.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "ServerApiListLayer.h"
#import "ServerApiTestLayer.h"
#import "IntroLayer.h"

@implementation ServerApiListLayer

@synthesize apiListArray;

+ (CCScene *)scene
{
	CCScene *scene = [CCScene node];
	
	[scene addChild:[ServerApiListLayer node]];
	
	return scene;
}

- (NSString *)getMethodNameFromInfo:(NSDictionary *)dicInfo
{
    return [dicInfo objectForKey:@"method"];
}

- (NSDictionary *)getInfoDicFromMethodName:(NSString *)methodName
{
    for (NSDictionary *dic in self.apiListArray)
    {
        if ([methodName isEqualToString:[self getMethodNameFromInfo:dic]])
        {
            return dic;
        }
    }
    
    return nil;
}

- (void)onApiNameClick:(CCMenuItemFont *)item
{
    [[CCDirector sharedDirector] replaceScene:[ServerApiTestLayer sceneWithApiParams:
                                               [self getInfoDicFromMethodName:item.label.string]]];
}

- (void)loadApiList
{
    NSDictionary *apiLisDic = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle].resourcePath
                                                                          stringByAppendingPathComponent:@"ServerApiList.plist"]];
    
    self.apiListArray = [[apiLisDic allValues] objectAtIndex:0];
    
    CCMenu *menu = [CCMenu menuWithItems:nil];
    [self addChild:menu];
    
    for (NSDictionary *dic in self.apiListArray)
    {
        [menu addChild:[CCMenuItemFont itemFromString:[self getMethodNameFromInfo:dic]
                                               target:self
                                             selector:@selector(onApiNameClick:)]];
    }
    
    [menu alignItemsVertically];
}

#pragma mark -
#pragma mark 构造函数

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        [self loadApiList];
        
        CCMenu *menu = [CCMenu menuWithItems:[CCMenuItemFont itemFromString:@"Back"
                                                                      block:^(id sender) {
                                                                          [[CCDirector sharedDirector] replaceScene:[IntroLayer scene]];
                                                                      }],
                        nil];
        menu.position = ccpAdd(menu.position, ccp(-120, 220));
        [self addChild:menu];
    }
    
    return self;
}

- (void)dealloc
{
    self.apiListArray = nil;
    
    [super dealloc];
}

@end
