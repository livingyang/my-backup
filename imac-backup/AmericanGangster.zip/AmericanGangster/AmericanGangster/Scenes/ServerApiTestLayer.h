//
//  ServerApiTestLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-16.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@interface ServerApiTestLayer : BaseLayer <UITextFieldDelegate>
{
    
}

@property (nonatomic, retain) NSMutableDictionary *apiParams;
@property (nonatomic, assign) CCMenuItemFont *selectedLabel;

+ (CCScene *)sceneWithApiParams:(NSDictionary *)params;

@end
