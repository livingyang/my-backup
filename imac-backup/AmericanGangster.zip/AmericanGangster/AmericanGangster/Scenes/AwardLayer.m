//
//  AwardLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-9.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "AwardLayer.h"
#import "CCBalsamiqLayer.h"
#import "HomeLayer.h"
#import "AGLoginInfo.h"
#import "AGStoreItemInfoCache.h"
#import "AGStoreItemInfo.h"
#import "AGShopItemInfo.h"
#import "AGAwardInfo.h"
#import "CCLabelTTF+ChangeFont.h"
#import "CCTouchCatchNode.h"

#define IMAGE_EXP @"UI/1-login/img-award-exp.png"
#define IMAGE_COIN @"UI/1-login/img-award-coin.png"

#define TIME_ROTATE (0.2f)

@implementation AwardLayer

- (CCBalsamiqLayer *)createLayerFromAwardItem:(AGAwardItemInfo *)awardItem
{
    if ([@"coin" isEqualToString:awardItem.itemName])
    {
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"1.6.1-award-coin.bmml"
                                                            eventHandle:self];
        [[layer getControlByName:@"num"] setString:[NSString stringWithFormat:@"%d", awardItem.num]];
        [[layer getControlByName:@"num"] changeToBlackArialFont];
        return layer;
    }
    else if ([@"exp" isEqualToString:awardItem.itemName])
    {
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"1.6.2-award-exp.bmml"
                                                            eventHandle:self];
        [[layer getControlByName:@"num"] setString:[NSString stringWithFormat:@"%d", awardItem.num]];
        [[layer getControlByName:@"num"] changeToBlackArialFont];
        return layer;
    }
    else if ([@"card" isEqualToString:awardItem.itemName])
    {
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"1.6.3-award-card.bmml"
                                                            eventHandle:self];
        
        AGCardInfo *cardInfo = [[AGCardInfoCache instance] getCardInfoById:awardItem.num];
        
        [[layer getControlByName:@"image_card"] setTexture:
         [[CCTextureCache sharedTextureCache] addImage:[@"card" stringByAppendingPathComponent:cardInfo.imageName]]];

        [[layer getControlByName:@"name"] setString:cardInfo.name];
        return layer;
    }
    else if ([@"item" isEqualToString:awardItem.itemName])
    {
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"1.6.4-award-weapon.bmml"
                                                            eventHandle:self];
        
        AGStoreItemInfo *itemInfo = [[AGStoreItemInfoCache instance] getItemInfoFromEquipId:awardItem.num];
        [itemInfo updateDataToLayer:layer];
        return layer;
    }
    
    CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"1.6.3-award-card.bmml"
                                                        eventHandle:self];
    [[layer getControlByName:@"name"] setString:awardItem.itemName];
    return layer;
}

- (CCMenuItemImage *)getGridWithIndex:(int)lastAwardIndex
{
    return [balsamiqLayer getControlByName:[NSString stringWithFormat:@"Grid%d", lastAwardIndex + 1]];
}

- (void)updateAwardCount:(AGAwardInfo *)info
{
    // 更新今日数量
    for (int i = 1; i <= 3; ++i)
    {
        CCSprite *sprCount = [balsamiqLayer getControlByName:[NSString stringWithFormat:@"image_count%d", i]];
        
        sprCount.visible = (info.curAwardCount >= i);
    }
}

- (void)updateLastAwardInfo:(AGAwardInfo *)info
{
    [self updateAwardCount:info];
    
    [self openGrid:[self getGridWithIndex:info.lastUpdatedItemIndex]
          withItem:[info.itemArray objectAtIndex:info.lastUpdatedItemIndex]
          isOpened:YES];
    
    if (![AGAwardInfo instance].needsAward)
    {
        [self performSelector:@selector(openOtherGrid) withObject:nil afterDelay:1.5f];
    }
}

- (void)loadAwardInfo:(AGAwardInfo *)info
{
    [self updateAwardCount:info];
    [[balsamiqLayer getControlByName:@"PlayGame"] setVisible:!info.needsAward];
    
    // 更新物品
    for (int i = 0; i < 9; ++i)
    {
        AGAwardItemInfo *item = [info.itemArray objectAtIndex:i];
        if (item.isOpened)
        {
            CCBalsamiqLayer *layer = [self createLayerFromAwardItem:item];
            CCMenuItemImage *grid = [self getGridWithIndex:i];
            
            [self changeGridToBg:grid];
            [grid addChild:layer];
        }
    }
}

- (CCBalsamiqLayer *)getGridLayerFromIndex:(int)index
{
    return [balsamiqLayer getControlByName:[NSString stringWithFormat:@"item%d", index + 1]];
}

- (void)openOtherGrid
{
    for (int i = 0; i < [AGAwardInfo instance].itemArray.count; ++i)
    {
        AGAwardItemInfo *item = [[AGAwardInfo instance].itemArray objectAtIndex:i];
        
        if (!item.isOpened)
        {
            [self openGrid:[self getGridWithIndex:i]
                  withItem:item
                  isOpened:NO];
        }
    }
    
    // show PlayGame button
    CCMenuItem *btnPlayGame = [balsamiqLayer getControlByName:@"PlayGame"];
    [self runAction:[CCSequence actions:
                     [CCDelayTime actionWithDuration:1.5f],
                     [CCCallFuncO actionWithTarget:btnPlayGame.parent selector:@selector(addChild:) object:btnPlayGame],
                     nil]];
    
    [btnPlayGame removeFromParentAndCleanup:YES];
    btnPlayGame.visible = YES;
    
    [[balsamiqLayer getControlByName:@"detail"] setVisible:NO];
}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"1.5-award.bmml"
                                                   eventHandle:self];
        
        [self addChild:balsamiqLayer];
        
        sprGridBg = [balsamiqLayer getControlByName:@"image_grid_bg"];
        sprGridMask = [balsamiqLayer getControlByName:@"image_grid_mask"];
        sprGridGray = [balsamiqLayer getControlByName:@"image_grid_gray"];
        
//        self.toolLayer = [balsamiqLayer getControlByName:@"tool-bar"];
//        [self.toolLayer addChild:[CCTouchCatchNode nodeWithCatchTarget:self.toolLayer]];
        
        [self postGetPlayerInfoRequest];
        
        [self loadAwardInfo:[AGAwardInfo instance]];
    }
    
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)onPlayGameClick:(id)sender
{
    [[CCDirector sharedDirector] replaceScene:[HomeLayer scene]];
}

- (void)changeGridToMask:(CCMenuItemImage *)grid
{
    ((CCSprite *)grid.normalImage).texture = sprGridMask.texture;
}

- (void)changeGridToBg:(CCMenuItemImage *)grid
{
    ((CCSprite *)grid.normalImage).texture = sprGridBg.texture;
}

- (void)onGridActionDone:(CCMenuItemImage *)grid
{
    NSLog(@"onGridActionDone");
    CCSprite *normalSprite = (CCSprite *)grid.normalImage;
    
    //grid.selectedImage = [CCSprite spriteWithTexture:normalSprite.texture];
    grid.disabledImage = [CCSprite spriteWithTexture:normalSprite.texture];
    grid.isEnabled = NO;
    
    isGridOpenning = NO;
}

- (void)openGrid:(CCMenuItemImage *)grid
        withItem:(AGAwardItemInfo *)item
        isOpened:(BOOL)isOpened
{
    CCBalsamiqLayer *layer = [self createLayerFromAwardItem:item];
    
    id action = [CCSequence actions:
                 [CCScaleTo actionWithDuration:TIME_ROTATE scaleX:0 scaleY:1],
                 [CCCallFuncO actionWithTarget:self selector:@selector(changeGridToBg:) object:grid],
                 [CCScaleTo actionWithDuration:TIME_ROTATE scaleX:1 scaleY:1],
                 [CCScaleTo actionWithDuration:TIME_ROTATE scaleX:0 scaleY:1],
                 [CCCallFuncO actionWithTarget:self selector:@selector(changeGridToMask:) object:grid],
                 [CCScaleTo actionWithDuration:TIME_ROTATE scaleX:1 scaleY:1],
                 [CCScaleTo actionWithDuration:TIME_ROTATE scaleX:0 scaleY:1],
                 [CCCallFuncO actionWithTarget:self selector:@selector(changeGridToBg:) object:grid],
                 [CCScaleTo actionWithDuration:TIME_ROTATE scaleX:1 scaleY:1],
                 [CCCallFuncO actionWithTarget:self selector:@selector(onGridActionDone:) object:grid],
                 [CCCallFuncO actionWithTarget:grid selector:@selector(addChild:) object:layer],
                 nil];
    
    if (!isOpened)
    {
        CCSprite *sprGray = [CCSprite spriteWithTexture:sprGridGray.texture];
        sprGray.anchorPoint = CGPointZero;
        action = [CCSequence actions:action,
                  [CCCallFuncO actionWithTarget:grid selector:@selector(addChild:) object:sprGray],
                  nil];
    }
    
    [grid runAction:action];
}

- (void)onGridClick:(int)gridIndex
{
    if (isGridOpenning == YES)
    {
        return;
    }
    isGridOpenning = YES;
    
    if ([AGAwardInfo instance].needsAward == NO
        || [[[AGAwardInfo instance].itemArray objectAtIndex:gridIndex] isOpened])
    {
        return;
    }
    
    [self postGetDayAwardsRequest:gridIndex];
}

- (void)onGrid1Click:(id)sender
{
    [self onGridClick:0];
}

- (void)onGrid2Click:(id)sender
{
    [self onGridClick:1];
}

- (void)onGrid3Click:(id)sender
{
    [self onGridClick:2];
}

- (void)onGrid4Click:(id)sender
{
    [self onGridClick:3];
}

- (void)onGrid5Click:(id)sender
{
    [self onGridClick:4];
}

- (void)onGrid6Click:(id)sender
{
    [self onGridClick:5];
}

- (void)onGrid7Click:(id)sender
{
    [self onGridClick:6];
}

- (void)onGrid8Click:(id)sender
{
    [self onGridClick:7];
}

- (void)onGrid9Click:(id)sender
{
    [self onGridClick:8];
}
#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_getDayAwards:(NSDictionary *)info
{
    [[AGAwardInfo instance] updateAwardInfoFromInfo:info];
    
    [self updateLastAwardInfo:[AGAwardInfo instance]];
}

@end
