//
//  HomeLayer.m
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-4-27.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "HomeLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCAlertLayer.h"
#import "IntroLayer.h"
#import "StoreLayer.h"
#import "PackLayer.h"
#import "GangsterLayer.h"
#import "AGPlayerInfo.h"
#import "AttackLayer.h"
#import "MissionLayer.h"
#import "RefineLayer.h"
#import "BusinessLayer.h"
#import "ItemLayer.h"
#import "ArenaLayer.h"
#import "SettingLayer.h"
#import "MessageLayer.h"
#import "CharacterImageManager.h"
#import "PlayerTypeManager.h"
#import "CCLabelTTF+ChangeFont.h"
#import "GuideEventHandle.h"
#import "AGStoreItemInfoCache.h"
#import "AGStoreItemInfo.h"
#import "GuideLayer.h"
#import "AGBusinessInfo.h"
#import "AGMessageInfo.h"
#import "AnnounceLayer.h"

@implementation HomeLayer

- (void)onEnter
{
    [super onEnter];
    
    if ([AGAnnounceCache instance].hasDisplayed == NO)
    {
        [[CCDirector sharedDirector] replaceScene:[AnnounceLayer scene]];
        return;
    }
    
    [self.toolLayer selectRadioItem:@"radio_Tool_home"];
    
    [self postGetBusinessList];
    [self postGetPlayerInfoRequest];
}

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        homeBalsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"2-home.bmml"
                                                       eventHandle:self];
        [self addChild:homeBalsamiqLayer];
        homeBalsamiqLayer.visible = NO;
        
        self.headerLayer = [homeBalsamiqLayer getControlByName:@"header-property"];
        self.toolLayer = [homeBalsamiqLayer getControlByName:@"tool-bar"];
    }
    
    return self;
}

- (void)dealloc
{
	[super dealloc];
}

- (void)onMessageClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[MessageLayer scene]];
}

- (void)onSettingClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[SettingLayer scene]];
}

- (void)onStoreClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[StoreLayer scene]];
}

- (void)onPackClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[PackLayer sceneWithEquipmentType:1]];
}

- (void)onGangsterClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[GangsterLayer scene]];
}

- (void)onBattleClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[AttackLayer scene]];
}

- (void)onMissionClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[MissionLayer scene]];
}

- (void)onRefineClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[RefineLayer scene]];
}

- (void)onBusinessClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[BusinessLayer scene]];    
}

- (void)onItemClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[ItemLayer sceneWithTab:0]];    
}

- (void)onArenaClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    if ([AGPlayerInfo defaultPlayerInfo].isArenaOpen == NO)
    {
        [self showSystemTip:@"Open at 30 level"];
        return;
    }
    
    [[CCDirector sharedDirector] replaceScene:[ArenaLayer scene]];    
}

#pragma mark -
#pragma mark Receive info handle

- (void)updatePlayerInfo:(AGPlayerInfo *)playerinfo toLayer:(CCBalsamiqLayer *)layer
{
    homeBalsamiqLayer.visible = YES;
    
    [[homeBalsamiqLayer getControlByName:@"name"] setString:playerinfo.name];
    [[homeBalsamiqLayer getControlByName:@"name"] changeToBlackArialFont];
    [[homeBalsamiqLayer getControlByName:@"title"] setString:playerinfo.title];
    [[homeBalsamiqLayer getControlByName:@"type"] setString:[PlayerTypeManager getTypeStringFromValue:playerinfo.type]];
    [[homeBalsamiqLayer getControlByName:@"employ-count"] setString:
     [NSString stringWithFormat:@"%d/%d", playerinfo.curServantCount, playerinfo.maxServantCount]];
    
    CCSprite *sprite = [homeBalsamiqLayer getControlByName:@"image_player"];
    CCTexture2D *playerImage = [[CharacterImageManager instance] getTextureFromImageName:playerinfo.imageName];
    [sprite setTexture:playerImage];
    [sprite setTextureRect:(CGRect){CGPointZero, {playerImage.contentSize.width, playerImage.contentSize.height / 2.1f}}];
}

- (void)onReceiveInfoWithType_getPlayerInfo:(NSDictionary *)info
{
    [super onReceiveInfoWithType_getPlayerInfo:info];

    [self updatePlayerInfo:[AGPlayerInfo defaultPlayerInfo] toLayer:homeBalsamiqLayer];
    
    [self onEventHappened:@"IntoHome"];
    
    if ([AGPlayerInfo defaultPlayerInfo].isClearNewbieMission == NO &&
        [GuideEventHandle instance].isClearGuideEvent)
    {
        [self postClearGuideMission];
    }
}

- (void)onReceiveInfoWithType_clearGuideMission:(NSDictionary *)info
{
    int dollars = [[info objectForKey:@"dollars"] intValue];
    AGStoreItemInfo *item1 = [[AGStoreItemInfoCache instance] getItemInfoFromEquipId:
                              [[info objectForKey:@"item1"] intValue]];
    AGStoreItemInfo *item2 = [[AGStoreItemInfoCache instance] getItemInfoFromEquipId:
                              [[info objectForKey:@"item2"] intValue]];
    
    CCAlertLayer *giftAlert = [CCAlertLayer showAlert:@"2.1-gift-alert.bmml"
                                           parentNode:self];
    
    [[giftAlert.balsamiqLayer getControlByName:@"dollar"] setString:
     [NSString stringWithFormat:@"%d", dollars]];
    [[giftAlert.balsamiqLayer getControlByName:@"lab-dollar"] changeToBlackArialFont];
    
    [item1 updateDataToLayer:[giftAlert.balsamiqLayer getControlByName:@"item1"]];
    [item2 updateDataToLayer:[giftAlert.balsamiqLayer getControlByName:@"item2"]];
    
    if ([AGPlayerInfo defaultPlayerInfo].isMan)
    {
        [GuideLayer changeSpriteImageToWoman:[giftAlert.balsamiqLayer getControlByName:@"image_friend"]];
    }
    
    [self postGetPlayerInfoRequest];
}

- (void)onReceiveInfoWithType_getBusinessList:(NSDictionary *)info
{
    int gainBusinessCount = [AGBusinessInfo getCountOfGainBusiness:[AGBusinessInfo businessListFromInfo:info]];
    if (gainBusinessCount > 0)
    {
        [[homeBalsamiqLayer getControlByName:@"gain-business-count"] setString:
         [NSString stringWithFormat:@"%d", gainBusinessCount]];
    }
    else
    {
        [[homeBalsamiqLayer getControlByName:@"gain-business-count"] setString:@""];
        [[homeBalsamiqLayer getControlByName:@"image_count"] setVisible:NO];
    }
}

@end
