//
//  StoreLayer.m
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-5-5.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "StoreLayer.h"
#import "CCBalsamiqLayer.h"
#import "HomeLayer.h"
#import "CCTableLayer.h"
#import "AGStoreItemInfo.h"
#import "AGStoreItemInfoCache.h"
#import "CCAlertLayer.h"

#define COUNT_OF_MORE_ITEM (3)

@implementation StoreLayer

@synthesize tableLayer;
@synthesize weaponItemArray;

- (void)updateItems:(NSString *)radioItemName
{
    NSDictionary *itemNameAndListKindDic = [NSDictionary dictionaryWithObjectsAndKeys:
                                            @"1", @"radio_kind_knife",
                                            @"2", @"radio_kind_gun",
                                            @"3", @"radio_kind_car",
                                            @"4", @"radio_kind_armor",
                                            nil];
    
    [self updateTableLayer:[[AGStoreItemInfoCache instance] getItemInfoFromType:[[itemNameAndListKindDic objectForKey:radioItemName] intValue]
                                                                    playerLevel:[AGPlayerInfo defaultPlayerInfo].level]];
}

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"9-store.bmml"
                                                            eventHandle:self];
        [self addChild:layer];
        
        self.tableLayer = [layer getControlByName:@"table"];
        
        [layer selectRadioItem:@"radio_kind_knife"];
        [self updateItems:@"radio_kind_knife"];
        
        self.headerLayer = [layer getControlByName:@"header-property"];
        self.toolLayer = [layer getControlByName:@"tool-bar"];
    }
    
    return self;
}

- (void)dealloc
{
    self.weaponItemArray = nil;
    
	[super dealloc];
}

- (void)onEnter
{
    [super onEnter];
    
    [self onEventHappened:@"IntoStore"];
}

- (void)updateTableLayer:(NSArray *)weaponArray
{
    if (weaponArray.count == 0)
    {
        return;
    }
    
    self.weaponItemArray = weaponArray;
    
    CCNode *cellContainer = [CCNode node];
    
    CCBalsamiqLayer *moreLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"9.3-more.bmml"
                                                            eventHandle:self];
    moreLayer.position = ccp(0, 0);
    [cellContainer addChild:moreLayer];
    
    [[moreLayer getControlByName:@"More"] setTag:0];

    [self.tableLayer setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
    
    [self updateItemByMoreLayer:moreLayer];
}

- (void)onBuyClick:(id)sender
{
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"9.2-buy-confirm.bmml"
                                       parentNode:self];
    
    int itemId = [sender tag];
    
    [[[AGStoreItemInfoCache instance] getItemInfoFromEquipId:itemId] updateDataToLayer:alert.balsamiqLayer];
    [[alert.balsamiqLayer getControlByName:@"Ok"] setTag:itemId];
    
    [self onEventHappened:@"ShowBuyConfirm"];
}

- (void)onCancelClick:(id)sender
{
    [self onCommonAlertCloseClick:sender];
}

- (void)onOkClick:(id)sender
{
    [self onCommonAlertOkClick:sender];
    
    [self postBuyItemRequest:[sender tag]];
}

#pragma mark -
#pragma mark more control

- (void)updateItemByMoreLayer:(CCBalsamiqLayer *)moreLayer
{
    CCMenuItem *btnMore = [moreLayer getControlByName:@"More"];
    int startItemIndex = btnMore.tag;
    
    for (int curItemIndex = startItemIndex;
         curItemIndex < startItemIndex + COUNT_OF_MORE_ITEM;
         ++curItemIndex)
    {
        AGStoreItemInfo *item = [self.weaponItemArray objectAtIndex:self.weaponItemArray.count - 1 - curItemIndex];
        
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"9.1-item.bmml"
                                                           eventHandle:self];
        cell.position = moreLayer.position;
        moreLayer.position = ccp(moreLayer.position.x, moreLayer.position.y - cell.contentSize.height);
        [self.tableLayer.cellContainer addChild:cell];
        
        [item updateDataToLayer:cell];
        
        [[cell getControlByName:@"Buy"] setTag:item.itemId];
        btnMore.tag = curItemIndex + 1;
        
        if (curItemIndex == self.weaponItemArray.count - 1)
        {
            [self.tableLayer.cellContainer removeChild:moreLayer cleanup:YES];
            break;
        }
    }
    
    [self.tableLayer resetMaxDistance];
}

- (void)onMoreClick:(id)sender
{
    [self updateItemByMoreLayer:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]];
}

#pragma mark -
#pragma mark Radio handler

- (void)onkindRadioSelected:(NSString *)radioItemName
{
    [self updateItems:radioItemName];
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_buyStoreGoods:(NSDictionary *)info
{
    [self showSystemTip:[self getLanguageString:@"9001"]];
    
    [self postGetPlayerInfoRequest];
    
    [self onEventHappened:@"BuySuccess"];
}

//- (void)onReceiveInfoWithType_buyStoreGoods_err:(NSDictionary *)info
//{
//    [[[[UIAlertView alloc] initWithTitle:@"buyStoreGoods_err"
//                                 message:[info objectForKey:@"msg"]
//                                delegate:nil
//                       cancelButtonTitle:@"OK"
//                       otherButtonTitles:nil] autorelease] show];
//}

@end
