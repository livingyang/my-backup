//
//  BusinessLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-11.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@class CCBalsamiqLayer;
@class CCAlertLayer;
@class AGBusinessInfo;
@interface BusinessLayer : BaseLayer
{
    CCBalsamiqLayer *balsamiqLayer;
    
    CCAlertLayer *alertUpBusiness;
    
    NSMutableDictionary *layerAndInfoDic;
}

@property (nonatomic, assign) AGBusinessInfo *curSpeedUpBusinessInfo;

@end
