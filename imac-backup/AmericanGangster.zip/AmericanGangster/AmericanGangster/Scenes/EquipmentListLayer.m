//
//  EquipmentListLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-30.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "EquipmentListLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCTableLayer.h"
#import "GangsterLayer.h"
#import "AGEquipmentInfo.h"
#import "CharacterImageManager.h"
#import "AGStoreItemInfo.h"

#define COUNT_OF_SERVANT_EQUIPMENT (10)

@interface EquipmentListLayer (Private)

- (void)loadEquipmentListFromPos:(int)pos withServantId:(int)servantId;

@end

@implementation EquipmentListLayer

@synthesize equipmentList;

+ (CCScene *)sceneWithPos:(int)equipmentPos withServantId:(int)servantId
{
    CCScene *scene = [CCScene node];
    
    EquipmentListLayer *layer = [EquipmentListLayer node];
    [layer loadEquipmentListFromPos:equipmentPos withServantId:servantId];
    [scene addChild:layer];
    return scene;
}

- (void)loadEquipmentListFromPos:(int)pos withServantId:(int)servantId
{
    equipmentPos_ = pos;
    servantId_ = servantId;
    
    [self postGetEquipmentListFromPosRequest:pos];
}

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"5.6-equipment-list.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        selectedToggle = nil;
        
        self.headerLayer = [balsamiqLayer getControlByName:@"header-property"];
    }
    
    return self;
}

- (void)dealloc
{
    self.equipmentList = nil;
    
    [super dealloc];
}

- (void)onBackClick:(id)sender
{
    [[CCDirector sharedDirector] replaceScene:[GangsterLayer sceneWithSelectServantHeaderIndex:lastSelectServantHeaderIndex]];
}

- (CCBalsamiqLayer *)selectedLayer
{
    if (selectedToggle == nil)
    {
        return nil;
    }
    
    id layerParent = selectedToggle;
    while ([layerParent class] != [CCBalsamiqLayer class])
    {
        if ([layerParent parent] == nil)
        {
            return nil;
        }
        
        layerParent = [layerParent parent];
    }
    
    return layerParent;
}

- (void)onOkClick:(id)sender
{
    CCBalsamiqLayer *selectLayer = [self selectedLayer];
    if (selectLayer != nil)
    {
        int equipmentId = [[selectLayer getControlByName:@"image_icon"] tag];
        NSLog(@"select equipment id = %d", equipmentId);
        
        [self postChangeEquipment:equipmentId servantId:servantId_ pos:equipmentPos_];
    }
}

- (void)onClick_toggle_ok:(CCMenuItemToggle *)toggle
{
    if (toggle == selectedToggle)
    {
        selectedToggle = nil;
        
        [[SoundManager instance] playEffectCheckUnselect];
    }
    else
    {
        selectedToggle.selectedIndex = 0;
        selectedToggle = toggle;
        
        [[SoundManager instance] playEffectCheckSelect];
    }
    
    [self onEventHappened:@"SelectEquipment"];
}

- (void)updateEquipmentList:(NSArray *)equipmentArray
{
    [[balsamiqLayer getControlByName:@"count"] setString:[NSString stringWithFormat:@"%d", equipmentArray.count]];
    
    if (equipmentArray.count == 0)
    {
        CCNode *cellContainer = [CCNode node];
        [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
        return;
    }
    
    CCNode *cellContainer = [CCNode node];
    
    CCBalsamiqLayer *moreLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"5.8-more.bmml"
                                                            eventHandle:self];
    moreLayer.position = ccp(0, 0);
    [cellContainer addChild:moreLayer];
    
    [[moreLayer getControlByName:@"More"] setTag:0];
    
    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
    
    [self updateItemByMoreLayer:moreLayer];
//    return;
//    if (equipmentArray.count == 0)
//    {
//        CCNode *cellContainer = [CCNode node];
//        [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
//        return;
//    }
//    
//    CCNode *cellContainer = [CCNode node];
//    
//    for (AGPackItemInfo *equipmentInfo in equipmentArray)
//    {
//        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"5.7-equipment-list-info.bmml"
//                                                            eventHandle:self];
//        layer.position = ccp(0, [equipmentArray indexOfObject:equipmentInfo] * layer.contentSize.height);
//        [cellContainer addChild:layer];   
//        
//        CCSprite *header = [layer getControlByName:@"image_icon"];
//        header.tag = equipmentInfo.uniqueId;
//        
//        [equipmentInfo updateDataToLayer:layer];
//    }
//    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

- (void)updateItemByMoreLayer:(CCBalsamiqLayer *)moreLayer
{
    CCMenuItem *btnMore = [moreLayer getControlByName:@"More"];
    int startItemIndex = btnMore.tag;
    
    CCTableLayer *tableLayer = [balsamiqLayer getControlByName:@"table"];
    
    for (int curItemIndex = startItemIndex;
         curItemIndex < startItemIndex + COUNT_OF_SERVANT_EQUIPMENT;
         ++curItemIndex)
    {
        AGEquipmentInfo *equipmentInfo = [self.equipmentList objectAtIndex:self.equipmentList.count - 1 - curItemIndex];
        
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"5.7-equipment-list-info.bmml"
                                                           eventHandle:self];
        cell.position = moreLayer.position;
        moreLayer.position = ccp(moreLayer.position.x, moreLayer.position.y - cell.contentSize.height);
        [tableLayer.cellContainer addChild:cell];
        
        
        CCSprite *header = [cell getControlByName:@"image_icon"];
        header.tag = equipmentInfo.uniqueId;
        
        [equipmentInfo updateDataToLayer:cell];
        
        btnMore.tag = curItemIndex + 1;
        
        if (curItemIndex == self.equipmentList.count - 1)
        {
            [tableLayer.cellContainer removeChild:moreLayer cleanup:YES];
            break;
        }
    }
    
    [tableLayer resetMaxDistance];
}

- (void)onMoreClick:(id)sender
{
    [self updateItemByMoreLayer:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]];
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_getEquipmentListFromPos:(NSDictionary *)info
{
    self.equipmentList = [AGEquipmentInfo getIsNotUsingPackItemList:[AGEquipmentInfo equipmentInfoFromDictionaryInfo:info]];
    [self updateEquipmentList:self.equipmentList];
    
    [self onEventHappened:@"ShowEquipmentList"];
}

- (void)onReceiveInfoWithType_changeServantEquip:(NSDictionary *)info
{
    [[CCDirector sharedDirector] replaceScene:[GangsterLayer sceneWithSelectServantHeaderIndex:lastSelectServantHeaderIndex]];
}

@end
