//
//  ServerApiListLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-17.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface ServerApiListLayer : CCLayer {
    
}

@property (nonatomic, retain) NSArray *apiListArray;

+ (CCScene *)scene;

@end
