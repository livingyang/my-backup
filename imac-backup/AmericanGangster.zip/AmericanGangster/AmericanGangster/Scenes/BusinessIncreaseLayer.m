//
//  BusinessIncreaseLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-13.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "BusinessIncreaseLayer.h"
#import "CCBalsamiqLayer.h"
#import "AGBusinessInfo.h"
#import "BusinessLayer.h"
#import "CCTableLayer.h"
#import "AGServantInfo.h"
#import "CharacterImageManager.h"
#import "BalsamiqReaderConfig.h"
#import "CCTouchCatchNode.h"

@implementation BusinessIncreaseLayer

@synthesize businessInfo;

+ (CCScene *)sceneWithInfo:(AGBusinessInfo *)info
{
    BusinessIncreaseLayer *layer = [BusinessIncreaseLayer node];
    [layer loadBusinessInfo:info];
    
    CCScene *scene = [CCScene node];
    [scene addChild:layer];
    
    return scene;
}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        layerAndServantInfoDic = [[NSMutableDictionary alloc] init];
        
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"8.2-increase-business.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        self.headerLayer = [balsamiqLayer getControlByName:@"header-property"];
        
        CCSprite *sprMask = [balsamiqLayer getControlByName:@"image_mask"];
        sprMask.opacity = 150;
        
        self.labHasDetail.visible = NO;
        self.labNoDetail.visible = NO;
        self.btnDispatch.visible = NO;
        self.btnBattle.visible = NO;
    }
    
    return self;
}

- (void)dealloc
{
    [layerAndServantInfoDic release];
    self.businessInfo = nil;
    
    [super dealloc];
}

- (CCLabelTTF *)labHasDetail
{
    return [balsamiqLayer getControlByName:@"detail-has-servant"];
}

- (CCLabelTTF *)labNoDetail
{
    return [balsamiqLayer getControlByName:@"detail-no-servant"];
}

- (CCMenuItemImage *)btnDispatch
{
    return [balsamiqLayer getControlByName:@"Send"];
}

- (CCMenuItemImage *)btnBattle
{
    return [balsamiqLayer getControlByName:@"Battle"];
}

- (int)curSelectServantCount
{
    int count = 0;
    for (NSValue *value in [layerAndServantInfoDic allKeys])
    {
        CCBalsamiqLayer *layer = [value nonretainedObjectValue];
        CCMenuItemToggle *toggle = [layer getControlByName:@"toggle_ok"];
        
        if (toggle.selectedIndex == 1)
        {
            ++count;
        }
    }
    
    return count;
}

- (void)setServantCount:(int)curCount maxCount:(int)maxCount
{
    [[balsamiqLayer getControlByName:@"send-number"] setString:
     [NSString stringWithFormat:@"%d/%d", curCount, maxCount]];
}

- (void)loadBusinessInfo:(AGBusinessInfo *)info
{
    self.businessInfo = info;
    
    [[balsamiqLayer getControlByName:@"name"] setString:info.name];
    [[balsamiqLayer getControlByName:@"level"] setString:
     [NSString stringWithFormat:@"%d", info.level]];
    
    [[balsamiqLayer getControlByName:@"image_icon"] setTexture:
     [[CCTextureCache sharedTextureCache] addImage:[@"business" stringByAppendingPathComponent:businessInfo.imageName]]];
    
    [[balsamiqLayer getControlByName:@"cur-gain-coins"] setString:
     [NSString stringWithFormat:@"%d + %d", info.gainCoins, info.increaseCoins]];
    [[balsamiqLayer getControlByName:@"increase-gain"] setString:@"0"];
    [self setServantCount:info.curCostServant maxCount:info.maxCostServant];

    [self postGetMyServantList];
}

- (void)onCloseClick:(id)sender
{
    [self onBackClick:nil];
}

- (void)onBackClick:(id)sender
{
    [[CCDirector sharedDirector] replaceScene:[BusinessLayer scene]];
    
    [[SoundManager instance] playEffectButtonBack];
}

- (void)onSendClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    NSMutableString *servantList = [NSMutableString string];
    
    for (NSValue *value in [layerAndServantInfoDic allKeys])
    {
        CCBalsamiqLayer *layer = [value nonretainedObjectValue];
        AGServantInfo *servantInfo = [layerAndServantInfoDic objectForKey:value];
        
        CCMenuItemToggle *toggle = [layer getControlByName:@"toggle_ok"];
        
        if (toggle.selectedIndex == 1)
        {
            [servantList appendFormat:@"%d,", servantInfo.servantId];
        }
    }
    
    if (servantList.length == 0)
    {
        [self showSystemTip:@"Please select servants."];
    }
    else
    {
        [self postIncreaseBusiness:self.businessInfo.type
                             level:self.businessInfo.level
                       servantList:[servantList substringToIndex:servantList.length - 1]];
        
        [self playIncreaseEffect];
    }
}

- (void)onBattleClick:(id)sender
{
    [self onSelect_radio_Tool_battle:nil];
}

- (void)onClick_toggle_ok:(CCMenuItemToggle *)toggle
{
    if (toggle.selectedIndex == 1
        && (self.curSelectServantCount > self.businessInfo.maxCanSendServantCount))
    {
        toggle.selectedIndex = 0;
        [self showSystemTip:[self getLanguageString:@"8003"]];
        
//        CGPoint offsetPos = ccp(10, 0);
        CCBalsamiqLayer *layer = [CCBalsamiqLayer getBalsamiqLayerFromChild:toggle];
        
        CCTouchCatchNode *catchNode = [CCTouchCatchNode nodeWithCatchTarget:self];
        [layer addChild:catchNode];
        
        [layer stopAllActions];
        [layer runAction:[CCSequence actions:
                          [CCMoveBy actionWithDuration:0.1f position:ccp(5, 0)],
                          [CCMoveBy actionWithDuration:0.1f position:ccp(-10, 0)],
                          [CCMoveBy actionWithDuration:0.1f position:ccp(10, 0)],
                          [CCMoveBy actionWithDuration:0.1f position:ccp(-5, 0)],
                          [CCCallFunc actionWithTarget:catchNode selector:@selector(removeFromParentAndCleanup:)],
                          nil]];
        return;
    }
    
    int totalIncreaseCoins = 0;
    for (NSValue *value in [layerAndServantInfoDic allKeys])
    {
        CCBalsamiqLayer *layer = [value nonretainedObjectValue];
        AGServantInfo *servantInfo = [layerAndServantInfoDic objectForKey:value];
        
        CCMenuItemToggle *toggle = [layer getControlByName:@"toggle_ok"];
        NSLog(@"servant id = %d, toggle index = %d", servantInfo.servantId, toggle.selectedIndex);
        
        if (toggle.selectedIndex == 1)
        {
            totalIncreaseCoins += servantInfo.increaseCoins;
        }
    }
    
    [[balsamiqLayer getControlByName:@"increase-gain"] setString:[NSString stringWithFormat:@"%d", totalIncreaseCoins]];
    
    [self setServantCount:self.curSelectServantCount + self.businessInfo.curCostServant
                 maxCount:self.businessInfo.maxCostServant];
}

- (void)updateServantList:(NSArray *)servantList
{
    if (servantList.count == 0)
    {
        self.labHasDetail.visible = NO;
        self.labNoDetail.visible = YES;
        self.btnDispatch.visible = NO;
        self.btnBattle.visible = YES;
    }
    else
    {
        self.labHasDetail.visible = YES;
        self.labNoDetail.visible = NO;
        self.btnDispatch.visible = YES;
        self.btnBattle.visible = NO;
    }
    
    [layerAndServantInfoDic removeAllObjects];
    
    float lastCellPosX = 0;
    CCNode *cellContainer = [CCNode node];
    for (AGServantInfo *servantInfo in servantList)
    {
        if (servantInfo.isBattle)
        {
            continue;
        }
        
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"8.3-servant-info.bmml"
                                                            eventHandle:self];
        layer.position = ccp(lastCellPosX, 0);
        lastCellPosX += layer.contentSize.width;
        
        [servantInfo.opponentInfo updateDataToLayer:layer];
        
        [[layer getControlByName:@"image_red_bg"] setVisible:servantInfo.isBattle];
        
        [cellContainer addChild:layer];
        [layerAndServantInfoDic setObject:servantInfo forKey:[NSValue valueWithNonretainedObject:layer]];
    }
    
    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(-1, 0)];
}

- (void)playIncreaseEffect
{
    CCSprite *sprIcon = [balsamiqLayer getControlByName:@"image_icon"];
    
    for (NSValue *value in [layerAndServantInfoDic allKeys])
    {
        CCBalsamiqLayer *layer = [value nonretainedObjectValue];
        [[layer retain] autorelease];
        
        CCMenuItemToggle *toggle = [layer getControlByName:@"toggle_ok"];
        if (toggle.selectedIndex == 1)
        {
            CGPoint posInIconParent = [sprIcon.parent convertToNodeSpace:[layer convertToWorldSpace:CGPointZero]];
            [layer removeFromParentAndCleanup:YES];
            layer.position = posInIconParent;
            [sprIcon.parent addChild:layer z:INT_MAX];
            
            [layer runAction:[CCSpawn actions:
                              [CCMoveTo actionWithDuration:1.0f position:sprIcon.position],
                              //[CCRotateBy actionWithDuration:0.8f angle:720.0f],
                              [CCScaleTo actionWithDuration:1.0f scale:0],
                              nil]];
        }
    }
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_getMyServantList:(NSDictionary *)info
{
    NSArray *servantList = [AGServantInfo getServantListFromInfo:info];
    [self updateServantList:[AGServantInfo getNotInBattleServantList:servantList]];
}

- (void)onReceiveInfoWithType_increaseBusiness:(NSDictionary *)info
{
    [self loadBusinessInfo:[AGBusinessInfo businessInfoFromCommercialInfo:info]];
    [self postGetMyServantList];
}

@end
