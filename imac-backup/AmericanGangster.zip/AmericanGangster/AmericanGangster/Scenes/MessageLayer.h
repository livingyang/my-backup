//
//  MessageLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-25.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"
#import <MessageUI/MessageUI.h>
#import <MessageUI/MFMailComposeViewController.h>

@class CCBalsamiqLayer;
@interface MessageLayer : BaseLayer <MFMailComposeViewControllerDelegate>
{
    CCBalsamiqLayer *balsamiqLayer;
}

@end
