//
//  StoreLayer.h
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-5-5.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "BaseLayer.h"

@class CCTableLayer;
@interface StoreLayer : BaseLayer
{
}

@property (nonatomic, assign) CCTableLayer *tableLayer;
@property (nonatomic, retain) NSArray *weaponItemArray; // object : AGStoreItemInfo

@end
