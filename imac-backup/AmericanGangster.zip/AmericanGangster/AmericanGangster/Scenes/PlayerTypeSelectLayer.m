//
//  PlayerTypeSelectLayer.m
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-4-27.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "PlayerTypeSelectLayer.h"
#import "CCBalsamiqLayer.h"
#import "IntroLayer.h"
#import "HomeLayer.h"
#import "AGLoginInfo.h"
#import "CharacterImageManager.h"
#import "PlayerTypeManager.h"

@implementation PlayerTypeSelectLayer

@synthesize loginInfo;
@synthesize gameDataCache;

+ (CCScene *)sceneWithLoginInfo:(AGLoginInfo *)info
{
    CCScene *scene = [CCScene node];
    
    PlayerTypeSelectLayer *layer = [PlayerTypeSelectLayer node];
    [layer loadLoginInfo:info];
    [scene addChild:layer];
    
    return scene;
}

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"1.3-type-select.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        [[balsamiqLayer getControlByName:@"type"] selectRadioItem:@"radio_type_int"];
        [self updateTypeInfo:@"radio_type_int"];
        
        [[balsamiqLayer getControlByName:@"image_player"] runAction:
         [CCMoveBy actionWithDuration:0.5f position:ccp(-90, 0)]];
        
        [[balsamiqLayer getControlByName:@"type"] runAction:
         [CCMoveBy actionWithDuration:0.5f position:ccp(0, -400)]];
        
        ((CCSprite *)[balsamiqLayer getControlByName:@"image_type"]).opacity = 0;
        [[balsamiqLayer getControlByName:@"image_type"] runAction:[CCFadeIn actionWithDuration:0.5f]];
        
        self.gameDataCache = [GameDataCache gameDataCacheWithDelegate:self];
    }
    
    return self;
}

- (void)loadLoginInfo:(AGLoginInfo *)info
{
    self.loginInfo = info;
    CCTexture2D *playerImage = [[CharacterImageManager instance] getTextureFromImageName:info.imageName];
    [[balsamiqLayer getControlByName:@"image_player"] setTexture:playerImage];
}

- (void)updateTypeInfo:(NSString *)selectRadioName
{
    // type image over player image
    NSString *imagePath = [PlayerTypeManager getTypeImageFromRadioName:selectRadioName];
    [[balsamiqLayer getControlByName:@"image_type"] setTexture:
     [[CCTextureCache sharedTextureCache] addImage:imagePath]];
    
    // type detail
    NSDictionary *typeInfoDic = [NSDictionary dictionaryWithObjectsAndKeys:
                                 [self getLanguageString:@"1006"], @"radio_type_int",
                                 [self getLanguageString:@"1007"], @"radio_type_cha",
                                 [self getLanguageString:@"1008"], @"radio_type_pow",
                                 nil];
    [[[balsamiqLayer getControlByName:@"type"] getControlByName:@"detail"]
     setString:[typeInfoDic objectForKey:selectRadioName]];
}

- (void)ontypeRadioSelected:(NSString *)radioItemName
{
    [self updateTypeInfo:radioItemName];
    //[[balsamiqLayer getControlByName:@"image_type"] runAction:[CCRotateBy actionWithDuration:0.5f angle:360]];
}

- (void)onNextClick:(id)sender
{
    NSString *selectRadioName = [[balsamiqLayer getControlByName:@"type"] getRadioManagerByGroup:@"type"].selectedItemInfo;
                                 
    self.loginInfo.type = [PlayerTypeManager getTypeFromRadioName:selectRadioName];
    
    [self postRegisterRequest:self.loginInfo];
}

- (void)onTotalDataCached
{
    [[CCDirector sharedDirector] replaceScene:[HomeLayer scene]];
}

- (void)dealloc
{
    self.loginInfo = nil;
    self.gameDataCache = nil;
    
	[super dealloc];
}

- (void)onReceiveInfoWithType_register:(NSDictionary *)info
{
    [self postGetCardList];
    [self postGetTotalStoreListRequest];
}

- (void)onReceiveInfoWithType_getTotalStoreList:(NSDictionary *)info
{
    [self.gameDataCache cacheTotalStore:info];
}

- (void)onReceiveInfoWithType_getCardList:(NSDictionary *)info
{
    [self.gameDataCache cacheTotalCard:info];
}

@end
