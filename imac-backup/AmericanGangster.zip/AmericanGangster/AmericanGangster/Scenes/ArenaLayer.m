//
//  ArenaLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-25.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "ArenaLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCTableLayer.h"
#import "AGArenaPlayerRankInfo.h"
#import "AGOpponentInfo.h"
#import "AGArenaInfo.h"
#import "CCTimeManageNode.h"
#import "CharacterImageManager.h"
#import "CCLabelTTF+ChangeFont.h"
#import "CCVideoPlayer.h"
#import "CCAlertLayer.h"
#import "AGStoreItemInfo.h"
#import "PackLayer.h"

@implementation ArenaLayer

@synthesize messageArray;
@synthesize arenaOpponentList;
@synthesize curArenaInfo;

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"10-arena.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        CCLabelTTF *labMessage = [balsamiqLayer getControlByName:@"message"];
        labMessage.opacity = 0;
        
        [balsamiqLayer selectRadioItem:@"radio_tab_challenge"];
        [self postInfoBySelectedRadioItem:@"radio_tab_challenge"];
        
        [self postGetMyArena];
        [self postGetArenaMsgList];
        
        // 每天打开一次帮助界面
        static NSTimeInterval lastHelpShowTime = 0;
        if ([NSDate timeIntervalSinceReferenceDate] - lastHelpShowTime > 60 * 60 * 24)
        {
            lastHelpShowTime = [NSDate timeIntervalSinceReferenceDate];
            [self onHelpClick:nil];
        }
    }
    
    return self;
}

- (void)dealloc
{
    self.messageArray = nil;
    self.arenaOpponentList = nil;
    
    [super dealloc];
}

- (void)postInfoBySelectedRadioItem:(NSString *)radioItemName
{
    if ([radioItemName isEqualToString:@"radio_tab_challenge"])
    {
        [self postGetArenaOpponentList];
    }
    else
    {
        [self postGetArenaRankList:1];
    }
}

- (AGArenaPlayerRankInfo *)getArenaOpponentFromId:(int)opponentId
{
    for (AGArenaPlayerRankInfo *playerInfo in self.arenaOpponentList)
    {
        if (playerInfo.uniqueId == opponentId)
        {
            return playerInfo;
        }
    }
    
    return nil;
}

- (void)onCheckClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    [[SoundManager instance] continuePlayBackgroundMusic];
    
    [[CCDirector sharedDirector] replaceScene:[PackLayer sceneWithEquipmentType:[sender tag]]];
}

- (void)onOkWinItemClick:(id)sender
{
    [self onOkWinClick:sender];
    
    [self showSystemTip:[self getLanguageString:@"12004"]];
}

- (void)onOkWinClick:(id)sender
{
    [[SoundManager instance] continuePlayBackgroundMusic];
    [self onCommonAlertOkClick:sender];
}

- (void)onCloseWinClick:(id)sender
{
    [[SoundManager instance] continuePlayBackgroundMusic];
    [self onCommonAlertCloseClick:sender];
}

- (void)onFightClick:(id)sender
{
    [self onCommonAlertOkClick:sender];
    
    [self postChallengeArenaOpponent:[sender tag]];
}

- (void)onChallengeClick:(id)sender
{
    if (self.curArenaInfo.curChallengeCount == 0)
    {
        [self openItemAlert:[self getLanguageString:@"2"] withType:@"g"];
        return;
    }
    
    AGArenaPlayerRankInfo *opponentInfo = [self getArenaOpponentFromId:[sender tag]];
    
    if (opponentInfo != nil)
    {
        CCAlertLayer *alert = [CCAlertLayer showAlert:@"10.9-arena-battle.bmml"
                                           parentNode:self];
        
        CCSprite *sprMy = [alert.balsamiqLayer getControlByName:@"image_my"];
        sprMy.texture = [[CharacterImageManager instance] getTextureFromImageName:
                         [AGPlayerInfo defaultPlayerInfo].imageName];
        CCSprite *sprOpponent = [alert.balsamiqLayer getControlByName:@"image_opponent"];
        sprOpponent.texture = [[CharacterImageManager instance] getTextureFromImageName:
                               opponentInfo.imageName];
        sprOpponent.flipX = YES;
        
        [[alert.balsamiqLayer getControlByName:@"name-my"] setString:[AGPlayerInfo defaultPlayerInfo].name];
        [self setNode:[alert.balsamiqLayer getControlByName:@"name-my"] toParentSpace:sprMy];
        [[alert.balsamiqLayer getControlByName:@"name-opponent"] setString:opponentInfo.name];
        [self setNode:[alert.balsamiqLayer getControlByName:@"name-opponent"] toParentSpace:sprOpponent];
                
        CGPoint movePosMy = {-200, 0};
        sprMy.position = ccpAdd(sprMy.position, movePosMy);
        [sprMy runAction:[CCEaseBackOut actionWithAction:
                          [CCMoveBy actionWithDuration:0.5f position:ccpNeg(movePosMy)]]];
        
        CGPoint movePosOpponent = {200, 0};
        sprOpponent.position = ccpAdd(sprOpponent.position, movePosOpponent);
        [sprOpponent runAction:[CCEaseBackOut actionWithAction:
                                [CCMoveBy actionWithDuration:0.5f position:ccpNeg(movePosOpponent)]]];
        
        [[alert.balsamiqLayer getControlByName:@"Fight"] setTag:opponentInfo.uniqueId];
        
        NSString *randomDetail = [[alert.balsamiqLayer getControlByName:
                                   [NSString stringWithFormat:@"detail%d", (arc4random() % 3) + 1]] string];
        [[alert.balsamiqLayer getControlByName:@"detail"] setString:randomDetail];
    }
}

- (void)onArenaItemClick:(id)sender
{
    [self openItemAlert:[self getLanguageString:@"2"] withType:@"g"];
}

- (void)onGainClick:(id)sender
{
    [self postGetGainRankingAward];
}

- (void)onRewardOkClick:(id)sender
{
    [self onCommonAlertOkClick:sender];
    
    [self postGainRankingAward];
}

- (void)onHelpClick:(id)sender
{
    [CCAlertLayer showAlert:@"10.8-arena-help.bmml"
                 parentNode:self];
}

- (void)ontabRadioSelected:(NSString *)radioItemName
{
    [self postInfoBySelectedRadioItem:radioItemName];
}

- (void)updateArenaOpponentList:(NSArray *)oppnentList
{
    CCTableLayer *tableLayer = [balsamiqLayer getControlByName:@"tab_challenge"];
    CCNode *cellContainer = [CCNode node];
    for (AGArenaPlayerRankInfo *info in oppnentList)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"10.1-opponent-info.bmml"
                                                           eventHandle:self];
        [cellContainer addChild:cell];
        
        cell.position = ccp(0, cell.contentSize.height * [oppnentList indexOfObject:info]);
        
        [info updateDataToLayer:cell];
        [[cell getControlByName:@"rank"] setString:
         [NSString stringWithFormat:@"%d", info.rank]];
        [[cell getControlByName:@"Challenge"] setTag:info.uniqueId];
    }
    
    [tableLayer setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

#pragma mark -
#pragma mark updateArenaRankList

- (CCBalsamiqLayer *)getTopThreeRankLayer:(NSArray *)arenaRankList
{
    CCBalsamiqLayer *rankLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"10.2-top-three-rank.bmml"
                                                            eventHandle:self];
    
    for (int i = 0; i < 3; ++i)
    {
        if (arenaRankList.count <= i)
        {
            break;
        }
        
        AGArenaPlayerRankInfo *info = [arenaRankList objectAtIndex:i];
        [[rankLayer getControlByName:[NSString stringWithFormat:@"name%d", i + 1]] setString:
         [NSString stringWithFormat:@"%@", info.name]];

        [[rankLayer getControlByName:[NSString stringWithFormat:@"level%d", i + 1]] setString:
         [NSString stringWithFormat:@"LEVEL: %d", info.level]];       
        [[rankLayer getControlByName:[NSString stringWithFormat:@"level%d", i + 1]] changeToBlackArialFont];
        
        [[rankLayer getControlByName:[NSString stringWithFormat:@"image_header%d", i + 1]] setTexture:
         [[CCTextureCache sharedTextureCache] addImage:info.headerImageName]];
    }
    
    return rankLayer;
}

- (void)updateRankPlayerInfo:(AGArenaPlayerRankInfo *)rankInfo
                     toLayer:(CCBalsamiqLayer *)layer
{
    if (rankInfo != nil)
    {
        [rankInfo updateDataToLayer:layer];
        [[layer getControlByName:@"rank"] setString:[NSString stringWithFormat:@"%d", rankInfo.rank]];
    }
    else
    {
        layer.visible = NO;
    }
}

- (CCBalsamiqLayer *)getRankRowLayerFromLeftInfo:(AGArenaPlayerRankInfo *)leftPlayer
                          rightInfo:(AGArenaPlayerRankInfo *)rightPlayer
{
    CCBalsamiqLayer *layerRow = [CCBalsamiqLayer layerWithBalsamiqFile:@"10.3-rank-row-info.bmml"
                                                           eventHandle:self];
    
    [self updateRankPlayerInfo:leftPlayer toLayer:[layerRow getControlByName:@"info-left"]];
    [self updateRankPlayerInfo:rightPlayer toLayer:[layerRow getControlByName:@"info-right"]];
    
    return layerRow;
}

- (void)updateArenaRankList:(NSArray *)array
{
    CCBalsamiqLayer *topThreeLayer = [self getTopThreeRankLayer:array];
    
    CCTableLayer *rankTableLayer = [balsamiqLayer getControlByName:@"tab_rank"];
    CCNode *cellContainer = [CCNode node];
    [cellContainer addChild:topThreeLayer];
    
    float lastCellPosY = 0;
    for (int playerIndex = 3; playerIndex + 1 < array.count; playerIndex += 2)
    {
        CCBalsamiqLayer *cell = [self getRankRowLayerFromLeftInfo:[array objectAtIndex:playerIndex]
                                                        rightInfo:[array objectAtIndex:playerIndex + 1]];
        lastCellPosY -= cell.contentSize.height;
        cell.position = ccp(0, lastCellPosY);
        [cellContainer addChild:cell];
    }
    
    [rankTableLayer setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

- (void)onArenaChallengeVideoDone:(AGArenaChallengeResultInfo *)info
{
    if (info.isWin)
    {
        [[SoundManager instance] playEffectWin];
        
        if (info.rewardItem == nil)
        {
            CCAlertLayer *alert = [CCAlertLayer showAlert:@"10.5.1-arena-win-no-item.bmml"
                                               parentNode:self];
            
            [[alert.balsamiqLayer getControlByName:@"rank"] setString:
             [NSString stringWithFormat:@"%d", info.rank]];
            [[alert.balsamiqLayer getControlByName:@"detail"] setString:
             [NSString stringWithFormat:@"You challenge %@ success.", info.opponentName]];
        }
        else
        {
            CCAlertLayer *alert = [CCAlertLayer showAlert:@"10.5-arena-win.bmml"
                                               parentNode:self];
            
            [[alert.balsamiqLayer getControlByName:@"rank"] setString:
             [NSString stringWithFormat:@"%d", info.rank]];
            
            [[alert.balsamiqLayer getControlByName:@"Check"] setTag:info.rewardItem.type];
            
            [info.rewardItem updateDataToLayer:alert.balsamiqLayer];
        }
    }
    else
    {
        [[SoundManager instance] playEffectLost];
        
        CCAlertLayer *alert = [CCAlertLayer showAlert:@"10.6-arena-lost.bmml"
                                           parentNode:self];
        
        [[alert.balsamiqLayer getControlByName:@"detail"] setString:
         [NSString stringWithFormat:@"    You challenge %@ failed, keep rank.You need better weapon to defeat your opponent.", info.opponentName]];
        
        [[alert.balsamiqLayer getControlByName:@"rank"] setString:
         [NSString stringWithFormat:@"%d", info.rank]];
    }
    
    [self postGetArenaOpponentList];
    [self postGetMyArena];
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_getArenaRankList:(NSDictionary *)info
{
    [self updateArenaRankList:[AGArenaPlayerRankInfo playerRankListFromInfo:info]];
}

- (void)onReceiveInfoWithType_getArenaOpponentList:(NSDictionary *)info
{
    self.arenaOpponentList = [AGArenaPlayerRankInfo arenaOpponentListFromInfo:info];
    [self updateArenaOpponentList:self.arenaOpponentList];
}

- (void)onTimeCountDown:(CCMenuItemImage *)btnGain
{
    btnGain.visible = YES;
}

- (void)onReceiveInfoWithType_getMyArena:(NSDictionary *)info
{
    AGArenaInfo *arenaInfo = [AGArenaInfo arenaInfoFromDic:info];
    self.curArenaInfo = arenaInfo;
    
    [[balsamiqLayer getControlByName:@"name"] setString:arenaInfo.name];
    
    CCSprite *spriteHeader = [balsamiqLayer getControlByName:@"image_header"];
    spriteHeader.texture = [[CCTextureCache sharedTextureCache] addImage:
                            [CharacterImageManager headerImageFromCharacterImage:arenaInfo.imageName]];
    
    [[balsamiqLayer getControlByName:@"level"]
     setString:[NSString stringWithFormat:@"LV: %d", arenaInfo.level]];
    [[balsamiqLayer getControlByName:@"attack"]
     setString:[NSString stringWithFormat:@"%d", arenaInfo.attack]];
    [[balsamiqLayer getControlByName:@"rank"]
     setString:[NSString stringWithFormat:@"%d", arenaInfo.rank]];
    [[balsamiqLayer getControlByName:@"count"]
     setString:[NSString stringWithFormat:@"%d/%d", arenaInfo.curChallengeCount, arenaInfo.maxChallengeCount]];
    
    CCProgressTimer *barCount = [balsamiqLayer getControlByName:@"bar_count"];
    barCount.percentage = arenaInfo.challengeCountPercent;
    
    [[balsamiqLayer getControlByName:@"Gain"] setVisible:NO];
    [CCTimeManageNode startCountDown:[balsamiqLayer getControlByName:@"time"]
                            timeLeft:arenaInfo.time
                            isHHMMSS:YES
                      withStopAction:[CCCallFuncO actionWithTarget:self
                                                          selector:@selector(onTimeCountDown:)
                                                            object:[balsamiqLayer getControlByName:@"Gain"]]];
}

- (ccColor3B)getColorFromType:(char)type
{
    switch (type)
    {
        case 'R':
            return ccRED;
        case 'W':
            return ccWHITE;
            
        default:
            break;
    }
    
    return ccWHITE;
}

- (NSString *)getStringByDeleteType:(NSString *)msg
{
    if (msg.length <= 1)
    {
        return msg;
    }
    
    return [msg substringFromIndex:1];
}

- (CCNode *)getStringNodeFromMessage:(NSString *)msg
{
    CCNode *labNode = [CCNode node];
    
    NSArray *stringArray = [msg componentsSeparatedByString:@"%"];
    
    float startPosX = 0;
    for (NSString *str in stringArray)
    {
        if (str.length > 1)
        {
            CCLabelTTF *label = [CCLabelTTF labelWithString:[self getStringByDeleteType:str] fontName:@"arial" fontSize:10];
            label.position = ccp(startPosX, 0);
            label.anchorPoint = CGPointZero;
            label.color = [self getColorFromType:[str characterAtIndex:0]];
            startPosX += label.contentSize.width;
            
            [labNode addChild:label];
        }
    }
    
    return labNode;
}

- (void)updateLabelString:(ccTime)dt
{
    CCLabelTTF *labMessage = [balsamiqLayer getControlByName:@"message"];
    
    NSString *msg = [self.messageArray objectAtIndex:arc4random() % self.messageArray.count];
    CCNode *strNode = [self getStringNodeFromMessage:msg];
    [labMessage addChild:strNode];
    
    strNode.position = ccp(300, 0);
    [strNode runAction:[CCSequence actions:
                        [CCMoveBy actionWithDuration:15 position:ccp(-700, 0)],
                        [CCCallFunc actionWithTarget:strNode selector:@selector(removeFromParentAndCleanup:)],
                        nil]];
}

- (void)onReceiveInfoWithType_getArenaMsgList:(NSDictionary *)info
{
    self.messageArray = [info objectForKey:@"myArenaMsgList"];
    
    if (self.messageArray.count == 0)
    {
        return;
    }
    
    [self updateLabelString:0];
    [self schedule:@selector(updateLabelString:) interval:10.0f];
}

- (void)onReceiveInfoWithType_challengeArenaOpponent:(NSDictionary *)info
{
    AGArenaChallengeResultInfo *resultInfo = [AGArenaChallengeResultInfo resultFromInfo:info];
    
    [[CCVideoPlayer instance] playerVideo:@"fight"
                                   ofType:@"mp4"
                                 callback:[CCCallFuncO actionWithTarget:self
                                                               selector:@selector(onArenaChallengeVideoDone:)
                                                                 object:resultInfo]];
}

- (void)onReceiveInfoWithType_getGainRankingAward:(NSDictionary *)info
{
    AGArenaRankingRewardInfo *rewardInfo = [AGArenaRankingRewardInfo rewardInfoFromDic:info];
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"10.7-arena-reward.bmml"
                                       parentNode:self];
    
    [[alert.balsamiqLayer getControlByName:@"rank"] setString:
     [NSString stringWithFormat:@"%d", rewardInfo.rank]];
    [[alert.balsamiqLayer getControlByName:@"coin"] setString:
     [NSString stringWithFormat:@"%d", rewardInfo.gainCoins]];
    [[alert.balsamiqLayer getControlByName:@"RewardOk"] setTag:rewardInfo.gainCoins];
}

- (void)onReceiveInfoWithType_gainRankingAward:(NSDictionary *)info
{
    AGArenaRankingRewardInfo *rewardInfo = [AGArenaRankingRewardInfo rewardInfoFromDic:info];
    [self showGainEffect:rewardInfo.gainCoins];
    [self postGetMyArena];
}

- (void)onReceiveInfoWithType_useProps:(NSDictionary *)info
{
    [super onReceiveInfoWithType_useProps:info];
    
    [self postGetMyArena];
}

@end
