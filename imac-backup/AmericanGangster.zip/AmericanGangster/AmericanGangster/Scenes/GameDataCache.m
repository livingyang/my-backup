//
//  GameDataCache.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-9-3.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "GameDataCache.h"
#import "AGStoreItemInfoCache.h"
#import "AGShopItemInfo.h"
#import "AGPlayerInfo.h"

@implementation GameDataCache

- (id)initWithDelegate:(id<GameDataCacheDelegate>)delegate
{
    self = [super init];
    
    if (self != nil)
    {
        delegate_ = delegate;
        
        isTotalStoreCached = NO;
        isTotalCardCached = NO;
    }
    
    return self;
}

+ (GameDataCache *)gameDataCacheWithDelegate:(id<GameDataCacheDelegate>)delegate
{
    return [[[GameDataCache alloc] initWithDelegate:delegate] autorelease];
}

- (void)checkCacheState
{
    if (isTotalStoreCached && isTotalCardCached)
    {
        [delegate_ onTotalDataCached];
    }
}

- (void)cacheTotalStore:(NSDictionary *)data
{
    [[AGStoreItemInfoCache instance] updateCache:data];
    isTotalStoreCached = YES;
    
    [self checkCacheState];
}

- (void)cacheTotalCard:(NSDictionary *)data
{
    [[AGCardInfoCache instance] loadTotalCardInfo:data];
    isTotalCardCached = YES;
    
    [self checkCacheState];
}

@end
