//
//  GuideLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-30.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "GuideLayer.h"
#import "CCBalsamiqLayer.h"
#import "AGPlayerInfo.h"
#import "LanguageManager.h"

enum
{
    zMaskSprite = 0,
    zGuideLayer,
};

#define IMAGE_WOMAN_FRIEND @"UI/15-guide/img-friend-woman.png"

@implementation GuideLayer

@synthesize balsamiqLayer;

+ (GuideLayer *)guideLayerFromFileName:(NSString *)fileName
{
    GuideLayer *guideLayer = [GuideLayer node];
    [guideLayer loadGuideLayer:fileName];
    return guideLayer;
}

+ (void)changeSpriteImageToWoman:(CCSprite *)sprite
{
    sprite.texture = [[CCTextureCache sharedTextureCache] addImage:IMAGE_WOMAN_FRIEND];
}

- (CCSprite *)sprRange
{
    return [self.balsamiqLayer getControlByName:@"image_range"];
}

- (void)addMaskLayerWithRangeSprite:(CCSprite *)rangeSprite
{
    if (rangeSprite == nil)
    {
        return;
    }
    
    CCRenderTexture *texture = [[[CCRenderTexture alloc] initWithWidth:self.contentSize.width
                                                                height:self.contentSize.height
                                                           pixelFormat:kCCTexture2DPixelFormat_Default] autorelease];
    
    [texture begin];
    
    [[CCLayerColor layerWithColor:ccc4(0, 0, 0, 150)] visit];
    
    ccBlendFunc oldBlendFunc = rangeSprite.blendFunc;
    ccBlendFunc newBlendFunc = {GL_ONE, GL_ZERO};
    rangeSprite.blendFunc = newBlendFunc;
    [rangeSprite visit];
    rangeSprite.blendFunc = oldBlendFunc;
    
    [texture end];
    
    CCSprite *sprMask = [CCSprite spriteWithTexture:texture.sprite.texture];
    sprMask.flipY = YES;
    [self addChild:sprMask z:zMaskSprite];
    sprMask.anchorPoint = CGPointZero;
}

- (void)loadGuideLayer:(NSString *)fileName
{
    self.isTouchEnabled = YES;
    
    self.balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:fileName
                                                    eventHandle:self];
    [self addChild:self.balsamiqLayer z:zGuideLayer];
    
    CCLabelTTF *labDetail = [self.balsamiqLayer getControlByName:@"detail"];
    if ([[LanguageManager instance] hasStringFromId:labDetail.string])
    {
        labDetail.string = [[LanguageManager instance] getStringFromId:labDetail.string];
    }
    
    CCSprite *sprPoint = [self.balsamiqLayer getControlByName:@"image_point"];
    [sprPoint runAction:[CCRepeatForever actionWithAction:[CCSequence actions:
                                                           [CCMoveBy actionWithDuration:0.5f position:ccp(0, 20)],
                                                           [CCMoveBy actionWithDuration:0.5f position:ccp(0, -20)],
                                                           nil]]];
    [self addMaskLayerWithRangeSprite:self.sprRange];
    
    if ([AGPlayerInfo defaultPlayerInfo].isMan)
    {
        [GuideLayer changeSpriteImageToWoman:[self.balsamiqLayer getControlByName:@"image_friend"]];
        
        labDetail.string = [labDetail.string stringByReplacingOccurrencesOfString:@"Andy" withString:@"Maggie"];
    }
}

- (void)registerWithTouchDispatcher
{
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self
                                                     priority:INT_MIN
                                              swallowsTouches:YES];
}

- (BOOL)ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
    BOOL isClickInRangeSprite = CGRectContainsPoint(self.sprRange.textureRect,
                                                    [self.sprRange convertTouchToNodeSpace:touch]);
    
    [[NSNotificationCenter defaultCenter] postNotificationName:isClickInRangeSprite ? NOTIFICATION_GUIDE_RANGE_SPRITE_CLICK : NOTIFICATION_GUIDE_OUT_OF_RANGE_CLICK
                                                        object:self];
    
    return !isClickInRangeSprite;
}

@end
