//
//  BaseLayer.m
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-4-27.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "BaseLayer.h"
#import "NSDictionary_JSONExtensions.h"
#import "UIDevice+IdentifierAddition.h"
#import "AttackLayer.h"
#import "HomeLayer.h"
#import "StoreLayer.h"
#import "PackLayer.h"
#import "GangsterLayer.h"
#import "ItemLayer.h"
#import "AGPlayerInfo.h"
#import "AGLoginInfo.h"
#import "MissionLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCTableLayer.h"
#import "CCAlertLayer.h"
#import "CCSprite+LoadingBar.h"
#import "AGShopItemInfo.h"
#import "TimeLeftManager.h"
#import "CCTimeManageNode.h"
#import "AGOpponentInfo.h"
#import "AGChallengeResult.h"
#import "CCVideoPlayer.h"
#import "CharacterImageManager.h"
#import "GuideEventHandle.h"
#import "AGPurchaseProduct.h"
#import "AGStoreItemInfo.h"
#import "AGStoreItemInfoCache.h"
#import "MessageLayer.h"
#import "IntroLayer.h"
#import "MobClick.h"
#import "ShareManager.h"
#import "LanguageManager.h"
#import "PPMainHelper.h"
#import "PPAppPlatform.h"
#import "PPControl.h"

#define TAG_ITEM_ALERT (9999)
#define TAG_PURCHASE_ALERT (9998)
#define TAG_LEVEL_UP_ALERT (9997)
#define TAG_BATTLE_ALERT (9996)

@implementation BaseLayer

@synthesize headerLayer;
@synthesize toolLayer;
@synthesize loadingLayer;
@synthesize challengeResult;

- (CCAlertLayer *)getAlertFromTag:(int)tagAlert
{
    id alert = [self getChildByTag:tagAlert];
    
    if ([alert isKindOfClass:[CCAlertLayer class]] || alert == nil)
    {
        return alert;
    }
    else
    {
        NSLog(@"%@#getAlertFromTag get alert is error", NSStringFromClass([self class]));
        return nil;
    }
}

- (CCAlertLayer *)itemAlertLayer
{
    return [self getAlertFromTag:TAG_ITEM_ALERT];}

- (CCAlertLayer *)purchaseAlertLayer
{
    return [self getAlertFromTag:TAG_PURCHASE_ALERT];
}

- (CCAlertLayer *)levelUpAlertLayer
{
    return [self getAlertFromTag:TAG_LEVEL_UP_ALERT];
}

+ (CCScene *)scene
{
    CCScene *scene = [CCScene node];
    [scene addChild:[self node]];
    
    return scene;
}

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        connectAndReciveDataDic = [[NSMutableDictionary alloc] init];
        
        //modify by ganhaidong 2012-12-23
        if ([[LanguageManager instance]isEnglishVersion]) {
           [InAppPurchaseListen instance].delegate = self;
        }
        if ([[LanguageManager instance]isChineseVersion]) {
           [PPMainHelper instance].delegate = self;
        }
    }
    
    return self;
}

- (void)onApplicationBecomeActive:(NSNotification *)notification
{
}

- (void)onEnter
{
    [super onEnter];
    
    [self updateDefaultPlayerInfo];
}

- (void)onExit
{
    [super onExit];
    
    [self cancleAllConnection];
    
    [[CCTextureCache sharedTextureCache] removeUnusedTextures];
}

- (void)dealloc
{
    self.challengeResult = nil;
    
    // 问题！！
    // 似乎有baselayer没有被删除
    // 注册一个消息中心方法统一打印一下信息
    
    //modify by ganhaidong 2012-12-23
    if ([[LanguageManager instance]isEnglishVersion]) {
        if ([InAppPurchaseListen instance].delegate == self)
        {
            [InAppPurchaseListen instance].delegate = nil;
        }
    }
    if ([[LanguageManager instance]isChineseVersion]) {
        if ([PPMainHelper instance].delegate == self)
        {
            [PPMainHelper instance].delegate = nil;
        }
        [ShareManager instance].delegate=nil;
    }

    
    [self cancleAllConnection];
    [connectAndReciveDataDic release];
    
	[super dealloc];
}

- (void)cancleAllConnection
{
    for (NSValue *connectionValue in [connectAndReciveDataDic allKeys])
    {
        NSURLConnection *connection = [connectionValue nonretainedObjectValue];
        [connection cancel];
    }
    
    [connectAndReciveDataDic removeAllObjects];
    
    self.isLoading = NO;
}

- (NSString *)loadingLayerName
{
    return @"0-loading-2.bmml";
}

- (void)setIsLoading:(BOOL)isLoading
{
    if (self.isLoading == isLoading)
    {
        return;
    }
    
    if (isLoading)
    {
        self.loadingLayer = [CCAlertLayer showAlert:self.loadingLayerName
                                         parentNode:self];
        
        [[self.loadingLayer.balsamiqLayer getControlByName:@"image_loading"] loadingWithInterval:2];
    }
    else
    {
        [CCAlertLayer removeAlertFromNode:self.loadingLayer];
        self.loadingLayer = nil;
    }
}

- (BOOL)isLoading
{
    return (self.loadingLayer != nil);
}

#pragma mark -
#pragma mark 多语言支持

- (NSString *)getLanguageString:(NSString *)strId
{
    return [[LanguageManager instance] getStringFromId:strId];
}

- (void)setLabel:(CCLabelTTF *)label toLanguage:(NSString *)strId
{
    if ([[LanguageManager instance] hasStringFromId:strId])
    {
        label.string = [self getLanguageString:strId];
    }
}

#pragma mark -
#pragma mark item use alert

- (void)openItemAlert:(NSString *)title withType:(NSString *)itemType
{
    [self openItemAlert];
    
    [self postGetAlertItemList:itemType];
    
    [[self.itemAlertLayer.balsamiqLayer getControlByName:@"title"] setString:title];
    [[self.itemAlertLayer.balsamiqLayer getControlByName:@"type"] setString:itemType];
    [[self.itemAlertLayer.balsamiqLayer getControlByName:@"type"] setVisible:NO];
    [[self.itemAlertLayer.balsamiqLayer getControlByName:@"message"] setVisible:NO];
    
    if ([itemType isEqualToString:@"e"])
    {
        [[self.itemAlertLayer.balsamiqLayer getControlByName:@"message"] setVisible:YES];
        [self setAlertCurrentEnergy];
    }
    else if ([itemType isEqualToString:@"d"])
    {
        CCMenuItemImage *btnBuy = [self.itemAlertLayer.balsamiqLayer getControlByName:@"AlertBuyItem"];
        CCMenuItemImage *btnUse = [self.itemAlertLayer.balsamiqLayer getControlByName:@"AlertUseItem"];
        btnUse.visible = NO;
        btnBuy.position = ccpAdd(btnBuy.position, ccp(80, 0));
    }
}

- (void)openItemAlert
{
    if (self.itemAlertLayer != nil)
    {
        return;
    }
    
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"0-item-use-alert.bmml"
                                       parentNode:self];
    alert.tag = TAG_ITEM_ALERT;
    [[alert.balsamiqLayer getControlByName:@"item"] setVisible:NO];
    
    [[SoundManager instance] playEffectButtonOk];
}

- (void)updateItemListToAlert:(NSArray *)itemList
{
    if (self.itemAlertLayer == nil)
    {
        return;
    }
    
    AGShopItemInfo *item = [itemList objectAtIndex:0];
    
    [item updateDataToLayer:[self.itemAlertLayer.balsamiqLayer getControlByName:@"item"]];
    [[self.itemAlertLayer.balsamiqLayer getControlByName:@"item"] setVisible:YES];
    
    CCMenuItemImage *btnBuy = [self.itemAlertLayer.balsamiqLayer getControlByName:@"AlertBuyItem"];
    CCMenuItemImage *btnUse = [self.itemAlertLayer.balsamiqLayer getControlByName:@"AlertUseItem"];
    
    btnBuy.tag = item.propsId;
    btnUse.tag = item.propsId;
    btnUse.isEnabled = (item.count > 0);
}

- (BOOL)onUseItem:(int)itemId itemType:(NSString *)type
{
    if ([type isEqualToString:@"e"])
    {
        if ([AGPlayerInfo defaultPlayerInfo].isFullEnergy)
        {
            [self showSystemTip:[self getLanguageString:@"3"]];
            return YES;
        }
    }
    else if ([type isEqualToString:@"h"])
    {
        if ([AGPlayerInfo defaultPlayerInfo].isFullHealth)
        {
            [self showSystemTip:[self getLanguageString:@"4"]];
            return YES;
        }
    }
    else if ([type isEqualToString:@"a"])
    {
        [[self.headerLayer getControlByName:@"image_attack"]
         runAction:[CCBlink actionWithDuration:2.0f blinks:4]];
    }
    
    [self postUsePropsGoods:itemId];
    
    if ([type isEqualToString:@"a"]
        || [type isEqualToString:@"d"]
        || [type isEqualToString:@"r"])
    {
        return YES;
    }
    
    return NO;
}

- (void)onAlertUseItemClick:(id)sender
{
    BOOL isCloseAlert = [self onUseItem:[sender tag]
                               itemType:[[self.itemAlertLayer.balsamiqLayer getControlByName:@"type"] string]];
    if (isCloseAlert)
    {
        [CCAlertLayer removeAlertFromNode:sender];
    }
}

- (void)onAlertBuyItemClick:(id)sender
{
    [self postBuyPropsGoods:[sender tag]];
}

- (void)postGetAlertItemList:(NSString *)itemType
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getAlertPropsList", @"method",
                                               itemType, @"param",
                                               nil]];
}

- (void)onReceiveInfoWithType_getAlertPropsList:(NSDictionary *)info
{
    [self updateItemListToAlert:[AGShopItemInfo shopItemListFromAlertInfo:info]];
}

#pragma mark -
#pragma mark common alert button

- (void)onCommonAlertCloseClick:(id)sender
{
    [[SoundManager instance] playEffectButtonBack];
    
    [CCAlertLayer removeAlertFromNode:sender];
}

- (void)onCommonAlertOkClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [CCAlertLayer removeAlertFromNode:sender];
}

#pragma mark -
#pragma mark recover item use

- (void)onHeaderCoinClick:(id)sender
{
    [self openItemAlert:[self getLanguageString:@"2"] withType:@"m"];
}

- (void)onHeaderLevelClick:(id)sender
{
    [self openItemAlert:[self getLanguageString:@"2"] withType:@"l"];
}

- (void)onHeaderHealthClick:(id)sender
{
    [self openItemAlert:[self getLanguageString:@"2"] withType:@"h"];
}

- (void)onHeaderEnergyClick:(id)sender
{
    [self openItemAlert:[self getLanguageString:@"2"] withType:@"e"];
}

- (void)onHeaderAttackClick:(id)sender
{
    if ([AGPlayerInfo defaultPlayerInfo].attackTimeLeft.curTimeLeft == 0)
    {
        [self openItemAlert:[self getLanguageString:@"2"] withType:@"a"];
    }
    else
    {
        [self showSystemTip:[self getLanguageString:@"7"]];
    }
}

- (void)onHeaderDefenseClick:(id)sender
{
    if ([AGPlayerInfo defaultPlayerInfo].defenseTimeLeft.curTimeLeft == 0)
    {
        [self openItemAlert:[self getLanguageString:@"6"] withType:@"d"];
    }
}

#pragma mark -
#pragma mark purchase

- (void)onReceiveInfoWithType_getPurchaseProductList:(NSDictionary *)info
{
    [[AGPurchaseProductList instance] updateWithInfo:info];
    
    CCAlertLayer *alert = self.purchaseAlertLayer;
    if (alert == nil)
    {
        alert = [CCAlertLayer showAlert:@"12.4-purchase.bmml"
                             parentNode:self];
        alert.tag = TAG_PURCHASE_ALERT;
    }
    
    CCNode *cellContainer = [CCNode node];
    float lastCellPosY = 0;
    for (AGPurchaseProduct *productInfo in [AGPurchaseProductList instance].productList)
    {        
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"12.5-purchase-info.bmml"
                                                           eventHandle:self];
        cell.position = ccp(0, lastCellPosY);
        lastCellPosY += cell.contentSize.height;
        [cellContainer addChild:cell];
        
        [productInfo updateDataToLayer:cell];
    }
    
    if ([AGPurchaseProductList instance].newbieProcuct.isPurchased == NO)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"12.5.1-newbie-purchase-info.bmml"
                                                           eventHandle:self];
        cell.position = ccp(0, lastCellPosY);
        [cellContainer addChild:cell];
        
        [[AGPurchaseProductList instance].newbieProcuct.productInfo updateDataToLayer:cell];
        [[cell getControlByName:@"title"] setString:[AGPurchaseProductList instance].newbieProcuct.title];
        [[cell getControlByName:@"detail"] setString:[AGPurchaseProductList instance].newbieProcuct.detail];
    }
    
    [[alert.balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer
                                                autoSetWithVectorMove:ccp(0, 1)];
}

- (void)onReceiveInfoWithType_purchaseProduct:(NSDictionary *)info
{
    [self postGetPlayerInfoRequest];
    
    if ([info objectForKey:@"item"] != nil)
    {
        AGStoreItemInfo *reward = [[AGStoreItemInfoCache instance]
                                   getItemInfoFromEquipId:[[info objectForKey:@"item"] intValue]];
        
        CCAlertLayer *alert = [CCAlertLayer showAlert:@"12.8-newbie-purchase-item.bmml"
                                           parentNode:self];
        [reward updateDataToLayer:alert.balsamiqLayer];
        
        [self postGetPurchaseProductList];
    }
}

- (void)onHeaderDollarClick:(id)sender
{
    [self postGetPurchaseProductList];
}

- (void)onAlertRechargeClick:(id)sender
{
    [self onCommonAlertOkClick:sender];
    [self onHeaderDollarClick:nil];
}

- (void)onBuyPurchaseClick:(id)sender
{
    NSString *productId = [[AGPurchaseProductList instance] getProductIdFromUniqueId:[sender tag]];
    
    NSLog(@"product id = %@", productId);
    
    //modify by ganhaidong 2012-12-23
    if ([[LanguageManager instance] isEnglishVersion]) {
        if ([[InAppPurchaseManager instance] canMakePurchases])
        {
            [[InAppPurchaseManager instance] loadStore:productId];
        }
    }
    if ([[LanguageManager instance] isChineseVersion]){
        if ([[PPAppPlatform defaultPlatform] userId]==0) {
            [[ShareManager instance] removeLoading];
            
            //登录按钮消息事件
            //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(buyPurchase:) name:@"k25ppLoginForBuyPurchaseNotification" object:nil];
            //[PPMainHelper instance].productId=productId;
            [PPControl pushViewWithTag:PP_LOGIN_VIEW_TAG];
        }else {
         
            [[PPMainHelper instance]buyPurchase:productId];
        }
    }
    self.isLoading = YES;
}
//add by ganhaidong 2012-12-23
-(void)buyPurchase:(NSNotification *)noti
{
    NSLog(@"buyPurchase:%@",[PPMainHelper instance].productId);
    [[NSNotificationCenter defaultCenter]  removeObserver:self name:@"k25ppLoginForBuyPurchaseNotification"  object:nil];
    [[PPMainHelper instance]buyPurchase:[PPMainHelper instance].productId];
    
}
- (void)showConfirmPurchase
{
    [CCAlertLayer showAlert:@"12.7-purchase-confirm.bmml"
                 parentNode:self];
}

- (void)onPurchaseSuccess:(NSString *)productId transactionReceipt:(NSString *)transactionReceipt
{
    [self postPurchaseProduct:[[AGPurchaseProductList instance] getUniqueIdFromProductId:productId]
           transactionReceipt:transactionReceipt];
    
    self.isLoading = NO;
    
    //MobClick
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
                          @"Product title:",productId,nil];
    [MobClick event:@"purchaseSucceed" attributes:dict];
}

- (void)onPurchaseFail:(NSString *)productId
{
    self.isLoading = NO;
    //MobClick
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
                          @"Product title:",productId,nil];
    [MobClick event:@"PurchaseFail" attributes:dict];
}

- (void)onPurchaseCancel:(NSString *)productId
{
    self.isLoading = NO;
    //MobClick
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:
                          @"Product title:",productId,nil];
    [MobClick event:@"PurchaseCancel" attributes:dict];
}

#pragma mark -
#pragma mark Levelup

- (void)onLevelUpOkClick:(id)sender
{
    [self onCommonAlertOkClick:sender];
    
    [self onEventHappened:@"LevelUpOk"];
}

- (void)onPlayerLevelUp
{
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"11-levelup.bmml"
                                       parentNode:self];
    alert.tag = TAG_LEVEL_UP_ALERT;
    
    [[alert.balsamiqLayer getControlByName:@"level"] setString:
     [NSString stringWithFormat:@"%d", [AGPlayerInfo defaultPlayerInfo].level]];
    
    [[alert.balsamiqLayer getControlByName:@"health"] setString:
     [NSString stringWithFormat:@"%d + %d", [AGPlayerInfo defaultPlayerInfo].maxHealth, [AGPlayerInfo defaultPlayerInfo].upHealth]];
    [[alert.balsamiqLayer getControlByName:@"energy"] setString:
     [NSString stringWithFormat:@"%d + %d", [AGPlayerInfo defaultPlayerInfo].maxEnergy, [AGPlayerInfo defaultPlayerInfo].upEnergy]];
    [[alert.balsamiqLayer getControlByName:@"attack"] setString:
     [NSString stringWithFormat:@"%d + %d", [AGPlayerInfo defaultPlayerInfo].maxAttack, [AGPlayerInfo defaultPlayerInfo].upAttack]];
    [[alert.balsamiqLayer getControlByName:@"defense"] setString:
     [NSString stringWithFormat:@"%d + %d", [AGPlayerInfo defaultPlayerInfo].maxDefense, [AGPlayerInfo defaultPlayerInfo].upDefense]];
    [[alert.balsamiqLayer getControlByName:@"up-coin"] setString:
     [NSString stringWithFormat:@"%d", [AGPlayerInfo defaultPlayerInfo].upCoin]];
    [[alert.balsamiqLayer getControlByName:@"up-dollar"] setString:
     [NSString stringWithFormat:@"%d", [AGPlayerInfo defaultPlayerInfo].upDollar]];
    
    [[alert.balsamiqLayer getControlByName:@"detail"] setString:[AGPlayerInfo defaultPlayerInfo].levelDetail];

    [[SoundManager instance] playEffectLevelUp];
    [self onEventHappened:@"OnLevelUp"];
}

- (void)closeLevelUpAlert
{
    if (self.levelUpAlertLayer != nil)
    {
        [self onLevelUpOkClick:self.levelUpAlertLayer];
    }
}

#pragma mark -
#pragma mark show system tip

- (void)showSystemTip:(NSString *)message
{
    CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"0-system-tip.bmml"
                                                        eventHandle:self];
    [self addChild:layer z:INT_MAX];
    
    [[layer getControlByName:@"message"] setString:message];
    
    for (CCNode<CCRGBAProtocol> *child in layer.children)
    {
        child.opacity = 0;
        [child runAction:[CCSequence actions:
                          [CCFadeIn actionWithDuration:0.5f],
                          [CCDelayTime actionWithDuration:2.0f],
                          [CCFadeOut actionWithDuration:0.5f],
                          nil]];
    }
    
    [layer runAction:[CCSequence actions:
                      [CCDelayTime actionWithDuration:3.0f],
                      [CCCallFunc actionWithTarget:layer selector:@selector(removeFromParentAndCleanup:)],
                      nil]];
}

#pragma mark -
#pragma mark Challenge opponent

- (void)onBattleCancelClick:(id)sender
{
    [self onCommonAlertCloseClick:sender];
}

- (void)onBattlePkClick:(id)sender
{
    [self postChallengeOpponentRequest:[sender tag]];
    
//    [CCAlertLayer removeAlertFromNode:sender];
}

- (void)setNode:(CCNode *)node toParentSpace:(CCNode *)parentNode
{
    node.position = [parentNode convertToNodeSpace:[node convertToWorldSpaceAR:CGPointZero]];
    
    [node removeFromParentAndCleanup:YES];
    [parentNode addChild:node];
}

#pragma mark -
#pragma mark Share

//modify by ganhaidong 2012-12-22
- (void)onFacebookClick:(id)sender
{
    if ([[LanguageManager instance] isEnglishVersion]) {
        [[ShareManager instance] showFacebook];
    }
    if ([[LanguageManager instance] isChineseVersion]) {
        self.isLoading=YES;
        [ShareManager instance].delegate=self;
        [[ShareManager instance] showSinaShare];
    }
}

//modify by ganhaidong 2012-12-22
- (void)onTwitterClick:(id)sender
{
    if ([[LanguageManager instance] isEnglishVersion]) {
        [[ShareManager instance] showTwitter];
    }
    if ([[LanguageManager instance] isChineseVersion]) {
        self.isLoading=YES;
        [ShareManager instance].delegate=self;
        [[ShareManager instance] showQQShare];
    }
}

#pragma mark -
#pragma mark challenge

- (void)challengeOpponent:(int)opponentId
{
    if ([AGPlayerInfo defaultPlayerInfo].curHealth == 0)
    {
        [self openItemAlert:[self getLanguageString:@"2"] withType:@"h"];
    }
    else
    {
        AGOpponentInfo *opponentInfo = [[AGOpponentInfoCache instance]
                                        getOpponentInfoFromId:opponentId];
        
        if (opponentInfo != nil)
        {
            CCAlertLayer *alert = [CCAlertLayer showAlert:@"4.8-battle-info.bmml"
                                               parentNode:self];
            alert.tag = TAG_BATTLE_ALERT;
            
            CCSprite *sprMy = [alert.balsamiqLayer getControlByName:@"image_my"];
            sprMy.texture = [[CharacterImageManager instance] getTextureFromImageName:
                             [AGPlayerInfo defaultPlayerInfo].imageName];
            CCSprite *sprOpponent = [alert.balsamiqLayer getControlByName:@"image_opponent"];
            sprOpponent.texture = [[CharacterImageManager instance] getTextureFromImageName:
                                   opponentInfo.imageName];
            sprOpponent.flipX = YES;
            
            [[alert.balsamiqLayer getControlByName:@"name-my"] setString:[AGPlayerInfo defaultPlayerInfo].name];
            [self setNode:[alert.balsamiqLayer getControlByName:@"name-my"] toParentSpace:sprMy];
            [[alert.balsamiqLayer getControlByName:@"name-opponent"] setString:opponentInfo.name];
            [self setNode:[alert.balsamiqLayer getControlByName:@"name-opponent"] toParentSpace:sprOpponent];
            
            CCSprite *sprSignHeeler = [alert.balsamiqLayer getControlByName:@"image_sign_heeler"];
            [self setNode:sprSignHeeler toParentSpace:sprOpponent];
            sprSignHeeler.visible = opponentInfo.isHeeler;
            
            CCLabelTTF *labNotHeller = [alert.balsamiqLayer getControlByName:@"label-not-heeler"];
            labNotHeller.visible = !opponentInfo.isHeeler;
            labNotHeller.string = opponentInfo.isMan ? [self getLanguageString:@"4004"] : [self getLanguageString:@"4005"];
            
            [[alert.balsamiqLayer getControlByName:@"label-not-heeler"] setVisible:!opponentInfo.isHeeler];
            [[alert.balsamiqLayer getControlByName:@"label-heeler"] setVisible:opponentInfo.isHeeler];
            
            CGPoint movePosMy = {-200, 0};
            sprMy.position = ccpAdd(sprMy.position, movePosMy);
            [sprMy runAction:[CCEaseBackOut actionWithAction:
                              [CCMoveBy actionWithDuration:0.5f position:ccpNeg(movePosMy)]]];
            
            CGPoint movePosOpponent = {200, 0};
            sprOpponent.position = ccpAdd(sprOpponent.position, movePosOpponent);
            [sprOpponent runAction:[CCEaseBackOut actionWithAction:
                                    [CCMoveBy actionWithDuration:0.5f position:ccpNeg(movePosOpponent)]]];
            
            [[alert.balsamiqLayer getControlByName:@"BattlePk"] setTag:opponentInfo.uniqueId];

            [self onEventHappened:@"ShowBattleDetail"];
        }
    }
}

- (void)onChallengeItemClick:(id)sender
{
    [[SoundManager instance] continuePlayBackgroundMusic];
    
    [[CCDirector sharedDirector] replaceScene:[ItemLayer sceneWithTab:1]];
}

- (void)onChallengeLostCloseClick:(id)sender
{
    [[SoundManager instance] continuePlayBackgroundMusic];
    
    [CCAlertLayer removeAlertFromNode:sender];
}

- (void)onChallengeWinOkClick:(id)sender
{
    [[SoundManager instance] continuePlayBackgroundMusic];
    
    [CCAlertLayer removeAlertFromNode:sender];
    
    [self onEventHappened:@"ChallengeSuccessOk"];
}

- (void)onChallengeWinCloseClick:(id)sender
{
    [[SoundManager instance] continuePlayBackgroundMusic];
    
    [CCAlertLayer removeAlertFromNode:sender];
}

- (void)onChallengeDetailsClick:(id)sender
{
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"4.4-details.bmml"
                                       parentNode:self];
    
    [[alert.balsamiqLayer getControlByName:@"my-name"] setString:[AGPlayerInfo defaultPlayerInfo].name];
    [[alert.balsamiqLayer getControlByName:@"my-level"] setString:
     [NSString stringWithFormat:@"%d", [AGPlayerInfo defaultPlayerInfo].level]];
    [[alert.balsamiqLayer getControlByName:@"my-attack"] setString:
     [NSString stringWithFormat:@"%d", self.challengeResult.myTotalAttack]];
    
    [[alert.balsamiqLayer getControlByName:@"opponent-name"] setString:self.challengeResult.opponentInfo.name];
    [[alert.balsamiqLayer getControlByName:@"opponent-level"] setString:
     [NSString stringWithFormat:@"%d", self.challengeResult.opponentInfo.level]];
    [[alert.balsamiqLayer getControlByName:@"opponent-defense"] setString:
     [NSString stringWithFormat:@"%d", self.challengeResult.opponentTotalDefense]];
    
    CCNode *attackCellContainer = [CCNode node];
    for (AGOpponentInfo *info in self.challengeResult.myServentList)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"4.5-servant-info.bmml"
                                                           eventHandle:self];
        
        cell.position = ccp(0, [self.challengeResult.myServentList indexOfObject:info] * cell.contentSize.height);
        [attackCellContainer addChild:cell];
        
        [info updateDataToLayer:cell];
    }
    [[alert.balsamiqLayer getControlByName:@"table-attack"] setCellContainer:attackCellContainer autoSetWithVectorMove:ccp(0, 1)];
    
    CCNode *defenseCellContainer = [CCNode node];
    for (AGOpponentInfo *info in self.challengeResult.opponentServentList)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"4.6-opponent-servant-info.bmml"
                                                           eventHandle:self];
        cell.position = ccp(0, [self.challengeResult.opponentServentList indexOfObject:info] * cell.contentSize.height);
        [defenseCellContainer addChild:cell];
        
        [info updateDataToLayer:cell];
    }
    [[alert.balsamiqLayer getControlByName:@"table-defense"] setCellContainer:defenseCellContainer autoSetWithVectorMove:ccp(0, 1)];
}

- (void)updateAwardToLayer:(CCBalsamiqLayer *)layer
{
    [[layer getControlByName:@"coin"] setString:
     [NSString stringWithFormat:@"%d", self.challengeResult.gainCoin]];
    [[layer getControlByName:@"exp"] setString:
     [NSString stringWithFormat:@"%d", self.challengeResult.gainExp]];
}

- (void)showLoseLayer
{
    [[SoundManager instance] playEffectLost];
    
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"4.3-lose.bmml" parentNode:self];
    [self updateAwardToLayer:alert.balsamiqLayer];
}

- (void)showWinLayer
{
    [[SoundManager instance] playEffectWin];
    [[SoundManager instance] playEffectAttackSign];
    
    if (self.challengeResult.isCatchHeeler)
    {
        CCAlertLayer *alert = [CCAlertLayer showAlert:@"4.2-win.bmml" parentNode:self];
        [self updateAwardToLayer:alert.balsamiqLayer];
        
        CCSprite *sprConquer = [alert.balsamiqLayer getControlByName:@"image_conquer"];
        
        sprConquer.scale = 10;
        sprConquer.opacity = 0;
        
        [sprConquer runAction:[CCSpawn actionOne:[CCFadeIn actionWithDuration:0.5f]
                                             two:[CCScaleTo actionWithDuration:0.5f scale:1]]];
        
        [[alert.balsamiqLayer getControlByName:@"image_player"] setTexture:
         [[CharacterImageManager instance] getTextureFromImageName:self.challengeResult.opponentInfo.imageName]];
        [self.challengeResult.opponentInfo updateDataToLayer:alert.balsamiqLayer];
        
        [self setLabel:[alert.balsamiqLayer getControlByName:@"detail"]
            toLanguage:self.challengeResult.opponentInfo.isMan ? @"4001" : @"4002"];
    }
    else
    {
        CCAlertLayer *alert = [CCAlertLayer showAlert:@"4.2.1-win-no-heeler.bmml" parentNode:self];
        [self updateAwardToLayer:alert.balsamiqLayer];
    }
    

    [self onEventHappened:@"ChallengeSuccess"];
}

- (void)onChallengeVideoPlayDone
{
    [[self getAlertFromTag:TAG_BATTLE_ALERT] removeFromParentAndCleanup:YES];
    
    self.challengeResult.isWin
    ? [self showWinLayer]
    : [self showLoseLayer];
    
    [self postGetPlayerInfoRequest];
}

- (void)playFightVideoAndCallback
{
    [[CCVideoPlayer instance] playerVideo:@"fight"
                                   ofType:@"mp4"
                                 callback:[CCCallFunc actionWithTarget:self selector:@selector(onChallengeVideoPlayDone)]];
}

- (void)onReceiveInfoWithType_challengeOpponent:(NSDictionary *)info
{
    self.challengeResult = [AGChallengeResult challengeResultFromInfo:info];
    
    [self playFightVideoAndCallback];
}

#pragma mark -
#pragma mark show coin effect

- (void)moveCoin:(CGPoint)startPos targetSprite:(CCSprite *)sprTarget delay:(ccTime)delay
{
    CCSprite *sprite = [CCSprite spriteWithTexture:sprTarget.texture];
    [sprTarget.parent addChild:sprite z:sprTarget.zOrder];
    sprite.position = startPos;
    
    id moveAction = [CCSpawn actions:
                     [CCMoveTo actionWithDuration:0.5f position:sprTarget.position],
                     [CCScaleTo actionWithDuration:0.5f scale:0.0f],
                     nil];
    
    [sprite runAction:[CCSequence actions:
                       [CCDelayTime actionWithDuration:delay],
                       moveAction,
                       nil]];
}

- (void)showGainEffect:(int)coins
{
    [[SoundManager instance] playEffectGainCoin];
    
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"8.5-gain-effect.bmml"
                                       parentNode:self];
    
    CCSprite *sprTarget = [alert.balsamiqLayer getControlByName:@"image_target"];
    sprTarget.visible = NO;
    
    [[alert.balsamiqLayer getControlByName:@"coins"] setString:
     [NSString stringWithFormat:@"%d", coins]];
    
    [self moveCoin:ccp(100, 200) targetSprite:sprTarget delay:0];
    [self moveCoin:ccp(120, 210) targetSprite:sprTarget delay:0.1f];
    [self moveCoin:ccp(130, 220) targetSprite:sprTarget delay:0.2f];
    [self moveCoin:ccp(150, 230) targetSprite:sprTarget delay:0.3f];
    [self moveCoin:ccp(170, 240) targetSprite:sprTarget delay:0.4f];
    [self moveCoin:ccp(180, 210) targetSprite:sprTarget delay:0.5f];
    [self moveCoin:ccp(170, 210) targetSprite:sprTarget delay:0.6f];
    [self moveCoin:ccp(190, 220) targetSprite:sprTarget delay:0.7f];
    [self moveCoin:ccp(200, 210) targetSprite:sprTarget delay:0.8f];
    
    [alert runAction:[CCSequence actions:
                      [CCDelayTime actionWithDuration:1.5f],
                      [CCCallFunc actionWithTarget:alert selector:@selector(removeFromParentAndCleanup:)],
                      nil]];
}

#pragma mark -
#pragma mark event happen

- (void)onEventHappened:(NSString *)eventName
{
    [[GuideEventHandle instance] onEventHappened:eventName];
}

#pragma mark -
#pragma mark Game Requests

- (void)onReceiveSuccess:(NSURLConnection *)connection jsonInfo:(NSDictionary *)info
{
    NSString *type = [info objectForKey:@"type"];
    SEL method = type.length > 0 ? NSSelectorFromString([NSString stringWithFormat:@"onReceiveInfoWithType_%@:", type]) : nil;
    
    if ([self respondsToSelector:method])
    {
        [self performSelector:method withObject:info];
    }
    else
    {
        if ([info objectForKey:@"msg"] != nil)
        {
            [self showSystemTip:[info objectForKey:@"msg"]];
        }
        
        CCLOG(@"%@#onReceiveSuccess type = %@, info = %@", NSStringFromClass([self class]), type, info);
    }
}

- (void)onReceiveFail:(NSURLConnection *)connection
{
    if ([self isKindOfClass:[IntroLayer class]] == NO)
    {
        [[CCDirector sharedDirector] replaceScene:[IntroLayer scene]];
    }
    
    [[[[UIAlertView alloc] initWithTitle:nil
                                 message:[self getLanguageString:@"1"]
                                delegate:self
                       cancelButtonTitle:@"OK"
                       otherButtonTitles:nil] autorelease] show];
}

#pragma mark -
#pragma mark updateDefaultPlayerInfo

- (void)updateHealthTimeLeft
{
    CCLabelTTF *labHealth = [headerLayer getControlByName:@"label-health"];
    
    [[headerLayer getControlByName:@"health"] setString:
     [NSString stringWithFormat:@"%d / %d", [AGPlayerInfo defaultPlayerInfo].curHealth, [AGPlayerInfo defaultPlayerInfo].maxHealth]];
    
    [CCTimeManageNode stopCountDown:labHealth];
    
    if ([AGPlayerInfo defaultPlayerInfo].isFullHealth)
    {
        labHealth.string = [self getLanguageString:@"2001"];//@"Health";
    }
    else
    {
        
        [CCTimeManageNode startCountDown:labHealth
                                timeLeft:[AGPlayerInfo defaultPlayerInfo].recoverHealthTime
                                isHHMMSS:NO
                          withStopAction:[CCCallFunc actionWithTarget:self selector:@selector(updateHealthTimeLeft)]];        
    }
}

- (void)setAlertCurrentEnergy
{
    [[self.itemAlertLayer.balsamiqLayer getControlByName:@"message"] setString:
     [NSString stringWithFormat:[self getLanguageString:@"5"], [AGPlayerInfo defaultPlayerInfo].curEnergy, [AGPlayerInfo defaultPlayerInfo].maxEnergy]];
}

- (void)updateEnergyTimeLeft
{
    CCLabelTTF *labEnergy = [headerLayer getControlByName:@"label-energy"];
    
    [[headerLayer getControlByName:@"energy"] setString:
     [NSString stringWithFormat:@"%d / %d", [AGPlayerInfo defaultPlayerInfo].curEnergy, [AGPlayerInfo defaultPlayerInfo].maxEnergy]];
    
    [self setAlertCurrentEnergy];
    
    [CCTimeManageNode stopCountDown:labEnergy];
    
    if ([AGPlayerInfo defaultPlayerInfo].isFullEnergy)
    {
        labEnergy.string = [self getLanguageString:@"2002"];//@"Energy";
    }
    else
    {
        [CCTimeManageNode startCountDown:labEnergy
                                timeLeft:[AGPlayerInfo defaultPlayerInfo].recoverEnergyTime
                                isHHMMSS:NO
                          withStopAction:[CCCallFunc actionWithTarget:self selector:@selector(updateEnergyTimeLeft)]];        
    }
}

- (void)updateAttackTimeLeft
{
    CCLabelTTF *labAttack = [headerLayer getControlByName:@"label-attack"];
    
    [[headerLayer getControlByName:@"attack"] setString:
     [NSString stringWithFormat:@"%d", [AGPlayerInfo defaultPlayerInfo].maxAttack]];
        
    if ([AGPlayerInfo defaultPlayerInfo].attackTimeLeft.curTimeLeft == 0)
    {
        labAttack.string = [self getLanguageString:@"2003"];//@"Attack";
    }
    else
    {
        [CCTimeManageNode startCountDown:labAttack
                                timeLeft:[AGPlayerInfo defaultPlayerInfo].attackTimeLeft.curTimeLeft
                                isHHMMSS:NO
                          withStopAction:[CCCallFunc actionWithTarget:self selector:@selector(updateAttackTimeLeft)]];        
    }
}

- (void)updateDefenseTimeLeft
{
    CCLabelTTF *labDefense = [headerLayer getControlByName:@"label-defense"];
    
    [[headerLayer getControlByName:@"defense"] setString:
     [NSString stringWithFormat:@"%d", [AGPlayerInfo defaultPlayerInfo].maxDefense]];
    
    if ([AGPlayerInfo defaultPlayerInfo].defenseTimeLeft.curTimeLeft == 0)
    {
        labDefense.string = [self getLanguageString:@"2004"];//@"Defense";
    }
    else
    {
        [CCTimeManageNode startCountDown:labDefense
                                timeLeft:[AGPlayerInfo defaultPlayerInfo].defenseTimeLeft.curTimeLeft
                                isHHMMSS:NO
                          withStopAction:[CCCallFunc actionWithTarget:self selector:@selector(updateDefenseTimeLeft)]];
    }
}

- (void)updateDefaultPlayerInfo
{
    if (headerLayer == nil)
    {
        return;
    }
    
    [[headerLayer getControlByName:@"level"] setString:
     [NSString stringWithFormat:@"%d", [AGPlayerInfo defaultPlayerInfo].level]];
    
    [[headerLayer getControlByName:@"coin"] setString:
     [NSString stringWithFormat:@"%d", [AGPlayerInfo defaultPlayerInfo].coins]];
    
    [[headerLayer getControlByName:@"dollar"] setString:
     [NSString stringWithFormat:@"%d", [AGPlayerInfo defaultPlayerInfo].dollar]];
    
    if ([AGPlayerInfo defaultPlayerInfo].maxExp != 0)
    {
        CCProgressTimer *barExp = [headerLayer getControlByName:@"bar_exp"];
        barExp.percentage = [AGPlayerInfo defaultPlayerInfo].curExp / (float)[AGPlayerInfo defaultPlayerInfo].maxExp * 100;
    }
    
    [[headerLayer getControlByName:@"label-exp"] setString:
     [NSString stringWithFormat:@"%d/%d", [AGPlayerInfo defaultPlayerInfo].curExp, [AGPlayerInfo defaultPlayerInfo].maxExp]];
    
    [self updateHealthTimeLeft];
    [self updateEnergyTimeLeft];
    [self updateAttackTimeLeft];
    [self updateDefenseTimeLeft];
    
    if ([AGPlayerInfo defaultPlayerInfo].defenseItemCount > 0)
    {
        [[headerLayer getControlByName:@"defense-count"] setString:
         [NSString stringWithFormat:@"%d", [AGPlayerInfo defaultPlayerInfo].defenseItemCount]];
        [[headerLayer getControlByName:@"image_defense_count"] setVisible:YES];
    }
    else
    {
        [[headerLayer getControlByName:@"defense-count"] setString:@""];
        [[headerLayer getControlByName:@"image_defense_count"] setVisible:NO];
    }
    
    if ([AGPlayerInfo defaultPlayerInfo].hasLevelUp)
    {
        [self onPlayerLevelUp];
        [AGPlayerInfo defaultPlayerInfo].hasLevelUp = NO;
    }
    
    CCMenuItemImage *btnAttack = [headerLayer getControlByName:@"HeaderAttack"];
    CCMenuItemImage *btnDefense = [headerLayer getControlByName:@"HeaderDefense"];
    
    btnAttack.opacity = 0;
    btnDefense.opacity = 0;
}

- (void)onReceiveInfoWithType_getPlayerInfo:(NSDictionary *)info
{
    [[AGPlayerInfo defaultPlayerInfo] updateWithInfo:info];
    [self updateDefaultPlayerInfo];
}

- (void)onReceiveInfoWithType_useProps:(NSDictionary *)info
{
    [self showSystemTip:[self getLanguageString:@"12002"]];
    
    [self postGetPlayerInfoRequest];
    
    AGShopItemInfo *item = [AGShopItemInfo shopItemFromUseAndBuyInfo:info];
    if (self.itemAlertLayer != nil)
    {
        [[self.itemAlertLayer.balsamiqLayer getControlByName:@"AlertUseItem"] setIsEnabled:(item.count > 0)];
        [item updateDataToLayer:[self.itemAlertLayer.balsamiqLayer getControlByName:@"item"]];
    }
}

- (void)onReceiveInfoWithType_buyPropsGoods:(NSDictionary *)info
{
    [self showSystemTip:[self getLanguageString:@"12001"]];
    
    [self postGetPlayerInfoRequest];
    
    AGShopItemInfo *item = [AGShopItemInfo shopItemFromUseAndBuyInfo:info];
    if (self.itemAlertLayer != nil)
    {
        [[self.itemAlertLayer.balsamiqLayer getControlByName:@"AlertUseItem"] setIsEnabled:(item.count > 0)];
        [item updateDataToLayer:[self.itemAlertLayer.balsamiqLayer getControlByName:@"item"]];
    }
}

- (void)onReceiveInfoWithType_energy_not_enough:(NSDictionary *)info
{
    [self onHeaderEnergyClick:nil];
}

- (void)onReceiveInfoWithType_coin_not_enough:(NSDictionary *)info
{
    [self onHeaderCoinClick:nil];
}

- (void)onReceiveInfoWithType_dollar_not_enough:(NSDictionary *)info
{
    [self showConfirmPurchase];
}

- (void)onReceiveInfoWithType_addDollar:(NSDictionary *)info
{
    [self postGetPlayerInfoRequest];
}

#pragma mark -
#pragma mark NSURLConnectionDataDelegate

- (void)removeConnectFromCache:(NSURLConnection *)connection
{
    [connectAndReciveDataDic removeObjectForKey:[NSValue valueWithNonretainedObject:connection]];
    
    if (connectAndReciveDataDic.count == 0)
    {
        self.isLoading = NO;
    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    NSLog(@"error = %@", error);
    
    [self removeConnectFromCache:connection];
    
    [self onReceiveFail:connection];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    [[connectAndReciveDataDic objectForKey:[NSValue valueWithNonretainedObject:connection]] appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    [self onReceiveSuccess:connection
                  jsonInfo:[NSDictionary dictionaryWithJSONData:[connectAndReciveDataDic objectForKey:[NSValue valueWithNonretainedObject:connection]]
                                                          error:nil]];
    
    [self removeConnectFromCache:connection];
}

- (NSString *)getEncodeString:(NSString *)string
{
//    base64Decode();
    return string;
}

- (NSString *)parseParamFromDictionary:(NSDictionary *)dic
{
    NSMutableString *string = [NSMutableString string];
    
    for (NSString *key in [dic allKeys])
    {
        NSString *value = [dic objectForKey:key];
        [string appendFormat:@"%@=%@&", key, value];
    }
    
    return [self getEncodeString:string];
}

- (void)postRequestToAmaricanGangsterServer:(NSDictionary *)postInfo
{
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:
                                    [NSURL URLWithString:[LanguageManager serverAddress]]];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-type"];
    
    [request setHTTPBody:[[self parseParamFromDictionary:postInfo] dataUsingEncoding:NSUTF8StringEncoding]];

    NSURLConnection *connection = [NSURLConnection connectionWithRequest:request delegate:self];
    [connectAndReciveDataDic setObject:[NSMutableData data] forKey:[NSValue valueWithNonretainedObject:connection]];
    [connection start];
    
    self.isLoading = YES;
}

#pragma mark -
#pragma mark Post requestes

- (void)postLoginRequest
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"login", @"method",
                                               [AGPushToken instance].token, @"pushToken",
                                               nil]];
}

- (void)postRegisterRequest:(AGLoginInfo *)registerInfo
{
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                   @"JSON", @"format",
                                   @"register", @"method",
                                   registerInfo.type, @"type",
                                   registerInfo.imageName, @"headerId",
                                   registerInfo.sex, @"sex",
                                   registerInfo.name, @"name",
                                   [AGPushToken instance].token, @"pushToken",
                                   nil];
    
    [self postRequestToAmaricanGangsterServer:params];
}

- (void)postGetPlayerInfoRequest
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getPlayerInfo", @"method",
                                               nil]];
}

- (void)postGetDayAwardsRequest:(int)gridPosition
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getDayAwards", @"method",
                                               [NSString stringWithFormat:@"%d", gridPosition], @"position",
                                               nil]];
}

- (void)postClearGuideMission
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"clearGuideMission", @"method",
                                               nil]];
}

- (void)postGetMyServantList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getMyServantList", @"method",
                                               nil]];
}

- (void)postGetServantInfoRequest:(int)servantId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getMyServantBind", @"method",
                                               [NSString stringWithFormat:@"%d", servantId], @"servantId",
                                               nil]];
}

- (void)postGetMyServantHeader
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getMyServantHeaders", @"method",
                                               nil]];
}

- (void)postChangeServant:(int)servantId pos:(int)pos
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"changeServant", @"method",
                                               [NSString stringWithFormat:@"%d", pos], @"pos",
                                               [NSString stringWithFormat:@"%d", servantId], @"servantId",
                                               nil]];
}

- (void)postGetEquipmentListFromPosRequest:(int)pos
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getEquipmentListFromPos", @"method",
                                               [NSString stringWithFormat:@"%d", pos], @"iPos",
                                               nil]];
}

- (void)postChangeEquipment:(int)equipmentId servantId:(int)servantId pos:(int)pos
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"changeServantEquip", @"method",
                                               [NSString stringWithFormat:@"%d", pos], @"iPos",
                                               [NSString stringWithFormat:@"%d", servantId], @"servantId",
                                               [NSString stringWithFormat:@"%d", equipmentId], @"equipId",
                                               nil]];
}

- (void)postGetRefineListRequest:(int)equipmentType
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getRefineList", @"method",
                                               [NSString stringWithFormat:@"%d", equipmentType], @"type",
                                               nil]];
}

- (void)postRefineItemRequest:(int)itemId isUseItem:(BOOL)isUseItem
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"refineItem", @"method",
                                               [NSString stringWithFormat:@"%d", isUseItem], @"isUseItem",
                                               [NSString stringWithFormat:@"%d", itemId], @"id",
                                               nil]];
}

- (void)postGetRefineInfo
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getRefineInfo", @"method",
                                               nil]];
}

- (void)postTryClearRefineTime
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"tryClearRefineTime", @"method",
                                               nil]];
}

- (void)postClearRefineTime
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"clearRefineTime", @"method",
                                               nil]];
}

- (void)postGetTotalStoreListRequest
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getTotalStoreList", @"method",
                                               nil]];
}

- (void)postGetStoreList:(NSString *)listKind
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getStoreList", @"method",
                                               listKind, @"types",
                                               nil]];
}

- (void)postGetPackList:(NSString *)listKind
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getPackList", @"method",
                                               listKind, @"type",
                                               nil]];
}

- (void)postBuyItemRequest:(int)itemId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"buyStoreGoods", @"method",
                                               [NSString stringWithFormat:@"%d", itemId], @"equipId",
                                               nil]];
}

- (void)postSellItemRequest:(int)goodsId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"sellPackGoods", @"method",
                                               [NSString stringWithFormat:@"%d", goodsId], @"goodsId",
                                               nil]];
}

#pragma mark -
#pragma mark business

- (void)postGetBusinessList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getBusinessList", @"method",
                                               nil]];
}

- (void)postUpBusiness:(int)type level:(int)level
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"upBusiness", @"method",
                                               [NSString stringWithFormat:@"%d", type], @"ctype",
                                               [NSString stringWithFormat:@"%d", level], @"clevel",
                                               nil]];
}

- (void)postGainBusiness:(int)type level:(int)level
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"gainBusiness", @"method",
                                               [NSString stringWithFormat:@"%d", type], @"ctype",
                                               [NSString stringWithFormat:@"%d", level], @"clevel",
                                               nil]];
}

- (void)postSpeedUpBusiness:(int)type level:(int)level itemId:(int)itemId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"speedGainBusiness", @"method",
                                               [NSString stringWithFormat:@"%d", type], @"ctype",
                                               [NSString stringWithFormat:@"%d", level], @"clevel",
                                               [NSString stringWithFormat:@"%d", itemId], @"magicId",
                                               @"0", @"magicId",
                                               nil]];
}

- (void)postIncreaseBusiness:(int)type level:(int)level servantList:(NSString *)servantList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"increaseBusiness", @"method",
                                               [NSString stringWithFormat:@"%d", type], @"ctype",
                                               [NSString stringWithFormat:@"%d", level], @"clevel",
                                               servantList, @"servantList",
                                               @"0", @"magicId",
                                               nil]];
}

- (void)postGetOpponentListRequest:(NSString *)condition
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getOpponentList", @"method",
                                               condition, @"condition",
                                               nil]];
}

- (void)postGetRevengeListRequest
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getRevengeList", @"method",
                                               nil]];
}

- (void)postChallengeOpponentRequest:(int)playerId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"challengeOpponent", @"method",
                                               [NSString stringWithFormat:@"%d", playerId], @"oppPlayerId",
                                               nil]];
}

- (void)postGetMissionIndex
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getMissionIndex", @"method",
                                               nil]];
}

- (void)postGetAccessPlaceList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getAccessPlaceList", @"method",
                                               nil]];
}

- (void)postGetPlaceMissionRequest:(int)mapId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getPlaceMission", @"method",
                                               [NSString stringWithFormat:@"%d", mapId], @"mapId",
                                               nil]];
}

- (void)postDoMissionRequest:(int)missionId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"doMission", @"method",
                                               [NSString stringWithFormat:@"%d", missionId], @"missionId",
                                               nil]];
}

- (void)postDoBossMissionRequest:(int)bossId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"pkBoss", @"method",
                                               [NSString stringWithFormat:@"%d", bossId], @"bossId",
                                               nil]];
}

- (void)postTryBailPlayer
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"tryBail", @"method",
                                               nil]];
}

- (void)postBailPlayer
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"bailPlayer", @"method",
                                               nil]];
}

- (void)postGetPropsList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getPropsList", @"method",
                                               nil]];
}

- (void)postGetAlertPropsList:(int)propsId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"buyAlertPropsList", @"method",
                                               [NSString stringWithFormat:@"%d", propsId], @"propsId",
                                               nil]];
}

- (void)postBuyPropsGoods:(int)propsId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"buyPropsGoods", @"method",
                                               [NSString stringWithFormat:@"%d", propsId], @"propsId",
                                               nil]];
}

- (void)postBuyGiftBagProps:(int)propsId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"buyGiftBagProps", @"method",
                                               [NSString stringWithFormat:@"%d", propsId], @"propsId",
                                               nil]];
}

- (void)postUsePropsGoods:(int)propsId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"useProps", @"method",
                                               [NSString stringWithFormat:@"%d", propsId], @"propsId",
                                               nil]];
}

- (void)postGetWeaponList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getWeaponList", @"method",
                                               nil]];
}

- (void)postBuyWeaponRequest:(int)itemId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"buyWeaponGoods", @"method",
                                               [NSString stringWithFormat:@"%d", itemId], @"equipId",
                                               nil]];
}

- (void)postGetCardList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getCardList", @"method",
                                               nil]];
}

- (void)postExchangeCard:(int)cardId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"exchangeProps", @"method",
                                               [NSString stringWithFormat:@"%d", cardId], @"cardId",
                                               nil]];
}

- (void)postAddDollar:(int)dollar
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"addDollar", @"method",
                                               [NSString stringWithFormat:@"%d", dollar], @"dollar",
                                               nil]];
}

- (void)postGetSpinWeaponList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getSpinWeaponList", @"method",
                                               nil]];
}

- (void)postStartSlotMachine:(int)slotId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"startSlotMachine", @"method",
                                               [NSString stringWithFormat:@"%d", slotId], @"Id",
                                               nil]];
}

- (void)postGetPurchaseProductList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getPurchaseProductList", @"method",
                                               nil]];
}

- (void)postGeneratorPurchaseOrder:(int)productId count:(int)count
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"generatorPurchaseOrder", @"method",
                                               [NSString stringWithFormat:@"%d", productId], @"id",
                                               [NSString stringWithFormat:@"%d", count], @"num",
                                               nil]];
}

- (void)postPurchaseProduct:(int)productId transactionReceipt:(NSString *)transactionId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"purchaseProduct", @"method",
                                               [NSString stringWithFormat:@"%d", productId], @"Id",
                                               transactionId, @"transactionId",
                                               nil]];
}

- (void)postGetArenaRankList:(int)pageNum
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getArenaRankList", @"method",
                                               [NSString stringWithFormat:@"%d", pageNum], @"pageNum",
                                               nil]];
}

- (void)postGetArenaOpponentList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getArenaOpponentList", @"method",
                                               nil]];
}

- (void)postChallengeArenaOpponent:(int)oppId
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"challengeArenaOpponent", @"method",
                                               [NSString stringWithFormat:@"%d", oppId], @"oppPlayerId",
                                               nil]];
}

- (void)postGetMyArena
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getMyArena", @"method",
                                               nil]];

}

- (void)postGetArenaMsgList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getArenaMsgList", @"method",
                                               nil]];
}

- (void)postGetGainRankingAward
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getGainRankingAward", @"method",
                                               nil]];
}

- (void)postGainRankingAward
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"gainRankingAward", @"method",
                                               nil]];
}

- (void)postGetSettings
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getSettings", @"method",
                                               nil]];
}

- (void)postUpdateSettings:(NSString *)settingString
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"updateSettings", @"method",
                                               settingString, @"param",
                                               nil]];
}

- (void)postGetBattleMsgList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getBattleMsgList", @"method",
                                               nil]];
}

- (void)postGetHeelerMsgList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getHeelerMsgList", @"method",
                                               nil]];
}

- (void)postGetSystemMsgList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getSystemMsgList", @"method",
                                               nil]];
}

- (void)postGetNoticeList
{
    [self postRequestToAmaricanGangsterServer:[NSDictionary dictionaryWithObjectsAndKeys:
                                               [[UIDevice currentDevice] uniqueGlobalDeviceIdentifier], @"devId",
                                               @"JSON", @"format",
                                               @"getNoticeList", @"method",
                                               nil]];
}

#pragma mark -
#pragma mark HeaderLayer



#pragma mark -
#pragma mark ToolBar

- (void)onSelect_radio_Tool_home:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[HomeLayer scene]];
}

- (void)onSelect_radio_Tool_battle:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[AttackLayer scene]];
}

- (void)onSelect_radio_Tool_mission:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[MissionLayer scene]];
}

- (void)onSelect_radio_Tool_group:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[GangsterLayer scene]];
}

- (void)onSelect_radio_Tool_item:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[ItemLayer sceneWithTab:0]];
}

- (void)onSelect_radio_Tool_store:(id)sender
{
//    static CCScene *scene = nil;
//    if (scene == nil)
//    {
//        scene = [StoreLayer scene];
//        [scene retain];
//    }
//    
//    [[CCDirector sharedDirector] replaceScene:scene];   
    [[CCDirector sharedDirector] replaceScene:[StoreLayer scene]];
}

- (void)onSelect_radio_Tool_pack:(id)sender
{
//    static CCScene *scene = nil;
//    if (scene == nil)
//    {
//        scene = [PackLayer scene];
//        [scene retain];
//    }
//    
//    [[CCDirector sharedDirector] replaceScene:scene];   
    [[CCDirector sharedDirector] replaceScene:[PackLayer scene]];
}

@end
