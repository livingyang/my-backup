//
//  PlayerCreateLayer.m
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-4-27.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "PlayerCreateLayer.h"
#import "CCBalsamiqLayer.h"
#import "PlayerTypeSelectLayer.h"
#import "CharacterImageManager.h"
#import "AGLoginInfo.h"
#import "LanguageManager.h"

const CGPoint EditOffset = {0, 200};
#define MAX_CHARACTER_INDEX (7)

@implementation PlayerCreateLayer

@synthesize manImageNameAndTextureDic, womanImageNameAndTextureDic;

+ (CCScene *)scene
{
    CCScene *scene = [CCScene node];
    
    PlayerCreateLayer *layer = [PlayerCreateLayer node];
    [scene addChild:layer];
    
    return scene;
}

- (void)loadCharacterImage
{
    NSMutableDictionary *manDic = [NSMutableDictionary dictionary];
    for (NSString *manImageName in [CharacterImageManager instance].manImageNameArray)
    {
        [manDic setObject:[[CharacterImageManager instance] getTextureFromImageName:manImageName] forKey:manImageName];
    }
    self.manImageNameAndTextureDic = manDic;
    
    NSMutableDictionary *womanDic = [NSMutableDictionary dictionary];
    for (NSString *womanImageName in [CharacterImageManager instance].womanImageNameArray)
    {
        [womanDic setObject:[[CharacterImageManager instance] getTextureFromImageName:womanImageName] forKey:womanImageName];
    }
    self.womanImageNameAndTextureDic = womanDic;
}

- (NSString *)getImageNameFromTexture:(CCTexture2D *)texture
{
    NSMutableDictionary *totalImageNameAndTexture = [NSMutableDictionary dictionary];
    [totalImageNameAndTexture addEntriesFromDictionary:self.manImageNameAndTextureDic];
    [totalImageNameAndTexture addEntriesFromDictionary:self.womanImageNameAndTextureDic];
    
    for (NSString *name in totalImageNameAndTexture.allKeys)
    {
        CCTexture2D *textureValue = [totalImageNameAndTexture objectForKey:name];
        if (texture == textureValue)
        {
            return name;
        }
    }
    
    return nil;
}

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        [self loadCharacterImage];
        
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"1.2-player-create.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        CCLabelWithTextField *label = [balsamiqLayer getControlByName:@"name"];
        if ([[LanguageManager instance] isEnglishVersion])
        {
            label.textField.keyboardType = UIKeyboardTypeASCIICapable;
        }
        label.delegate = self;
        
        [balsamiqLayer selectRadioItem:@"radio_sex_man"];
        [[balsamiqLayer getControlByName:@"name"] textField].text = @"";
        
        [self updateScrollLayer];
    }
    
    return self;
}

- (void)dealloc
{
    self.manImageNameAndTextureDic = nil;
    self.womanImageNameAndTextureDic = nil;
    
	[super dealloc];
}

- (void)updateScrollLayer
{
    if (scrollLayer != nil)
    {
        [scrollLayer removeFromParentAndCleanup:YES];
    }
    
    NSString *selectRadio = [balsamiqLayer getRadioManagerByGroup:@"sex"].selectedItemInfo;
    NSArray *textureImages = [selectRadio isEqualToString:@"radio_sex_man"]
    ? self.manImageNameAndTextureDic.allValues
    : self.womanImageNameAndTextureDic.allValues;
    
    NSMutableArray *layers = [NSMutableArray array];
    for (CCTexture2D *texture in textureImages)
    {
        CCLayer *nodeLayer = [CCLayer node];
        CCSprite *sprPlayer = [CCSprite spriteWithTexture:texture];
        sprPlayer.position = ccp(nodeLayer.contentSize.width / 2,
                                 324);
        [nodeLayer addChild:sprPlayer];
        [layers addObject:nodeLayer];
    }
    
    scrollLayer = [CCScrollLayer nodeWithLayers:layers widthOffset:80];
    scrollLayer.delegate = self;
    scrollLayer.pagesIndicatorPosition = ccp(scrollLayer.pagesIndicatorPosition.x,
                                             scrollLayer.pagesIndicatorPosition.y + 90);
    [self addChild:scrollLayer z:INT_MAX];
    
    [self setHighLightPage:0];
}

- (void)onNextClick:(id)sender
{
    UITextField *textField = [[balsamiqLayer getControlByName:@"name"] textField];
    
    if ([textField.text length] == 0)
    {
        [[[[UIAlertView alloc] initWithTitle:@"Please input your name"
                                     message:nil
                                    delegate:self
                           cancelButtonTitle:@"OK"
                           otherButtonTitles:nil] autorelease] show];
        return;
    }
    
    // 获取注册数据
    AGLoginInfo *loginInfo = [[[AGLoginInfo alloc] init] autorelease];
    loginInfo.name = textField.text;
    loginInfo.sex = [[balsamiqLayer getRadioManagerByGroup:@"sex"].selectedItemInfo hasSuffix:@"_man"] ? @"1" : @"0";
    CCSprite *sprPlayer = [[scrollLayer.pages objectAtIndex:scrollLayer.currentScreen] children].lastObject;
    loginInfo.imageName = [self getImageNameFromTexture:sprPlayer.texture];
    
    [[CCDirector sharedDirector] replaceScene:[PlayerTypeSelectLayer sceneWithLoginInfo:loginInfo]];
}

- (void)onsexRadioSelected:(NSString *)itemName
{
    [self updateScrollLayer];
}

#pragma mark - 
#pragma mark CCLabelWithTextFieldDelegate

- (void)onLabel:(CCLabelWithTextField *)label textFieldShouldBeginEditing:(UITextField *)textField
{
    textField.text = @"";
    self.position = ccpAdd(self.position, EditOffset);
}

- (void)onLabel:(CCLabelWithTextField *)label textFieldDidEndEditing:(UITextField *)textField
{
    self.position = ccpSub(self.position, EditOffset);
}

#pragma mark -
#pragma mark CCScrollLayerDelegate

- (void)setHighLightPage:(int)page
{
    return;
    for (CCLayer *layer in scrollLayer.pages)
    {
        if ([scrollLayer.pages objectAtIndex:page] == layer)
        {
            ((CCSprite *)layer.children.lastObject).color = ccWHITE;
        }
        else
        {
            ((CCSprite *)layer.children.lastObject).color = ccGRAY;    
        }
    }
}

- (void)scrollLayer:(CCScrollLayer *)sender scrolledToPageNumber:(int)page
{
    [self setHighLightPage:page];
}

@end
