//
//  GangsterLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-11.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

extern int lastSelectServantHeaderIndex;

@class CCTableLayer;
@class AGServantInfo;
@interface GangsterLayer : BaseLayer
{
    CCTableLayer *tableLayer;
    
    CCBalsamiqLayer *layerEquipment1;
    CCBalsamiqLayer *layerEquipment2;
    CCBalsamiqLayer *layerEquipment3;
    CCBalsamiqLayer *layerEquipment4;
    
    CCBalsamiqLayer *balsamiqLayer;
    
    CCSprite *sprHeaderBorder;
}

@property (nonatomic, retain) NSMutableArray *headerLayerArray;
@property (nonatomic, retain) AGServantInfo *servantInfo;

+ (CCScene *)sceneWithSelectServantHeaderIndex:(int)selectServantHeaderIndex;

@end
