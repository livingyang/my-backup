//
//  GuideLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-30.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

#define NOTIFICATION_GUIDE_RANGE_SPRITE_CLICK @"NOTIFICATION_GUIDE_RANGE_SPRITE_CLICK"
#define NOTIFICATION_GUIDE_OUT_OF_RANGE_CLICK @"NOTIFICATION_GUIDE_OUT_OF_RANGE_CLICK"

@class CCBalsamiqLayer;
@interface GuideLayer : CCLayer

@property (nonatomic, assign) CCBalsamiqLayer *balsamiqLayer;
@property (nonatomic, readonly) CCSprite *sprRange;

+ (GuideLayer *)guideLayerFromFileName:(NSString *)fileName;

+ (void)changeSpriteImageToWoman:(CCSprite *)sprite;

@end
