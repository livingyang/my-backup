//
//  BaseLayer.h
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-4-27.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "AGPlayerInfo.h"
#import "SoundManager.h"
#import "GuideLayer.h"
#import "InAppPurchaseManager.h"

@class CCBalsamiqLayer;
@class CCAlertLayer;
@class AGLoginInfo;
@class AGChallengeResult;
@interface BaseLayer : CCLayer <InAppPurchaseListenDelegate>
{
    NSMutableDictionary *connectAndReciveDataDic;
}

@property (nonatomic, assign) CCBalsamiqLayer *headerLayer;
@property (nonatomic, assign) CCBalsamiqLayer *toolLayer;

@property (nonatomic, readonly) NSString *loadingLayerName;
@property (nonatomic, assign) CCAlertLayer *loadingLayer;
@property BOOL isLoading;

@property (nonatomic, readonly) CCAlertLayer *itemAlertLayer;
@property (nonatomic, readonly) CCAlertLayer *purchaseAlertLayer;
@property (nonatomic, readonly) CCAlertLayer *levelUpAlertLayer;

// 用于挑战功能
@property (nonatomic, retain) AGChallengeResult *challengeResult;

+ (CCScene *)scene;

// 多语言支持
- (NSString *)getLanguageString:(NSString *)strId;
- (void)setLabel:(CCLabelTTF *)label toLanguage:(NSString *)strId;

// 道具使用窗口的打开
- (void)openItemAlert:(NSString *)title withType:(NSString *)itemType;
- (BOOL)onUseItem:(int)itemId itemType:(NSString *)type; // 返回NO，代表不关闭窗口，返回YES，代表关闭窗口
- (void)onCommonAlertCloseClick:(id)sender;
- (void)onCommonAlertOkClick:(id)sender;

// 打开升级界面，用于测试分享功能
- (void)onPlayerLevelUp;
- (void)closeLevelUpAlert;

// 显示确认充值界面
- (void)showConfirmPurchase;

// 显示金币动画
- (void)showGainEffect:(int)coins;

// 显示系统提示信息
- (void)showSystemTip:(NSString *)message;

// 游戏事件的发生，用于新手引导
- (void)onEventHappened:(NSString *)eventName;

// 挑战其他玩家
- (void)challengeOpponent:(int)opponentId;
- (void)setNode:(CCNode *)node toParentSpace:(CCNode *)parentNode;

// 子类覆盖这两个函数，获取输出
- (void)postRequestToAmaricanGangsterServer:(NSDictionary *)postInfo;
- (void)onReceiveSuccess:(NSURLConnection *)connection jsonInfo:(NSDictionary *)info;
- (void)onReceiveFail:(NSURLConnection *)connection;

- (void)updateDefaultPlayerInfo;
- (void)onReceiveInfoWithType_getPlayerInfo:(NSDictionary *)info;
- (void)onReceiveInfoWithType_useProps:(NSDictionary *)info;
- (void)onReceiveInfoWithType_buyPropsGoods:(NSDictionary *)info;
- (void)onReceiveInfoWithType_energy_not_enough:(NSDictionary *)info;
- (void)onReceiveInfoWithType_challengeOpponent:(NSDictionary *)info;
- (void)onReceiveInfoWithType_dollar_not_enough:(NSDictionary *)info;

// login
- (void)postLoginRequest;
- (void)postRegisterRequest:(AGLoginInfo *)registerInfo;
- (void)postGetPlayerInfoRequest;
- (void)postGetDayAwardsRequest:(int)gridPosition;
- (void)postClearGuideMission;

// gangster
- (void)postGetMyServantList;
- (void)postGetServantInfoRequest:(int)servantId;
- (void)postGetMyServantHeader;
- (void)postChangeServant:(int)servantId pos:(int)pos;
- (void)postGetEquipmentListFromPosRequest:(int)pos;
- (void)postChangeEquipment:(int)equipmentId servantId:(int)servantId pos:(int)pos;

// refine
- (void)postGetRefineListRequest:(int)equipmentType;
- (void)postRefineItemRequest:(int)itemId isUseItem:(BOOL)isUseItem;
- (void)postGetRefineInfo;
- (void)postTryClearRefineTime;
- (void)postClearRefineTime;

// store
- (void)postGetTotalStoreListRequest;
- (void)postGetStoreList:(NSString *)listKind; // 暂时废弃不用
- (void)postGetPackList:(NSString *)listKind;

// business
- (void)postGetBusinessList;
- (void)postUpBusiness:(int)type level:(int)level;
- (void)postGainBusiness:(int)type level:(int)level;
- (void)postSpeedUpBusiness:(int)type level:(int)level itemId:(int)itemId;
- (void)postIncreaseBusiness:(int)type level:(int)level servantList:(NSString *)servantList;

// pk
- (void)postGetOpponentListRequest:(NSString *)condition;
- (void)postGetRevengeListRequest;
- (void)postChallengeOpponentRequest:(int)playerId;

// mission
//- (void)postGetMissionIndex;
- (void)postGetAccessPlaceList;
- (void)postGetPlaceMissionRequest:(int)mapId;
- (void)postDoMissionRequest:(int)missionId;
- (void)postDoBossMissionRequest:(int)bossId;
- (void)postTryBailPlayer;
- (void)postBailPlayer;

- (void)postBuyItemRequest:(int)itemId;
- (void)postSellItemRequest:(int)goodsId;

// item shop
- (void)postGetPropsList;
- (void)postGetAlertPropsList:(int)propsId;
- (void)postBuyPropsGoods:(int)propsId;
- (void)postBuyGiftBagProps:(int)propsId;

- (void)postUsePropsGoods:(int)propsId;
- (void)postGetWeaponList;
- (void)postBuyWeaponRequest:(int)itemId;
- (void)postGetCardList;
- (void)postExchangeCard:(int)cardId;
- (void)postAddDollar:(int)dollar;
- (void)postGetSpinWeaponList;
- (void)postStartSlotMachine:(int)slotId;
- (void)postGetPurchaseProductList;
- (void)postGeneratorPurchaseOrder:(int)productId count:(int)count;
- (void)postPurchaseProduct:(int)productId transactionReceipt:(NSString *)transactionId;

// arena
- (void)postGetArenaRankList:(int)pageNum;
- (void)postGetArenaOpponentList;
- (void)postChallengeArenaOpponent:(int)oppId;
- (void)postGetMyArena;
- (void)postGetArenaMsgList;
- (void)postGetGainRankingAward;
- (void)postGainRankingAward;

// setting
- (void)postGetSettings;
- (void)postUpdateSettings:(NSString *)settingString;

// message
- (void)postGetBattleMsgList;
- (void)postGetHeelerMsgList;
- (void)postGetSystemMsgList;
- (void)postGetNoticeList;

// toolbar manager
- (void)onSelect_radio_Tool_home:(id)sender;
- (void)onSelect_radio_Tool_mission:(id)sender;
- (void)onSelect_radio_Tool_battle:(id)sender;
- (void)onSelect_radio_Tool_group:(id)sender;
- (void)onSelect_radio_Tool_item:(id)sender;

@end
