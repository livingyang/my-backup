//
//  BusinessIncreaseLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-13.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@class AGBusinessInfo;
@class CCBalsamiqLayer;
@interface BusinessIncreaseLayer : BaseLayer
{
    CCBalsamiqLayer *balsamiqLayer;
    
    NSMutableDictionary *layerAndServantInfoDic;
}

@property (nonatomic, retain) AGBusinessInfo *businessInfo;
@property (nonatomic, readonly) int curSelectServantCount;

@property (nonatomic, readonly) CCLabelTTF *labHasDetail;
@property (nonatomic, readonly) CCLabelTTF *labNoDetail;

@property (nonatomic, readonly) CCMenuItemImage *btnDispatch;
@property (nonatomic, readonly) CCMenuItemImage *btnBattle;

- (void)loadBusinessInfo:(AGBusinessInfo *)info;
+ (CCScene *)sceneWithInfo:(AGBusinessInfo *)info;

@end
