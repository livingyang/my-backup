//
//  CharacterListLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-11.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@class CCBalsamiqLayer;
@interface CharacterListLayer : BaseLayer
{
    CCBalsamiqLayer *balsamiqLayer;
    
    CCMenuItemToggle *selectedToggle;
}

@property int headerIndex;
@property (nonatomic, retain) NSArray *servantArray;

+ (CCScene *)sceneWithIndex:(int)headerIndex;

@end
