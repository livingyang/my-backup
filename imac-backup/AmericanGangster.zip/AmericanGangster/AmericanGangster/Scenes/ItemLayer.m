//
//  ItemLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-18.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "ItemLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCTableLayer.h"
#import "CCAlertLayer.h"
#import "AGStoreItemInfo.h"
#import "AGStoreItemInfoCache.h"
#import "AGShopItemInfo.h"
#import "ItemImageManager.h"
#import "CCTimeManageNode.h"
#import "CCLabelTTF+ChangeFont.h"
#import "UIImage+Grayscale.h"
#import "SlotMachineNode.h"
#import "CCTouchCatchNode.h"
#import "AGEquipmentInfo.h"
#import "RefineLayer.h"

@implementation ItemLayer

@synthesize spinEquipment;

+ (CCScene *)sceneWithTab:(int)tabIndex
{
    ItemLayer *layer = [ItemLayer node];
    [layer loadTabIndex:tabIndex];
    
    CCScene *scene = [CCScene node];
    [scene addChild:layer];
    
    return scene;
}

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"12-item.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        self.headerLayer = [balsamiqLayer getControlByName:@"header-property"];
        self.toolLayer = [balsamiqLayer getControlByName:@"tool-bar"];
        
        touchCatchNode = [CCTouchCatchNode node];
        [self addChild:touchCatchNode];
    }
    
    return self;
}

- (void)dealloc
{
    self.spinEquipment = nil;
    [super dealloc];
}

- (void)loadTabIndex:(int)tabIndex
{
    switch (tabIndex)
    {
        case 1:
        {
            [balsamiqLayer selectRadioItem:@"radio_tab_weapon"];
            [self onSelect_radio_tab_weapon:nil];
        }break;
            
        case 2:
        {
            [balsamiqLayer selectRadioItem:@"radio_tab_card"];
            [self onSelect_radio_tab_card:nil];
        }break;
            
        default:
        {
            [balsamiqLayer selectRadioItem:@"radio_tab_item"];
            [self onSelect_radio_tab_item:nil];
        }break;
    }
}

- (void)onEnter
{
    [super onEnter];
    
    [self.toolLayer selectRadioItem:@"radio_Tool_item"];
}

#pragma mark -
#pragma mark slot equipment

- (NSString *)getStarsImage:(int)star
{
    return [NSString stringWithFormat:@"UI/12-item/img-star%d.png", star];
}

- (NSArray *)getEquipmentImagesWithSlotMachine:(AGShopSlotMachine *)slotMachine
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (id equipmentId in slotMachine.randomEquipmentIdList)
    {
        AGStoreItemInfo *equipmentInfo =
        [[AGStoreItemInfoCache instance] getItemInfoFromEquipId:[equipmentId intValue]];
        
        if (equipmentInfo == nil)
        {
            NSLog(@"ItemLayer#getEquipmentImagesWithSlotMachine equipmentInfo == nil, id = %@", equipmentId);
            continue;
        }
        
        [array addObject:equipmentInfo.equipmentImagePath];
    }
    
    return array;
}

- (NSArray *)getStarImagesWithSlotMachine:(AGShopSlotMachine *)slotMachine
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (int i = 2; i < 4; ++i)
    {
        [array addObject:[self getStarsImage:i]];
    }
    
    return array;
}

- (CCBalsamiqLayer *)getSlotMachineLayerFromSlotId:(int)slotId
{
    CCTableLayer *tableLayer = [balsamiqLayer getControlByName:@"table"];
    for (CCBalsamiqLayer *layer in tableLayer.cellContainer.children)
    {
        if ([[layer getControlByName:@"Spin"] tag] == slotId)
        {
            return layer;
        }
    }
    
    return nil;   
}

- (SlotMachineNode *)getEquipmentSlotMachineFromLayer:(CCBalsamiqLayer *)layer
{
    return [[layer getControlByName:@"image_slot_equipment"] slotMachine];
}

- (SlotMachineNode *)getStarSlotMachineFromLayer:(CCBalsamiqLayer *)layer
{
    return [[layer getControlByName:@"image_slot_star"] slotMachine];
}

- (void)onBuyConfirmClick:(id)sender
{
    [self onCommonAlertOkClick:sender];
    
    [self postBuyPropsGoods:[sender tag]];
}

- (void)onBuyBagClick:(id)sender
{
    [self onCommonAlertOkClick:sender];
    
    [self postBuyGiftBagProps:[sender tag]];
}

- (void)onBuyItemClick:(id)sender
{
    [self postGetAlertPropsList:[sender tag]];
}

- (void)onUseItemClick:(id)sender
{
    //NSLog(@"item id = %d", [sender tag]);
    [self postUsePropsGoods:[sender tag]];
}

- (void)onBuyWeaponClick:(id)sender
{
    [self postBuyWeaponRequest:[sender tag]];
}

- (void)onSpinClick:(id)sender
{
    NSLog(@"onSpinClick tag = %d", [sender tag]);
    
    lastSpinId = [sender tag];
    
    [self postStartSlotMachine:lastSpinId];
    CCBalsamiqLayer *layer = [self getSlotMachineLayerFromSlotId:lastSpinId];
    [[self getEquipmentSlotMachineFromLayer:layer] startSlot];
    
    SlotMachineNode *starSlot = [self getStarSlotMachineFromLayer:layer];
    [starSlot runAction:[CCSequence actions:
                         [CCDelayTime actionWithDuration:0.2f],
                         [CCCallFunc actionWithTarget:starSlot selector:@selector(startSlot)],
                         nil]];
    
    [self setIsForbidUserTouch:YES];
    
    [[SoundManager instance] playEffectSlot];
}

- (void)onRefineClick:(id)sender
{
    [[CCDirector sharedDirector] replaceScene:[RefineLayer sceneWithEquipmentType:self.spinEquipment.storeItemInfo.type
                                                                  withEquipmentId:self.spinEquipment.uniqueId]];
}

- (void)onSpinAwardOkClick:(id)sender
{
    [self onCommonAlertOkClick:sender];
    
    [self showSystemTip:[self getLanguageString:@"12004"]];
}

- (void)setIsForbidUserTouch:(BOOL)isForbidUserTouch
{
    touchCatchNode.catchTarget = isForbidUserTouch ? self : nil;
}

- (void)onSlotStopWithEquipment:(AGEquipmentInfo *)equipment
{
    [self setIsForbidUserTouch:NO];
    
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"12.6-spin-award.bmml"
                                       parentNode:self];
    [equipment.storeItemInfo updateDataToLayer:alert.balsamiqLayer];
    
    self.spinEquipment = equipment;
}

- (void)stopSlotMachine:(CCBalsamiqLayer *)slotMachineLayer withEquipment:(AGEquipmentInfo *)packItem
{
    SlotMachineNode *equipmentSlotMachine = [self getEquipmentSlotMachineFromLayer:slotMachineLayer];
    SlotMachineNode *starSlotMachine = [self getStarSlotMachineFromLayer:slotMachineLayer];
    
    AGStoreItemInfo *item = [[AGStoreItemInfoCache instance] getItemInfoFromEquipId:packItem.goodsId];
    
    [equipmentSlotMachine runAction:[CCSequence actions:
                                     [CCDelayTime actionWithDuration:2.0f],
                                     [CCCallFuncO actionWithTarget:equipmentSlotMachine
                                                          selector:@selector(stopSlotAtImage:)
                                                            object:item.equipmentImagePath],
                                     [CCCallFunc actionWithTarget:[SoundManager instance]
                                                         selector:@selector(playEffectSlotStop)],
                                     nil]];
    
    [starSlotMachine runAction:[CCSequence actions:
                                [CCDelayTime actionWithDuration:2.5f],
                                [CCCallFuncO actionWithTarget:starSlotMachine
                                                     selector:@selector(stopSlotAtImage:)
                                                       object:[self getStarsImage:packItem.storeItemInfo.star]],
                                [CCCallFunc actionWithTarget:[SoundManager instance]
                                                    selector:@selector(playEffectSlotStop)],
                                [CCDelayTime actionWithDuration:0.5f],
                                [CCCallFuncO actionWithTarget:self
                                                     selector:@selector(onSlotStopWithEquipment:)
                                                       object:packItem],
                                nil]];
}

- (void)stopSlotMachineWithDefaultImage:(int)slotId
{
    CCBalsamiqLayer *slotLayer = [self getSlotMachineLayerFromSlotId:slotId];
    
    AGShopSlotMachine *slotInfo = [[AGShopSlotMachineCache instance] getSlotMachineFromId:slotId];
    AGStoreItemInfo *storeItemInfo = [[AGStoreItemInfoCache instance] getItemInfoFromEquipId:slotInfo.displayEquipmentId];
    
    SlotMachineNode *equipmentSlotMachine = [self getEquipmentSlotMachineFromLayer:slotLayer];
    SlotMachineNode *starSlotMachine = [self getStarSlotMachineFromLayer:slotLayer];
    [starSlotMachine stopAllActions];
    
    [equipmentSlotMachine stopSlotAtSprite:[CCSprite spriteWithTexture:getGrayTextureFromPath(storeItemInfo.equipmentImagePath)]];
    [starSlotMachine stopSlotAtImage:[self getStarsImage:storeItemInfo.star]];
    
    [self setIsForbidUserTouch:NO];
}

- (void)onExchangeCardClick:(id)sender
{
    //NSLog(@"card id = %d", [sender tag]);
    [self postExchangeCard:[sender tag]];
}

- (void)onUseCardClick:(id)sender
{
    //NSLog(@"item id = %d", [sender tag]);
    [self postUsePropsGoods:[sender tag]];
}

#pragma mark -
#pragma mark Radio handler

- (void)onSelect_radio_tab_item:(id)sender
{
    [self postGetPropsList];
}

- (void)onSelect_radio_tab_weapon:(id)sender
{
    [self postGetSpinWeaponList];
}

- (void)onSelect_radio_tab_card:(id)sender
{
    [self postGetCardList];
}

- (void)updateItemList:(NSArray *)itemList
{
    CCNode *cellContainer = [CCNode node];
    
    float cellOffsetY = 0;
    for (AGShopItemInfo *shopItem in itemList)
    {
        //        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:shopItem.isBagItem ? @"12.1.1-bag-item-info.bmml" : @"12.1-item-info.bmml"
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"12.1-item-info.bmml"
                                                           eventHandle:self];
        cell.position = ccp(0, cellOffsetY);
        cellOffsetY += cell.contentSize.height;
        [cellContainer addChild:cell];
        
        [shopItem updateDataToLayer:cell];
        
        [[cell getControlByName:@"BuyItem"] setTag:shopItem.propsId];
        [[cell getControlByName:@"UseItem"] setTag:shopItem.propsId];
        [[cell getControlByName:@"UseItem"] setVisible:shopItem.isCanUseDirect];
    }
    
    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

- (void)updateCardList:(NSArray *)cardList
{
    CCNode *cellContainer = [CCNode node];
    
    for (AGCardInfo *cardInfo in cardList)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"12.3-card-info.bmml"
                                                           eventHandle:self];
        cell.position = ccp(0, cell.contentSize.height * [cardList indexOfObject:cardInfo]);
        [cellContainer addChild:cell];
        
        [cardInfo updateDataToLayer:cell];
    }
    
    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_getPropsList:(NSDictionary *)info
{
    [self updateItemList:[AGShopItemInfo shopItemListFromInfo:info]];
}

- (void)onReceiveInfoWithType_getWeaponList:(NSDictionary *)info
{
    return;
    [[AGShopInfo instance] updateFromInfo:info];
}

- (void)onReceiveInfoWithType_getSpinWeaponList:(NSDictionary *)info
{
    CCLOG(@"info = %@", info);
    
    [[AGShopSlotMachineCache instance] updateSlotMachineWithDic:info];
    
    CCNode *cellContainer = [CCNode node];
    for (AGShopSlotMachine *slotMachineInfo in [AGShopSlotMachineCache instance].slotMachineList)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"12.2-weapon-info.bmml"
                                                           eventHandle:self];
        
        cell.position = ccp(0, [[AGShopSlotMachineCache instance].slotMachineList indexOfObject:slotMachineInfo] * cell.contentSize.height);
        [cellContainer addChild:cell];
        
        [[cell getControlByName:@"dollar"] setString:
         [NSString stringWithFormat:@"%d", slotMachineInfo.dollar]];
        [[cell getControlByName:@"title"] setString:slotMachineInfo.title];
        [[cell getControlByName:@"title"] changeToBlackArialFont];
        [[cell getControlByName:@"detail"] setString:slotMachineInfo.detail];
        
        [[cell getControlByName:@"Spin"] setTag:slotMachineInfo.slotId];
        
        AGStoreItemInfo *displayItem = [[AGStoreItemInfoCache instance] getItemInfoFromEquipId:slotMachineInfo.displayEquipmentId];
        
        SlotMachineNode *equipmentSlotMachine = [self getEquipmentSlotMachineFromLayer:cell];
        [equipmentSlotMachine setInitImage:displayItem.equipmentImagePath];
        [equipmentSlotMachine setSlotImages:[self getEquipmentImagesWithSlotMachine:slotMachineInfo]];
        
        SlotMachineNode *starSlotMachine = [self getStarSlotMachineFromLayer:cell];
        [starSlotMachine setInitImage:[self getStarsImage:displayItem.star]];
        [starSlotMachine setSlotImages:[self getStarImagesWithSlotMachine:slotMachineInfo]];
    }
    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

- (void)onReceiveInfoWithType_startSlotMachine:(NSDictionary *)info
{
    [self stopSlotMachine:[self getSlotMachineLayerFromSlotId:lastSpinId]
            withEquipment:[AGEquipmentInfo getPackItemFromSpinSlotMachine:info]];
    
    [self postGetPlayerInfoRequest];
}

- (void)onReceiveInfoWithType_startSlotMachine_err:(NSDictionary *)info
{
    [self showSystemTip:[info objectForKey:@"msg"]];
    
    [self stopSlotMachineWithDefaultImage:lastSpinId];
}

- (void)onReceiveInfoWithType_dollar_not_enough:(NSDictionary *)info
{
    [super onReceiveInfoWithType_dollar_not_enough:info];
    
    [self stopSlotMachineWithDefaultImage:lastSpinId];
}

- (void)onReceiveInfoWithType_getCardList:(NSDictionary *)info
{
    [self updateCardList:[AGCardInfo cardListFromInfo:info]];
}

- (CCBalsamiqLayer *)getShopItemLayerFromPropsId:(int)propsId
{
    CCTableLayer *tableLayer = [balsamiqLayer getControlByName:@"table"];
    for (CCBalsamiqLayer *layer in tableLayer.cellContainer.children)
    {
        if ([[layer getControlByName:@"image_icon"] tag] == propsId)
        {
            return layer;
        }
    }
    
    return nil;
}

- (CCBalsamiqLayer *)getCardLayerFromCardId:(int)cardId
{
    CCTableLayer *tableLayer = [balsamiqLayer getControlByName:@"table"];
    for (CCBalsamiqLayer *layer in tableLayer.cellContainer.children)
    {
        if ([[layer getControlByName:@"ExchangeCard"] tag] == cardId)
        {
            return layer;
        }
    }
    
    return nil;
}

- (void)onReceiveInfoWithType_useProps:(NSDictionary *)info
{
    [super onReceiveInfoWithType_useProps:info];
    
    AGShopItemInfo *itemInfo = [AGShopItemInfo shopItemFromUseAndBuyInfo:info];
    [itemInfo updateDataToLayer:[self getShopItemLayerFromPropsId:itemInfo.propsId]];
}

- (void)onReceiveInfoWithType_buyPropsGoods:(NSDictionary *)info
{
    [super onReceiveInfoWithType_buyPropsGoods:info];
    
    AGShopItemInfo *itemInfo = [AGShopItemInfo shopItemFromUseAndBuyInfo:info];
    [itemInfo updateDataToLayer:[self getShopItemLayerFromPropsId:itemInfo.propsId]];
}

- (void)onReceiveInfoWithType_buyGiftBagProps:(NSDictionary *)info
{
    [super onReceiveInfoWithType_buyPropsGoods:info];
    
    AGShopItemInfo *itemInfo = [AGShopItemInfo shopItemFromUseAndBuyInfo:info];
    [itemInfo updateDataToLayer:[self getShopItemLayerFromPropsId:itemInfo.propsId]];
}

- (void)onReceiveInfoWithType_exchangeProps:(NSDictionary *)info
{
    AGCardInfo *cardInfo = [AGCardInfo cardInfoFromExchangeInfo:info];
    CCBalsamiqLayer *cardLayer = [self getCardLayerFromCardId:cardInfo.cardId];
    
    if (cardLayer == nil)
    {
        return;
    }
    
    [cardInfo updateDataToLayer:cardLayer];
    [[cardLayer getControlByName:@"count"] runAction:[CCSequence actionOne:[CCScaleTo actionWithDuration:0.3f scale:1.5f]
                                                                       two:[CCScaleTo actionWithDuration:0.3f scale:1]]];
    
    [self showSystemTip:[self getLanguageString:@"12003"]];
}

- (void)onReceiveInfoWithType_buyAlertPropsList:(NSDictionary *)info
{
    AGShopBagItemInfo *bagItem = [AGShopBagItemInfo bagItemFromInfo:info];
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"12.1.2-item-buy-confirm.bmml"
                                       parentNode:self];
    [bagItem updateDataToLayer:alert.balsamiqLayer];
    
    
    [[alert.balsamiqLayer getControlByName:@"BuyConfirm"] setTag:bagItem.itemInfo.propsId];
    [[alert.balsamiqLayer getControlByName:@"BuyBag"] setTag:bagItem.bagItemInfo.propsId];
}

@end
