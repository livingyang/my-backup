//
//  ArenaLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-25.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@class CCBalsamiqLayer;
@class AGArenaInfo;
@interface ArenaLayer : BaseLayer
{
    CCBalsamiqLayer *balsamiqLayer;
}

@property (nonatomic, retain) NSArray *messageArray;
@property (nonatomic, retain) NSArray *arenaOpponentList;
@property (nonatomic, retain) AGArenaInfo *curArenaInfo;
@end
