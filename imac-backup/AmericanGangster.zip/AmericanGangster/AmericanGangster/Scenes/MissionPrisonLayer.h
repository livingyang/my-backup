//
//  MissionPrisonLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-26.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@interface MissionPrisonLayer : BaseLayer
{
    CCBalsamiqLayer *balsamiqLayer;
}

+ (CCScene *)sceneWithEventTime:(NSTimeInterval)time;
+ (CCScene *)sceneWithEventTimeAndAnime:(NSTimeInterval)time andEventNode:(CCNode *)node;

@end
