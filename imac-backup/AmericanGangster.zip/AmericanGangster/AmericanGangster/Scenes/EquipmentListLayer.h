//
//  EquipmentListLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-30.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@interface EquipmentListLayer : BaseLayer
{
    CCBalsamiqLayer *balsamiqLayer;
    
    CCMenuItemToggle *selectedToggle;
    
    int equipmentPos_;
    int servantId_;
}

@property (nonatomic, retain) NSArray *equipmentList;

+ (CCScene *)sceneWithPos:(int)equipmentPos withServantId:(int)servantId;

@end
