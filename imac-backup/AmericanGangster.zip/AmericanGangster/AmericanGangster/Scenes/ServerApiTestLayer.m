//
//  ServerApiTestLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-16.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "ServerApiTestLayer.h"
#import "ServerApiListLayer.h"

#define TAG_EDIT_TEXTFIELD (200)

@interface ServerApiTestLayer (Private)

- (void)showAlert:(NSString *)propertyName propertyValue:(NSString *)propertyValue;

@end

@implementation ServerApiTestLayer

@synthesize apiParams;
@synthesize selectedLabel;

- (NSString *)getNameFromParamString:(NSString *)paramString
{
    NSArray *params = [paramString componentsSeparatedByString:@":"];
    return [[params objectAtIndex:0] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

- (NSString *)getParamStringFromName:(NSString *)name
{
    return [NSString stringWithFormat:@"%@ : %@", name, [self.apiParams objectForKey:name]];
}

- (void)onApiNameClick:(CCMenuItemFont *)apiLabel
{
    [self showAlert:[self getNameFromParamString:apiLabel.label.string]
      propertyValue:[self.apiParams objectForKey:[self getNameFromParamString:apiLabel.label.string]]];

    self.selectedLabel = apiLabel;
}

- (void)loadParams
{
    CCMenu *menu = [CCMenu menuWithItems:nil];
    [self addChild:menu];
    
    for (NSString *paramName in [self.apiParams allKeys])
    {
        [menu addChild:[CCMenuItemFont itemFromString:[self getParamStringFromName:paramName]
                                               target:self
                                             selector:@selector(onApiNameClick:)]];
    }
    
    [menu alignItemsVertically];
}

- (void)onPostClick:(id)sender
{
    NSLog(@"onPostClick");
    [self postRequestToAmaricanGangsterServer:self.apiParams];
}

- (void)onBackClick:(id)sender
{
    [[CCDirector sharedDirector] replaceScene:[ServerApiListLayer scene]];
}

#pragma mark -
#pragma mark 属性编辑

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	return YES;
}

- (void)showAlert:(NSString *)propertyName propertyValue:(NSString *)propertyValue
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:propertyName
													message:@"   " 
												   delegate:self 
										  cancelButtonTitle:@"Cancel" 
										  otherButtonTitles:@"OK", nil];
	
	UITextField *textField = [[UITextField alloc] initWithFrame:CGRectMake(12, 50, 260, 25)];
	CGAffineTransform myTransform = CGAffineTransformMakeTranslation(0, -60);
	[alert setTransform:myTransform];
	textField.tag = TAG_EDIT_TEXTFIELD;
	textField.returnKeyType = UIReturnKeyDone;
	textField.clearButtonMode = UITextFieldViewModeWhileEditing;
	textField.delegate = self;
	textField.text = propertyValue;
	[textField setBackgroundColor:[UIColor whiteColor]];
	[alert addSubview:textField];
	[alert show];
	
	[textField release];
	[alert release];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	//cancle按钮索引为0，其它按钮索引依次加1
	if (buttonIndex == 0)
	{
		return;
	}
	
	UITextField *field = (UITextField *)[alertView viewWithTag:TAG_EDIT_TEXTFIELD];
	
    [self.apiParams setObject:field.text forKey:alertView.title];
    
    selectedLabel.label.string = [self getParamStringFromName:alertView.title];
    
    NSLog(@"params = %@", self.apiParams);
}


#pragma mark -
#pragma mark 构造函数

- (id)initWithInfo:(NSDictionary *)params
{
    self = [super init];
	if (self != nil)
    {
        self.apiParams = [NSMutableDictionary dictionaryWithDictionary:params];
        
        [self loadParams];
        
        CCMenu *menu = [CCMenu menuWithItems:nil];
        [self addChild:menu];
        
        [menu addChild:[CCMenuItemFont itemFromString:@"Back"
                                               target:self
                                             selector:@selector(onBackClick:)]];
        
        [menu addChild:[CCMenuItemFont itemFromString:@"Post"
                                               target:self
                                             selector:@selector(onPostClick:)]];
        
        [menu alignItemsHorizontallyWithPadding:200];
        menu.position = ccpAdd(menu.position, ccp(0, 220));
    }
    
    return self;
}

- (void)dealloc
{
    self.apiParams = nil;
    
    [super dealloc];
}

+ (CCScene *)sceneWithApiParams:(NSDictionary *)params
{
    CCScene *scene = [CCScene node];
    [scene addChild:[[[ServerApiTestLayer alloc] initWithInfo:params] autorelease]];
    
    return scene;
}

- (NSString *)getStringFromJsonDic:(NSDictionary *)jsonDic
{
    NSMutableString *str = [NSMutableString string];
    [str appendString:@"{\n"];
    for (NSString *key in [jsonDic allKeys])
    {
        [str appendFormat:@"%@ = %@,\n", key, [jsonDic objectForKey:key]];
    }
    [str appendString:@"}"];
    
    return str;
}

- (void)onReceiveSuccess:(NSURLConnection *)connection jsonInfo:(NSDictionary *)info
{
    NSLog(@"info = %@", info);
    
    [[[[UIAlertView alloc] initWithTitle:@"Receive Message"
                                 message:[info description]
                                delegate:nil
                       cancelButtonTitle:@"OK"
                       otherButtonTitles:nil] autorelease] show];
}

@end
