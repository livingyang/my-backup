//
//  LogoLayer.m
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-4-27.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "IntroLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCMenuItemButton.h"
#import "HomeLayer.h"
#import "CCAlertLayer.h"
#import "PlayerCreateLayer.h"
#import "AGStoreItemInfoCache.h"
#import "ServerApiListLayer.h"
#import "AGMissionPlace.h"
#import "CharacterImageManager.h"
#import "AwardLayer.h"
#import "AGLoginInfo.h"
#import "AGAwardInfo.h"
#import "AGShopItemInfo.h"
#import "SimpleAudioEngine.h"
#import "ShareManager.h"
#import "CCVideoPlayer.h"
#import "GuideEventHandle.h"
#import "MobClick.h"
#import "PPLoginHelper.h"
#import "LanguageManager.h"

@implementation IntroLayer

@synthesize loginData;
@synthesize gameDataCache;

- (void)loadIntroResource
{
    isLoginNotExist = NO;
    
    self.isTouchEnabled = YES;
    
    balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"1.1-intro.bmml"
                                               eventHandle:self];
    [self addChild:balsamiqLayer];
    
    [[balsamiqLayer getControlByName:@"Debug"] setVisible:NO];
    [[balsamiqLayer getControlByName:@"Test"] setVisible:NO];
    
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
    [[balsamiqLayer getControlByName:@"version"] setString:
     [NSString stringWithFormat:@"Version: %@", version]];
    [[balsamiqLayer getControlByName:@"version"] setVisible:NO];
    
//    [[balsamiqLayer getControlByName:@"address"] setString:
//     [NSString stringWithFormat:@"Address:%@", SERVER_ADDRESS]];
    [[balsamiqLayer getControlByName:@"address"] setVisible:NO];
    
    CCLabelTTF *labClick = [balsamiqLayer getControlByName:@"click"];
    labClick.opacity = 0;
    
    self.gameDataCache = [GameDataCache gameDataCacheWithDelegate:self];
    [self postLoginRequest];
}

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        [[CCVideoPlayer instance] playerVideo:@"logo"
                                       ofType:@"mp4"
                                     callback:[CCCallFunc actionWithTarget:self selector:@selector(onLogoVideoPlayDone)]];
    }
    
    return self;
}

- (void)dealloc
{
    self.loginData = nil;
    self.gameDataCache = nil;
    
	[super dealloc];
}

- (void)onEnter
{
    [super onEnter];
}

- (void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    if (isLogined == NO && isLoginNotExist == NO)
    {
        NSLog(@"Restart server");
        [self postLoginRequest];
        return;
    }
    
    self.isTouchEnabled = NO;
    
    [[CCVideoPlayer instance] playerVideo:[self getLanguageString:@"1009"]
                                   ofType:@"mp4"
                                 callback:[CCCallFunc actionWithTarget:self selector:@selector(onOpVideoPlayDone)]];
}

- (void)onTotalDataCached
{
    [self showClickEffect];
}

- (void)showClickEffect
{
    id action = [CCRepeatForever actionWithAction:[CCSequence actions:
                                                   [CCFadeOut actionWithDuration:0.5f],
                                                   [CCFadeIn actionWithDuration:0.5f],
                                                   nil]];
    
    [[balsamiqLayer getControlByName:@"click"] runAction:action];
}

#pragma mark -
#pragma mark CCBalsamiqLayer button

- (void)onDebugClick:(id)sender
{
    [[CCDirector sharedDirector] replaceScene:[PlayerCreateLayer scene]];

}

#pragma mark -
#pragma mark ShareManager

- (void)onTestClick:(id)sender
{
    [self onPlayerLevelUp];
    
    if ([ShareManager instance] == nil)
    {
        [ShareManager instance];
    };
}

#pragma mark -
#pragma mark Receive info handle

- (void)onOpVideoPlayDone
{
    if (isLoginNotExist)
    {
        [[CCDirector sharedDirector] replaceScene:[PlayerCreateLayer scene]];
        return;
    }
    
    [[AGAwardInfo instance] updateAwardInfoFromLoginInfo:self.loginData];
    CCScene *scene = [AGAwardInfo instance].needsAward ? [AwardLayer scene] : [HomeLayer scene];
    
    [[CCDirector sharedDirector] replaceScene:scene];
}

- (void)onLogoVideoPlayDone
{
    [[SoundManager instance] playBackgroundMusic];
    
    [self loadIntroResource];
    
    //add by ganhaidong 2012-12-23
    
    //[self onPlayerLevelUp];
    if ([[LanguageManager instance]isChineseVersion]) {
        [[PPLoginHelper instance]login];
    }
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_login_not_exists:(NSDictionary *)info
{
    isLoginNotExist = YES;
    
    [self showClickEffect];
}

- (void)onReceiveInfoWithType_login:(NSDictionary *)info
{
    isLogined = YES;
    self.loginData = info;
    
    [GuideEventHandle instance].isClearGuideEvent = YES;
    
    [self postGetCardList];
    [self postGetTotalStoreListRequest];
}

- (void)onReceiveInfoWithType_getTotalStoreList:(NSDictionary *)info
{
    [self.gameDataCache cacheTotalStore:info];
}

- (void)onReceiveInfoWithType_getCardList:(NSDictionary *)info
{
    [self.gameDataCache cacheTotalCard:info];
}

@end
