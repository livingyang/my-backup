//
//  MissionLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-25.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "MissionLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCAlertLayer.h"
#import "CCMenuItemButton.h"
#import "AGMissionPlace.h"
#import "AGMissionInfo.h"
#import "MissionRewardLayer.h"
#import "SlotMachineNode.h"
#import "CCLabelTTF+ChangeFont.h"
#import "AGShopItemInfo.h"
#import "MissionPrisonLayer.h"
#import "SoundManager.h"
#import "ItemLayer.h"
#import "CCVideoPlayer.h"
#import "CCTouchCatchNode.h"

#define PLACE_MOVE_LENGTH (280)
#define INVALID_MAP_ID (-1)

#define TIME_EVENT_EFFECT (2.0f)

static NSString *ImageExp = @"slot-machine/img-slot-exp.png";
static NSString *ImageCoin = @"slot-machine/img-slot-coin.png";

#define IMAGE_X2_NAME @"UI/3-mission/img-x2.png"
#define IMAGE_X5_NAME @"UI/3-mission/img-x5.png"

@implementation BaseLayer (ShowMissionInfo)

#pragma mark -
#pragma mark tip

- (CCAction *)createFadeInAndOutAction
{
    return [CCSequence actions:
            [CCFadeIn actionWithDuration:0.5f],
            [CCDelayTime actionWithDuration:2.0f],
            [CCFadeOut actionWithDuration:0.5f],
            nil];
}

- (void)showTipWithBaseExp:(int)baseExp
                   moreExp:(int)moreExp
                 baseCoins:(int)baseCoins
                 moreCoins:(int)moreCoins
{
    CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"3.8-tip.bmml"
                                                        eventHandle:self];
    [self addChild:layer z:INT_MAX];
    
    [[layer getControlByName:@"exp"] setString:
     [NSString stringWithFormat:@"%d + %d", baseExp, moreExp]];
    [[layer getControlByName:@"coins"] setString:
     [NSString stringWithFormat:@"%d + %d", baseCoins, moreCoins]];
    
    for (CCNode<CCRGBAProtocol> *child in layer.children)
    {
        child.opacity = 0;
        [child runAction:[self createFadeInAndOutAction]];
    }
    
    [layer runAction:[CCSequence actions:
                      [CCDelayTime actionWithDuration:3.0f],
                      [CCCallFunc actionWithTarget:layer selector:@selector(removeFromParentAndCleanup:)],
                      nil]];
}

@end

@implementation MissionLayer

@synthesize fightBossInfo;
@synthesize curPlaceMissinInfo;
@synthesize curMissionFinishInfo;

- (CCBalsamiqLayer *)getBalsamiqLayerFromChild:(id)node
{
    while ([node isKindOfClass:[CCBalsamiqLayer class]] == NO)
    {
        if ([node parent] == nil)
        {
            return nil;
        }
        
        node = [node parent];
    }
    
    return node;
}

- (void)playSlotAnimation:(CCSprite *)spriteSlot
{
    sprSlot = spriteSlot;
    
    [spriteSlot.slotMachine setSlotImages:[AGMissionFinishInfo totalSlotImages]];
    [spriteSlot.slotMachine startSlot];
    
    [self setIsForbidMissionOperate:YES];
}

- (void)updatePlaceList:(AGMissionPlaceList *)placeList withSelectMapId:(int)mapId
{
    BOOL hasUnlockMapId = NO;
    for (AGMissionPlace *place in placeList.unlockedPlaceArray)
    {
        if (place.mapId == mapId)
        {
            hasUnlockMapId = YES;
        }
    }
    
    if (hasUnlockMapId == NO)
    {
        mapId = [placeList.unlockedPlaceArray.lastObject mapId];
    }
    
    CCBalsamiqLayer *selectedCell = nil;
    float startCellPositionX = 0;
    
    CCNode *cellContainer = [CCNode node];
    for (int i = 0; i < placeList.unlockedPlaceArray.count; ++i)
    {
        AGMissionPlace *place = [placeList.unlockedPlaceArray objectAtIndex:i];
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"3.3-place-button.bmml"
                                                                  eventHandle:self];
        
        [place updateDataToLayer:cell];
        
        CCMenuItemButton *button = [cell getControlByName:@"Place"];
        button.tag = place.mapId;
        
        cell.position = ccp(startCellPositionX, 0);
        [cellContainer addChild:cell];
        startCellPositionX += cell.contentSize.width;
        
        if (mapId == place.mapId)
        {
            selectedCell = cell;
            [self onPlaceClick:button];
        }
    }
    
    for (AGMissionPlace *place in placeList.lockedPlaceArray)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"3.3-place-button.bmml"
                                                           eventHandle:self];
        
        [place updateDataToLayer:cell];
        
        CCMenuItemButton *btnPlaceInvalid = [cell getControlByName:@"Place"];
        btnPlaceInvalid.tag = INVALID_MAP_ID;
        btnPlaceInvalid.labelNormalColor = btnPlaceInvalid.labelDisableColor;
        btnPlaceInvalid.label.color = btnPlaceInvalid.labelNormalColor;
        
        cell.position = ccp(startCellPositionX, 0);
        [cellContainer addChild:cell];
        startCellPositionX += cell.contentSize.width;
    }
    
    [placeTableLayer setCellContainer:cellContainer autoSetWithVectorMove:ccp(-1, 0)];
    placeTableLayer.curDistance = [placeTableLayer getCellDistance:selectedCell] + 130;
}

- (CCBalsamiqLayer *)getMissionLayerFromMissionId:(int)missionId
{
    for (id node in missionTableLayer.cellContainer.children)
    {
        if ([node isKindOfClass:[CCBalsamiqLayer class]])
        {
            CCBalsamiqLayer *layer = node;
            if ([[layer getControlByName:@"DoIt"] tag] == missionId)
            {
                return layer;
            }
        }
    }
    
    return nil;
}

- (void)updateMissionTableLayer:(AGPlaceMissionInfo *)totalMissionInfo
{
    CCNode *cellContainer = [CCNode node];
    
    if (totalMissionInfo.bossInfo != nil)
    {
        CCBalsamiqLayer *bossLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"3.2-boss-mission-info.bmml"
                                                                eventHandle:self];
        //lastCellPosY -= bossLayer.contentSize.height;
        bossLayer.position = ccp(0, 0);
        [cellContainer addChild:bossLayer];
        
        [totalMissionInfo.bossInfo updateDataToLayer:bossLayer];
        
        [[bossLayer getControlByName:@"Challenge"] setTag:totalMissionInfo.bossInfo.bossId];
    }
    
    float lastCellPosY = 0;
    for (AGMissionInfo *mission in totalMissionInfo.missionInfoArray)
    {
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"3.1-mission-info.bmml"
                                                            eventHandle:self];
        lastCellPosY -= layer.contentSize.height;
        layer.position = ccp(0, lastCellPosY);
        [cellContainer addChild:layer];
        
        [mission updateDataToLayer:layer];
        [[[layer getControlByName:@"image_slot"] slotMachine] setInitImage:[AGMissionFinishInfo eventImage]];

        [[layer getControlByName:@"DoIt"] setTag:mission.missionId];
    }
    
    [missionTableLayer setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
    
    self.curPlaceMissinInfo = totalMissionInfo;
}

- (void)setIsForbidMissionOperate:(BOOL)isForbidMissionOperate
{
    touchCatchNode.catchTarget = isForbidMissionOperate ? self : nil;
}

- (void)onEnter
{
    [super onEnter];
    
    [self.toolLayer selectRadioItem:@"radio_Tool_mission"];
    
    [self postGetPlayerInfoRequest];
    
    [self onEventHappened:@"IntoMission"];
}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"3-mission.bmml"
                                                            eventHandle:self];
        [self addChild:layer];
        
        self.headerLayer = [layer getControlByName:@"header-property"];
        self.toolLayer = [layer getControlByName:@"tool-bar"];
        
        // mission group table        
        placeTableLayer = [layer getControlByName:@"table-place"];
        placeTableLayer.delegate = self;
        missionTableLayer = [layer getControlByName:@"table-mission"];
        
        [self postGetAccessPlaceList];
        
        touchCatchNode = [CCTouchCatchNode node];
        [self addChild:touchCatchNode];
    }
    
    return self;
}

- (void)dealloc
{
    self.fightBossInfo = nil;
    self.curPlaceMissinInfo = nil;
    self.curMissionFinishInfo = nil;
    
    [super dealloc];
}

- (void)onChallengeClick:(id)sender
{
    if (self.levelUpAlertLayer != nil)
    {
        [self closeLevelUpAlert];
        return;
    }
    
    [self postDoBossMissionRequest:[sender tag]];
}

- (void)onMoveDone:(CCTableLayer *)tableLayer
{
    [btnPlace selected];
}

- (void)onPlaceClick:(id)sender
{
    int mapId = [sender tag];
    if (mapId == INVALID_MAP_ID)
    {
        [self showSystemTip:[self getLanguageString:@"3002"]];
        return;
    }
    
    if (btnPlace == sender)
    {
        return;
    }
    
    [self postGetPlaceMissionRequest:mapId];
    
    [btnPlace unselected];
    btnPlace = sender;
    [btnPlace selected];
}

- (void)onDoItClick:(id)sender
{
    if (sprSlot != nil)
    {
        return;
    }
    
    CCBalsamiqLayer *missionLayer = [self getBalsamiqLayerFromChild:sender];
    [self playSlotAnimation:[missionLayer getControlByName:@"image_slot"]];
    
    [self postDoMissionRequest:[sender tag]];
    
    [[SoundManager instance] playEffectSlot];
}

- (void)onPrevClick:(id)sender
{
    placeTableLayer.curDistance -= PLACE_MOVE_LENGTH;
}

- (void)onNextClick:(id)sender
{
    placeTableLayer.curDistance += PLACE_MOVE_LENGTH;
}

#pragma mark -
#pragma mark event

- (void)onEventEffectDone
{
    [self setIsForbidMissionOperate:NO];
    
    [self postGetPlayerInfoRequest];
}

- (void)onEventOkClick:(id)sender
{
    [self setIsForbidMissionOperate:YES];
    
    [self runAction:[CCSequence actions:
                     [CCDelayTime actionWithDuration:TIME_EVENT_EFFECT],
                     [CCCallFunc actionWithTarget:self selector:@selector(onEventEffectDone)],
                     nil]];
    
    if ([self.curMissionFinishInfo.rewardType isEqualToString:@"Event1"])
    {
        [self showBoomPercentEvent];
    }
    else if ([self.curMissionFinishInfo.rewardType isEqualToString:@"Event2"])
    {
        [self showDoubleExpAndCoinEvent];
    }
    else if ([self.curMissionFinishInfo.rewardType isEqualToString:@"Event3"])
    {
        [self showPrisonEvent:sender];
    }
    else if ([self.curMissionFinishInfo.rewardType isEqualToString:@"Event4"])
    {
        [self showZeroMissionEvent];
    }
    else if ([self.curMissionFinishInfo.rewardType isEqualToString:@"Event5"])
    {
        [self showFiveExpAndCoinEvent];
    }
    else if ([self.curMissionFinishInfo.rewardType isEqualToString:@"Event6"])
    {
        [self showBlinkEnergyEvent];
    }
    
    [CCAlertLayer removeAlertFromNode:sender];
}

- (void)showEventLayer
{
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"3.1.2-mission-event.bmml"
                                       parentNode:self];
    
    CCMenuItemButton *btnEvent = [alert.balsamiqLayer getControlByName:@"EventOk"];
    btnEvent.normalImage = [CCSprite spriteWithFile:[@"event" stringByAppendingPathComponent:self.curMissionFinishInfo.eventInfo.imageName]];
    btnEvent.selectedImage = [CCSprite spriteWithFile:[@"event" stringByAppendingPathComponent:self.curMissionFinishInfo.eventInfo.imageName]];
    
    [[alert.balsamiqLayer getControlByName:@"title"] setString:self.curMissionFinishInfo.eventInfo.name];
    [[alert.balsamiqLayer getControlByName:@"detail"] setString:self.curMissionFinishInfo.eventInfo.detail];
    
    alert.balsamiqLayer.scale = 0;
    [alert.balsamiqLayer runAction:[CCScaleTo actionWithDuration:0.5f scale:1.0f]];
//    [self showSystemTip:@"Event happened!!"];
}

- (void)showZeroMissionEvent
{
    CCBalsamiqLayer *missionLayer = [self getMissionLayerFromMissionId:self.curMissionFinishInfo.missionInfo.missionId];
    
    [[missionLayer getControlByName:@"bar_mission"] runAction:[CCSequence actions:
                                                               [CCBlink actionWithDuration:0.8f blinks:3],
                                                               [CCCallFunc actionWithTarget:[SoundManager instance] selector:@selector(playEffectRefineFail)],
                                                               [CCProgressTo actionWithDuration:1.0f percent:0],
                                                               [CCCallFuncO actionWithTarget:self.curMissionFinishInfo.missionInfo
                                                                                    selector:@selector(updateDataToLayer:)
                                                                                      object:missionLayer],
                                                               nil]];
    
    [self showTipWithBaseExp:self.curMissionFinishInfo.missionInfo.exp
                     moreExp:0
                   baseCoins:self.curMissionFinishInfo.missionInfo.coin
                   moreCoins:0];
}

- (void)displayImage:(NSString *)imageName onSprite:(CCSprite *)sprite
{
    CCLabelTTF *sprImage = [CCSprite spriteWithFile:imageName];
    sprImage.anchorPoint = CGPointZero;
    sprImage.position = ccp(0, sprite.contentSize.height / 2);
    sprImage.opacity = 0;
    
    [sprite addChild:sprImage];
    
    id actionIn = [CCSpawn actionOne:[CCFadeIn actionWithDuration:0.5f]
                                 two:[CCMoveBy actionWithDuration:0.5f position:ccp(0, 15)]];
    id actionOut = [CCSpawn actionOne:[CCFadeOut actionWithDuration:0.5f]
                                  two:[CCMoveBy actionWithDuration:0.5f position:ccp(0, 15)]];
    
    [sprImage runAction:[CCSequence actions:
                      actionIn,
                      [CCDelayTime actionWithDuration:0.5f],
                      actionOut,
                      [CCCallFunc actionWithTarget:sprImage selector:@selector(removeFromParentAndCleanup:)],
                      nil]];
}

- (id)getBoomAction:(float)boomScale
{
    return [CCSequence actions:
            [CCScaleTo actionWithDuration:0.5f scale:boomScale],
            [CCScaleTo actionWithDuration:0.5f scale:1.0f],
            nil];
}

- (void)showDoubleExpAndCoinEvent
{
    CCBalsamiqLayer *missionLayer = [self getMissionLayerFromMissionId:self.curMissionFinishInfo.missionInfo.missionId];
    [self.curMissionFinishInfo.missionInfo updateDataToLayer:missionLayer];
    
    CCSprite *sprXp = [missionLayer getControlByName:@"image_xp"];
    CCSprite *sprCoin = [missionLayer getControlByName:@"image_coin"];
    
    [self displayImage:IMAGE_X2_NAME onSprite:sprXp];
    [self displayImage:IMAGE_X2_NAME onSprite:sprCoin];
    
    id action = [CCSequence actions:
                 [CCDelayTime actionWithDuration:1.5f],
                 [self getBoomAction:1.5],
                 nil];
    [sprXp runAction:[action copy]];
    [sprCoin runAction:action];
    
    [self showTipWithBaseExp:self.curMissionFinishInfo.missionInfo.exp
                     moreExp:self.curMissionFinishInfo.missionInfo.exp
                   baseCoins:self.curMissionFinishInfo.missionInfo.coin
                   moreCoins:self.curMissionFinishInfo.missionInfo.coin];
}

- (void)showBlinkEnergyEvent
{
    CCBalsamiqLayer *missionLayer = [self getMissionLayerFromMissionId:self.curMissionFinishInfo.missionInfo.missionId];
    [self.curMissionFinishInfo.missionInfo updateDataToLayer:missionLayer];
    
    id actionBlick = [CCBlink actionWithDuration:1.5f blinks:8];
    [[missionLayer getControlByName:@"image_energy"] runAction:[actionBlick copy]];
    [[missionLayer getControlByName:@"energy"] runAction:actionBlick];
    
    [self showTipWithBaseExp:self.curMissionFinishInfo.missionInfo.exp
                     moreExp:0
                   baseCoins:self.curMissionFinishInfo.missionInfo.coin
                   moreCoins:0];
}

- (void)showBoomPercentEvent
{
    CCBalsamiqLayer *missionLayer = [self getMissionLayerFromMissionId:self.curMissionFinishInfo.missionInfo.missionId];

    [[missionLayer getControlByName:@"percent"] runAction:[CCSequence actions:
                                                           [self getBoomAction:1.5f],
                                                           [CCCallFuncO actionWithTarget:self.curMissionFinishInfo.missionInfo
                                                                                selector:@selector(updateDataToLayer:)
                                                                                  object:missionLayer],
                                                           nil]];
    
    [self showTipWithBaseExp:self.curMissionFinishInfo.missionInfo.exp
                     moreExp:0
                   baseCoins:self.curMissionFinishInfo.missionInfo.coin
                   moreCoins:0];
}

- (void)showFiveExpAndCoinEvent
{
    CCBalsamiqLayer *missionLayer = [self getMissionLayerFromMissionId:self.curMissionFinishInfo.missionInfo.missionId];
    
    CCSprite *sprXp = [missionLayer getControlByName:@"image_xp"];
    CCSprite *sprCoin = [missionLayer getControlByName:@"image_coin"];
    
    [self displayImage:IMAGE_X5_NAME onSprite:sprXp];
    [self displayImage:IMAGE_X5_NAME onSprite:sprCoin];
    
    [[missionLayer getControlByName:@"bar_mission"] runAction:[CCSequence actions:
                                                               [CCBlink actionWithDuration:0.8f blinks:3],
                                                               [CCCallFunc actionWithTarget:[SoundManager instance] selector:@selector(playEffectRecovery)],
                                                               [CCProgressTo actionWithDuration:1.0f percent:100],
                                                               [CCCallFuncO actionWithTarget:self.curMissionFinishInfo.missionInfo
                                                                                    selector:@selector(updateDataToLayer:)
                                                                                      object:missionLayer],
                                                               nil]];
    
    [self showTipWithBaseExp:self.curMissionFinishInfo.missionInfo.exp
                     moreExp:self.curMissionFinishInfo.missionInfo.exp * 4
                   baseCoins:self.curMissionFinishInfo.missionInfo.coin
                   moreCoins:self.curMissionFinishInfo.missionInfo.coin * 4];
}

- (void)showPrisonEvent:(CCMenuItemButton *)btnEvent
{
    [[AGPrizonInfo instance] arrestAtMissionPlace:self.curMissionFinishInfo.missionInfo.mapId];
    [[CCDirector sharedDirector] replaceScene:[MissionPrisonLayer sceneWithEventTimeAndAnime:self.curMissionFinishInfo.prizonTime
                                                                                andEventNode:btnEvent]];
}

#pragma mark -
#pragma mark card

- (void)showCardLayer:(NSString *)cardName
{
    AGCardInfo *cardInfo = [[AGCardInfoCache instance] getCardInfoByName:cardName];
    
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"3.4-gain-card.bmml"
                                       parentNode:self];
    CCSprite *sprBg = [alert.balsamiqLayer getControlByName:@"image_bg"];
    sprBg.opacity = 200;
    
    [cardInfo updateDataToLayer:alert.balsamiqLayer];
    
    CCMenuItemImage *btnCardImage = [alert.balsamiqLayer getControlByName:@"CardImage"];
    btnCardImage.opacity = 0;
    CCMenuItemImage *btnCardOk = [alert.balsamiqLayer getControlByName:@"CardOk"];
    CCMenuItemImage *btnCardExchange = [alert.balsamiqLayer getControlByName:@"CardExchange"];
    CCLabelTTF *labDetail = [alert.balsamiqLayer getControlByName:@"detail-gain"];
    labDetail.string = [NSString stringWithFormat:[self getLanguageString:@"3004"],
                        cardInfo.name, cardInfo.exchangeItem.name];
    
    CCSprite *sprCard = [alert.balsamiqLayer getControlByName:@"image_card"];
    sprCard.scale = 0;
    id scaleAndRotateAction = [CCSpawn actionOne:[CCScaleTo actionWithDuration:0.8f scale:1.2f]
                                             two:[CCRotateBy actionWithDuration:0.8f angle:360 * 2]];
    id moveAction = [CCRepeat actionWithAction:[CCSequence actions:
                                                [CCMoveBy actionWithDuration:1.0f position:ccp(0, 20)],
                                                [CCMoveBy actionWithDuration:1.0f position:ccp(0, -20)],
                                                nil] times:1000];
    [sprCard runAction:[CCSequence actions:
                        scaleAndRotateAction,
                        [CCDelayTime actionWithDuration:0.5f],
                        [CCScaleTo actionWithDuration:0.3f scale:1],
                        [CCCallFuncO actionWithTarget:btnCardOk.parent selector:@selector(addChild:) object:btnCardOk],
                        [CCCallFuncO actionWithTarget:btnCardImage.parent selector:@selector(addChild:) object:btnCardImage],
                        [CCCallFuncO actionWithTarget:btnCardExchange.parent selector:@selector(addChild:) object:btnCardExchange],
                        [CCCallFuncO actionWithTarget:labDetail.parent selector:@selector(addChild:) object:labDetail],
                        moveAction,
                        nil]];
    
    [btnCardExchange removeFromParentAndCleanup:YES];
    [btnCardOk removeFromParentAndCleanup:YES];
    [labDetail removeFromParentAndCleanup:YES];
    [btnCardImage removeFromParentAndCleanup:YES];
}

- (void)onCardOkClick:(id)sender
{
    [CCAlertLayer removeAlertFromNode:sender];
    [[SoundManager instance] playEffectButtonOk];
    [self postGetPlayerInfoRequest];
    
    [self showTipWithBaseExp:self.curMissionFinishInfo.missionInfo.exp
                     moreExp:0
                   baseCoins:self.curMissionFinishInfo.missionInfo.coin
                   moreCoins:0];
}

- (void)onCardImageClick:(id)sender
{
    [CCAlertLayer removeAlertFromNode:sender];
    [[SoundManager instance] playEffectButtonOk];
    [self postGetPlayerInfoRequest];
    
    [self showTipWithBaseExp:self.curMissionFinishInfo.missionInfo.exp
                     moreExp:0
                   baseCoins:self.curMissionFinishInfo.missionInfo.coin
                   moreCoins:0];
}

- (void)onCardExchangeClick:(id)sender
{
    CCScene *scene = [ItemLayer sceneWithTab:2];
    [[CCDirector sharedDirector] replaceScene:scene];
    
    ItemLayer *layer = [scene.children lastObject];
    if ([layer isKindOfClass:[BaseLayer class]])
    {
        [layer showTipWithBaseExp:self.curMissionFinishInfo.missionInfo.exp
                          moreExp:0
                        baseCoins:self.curMissionFinishInfo.missionInfo.coin
                        moreCoins:0];
    }
}

- (void)onRewardOkClick:(id)sender
{
    [CCAlertLayer removeAlertFromNode:sender];
}

- (void)showRewardLayer:(AGMissionFinishInfo *)finishInfo
{
    if (finishInfo.isRewardEvent)
    {
        [self showEventLayer];
        return;
    }
    
    [self.curMissionFinishInfo.missionInfo updateDataToLayer:
     [self getMissionLayerFromMissionId:self.curMissionFinishInfo.missionInfo.missionId]];
    
    if (finishInfo.isRewardCard)
    {
        [self showCardLayer:finishInfo.rewardType];
        return;
    }
    
    [self postGetPlayerInfoRequest];
    
    if (finishInfo.isRewardExp)
    {
        [self showTipWithBaseExp:finishInfo.missionInfo.exp
                         moreExp:finishInfo.rewardNum
                       baseCoins:finishInfo.missionInfo.coin
                       moreCoins:0];
        
        return;
    }
    
    if (finishInfo.isRewardCoin)
    {
        [self showTipWithBaseExp:finishInfo.missionInfo.exp
                         moreExp:0
                       baseCoins:finishInfo.missionInfo.coin
                       moreCoins:finishInfo.rewardNum];
        return;
    }
    
    if (finishInfo.isRewardNone)
    {
        [self showTipWithBaseExp:finishInfo.missionInfo.exp
                         moreExp:0
                       baseCoins:finishInfo.missionInfo.coin
                       moreCoins:0];
        return;
    }
    
    return;
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"3.1.1-mission-reward-info.bmml"
                                       parentNode:self];
    [[alert.balsamiqLayer getControlByName:@"reward"] setString:finishInfo.rewardItem];
}

#pragma mark -
#pragma mark VideoManagerDelegate

- (void)onBossLostOkClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [CCAlertLayer removeAlertFromNode:sender];
}

- (void)onBossLostItemClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    [[CCDirector sharedDirector] replaceScene:[ItemLayer sceneWithTab:1]];
}

- (void)onPkBossVideoPlayDone
{
    if (self.fightBossInfo.isWin)
    {
        [[CCDirector sharedDirector] replaceScene:[MissionRewardLayer sceneWithRewardItem:self.fightBossInfo
                                                                             withBossInfo:self.curPlaceMissinInfo.bossInfo]];
    }
    else
    {
        CCAlertLayer *alert = [CCAlertLayer showAlert:@"3.5.1-lose-boss.bmml" parentNode:self];
        
        [[alert.balsamiqLayer getControlByName:@"servant-count"] setString:
         [NSString stringWithFormat:@"%d", self.curPlaceMissinInfo.bossInfo.needsServantCount]];
        CCLabelTTF *labLost = [alert.balsamiqLayer getControlByName:@"lost"];
        labLost.string = [labLost.string stringByReplacingOccurrencesOfString:@"name"
                                                                   withString:self.curPlaceMissinInfo.bossInfo.name];
    }
    
    [self postGetPlayerInfoRequest];
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_getPlaceMission:(NSDictionary *)info
{
    [self updateMissionTableLayer:[AGPlaceMissionInfo getTotalMissionAtPlaceInfo:info]];
}

- (void)onReceiveInfoWithType_getAccessPlaceList:(NSDictionary *)info
{
    NSTimeInterval forbidTime = [AGMissionPlaceList getForbidDoMissionTime:info];
    if (forbidTime > 0)
    {
        [[CCDirector sharedDirector] replaceScene:[MissionPrisonLayer sceneWithEventTime:forbidTime]];
    }
    else
    {
        [self updatePlaceList:[AGMissionPlaceList placeListFromInfo:info]
              withSelectMapId:[AGPrizonInfo instance].isInPrizon ? [AGPrizonInfo instance].prizonAtMapId : INVALID_MAP_ID];
        
        if ([AGPrizonInfo instance].isInPrizon)
        {
            [[AGPrizonInfo instance] leavePrizon];
            
            [CCAlertLayer showAlert:@"3.10-leave-prizon.bmml"
                         parentNode:self];
        } 
    }
}

#pragma mark -
#pragma mark doMission

- (void)onSlotStop
{
    sprSlot = nil;
    
    [self setIsForbidMissionOperate:NO];
    
    [self showRewardLayer:self.curMissionFinishInfo];
    
    [self onEventHappened:@"DoMission"];
}

- (void)onReceiveInfoWithType_doMission:(NSDictionary *)info
{    
    self.curMissionFinishInfo = [AGMissionFinishInfo missionFinishInfoFromInfo:info];
    
    [sprSlot runAction:[CCSequence actions:
                        [CCDelayTime actionWithDuration:1],
                        [CCCallFuncO actionWithTarget:sprSlot.slotMachine
                                             selector:@selector(stopSlotAtImage:)
                                               object:self.curMissionFinishInfo.rewardSlotImage],
                        [CCDelayTime actionWithDuration:0.5f],
                        [CCCallFunc actionWithTarget:self selector:@selector(onSlotStop)],
                        nil]];
    return;

}

- (void)onReceiveInfoWithType_doMission_err:(NSDictionary *)info
{
    if (sprSlot != nil)
    {
        [sprSlot.slotMachine stopSlotAtImage:[AGMissionFinishInfo noneImage]];
        
        sprSlot = nil;
    }
    [self setIsForbidMissionOperate:NO];
}

- (void)onReceiveInfoWithType_energy_not_enough:(NSDictionary *)info
{
    [super onReceiveInfoWithType_energy_not_enough:info];
    
    if (sprSlot != nil)
    {
        [sprSlot.slotMachine stopSlotAtImage:[AGMissionFinishInfo noneImage]];
        
        sprSlot = nil;
    }
    [self setIsForbidMissionOperate:NO];
}

- (void)onReceiveFail:(NSURLConnection *)connection
{
    [self setIsForbidMissionOperate:NO];
}

- (void)onReceiveInfoWithType_pkBoss:(NSDictionary *)info
{
    self.fightBossInfo = [AGMissionFightBossInfo fightBossInfoFromInfo:info];
    
    [[CCVideoPlayer instance] playerVideo:@"fight"
                                   ofType:@"mp4"
                                 callback:[CCCallFunc actionWithTarget:self selector:@selector(onPkBossVideoPlayDone)]];
    
    [[SoundManager instance] playVibrate];
}

- (void)onCancelAlertClick:(id)sender
{
    [self onCommonAlertCloseClick:sender];
}

- (void)onBattleAlertClick:(id)sender
{
    [self onSelect_radio_Tool_battle:nil];
}

- (void)onReceiveInfoWithType_pkBoss_not_enough:(NSDictionary *)info
{
    // 缺少的帮派人数
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"3.5.2-servant-not-enough.bmml"
                                       parentNode:self];
    
    [[alert.balsamiqLayer getControlByName:@"detail"] setString:
     [NSString stringWithFormat:[self getLanguageString:@"3003"],
      self.curPlaceMissinInfo.bossInfo.needsServantCount]];
}

- (void)onReceiveInfoWithType_getPlayerInfo:(NSDictionary *)info
{
    [super onReceiveInfoWithType_getPlayerInfo:info];

    if (self.curMissionFinishInfo != nil && self.curMissionFinishInfo.needsRefresh)
    {
        [self postGetPlaceMissionRequest:self.curMissionFinishInfo.missionInfo.mapId];
        self.curMissionFinishInfo.needsRefresh = NO;
        
        [[SoundManager instance] playEffectWarningBoss];
    }
}

@end
