//
//  GangsterLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-11.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "GangsterLayer.h"
#import "CCBalsamiqLayer.h"
#import "HomeLayer.h"
#import "CCTableLayer.h"
#import "CharacterListLayer.h"
#import "EquipmentListLayer.h"
#import "CCAlertLayer.h"
#import "AGPlayerInfo.h"
#import "AGServantHeaderInfo.h"
#import "AGServantInfo.h"
#import "AGEquipmentInfo.h"
#import "AGStoreItemInfo.h"
#import "CharacterImageManager.h"
#import "RefineLayer.h"

int lastSelectServantHeaderIndex = 0;

#define INVALID_SERVANT_ID (-1)
#define INVALID_SERVANT_INDEX (-1)
#define TAG_ICON_SIGH (12345)

@implementation GangsterLayer

@synthesize headerLayerArray;
@synthesize servantInfo;

+ (CCScene *)scene
{
    lastSelectServantHeaderIndex = 0;
    
    return [super scene];
}

+ (CCScene *)sceneWithSelectServantHeaderIndex:(int)selectServantHeaderIndex
{
    lastSelectServantHeaderIndex = selectServantHeaderIndex;
    return [super scene];
}

- (void)loadHeaderLayer:(int)headerCount headerLockInfo:(AGServantHeaderLockInfo *)headerLockInfo
{
    self.headerLayerArray = [NSMutableArray array];
    CCNode *cellContainer = [CCNode node];
    
    float lastLayerXPos = 0;
    for (int i = 0; i < headerCount; ++i)
    {
        CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"5.5-character-header.bmml"
                                                            eventHandle:self];
        layer.position = ccp(lastLayerXPos, 0);
        lastLayerXPos += layer.contentSize.width;
        [cellContainer addChild:layer];
        
        [self.headerLayerArray addObject:layer];
    }
    
    if (headerLockInfo.hasLockHeader)
    {
        CCBalsamiqLayer *lockLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"5.5.1-header-lock.bmml"
                                                                eventHandle:self];
        lockLayer.position = ccp(lastLayerXPos, 0);

        [[lockLayer getControlByName:@"Lock"] setTag:headerLockInfo.nextUnlockLevel];
        
        [cellContainer addChild:lockLayer];
    }
    
    [tableLayer setCellContainer:cellContainer autoSetWithVectorMove:ccp(-1, 0)];
}

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"5-gangster.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        self.headerLayer = [balsamiqLayer getControlByName:@"header-property"];
        self.toolLayer = [balsamiqLayer getControlByName:@"tool-bar"];
        
        sprHeaderBorder = [balsamiqLayer getControlByName:@"image_border"];
        
        tableLayer = [balsamiqLayer getControlByName:@"table"];
        
        {
            layerEquipment1 = [balsamiqLayer getControlByName:@"equipment1"];
            layerEquipment2 = [balsamiqLayer getControlByName:@"equipment2"];
            layerEquipment3 = [balsamiqLayer getControlByName:@"equipment3"];
            layerEquipment4 = [balsamiqLayer getControlByName:@"equipment4"];
        }
        
        [self postGetMyServantHeader];
//        self.isLoading = YES;
    }
    
    return self;
}

- (void)onEnter
{
    [super onEnter];
    
    [self.toolLayer selectRadioItem:@"radio_Tool_group"];
    [self postGetPlayerInfoRequest];
    
    [self onEventHappened:@"IntoGroup"];
}

- (void)dealloc
{
    self.headerLayerArray = nil;
    self.servantInfo = nil;
    
    [super dealloc];
}

- (NSString *)loadingLayerName
{
    return @"0-loading.bmml";
}

- (int)getHeaderIndex:(id)sender
{
    return [self.headerLayerArray containsObject:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]]
    ? [self.headerLayerArray indexOfObject:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]]
    : INVALID_SERVANT_INDEX;
}

- (void)onCloseClick:(id)sender
{
    [CCAlertLayer removeAlertFromNode:sender];
}

- (void)onChangeEquipmentClick:(id)sender
{
    [[CCDirector sharedDirector] replaceScene:[EquipmentListLayer sceneWithPos:[sender tag]
                                                                 withServantId:self.servantInfo.servantId]];
}

- (void)onRefineClick:(id)sender
{
    int equipmentPos = [sender tag];
    
    AGEquipmentInfo *equipment = [self.servantInfo equipmentWithPos:equipmentPos];
    [[CCDirector sharedDirector] replaceScene:
     [RefineLayer sceneWithEquipmentType:equipment.storeItemInfo.type withEquipmentId:equipment.uniqueId]];
}

- (void)onEquipmentIconClick:(id)sender
{
    NSArray *equipmentLayerArray = [NSArray arrayWithObjects:
                                    layerEquipment1,
                                    layerEquipment2,
                                    layerEquipment3,
                                    layerEquipment4,
                                    nil];
    
    int equipmentPos = [equipmentLayerArray indexOfObject:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]] + 1;
    
    if ([self.servantInfo equipmentWithPos:equipmentPos] == nil)
    {
        [[CCDirector sharedDirector] replaceScene:[EquipmentListLayer sceneWithPos:equipmentPos
                                                                     withServantId:self.servantInfo.servantId]];
    }
    else
    {
        CCAlertLayer *alert = [CCAlertLayer showAlert:@"5.4-confirm.bmml" parentNode:self];
        [[alert.balsamiqLayer getControlByName:@"ChangeEquipment"] setTag:equipmentPos];
        [[alert.balsamiqLayer getControlByName:@"Refine"] setTag:equipmentPos];
        
        [[self.servantInfo equipmentWithPos:equipmentPos] updateDataToLayer:alert.balsamiqLayer];
        
        [self onEventHappened:@"ShowEquipmentSelection"];
    }
}

- (void)onChangeClick:(id)sender
{
    if ([sender tag] == 0)
    {
        [self showSystemTip:[self getLanguageString:@"5001"]];
        return;
    }
    
    [[CCDirector sharedDirector] replaceScene:[CharacterListLayer sceneWithIndex:[sender tag]]];
}

- (void)onServantHeaderClick:(id)sender
{
    int servantId = [sender tag];
    
    [[balsamiqLayer getControlByName:@"Change"] setTag:[self getHeaderIndex:sender]];
    
    if (servantId != INVALID_SERVANT_ID)
    {
        // 更新当前小弟信息
        sprHeaderBorder.position = CGPointZero;
        sprHeaderBorder.anchorPoint = CGPointZero;
        [sprHeaderBorder removeFromParentAndCleanup:YES];
        [sender addChild:sprHeaderBorder];
        
        [self postGetServantInfoRequest:servantId];        
    }
    else
    {
        [[CCDirector sharedDirector] replaceScene:[CharacterListLayer sceneWithIndex:[self getHeaderIndex:sender]]];
    }
}

- (void)onMissionClick:(id)sender
{
    [self onSelect_radio_Tool_mission:nil];
}

- (void)onLockClick:(id)sender
{
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"5.9-lock-alert.bmml"
                                       parentNode:self];
    
    [[alert.balsamiqLayer getControlByName:@"detail"] setString:
     [NSString stringWithFormat:[self getLanguageString:@"5002"], [sender tag]]];
}

#pragma mark -
#pragma mark data update func

- (void)updateEquipmentInfo:(AGEquipmentInfo *)info toLayer:(CCBalsamiqLayer *)layer slotSprite:(CCSprite *)slotSprite
{
    [layer removeChildByTag:TAG_ICON_SIGH cleanup:YES];
    
    if (info == nil)
    {
        [[layer getControlByName:@"name"] setString:@""];
        [[layer getControlByName:@"image_icon"] setVisible:NO];
        [[layer getControlByName:@"attack"] setString:@""];
        [[layer getControlByName:@"defense"] setString:@""];
        [[layer getControlByName:@"refine-count"] setString:@""];
        [[layer getControlByName:@"image_count_bg"] setVisible:NO];
        
        CCProgressTimer *barRefine = [layer getControlByName:@"bar_refine"];
        barRefine.percentage = 0;
        
        CCSprite *sprIcon = [layer getControlByName:@"image_icon"];
        CCSprite *spr = [CCSprite spriteWithTexture:slotSprite.texture];
        spr.position = sprIcon.position;
        [layer addChild:spr z:sprIcon.zOrder tag:TAG_ICON_SIGH];
        
        for (int i = 1; i <= 5; ++i)
        {
            [[layer getControlByName:[NSString stringWithFormat:@"image_star%d", i]] setVisible:NO];
        }
    }
    else
    {
        [[layer getControlByName:@"image_icon"] setVisible:YES];
        [[layer getControlByName:@"image_count_bg"] setVisible:YES];
        
        [info updateDataToLayer:layer];
        
        CCProgressTimer *barRefine = [layer getControlByName:@"bar_refine"];
        // 这样做是为了让进度显示的正常些
        barRefine.percentage = info.refinePercent * 0.9f + 10;
    }
}

- (void)updateServantInfo:(AGServantInfo *)info
{
    [info.opponentInfo updateDataToLayer:balsamiqLayer];
    
    [[balsamiqLayer getControlByName:@"image_servant"] setTexture:
     [[CharacterImageManager instance] getTextureFromImageName:info.opponentInfo.imageName]];
    
    [self updateEquipmentInfo:info.equipment1 toLayer:layerEquipment1 slotSprite:[balsamiqLayer getControlByName:@"image_equipment1"]];
    [self updateEquipmentInfo:info.equipment2 toLayer:layerEquipment2 slotSprite:[balsamiqLayer getControlByName:@"image_equipment2"]];
    [self updateEquipmentInfo:info.equipment3 toLayer:layerEquipment3 slotSprite:[balsamiqLayer getControlByName:@"image_equipment3"]];
    [self updateEquipmentInfo:info.equipment4 toLayer:layerEquipment4 slotSprite:[balsamiqLayer getControlByName:@"image_equipment4"]];
    
    self.servantInfo = info;
    
    for (int i = 0; i < self.headerLayerArray.count; ++i)
    {
        CCBalsamiqLayer *layer = [self.headerLayerArray objectAtIndex:i];
        
        if ([[layer getControlByName:@"ServantHeader"] tag] == info.servantId)
        {
            lastSelectServantHeaderIndex = i;
        }
    }
}

- (CCBalsamiqLayer *)curSelectServantHeaderLayer
{
    CCBalsamiqLayer *curSelectLayer = [self.headerLayerArray objectAtIndex:lastSelectServantHeaderIndex];
    
    return ([[curSelectLayer getControlByName:@"ServantHeader"] tag] != INVALID_SERVANT_ID)
    ? curSelectLayer
    : [self.headerLayerArray objectAtIndex:0];
}

- (void)updateServantHeader:(NSArray *)servantList
{
    for (CCBalsamiqLayer *layer in self.headerLayerArray)
    {
        [[layer getControlByName:@"image_header"] setVisible:NO];
        CCMenuItemImage *btnHeader = [layer getControlByName:@"ServantHeader"];
        btnHeader.tag = INVALID_SERVANT_ID;
        btnHeader.opacity = 255;
    }
    
    for (AGServantHeaderInfo *headerInfo in servantList)
    {
        if (headerInfo.headerIndex >= self.headerLayerArray.count)
        {
            NSLog(@"GangsterLayer#updateServantHeader invalid index = %d", headerInfo.headerIndex);
            continue;
        }
        
        CCBalsamiqLayer *headerLayer = [self.headerLayerArray objectAtIndex:headerInfo.headerIndex];
        
        [[headerLayer getControlByName:@"image_header"] setVisible:YES];
        CCMenuItemImage *btnHeader = [headerLayer getControlByName:@"ServantHeader"];
        btnHeader.tag = headerInfo.servantId;
        btnHeader.opacity = 0;
        
        [headerInfo updateDataToLayer:headerLayer];
    }
    
    // 更新头像列表后，需要获取第一个玩家的装备信息
    tableLayer.curDistance = [tableLayer getCellDistance:self.curSelectServantHeaderLayer];
    [self onServantHeaderClick:[self.curSelectServantHeaderLayer getControlByName:@"ServantHeader"]];
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_getMyServantHeaders:(NSDictionary *)info
{
    [self loadHeaderLayer:[AGPlayerInfo defaultPlayerInfo].maxServantCount
           headerLockInfo:[AGServantHeaderLockInfo headerLockInfoFromDic:info]];
    
    NSArray *servantList = [AGServantHeaderInfo getServantListFromInfo:info];
    [self updateServantHeader:servantList];
}

- (void)onReceiveInfoWithType_getMyServantBind:(NSDictionary *)info
{
    [self updateServantInfo:[AGServantInfo servantInfoFromInfo:info]];
}


@end
