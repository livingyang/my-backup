//
//  MissionLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-25.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"
#import "CCTableLayer.h"

@class CCMenuItemButton;
@class AGMissionFightBossInfo;
@class AGPlaceMissionInfo;
@class AGMissionFinishInfo;
@class CCTouchCatchNode;
@interface MissionLayer : BaseLayer <CCTableLayerDelegate>
{
    CCTableLayer *missionTableLayer;
    CCTableLayer *placeTableLayer;
    
    CCMenuItemButton *btnPlace;
    CCSprite *sprSlot;
    
    CCTouchCatchNode *touchCatchNode;
}

@property (nonatomic, retain) AGPlaceMissionInfo *curPlaceMissinInfo;
@property (nonatomic, retain) AGMissionFinishInfo *curMissionFinishInfo;
@property (nonatomic, retain) AGMissionFightBossInfo *fightBossInfo;

@end
