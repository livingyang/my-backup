//
//  PackLayer.h
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-5-5.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "BaseLayer.h"

@class CCBalsamiqLayer;
@class CCTableLayer;
@class RadioManager;
@interface PackLayer : BaseLayer
{
    CCBalsamiqLayer *balsamiqLayer;
    
    int lastSellItemId;
}

@property (nonatomic, readonly) CCTableLayer *tableLayer;
@property (nonatomic, readonly) RadioManager *kindRadioManager;
@property (nonatomic, readonly) CCLabelTTF *labListCount;

@property (nonatomic, retain) NSArray *packItemList;

+ (CCScene *)sceneWithEquipmentType:(int)type;

@end
