//
//  CharacterListLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-11.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "CharacterListLayer.h"
#import "CCBalsamiqLayer.h"
#import "GangsterLayer.h"
#import "CCTableLayer.h"
#import "AGServantInfo.h"
#import "CharacterImageManager.h"

#define COUNT_OF_MORE_SERVANT (10)

@implementation CharacterListLayer

@synthesize headerIndex;
@synthesize servantArray;

+ (CCScene *)sceneWithIndex:(int)headerIndex
{
    CCScene *scene = [CCScene node];
    CharacterListLayer *layer = [CharacterListLayer node];
    layer.headerIndex = headerIndex;
    [scene addChild:layer];
    
    return scene;
}

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"5.2-character-list.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        selectedToggle = nil;
        
        self.headerLayer = [balsamiqLayer getControlByName:@"header-property"];
        
        [self postGetMyServantList];
    }
    
    return self;
}

- (void)dealloc
{
    self.servantArray = nil;
    
    [super dealloc];
}

- (void)onBackClick:(id)sender
{
    [[CCDirector sharedDirector] replaceScene:[GangsterLayer sceneWithSelectServantHeaderIndex:lastSelectServantHeaderIndex]];
}

- (CCBalsamiqLayer *)selectedLayer
{
    if (selectedToggle == nil)
    {
        return nil;
    }
    
    id layerParent = selectedToggle;
    while ([layerParent class] != [CCBalsamiqLayer class])
    {
        if ([layerParent parent] == nil)
        {
            return nil;
        }
        
        layerParent = [layerParent parent];
    }
    
    return layerParent;
}

- (void)onOkClick:(id)sender
{
    CCBalsamiqLayer *selectLayer = [self selectedLayer];
    if (selectLayer != nil)
    {
        int servantId = [[selectLayer getControlByName:@"image_header"] tag];
        NSLog(@"select servant id = %d", servantId);
        
        [self postChangeServant:servantId pos:self.headerIndex];
    }
}

- (void)onClick_toggle_ok:(CCMenuItemToggle *)toggle
{
    if (toggle == selectedToggle)
    {
        selectedToggle = nil;
    }
    else
    {
        selectedToggle.selectedIndex = 0;
        selectedToggle = toggle;
    }
    
    [self onEventHappened:@"SelectServant"];
}

- (void)updateTableLayer:(NSArray *)servantList
{
    [[balsamiqLayer getControlByName:@"count"] setString:[NSString stringWithFormat:@"%d", servantList.count]];

    if (servantList.count == 0)
    {
        CCNode *cellContainer = [CCNode node];
        [cellContainer addChild:[CCBalsamiqLayer layerWithBalsamiqFile:@"5.10-no-servant-tip.bmml"
                                                           eventHandle:self]];
        [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
        return;
    }
    
    self.servantArray = servantList;
    
    CCNode *cellContainer = [CCNode node];
    
    CCBalsamiqLayer *moreLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"5.8-more.bmml"
                                                            eventHandle:self];
    moreLayer.position = ccp(0, 0);
    [cellContainer addChild:moreLayer];
    
    [[moreLayer getControlByName:@"More"] setTag:0];
    
    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
    
    [self updateItemByMoreLayer:moreLayer];
}

- (void)updateItemByMoreLayer:(CCBalsamiqLayer *)moreLayer
{
    CCMenuItem *btnMore = [moreLayer getControlByName:@"More"];
    int startItemIndex = btnMore.tag;
    
    CCTableLayer *tableLayer = [balsamiqLayer getControlByName:@"table"];
    
    for (int curItemIndex = startItemIndex;
         curItemIndex < startItemIndex + COUNT_OF_MORE_SERVANT;
         ++curItemIndex)
    {
        AGServantInfo *servantInfo = [self.servantArray objectAtIndex:self.servantArray.count - 1 - curItemIndex];
        
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"5.3-character-info.bmml"
                                                            eventHandle:self];
        cell.position = moreLayer.position;
        moreLayer.position = ccp(moreLayer.position.x, moreLayer.position.y - cell.contentSize.height);
        [tableLayer.cellContainer addChild:cell];
        
        [[cell getControlByName:@"image_header"] setTag:servantInfo.servantId];
        [servantInfo.opponentInfo updateDataToLayer:cell];
        
        if (servantInfo.isBattle)
        {
            ((CCLabelTTF *)[cell getControlByName:@"name"]).color = ccRED;
        }
        
        btnMore.tag = curItemIndex + 1;
        
        if (curItemIndex == self.servantArray.count - 1)
        {
            [tableLayer.cellContainer removeChild:moreLayer cleanup:YES];
            break;
        }
    }
    
    [tableLayer resetMaxDistance];
}

- (void)onMoreClick:(id)sender
{
    [self updateItemByMoreLayer:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]];
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_getMyServantList:(NSDictionary *)info
{
    NSArray *servantList = [AGServantInfo getServantListFromInfo:info];
    [self updateTableLayer:[AGServantInfo getNotInBattleServantList:servantList]];
    
    [self onEventHappened:@"ShowServantList"];
}

- (void)onReceiveInfoWithType_changeServant:(NSDictionary *)info
{
    [[CCDirector sharedDirector] replaceScene:[GangsterLayer sceneWithSelectServantHeaderIndex:self.headerIndex]];
}

@end
