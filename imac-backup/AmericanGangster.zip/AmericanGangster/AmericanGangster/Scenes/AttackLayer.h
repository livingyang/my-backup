//
//  AttackLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-21.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"
#import "CCLabelWithTextField.h"

@class CCTableLayer;
@class AGChallengeResult;
@interface AttackLayer : BaseLayer <CCLabelWithTextFieldDelegate>
{
    CCBalsamiqLayer *balsamiqLayer;
}

@end
