//
//  PackLayer.m
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-5-5.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "PackLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCTableLayer.h"
#import "CCAlertLayer.h"
#import "HomeLayer.h"
#import "AGEquipmentInfo.h"
#import "AGStoreItemInfo.h"
#import "RefineLayer.h"

#define COUNT_OF_MORE_PACK_ITEM (10)

@implementation PackLayer

@synthesize packItemList;

+ (CCScene *)sceneWithEquipmentType:(int)type
{
    CCScene *scene = [CCScene node];
    
    PackLayer *packLayer = [PackLayer node];
    [scene addChild:packLayer];
    
    [packLayer.kindRadioManager selectItemByName:[packLayer getItemNameFromType:type]];
    [packLayer updateItems:[packLayer getItemNameFromType:type]];
    
    return scene;
}

- (NSDictionary *)itemNameAndKindDic
{
    return [NSDictionary dictionaryWithObjectsAndKeys:
            @"1", @"radio_kind_knife",
            @"2", @"radio_kind_gun",
            @"3", @"radio_kind_car",
            @"4", @"radio_kind_armor",
            nil];
    
}

- (CCTableLayer *)tableLayer
{
    return [balsamiqLayer getControlByName:@"table"];
}

- (RadioManager *)kindRadioManager
{
    return [balsamiqLayer getRadioManagerByGroup:@"kind"];
}

- (CCLabelTTF *)labListCount
{
    return [balsamiqLayer getControlByName:@"count"];
}

- (NSString *)getItemNameFromType:(int)equipmentType
{
    for (NSString *itemName in [self.itemNameAndKindDic allKeys])
    {
        if (equipmentType == [[self.itemNameAndKindDic objectForKey:itemName] intValue])
        {
            return itemName;
        }
    }
    
    return [[self.itemNameAndKindDic allKeys] lastObject];
}

- (void)updateItems:(NSString *)radioItemName
{
    [self postGetPackList:[self.itemNameAndKindDic objectForKey:radioItemName]];
}

- (id)init
{
    self = [super init];
	if (self != nil)
    {
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"6-pack.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        self.headerLayer = [balsamiqLayer getControlByName:@"header-property"];
        self.toolLayer = [balsamiqLayer getControlByName:@"tool-bar"];
    }
    
    return self;
}

- (void)dealloc
{
    self.packItemList = nil;
    
	[super dealloc];
}

- (AGEquipmentInfo *)getPackItemFromId:(int)itemId
{
    for (AGEquipmentInfo *info in self.packItemList)
    {
        if (info.uniqueId == itemId)
        {
            return info;
        }
    }
    
    return nil;
}

#pragma mark -
#pragma mark more control

- (void)updateItemByMoreLayer:(CCBalsamiqLayer *)moreLayer
{
    CCMenuItem *btnMore = [moreLayer getControlByName:@"More"];
    int startItemIndex = btnMore.tag;
    
    for (int curItemIndex = startItemIndex;
         curItemIndex < startItemIndex + COUNT_OF_MORE_PACK_ITEM;
         ++curItemIndex)
    {
        AGEquipmentInfo *item = [self.packItemList objectAtIndex:self.packItemList.count - 1 - curItemIndex];
        
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"6.1-pack-item.bmml"
                                                           eventHandle:self];
        
        cell.position = moreLayer.position;
        moreLayer.position = ccp(moreLayer.position.x, moreLayer.position.y - cell.contentSize.height);
        [self.tableLayer.cellContainer addChild:cell];
        
        [item updateDataToLayer:cell];
        
        [[cell getControlByName:@"Sell"] setTag:item.uniqueId];
        [[cell getControlByName:@"Refine"] setTag:item.uniqueId];
        
        btnMore.tag = curItemIndex + 1;
        if (curItemIndex == self.packItemList.count - 1)
        {
            [self.tableLayer.cellContainer removeChild:moreLayer cleanup:YES];
            break;
        }
    }
    
    [self.tableLayer resetMaxDistance];
}

- (void)onMoreClick:(id)sender
{
    [self updateItemByMoreLayer:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]];
}

- (void)updateTableLayer:(NSArray *)weaponArray
{
    if (weaponArray.count == 0)
    {
        CCNode *cellContainer = [CCNode node];
        [cellContainer addChild:[CCBalsamiqLayer layerWithBalsamiqFile:@"6.3-no-equipment-tip.bmml"
                                                           eventHandle:self]];
        [self.tableLayer setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
        return;
    }
    else
    {
        CCNode *cellContainer = [CCNode node];
        
        CCBalsamiqLayer *moreLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"9.3-more.bmml"
                                                                eventHandle:self];
        [cellContainer addChild:moreLayer];
        
        [[moreLayer getControlByName:@"More"] setTag:0];
        
        [self.tableLayer setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
        
        [self updateItemByMoreLayer:moreLayer];   
    }
}

- (void)onSellClick:(id)sender
{
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"6.2-sell-confirm.bmml"
                                       parentNode:self];
    
    int itemId = [sender tag];
    
    [[self getPackItemFromId:itemId] updateDataToLayer:alert.balsamiqLayer];
    [[alert.balsamiqLayer getControlByName:@"Ok"] setTag:itemId];
}

- (void)onRefineClick:(id)sender
{
    AGEquipmentInfo *equipment = [self getPackItemFromId:[sender tag]];
    [[CCDirector sharedDirector] replaceScene:[RefineLayer sceneWithEquipmentType:equipment.storeItemInfo.type
                                                                  withEquipmentId:equipment.uniqueId]];
}

- (void)onCancelClick:(id)sender
{
    [self onCommonAlertCloseClick:sender];
}

- (void)onOkClick:(id)sender
{
    [CCAlertLayer removeAlertFromNode:sender];
    
    lastSellItemId = [sender tag];
    [self postSellItemRequest:lastSellItemId];
}

#pragma mark -
#pragma mark Radio handler

- (void)onkindRadioSelected:(NSString *)radioItemName
{
    [self updateItems:radioItemName];
}

#pragma mark -
#pragma mark Receive info handle

NSInteger packItemSort(AGEquipmentInfo *num1, AGEquipmentInfo *num2, void *context)
{
    if (num1.storeItemInfo.star < num2.storeItemInfo.star)
        return NSOrderedAscending;
    else if (num1.storeItemInfo.star > num2.storeItemInfo.star)
        return NSOrderedDescending;
    else
        return NSOrderedSame;
}

- (void)onReceiveInfoWithType_getPackList:(NSDictionary *)info
{
    self.packItemList = [AGEquipmentInfo packItemInfoArrayWithDictionaryInfo:info];
    self.packItemList = [AGEquipmentInfo getIsNotUsingPackItemList:self.packItemList];
    self.packItemList = [self.packItemList sortedArrayUsingFunction:packItemSort context:NULL];
    
    self.labListCount.string = [NSString stringWithFormat:@"%d/200.", self.packItemList.count];
    [self updateTableLayer:self.packItemList];
}

- (void)onReceiveInfoWithType_sellPackGoods:(NSDictionary *)info
{
    [self showSystemTip:[info objectForKey:@"msg"]];
    
    [self showGainEffect:[self getPackItemFromId:lastSellItemId].sellCoins];

    [self updateItems:self.kindRadioManager.selectedItemInfo];
    
    [self postGetPlayerInfoRequest];
}

@end
