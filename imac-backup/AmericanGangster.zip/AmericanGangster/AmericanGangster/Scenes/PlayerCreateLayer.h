//
//  PlayerCreateLayer.h
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-4-27.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "CCScrollLayer.h"
#import "CCLabelWithTextField.h"

@class CCBalsamiqLayer;
@interface PlayerCreateLayer : CCLayer <CCScrollLayerDelegate, CCLabelWithTextFieldDelegate>
{
    CCBalsamiqLayer *balsamiqLayer;
    CCScrollLayer *scrollLayer;
    
    // [0, 6]
    int curCharacterIndex;
}

@property (nonatomic, retain) NSDictionary *manImageNameAndTextureDic;
@property (nonatomic, retain) NSDictionary *womanImageNameAndTextureDic;

+ (CCScene *)scene;

@end
