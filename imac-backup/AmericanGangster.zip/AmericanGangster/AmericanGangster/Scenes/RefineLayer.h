//
//  RefineLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-7.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@class AGRefineItemInfo;
@interface RefineLayer : BaseLayer
{
    CCBalsamiqLayer *balsamiqLayer;
    CCSprite *sprBorder;
    
    NSMutableDictionary *layerAndRefineInfoDic;
    
    // key: equpment type (NSStrimg)
    // value: select equipment id (NSNumber)
    NSMutableDictionary *typeAndDefaultEquipmentIdDic;
}

@property (nonatomic, readonly) CCBalsamiqLayer *selectBalsamiqLayer;
@property (nonatomic, readonly) BOOL isAnimePlaying;
@property (nonatomic, copy) NSString *refineButtonText;

@property (nonatomic, readwrite) int selectEquipmentId;

+ (CCScene *)scene;
+ (CCScene *)sceneWithEquipmentType:(int)type withEquipmentId:(int)equipmentId;

@end
