//
//  MessageLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-25.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "MessageLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCTableLayer.h"
#import "AGMessageInfo.h"
#import "AppDelegate.h"

@implementation MessageLayer

- (id)init
{
    self = [super init];
    if (self != nil)
    {
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"14-message.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        self.headerLayer = [balsamiqLayer getControlByName:@"header-property"]; 
        
        [balsamiqLayer selectRadioItem:@"radio_tab_battle"];
        [self onSelect_radio_tab_battle:nil];
    }
    return self;
}

- (void)onSelect_radio_tab_battle:(id)sender
{
    [self postGetBattleMsgList];
}

- (void)onSelect_radio_tab_heeler:(id)sender
{
    [self postGetHeelerMsgList];
    return;
    CCNode *cellContainer = [CCNode node];
    for (int i = 0; i < 6; ++i)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"14.1-message-info.bmml"
                                                           eventHandle:self];
        cell.position = ccp(0, i * cell.contentSize.height);
        [cellContainer addChild:cell];
    }
    
    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

- (void)onSelect_radio_tab_system:(id)sender
{
    [self postGetSystemMsgList];
    return;
    CCNode *cellContainer = [CCNode node];
    for (int i = 0; i < 6; ++i)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"14.2-system-message-info.bmml"
                                                           eventHandle:self];
        cell.position = ccp(0, i * cell.contentSize.height);
        [cellContainer addChild:cell];
    }
    
    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

- (void)onChallengeClick:(id)sender
{
    [self challengeOpponent:[sender tag]];
}

- (void)onMailClick:(id)sender
{
    [self displayMailComposerSheet];
}

#pragma mark -
#pragma mark Receive info handle

- (void)updateBattleOrHeelerMessageList:(NSArray *)messageList
{
    CCNode *cellContainer = [CCNode node];
    
    for (AGMessageInfo *info in messageList)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"14.1-message-info.bmml"
                                                           eventHandle:self];
        [info updateDataToLayer:cell];
        
        cell.position = ccp(0, [messageList indexOfObject:info] * cell.contentSize.height);
        [cellContainer addChild:cell];
    }
    
    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

- (void)updateSystemMessageList:(NSArray *)messageList
{
    CCNode *cellContainer = [CCNode node];
    
    for (AGMessageSystemInfo *info in messageList)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"14.2-system-message-info.bmml"
                                                           eventHandle:self];
        [info updateDataToLayer:cell];
        
        cell.position = ccp(0, [messageList indexOfObject:info] * cell.contentSize.height);
        [cellContainer addChild:cell];
    }
    
    if (messageList.count == 0)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"14.3-no-message-tip.bmml"
                                                           eventHandle:self];
        [cellContainer addChild:cell];   
    }
    
    [[balsamiqLayer getControlByName:@"table"] setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

- (void)onReceiveInfoWithType_getBattleMsgList:(NSDictionary *)info
{
    [self updateBattleOrHeelerMessageList:[AGMessageInfo messageListFromBattleInfo:info]];
}

- (void)onReceiveInfoWithType_getHeelerMsgList:(NSDictionary *)info
{
    [self updateBattleOrHeelerMessageList:[AGMessageInfo messageListFromHeelerInfo:info]];
}

- (void)onReceiveInfoWithType_getSystemMsgList:(NSDictionary *)info
{
    [self updateSystemMessageList:[AGMessageSystemInfo messageListFromSystemInfo:info]];
}

#pragma mark -
#pragma mark mail

-(void)displayMailComposerSheet 
{
	MFMailComposeViewController *picker = [[[MFMailComposeViewController alloc] init] autorelease];
	if (picker == nil)
    {
        //        UIAlertView *alertView = [[[UIAlertView alloc] initWithTitle:@"无法打开邮箱服务"
        //                                                             message:@"是否未设置邮箱账户？"
        //                                                            delegate:nil
        //                                                   cancelButtonTitle:@"取消"
        //                                                   otherButtonTitles:nil] autorelease];
        //        
        //        [alertView show];
        return;
    }
    
    picker.mailComposeDelegate = self;
	
	[picker setSubject:[self getLanguageString:@"14006"]];
	
	
	// Set up recipients
	NSArray *toRecipients = [NSArray arrayWithObject:@"usa.gangster@yahoo.cn"]; 
    //	NSArray *ccRecipients = [NSArray arrayWithObjects:@"second@example.com", @"third@example.com", nil]; 
    //	NSArray *bccRecipients = [NSArray arrayWithObject:@"fourth@example.com"]; 
	
	[picker setToRecipients:toRecipients];
    //	[picker setCcRecipients:ccRecipients];	
    //	[picker setBccRecipients:bccRecipients];
	
	// Attach an image to the email
    //	NSString *path = [[NSBundle mainBundle] pathForResource:@"rainy" ofType:@"jpg"];
    //	NSData *myData = [NSData dataWithContentsOfFile:path];
    //	[picker addAttachmentData:myData mimeType:@"image/jpeg" fileName:@"rainy"];
	
	// Fill out the email body text
//	NSString *emailBody = self.shareText;
//	[picker setMessageBody:emailBody isHTML:NO];
	AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
	[appDelegate.viewController presentModalViewController:picker animated:YES];
}

- (void)mailComposeController:(MFMailComposeViewController*)controller 
          didFinishWithResult:(MFMailComposeResult)result
                        error:(NSError*)error
{
	// Notifies users about errors associated with the interface
	switch (result)
	{
		case MFMailComposeResultCancelled:
			[self showSystemTip:[self getLanguageString:@"14007"]];
			break;
		case MFMailComposeResultSaved:
			[self showSystemTip:[self getLanguageString:@"140078"]];
			break;
		case MFMailComposeResultSent:
			[self showSystemTip:[self getLanguageString:@"14009"]];
			break;
		case MFMailComposeResultFailed:
			[self showSystemTip:[self getLanguageString:@"14010"]];
			break;
		default:
			[self showSystemTip:[self getLanguageString:@"14011"]];
			break;
	}
	AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
	[appDelegate.viewController dismissModalViewControllerAnimated:YES];
}

@end
