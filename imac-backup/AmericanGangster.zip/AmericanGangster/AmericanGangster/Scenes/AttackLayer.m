//
//  AttackLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-21.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "AttackLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCTableLayer.h"
#import "CCAlertLayer.h"
#import "AGOpponentInfo.h"
#import "ItemLayer.h"

@implementation AttackLayer

- (void)onEnter
{
    [super onEnter];
    
    [self.toolLayer selectRadioItem:@"radio_Tool_battle"];
    
    [self onEventHappened:@"IntoBattle"];
}

- (id)init
{
    self = [super init];
    if (self != nil)
    {
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"4-attack.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        CCLabelWithTextField *label = [[balsamiqLayer getControlByName:@"tab_opponent"] getControlByName:@"name"];
        label.delegate = self;
        label.textField.text = @"";
        label.textField.placeholder = [self getLanguageString:@"4003"];
        
        [balsamiqLayer selectRadioItem:@"radio_tab_opponent"];
        
        [self postGetOpponentListRequest:@""];
        
        self.headerLayer = [balsamiqLayer getControlByName:@"header-property"];
        self.toolLayer = [balsamiqLayer getControlByName:@"tool-bar"];
    }
    
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)onChallengeClick:(id)sender
{
    [self challengeOpponent:[sender tag]];
}

- (void)onDetailGroupClick:(id)sender
{
    [self onSelect_radio_Tool_group:nil];
}

- (void)updatePlayerList:(NSArray *)playerList toTable:(CCTableLayer *)tableLayer
{
    [[AGOpponentInfoCache instance] clearOpponentList];
    [[AGOpponentInfoCache instance] appendOpponentList:playerList];
    
    CCNode *cellContainer = [CCNode node];
    
    for (AGOpponentInfo *info in playerList)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"4.1-opponent.bmml"
                                                           eventHandle:self];
        cell.position = ccp(0, [playerList indexOfObject:info] * cell.contentSize.height);
        [cellContainer addChild:cell];
        
        [info updateDataToLayer:cell];
        
        [[cell getControlByName:@"Challenge"] setTag:info.uniqueId];
    }
    
    if (playerList.count == 0)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:
                                 [[balsamiqLayer getRadioManagerByGroup:@"tab"].selectedItemInfo isEqualToString:@"radio_tab_opponent"]
                                 ? @"4.7.1-no-opponent-tip.bmml" : @"4.7-no-revange-tip.bmml"
                                                           eventHandle:self];
        [cellContainer addChild:cell];
    }
    
    [tableLayer setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

#pragma mark -
#pragma mark RadioManager


- (void)onSelect_radio_tab_opponent:(id)sender
{
    [self postGetOpponentListRequest:@""];
}

- (void)onSelect_radio_tab_revenge:(id)sender
{
    [self postGetRevengeListRequest];
}

#pragma mark -
#pragma mark CCLabelWithTextFieldDelegate

- (void)onLabel:(CCLabelWithTextField *)label textFieldShouldBeginEditing:(UITextField *)textField
{
    textField.text = @"";
}

- (void)onLabel:(CCLabelWithTextField *)label textFieldShouldReturn:(UITextField *)textField
{
    [self postGetOpponentListRequest:textField.text];
}

- (void)onSearchClick:(id)sender
{
    [[SoundManager instance] playEffectButtonOk];
    
    CCLabelWithTextField *label = [[balsamiqLayer getControlByName:@"tab_opponent"] getControlByName:@"name"];
    [self postGetOpponentListRequest:label.textField.text];
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_getOpponentList:(NSDictionary *)info
{
    CCTableLayer *tableOpponent = [[balsamiqLayer getControlByName:@"tab_opponent"] getControlByName:@"table"];
    [self updatePlayerList:[AGOpponentInfo getOpponentList:info] toTable:tableOpponent];
}

- (void)onReceiveInfoWithType_getRevengeList:(NSDictionary *)info
{
    [self updatePlayerList:[AGOpponentInfo getRevengeList:info] toTable:[balsamiqLayer getControlByName:@"tab_revenge"]];
}

- (void)onReceiveInfoWithType_challengeOpponent:(NSDictionary *)info
{
    [super onReceiveInfoWithType_challengeOpponent:info];
    
    if ([[balsamiqLayer getRadioManagerByGroup:@"tab"].selectedItemInfo isEqualToString:@"radio_tab_opponent"])
    {
        [self onSearchClick:nil];
    }
    else
    {
        [self postGetRevengeListRequest];
    }
}

@end
