//
//  MissionPrisonLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-26.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "MissionPrisonLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCAlertLayer.h"
#import "CCTimeManageNode.h"
#import "MissionLayer.h"
#import "AGMissionInfo.h"

#define SCALE_EVENT (0.6f)

@implementation MissionPrisonLayer

+ (CCScene *)sceneWithEventTime:(NSTimeInterval)time
{
    CCScene *scene = [CCScene node];
    MissionPrisonLayer *layer = [MissionPrisonLayer node];
    [scene addChild:layer];
    
    [layer loadControlWithCountDownTime:time];
    
    return scene;
}

+ (CCScene *)sceneWithEventTimeAndAnime:(NSTimeInterval)time andEventNode:(CCNode *)node
{
    CCScene *scene = [CCScene node];
    MissionPrisonLayer *layer = [MissionPrisonLayer node];
    [scene addChild:layer];
    
    [layer playPrizonEffectWithTime:time andEventNode:node];
    
    return scene;
}

- (void)loadControlWithCountDownTime:(NSTimeInterval)time
{
    [[balsamiqLayer getControlByName:@"image_event"] setScale:SCALE_EVENT];
    
    [CCTimeManageNode startCountDown:[balsamiqLayer getControlByName:@"time"]
                            timeLeft:time
                            isHHMMSS:NO
                      withStopAction:[CCCallFunc actionWithTarget:self selector:@selector(onTimeCountDown)]];
}

- (void)showAnotherControl
{
    [[balsamiqLayer getControlByName:@"time"] setVisible:YES];
    [[balsamiqLayer getControlByName:@"Bail"] setVisible:YES];
    [[balsamiqLayer getControlByName:@"detail"] setVisible:YES];
}

- (void)playPrizonEffectWithTime:(NSTimeInterval)time andEventNode:(CCNode *)node
{
    [[balsamiqLayer getControlByName:@"time"] setVisible:NO];
    [[balsamiqLayer getControlByName:@"Bail"] setVisible:NO];
    [[balsamiqLayer getControlByName:@"detail"] setVisible:NO];
    
    CCSprite *sprEvent = [balsamiqLayer getControlByName:@"image_event"];
    [sprEvent runAction:[CCSequence actions:
                         [CCScaleTo actionWithDuration:0.3f scale:SCALE_EVENT],
                         [CCCallFunc actionWithTarget:self selector:@selector(showAnotherControl)],
                         nil]];
    
    CGPoint endPos = sprEvent.position;
    sprEvent.position = [sprEvent.parent convertToNodeSpace:[node convertToWorldSpaceAR:CGPointZero]];
    [sprEvent runAction:[CCMoveTo actionWithDuration:0.3f position:endPos]];
    
    [CCTimeManageNode startCountDown:[balsamiqLayer getControlByName:@"time"]
                            timeLeft:time
                            isHHMMSS:NO
                      withStopAction:[CCCallFunc actionWithTarget:self selector:@selector(onTimeCountDown)]];
}

- (id)init
{
    self = [super init];
    if (self != nil)
    {
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"3.1.3-prison-event.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        self.headerLayer = [balsamiqLayer getControlByName:@"header-property"];
        self.toolLayer = [balsamiqLayer getControlByName:@"tool-bar"];
    }
    return self;
}

- (void)onEnter
{
    [super onEnter];
    
    [self.toolLayer selectRadioItem:@"radio_Tool_mission"];
}

- (void)onTimeCountDown
{
    [[CCDirector sharedDirector] replaceScene:[MissionLayer scene]];
}

- (void)onBailClick:(id)sender
{
    [self postTryBailPlayer];
}

- (void)onCancelBailClick:(id)sender
{
    [self onCommonAlertCloseClick:sender];
}

- (void)onOkBailClick:(id)sender
{
    [self postBailPlayer];
}

#pragma mark -
#pragma mark Receive info handle

- (void)onReceiveInfoWithType_bailPlayer:(NSDictionary *)info
{
    [[CCDirector sharedDirector] replaceScene:[MissionLayer scene]];
}

- (void)onReceiveInfoWithType_tryBail:(NSDictionary *)info
{
    AGPrizonTimeInfo *timeInfo = [AGPrizonTimeInfo prizonTimeInfoFromDic:info];
    
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"3.9-bail-alert.bmml"
                                       parentNode:self];
    [[alert.balsamiqLayer getControlByName:@"detail"] setString:
     [NSString stringWithFormat:[self getLanguageString:@"3001"], timeInfo.dollar]];
}

@end
