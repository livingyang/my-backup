//
//  ItemLayer.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-18.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@class CCTableLayer;
@class CCTouchCatchNode;
@class AGEquipmentInfo;
@interface ItemLayer : BaseLayer
{
    CCBalsamiqLayer *balsamiqLayer;
    
    int lastSpinId;
    CCTouchCatchNode *touchCatchNode;
}

@property (nonatomic, retain) AGEquipmentInfo *spinEquipment;

// tab, 0 - item, 1 - weapon, 2 - card
+ (CCScene *)sceneWithTab:(int)tabIndex;

@end
