//
//  RefineLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-7.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "RefineLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCAlertLayer.h"
#import "CCTableLayer.h"
#import "GangsterLayer.h"
#import "AGRefineItemInfo.h"
#import "AGStoreItemInfo.h"
#import "CCMenuItemButton.h"
#import "CCLabelTTF+ChangeFont.h"
#import "CCTimeManageNode.h"
#import "BalsamiqReaderConfig.h"
#import "TimeLeftManager.h"

#define TAG_REFINE_ANIME (1234456)
#define INVALID_REFINE_EQUIPMENT_ID (-1)

@interface RefineLayer (Private)

- (void)postRefineListFromSelectRadio;

@end

@implementation RefineLayer

@synthesize refineButtonText;

+ (CCScene *)scene
{
    CCScene *scene = [CCScene node];
    
    RefineLayer *layer = [self node];
    [layer loadEquipmentListFromType:1];
    [scene addChild:layer];
    
    return scene;
}

+ (CCScene *)sceneWithEquipmentType:(int)type withEquipmentId:(int)equipmentId
{
    CCScene *scene = [CCScene node];
    
    RefineLayer *layer = [self node];
    [layer setType:type withDefaultEquipmentId:equipmentId];
    [layer loadEquipmentListFromType:type];
    [scene addChild:layer];
    
    return scene;
}

- (id)init
{
    self = [super init];
    if (self != nil)
    {
        layerAndRefineInfoDic = [[NSMutableDictionary alloc] init];
        
        typeAndDefaultEquipmentIdDic = [[NSMutableDictionary alloc] initWithObjectsAndKeys:
                                       [NSNumber numberWithInt:INVALID_REFINE_EQUIPMENT_ID], @"1",
                                       [NSNumber numberWithInt:INVALID_REFINE_EQUIPMENT_ID], @"2",
                                       [NSNumber numberWithInt:INVALID_REFINE_EQUIPMENT_ID], @"3",
                                       [NSNumber numberWithInt:INVALID_REFINE_EQUIPMENT_ID], @"4",
                                       nil];
        
        balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"7-refine.bmml"
                                                   eventHandle:self];
        [self addChild:balsamiqLayer];
        
        self.headerLayer = [balsamiqLayer getControlByName:@"header-property"];
        
        [(CCSprite *)[balsamiqLayer getControlByName:@"image_anime"] setOpacity:0];
        
        sprBorder = [balsamiqLayer getControlByName:@"image_border"];
        sprBorder.anchorPoint = CGPointZero;
        
        self.refineButtonText = [[balsamiqLayer getControlByName:@"refine-time"] string];
        
        [[balsamiqLayer getControlByName:@"label-success"] changeToBlackArialFont];
        
        [self clearRefineEquipmentInfo];
    }
    
    return self;
}

- (void)dealloc
{
    [typeAndDefaultEquipmentIdDic release];
    [layerAndRefineInfoDic release];
    
    self.refineButtonText = nil;
    
    [super dealloc];
}

#pragma mark -
#pragma mark type and equipment id manage

- (int)getDefaultSelectEquipmentIdFromType:(int)equipmentType
{
    return [[typeAndDefaultEquipmentIdDic objectForKey:[NSString stringWithFormat:@"%d", equipmentType]] intValue];
}

- (void)setType:(int)equipmentType withDefaultEquipmentId:(int)defaultEquipmentId
{
    [typeAndDefaultEquipmentIdDic setObject:[NSNumber numberWithInt:defaultEquipmentId]
                                     forKey:[NSString stringWithFormat:@"%d", equipmentType]];
}

- (NSString *)getTabNameFromType:(int)equipmentType
{
    switch (equipmentType)
    {
        case 1:
        {
            return @"radio_kind_knife";
        }
        case 2:
        {
            return @"radio_kind_gun";
        }
        case 3:
        {
            return @"radio_kind_car";
        }
        case 4:
        {
            return @"radio_kind_armor";
        }
        default:
            break;
    }
    
    NSLog(@"RefineLayer#getTabNameFromType invalid type = %d", equipmentType);
    return @"radio_kind_knife";
}

- (int)getTypeFromSelectRadioItemName:(NSString *)itemName
{
    NSDictionary *radioNameAndKind = [NSDictionary dictionaryWithObjectsAndKeys:
                                      @"1", @"radio_kind_knife",
                                      @"2", @"radio_kind_gun",
                                      @"3", @"radio_kind_car",
                                      @"4", @"radio_kind_armor",
                                      nil];
    
    return [[radioNameAndKind objectForKey:itemName] intValue];
}

- (int)curTypeFromSelectRadioItemName
{
    return [self getTypeFromSelectRadioItemName:[balsamiqLayer getRadioManagerByGroup:@"kind"].selectedItemInfo];
}

#pragma mark -
#pragma mark update refine equipment info

- (void)loadEquipmentListFromType:(int)equipmentType
{
    [[balsamiqLayer getRadioManagerByGroup:@"kind"] selectItemByName:[self getTabNameFromType:equipmentType]];
    [self postRefineListFromSelectRadio];
}

- (int)selectEquipmentId
{
    return [[balsamiqLayer getControlByName:@"image_icon"] tag];
}

- (void)setSelectEquipmentId:(int)selectEquipmentId
{
    [[balsamiqLayer getControlByName:@"image_icon"] setTag:selectEquipmentId];
}

- (void)clearRefineEquipmentInfo
{
    [[balsamiqLayer getControlByName:@"count"] setString:@""];
    [[balsamiqLayer getControlByName:@"name"] setString:@""];
    
    for (int i = 1; i <= 5; ++i)
    {
        [[balsamiqLayer getControlByName:[NSString stringWithFormat:@"image_star%d", i]] setVisible:NO];
    }
    
    [[balsamiqLayer getControlByName:@"attack"] setString:@""];
    [[balsamiqLayer getControlByName:@"defense"] setString:@""];
    
    [[balsamiqLayer getControlByName:@"refine-detail"] setVisible:NO];
    [[balsamiqLayer getControlByName:@"up-max"] setVisible:NO];
    [[balsamiqLayer getControlByName:@"image_equiped"] setVisible:NO];
    
    [[balsamiqLayer getControlByName:@"image_icon"] setVisible:NO];
    
    self.selectEquipmentId = INVALID_REFINE_EQUIPMENT_ID;
}

#pragma mark -
#pragma mark clear alert

- (void)onCancelClearClick:(id)sender
{
    [self onCommonAlertCloseClick:sender];
}

- (void)onOkClearClick:(id)sender
{
    [self postClearRefineTime];
    [self onCommonAlertCloseClick:sender];
}

#pragma mark -
#pragma mark Balsamiq button function

- (void)onGangsterClick:(id)sender
{
    [[CCDirector sharedDirector] replaceScene:[GangsterLayer scene]];
}

- (void)onRefineClick:(id)sender
{
    if ([AGRefineInfo instance].canRefine == NO)
    {
        [self postTryClearRefineTime];
        return;
    }
    
    if (self.selectEquipmentId != INVALID_REFINE_EQUIPMENT_ID && !self.isAnimePlaying)
    {
        BOOL isUseItem = [[balsamiqLayer getControlByName:@"toggle_ok"] selectedIndex];
        [self postRefineItemRequest:self.selectEquipmentId isUseItem:isUseItem];
    }
}

- (void)onClick_toggle_ok:(CCMenuItemToggle *)toggle
{
    if ([AGRefineInfo instance].itemCount == 0)
    {
        toggle.selectedIndex = 0;
        
        [self openItemAlert:[self getLanguageString:@"2"] withType:@"r"];
    }
    
    if (toggle.selectedIndex == 1)
    {
        [self showSystemTip:[self getLanguageString:@"7003"]];
        
        [[SoundManager instance] playEffectButtonOk];
    }
    else
    {
        [[SoundManager instance] playEffectButtonBack];
    }
}

- (void)onRefineItemClick:(id)sender
{
    [[balsamiqLayer getControlByName:@"toggle_ok"] activate];
}

- (BOOL)onUseItem:(int)itemId itemType:(NSString *)type
{
    if ([type isEqualToString:@"r"])
    {
        [[balsamiqLayer getControlByName:@"toggle_ok"] setSelectedIndex:1];
        return YES;
    }
    
    return [super onUseItem:itemId itemType:type];
}

#pragma mark -
#pragma mark RadioManager

- (void)postRefineListFromSelectRadio
{
    [self postGetRefineListRequest:[self curTypeFromSelectRadioItemName]];
}

- (void)onkindRadioSelected:(NSString *)radioItemName
{
    [self postRefineListFromSelectRadio];
}

- (void)updateRefineListItemInfo:(CCBalsamiqLayer *)itemLayer withInfo:(AGEquipmentInfo *)info
{
    [info.storeItemInfo updateDataToLayer:itemLayer];
    [[itemLayer getControlByName:@"count"] setString:
     [NSString stringWithFormat:@"%d/%d", info.curUpCount, info.maxUpCount]];
    [[itemLayer getControlByName:@"name"] changeToFont:[BalsamiqReaderConfig instance].balsamiqFontName];
    [[itemLayer getControlByName:@"image_equiped"] setVisible:info.isEquiped];
}

- (void)updateRefineList:(NSArray *)refineList
{
    CCNode *cellContainer = [CCNode node];
    [layerAndRefineInfoDic removeAllObjects];
    
    int defaultSelectEquipmentId = [self getDefaultSelectEquipmentIdFromType:[self curTypeFromSelectRadioItemName]];
    CCBalsamiqLayer *defaultSelectItem = nil;
    for (AGEquipmentInfo *info in refineList)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"7.1-refine-item.bmml"
                                                           eventHandle:self];
        cell.position = ccp([refineList indexOfObject:info] * cell.contentSize.width, 0);
        [cellContainer addChild:cell];
        
        [layerAndRefineInfoDic setObject:info forKey:[NSValue valueWithNonretainedObject:cell]];
        
        [self updateRefineListItemInfo:cell withInfo:info];
        
        if (info.uniqueId == defaultSelectEquipmentId)
        {
            defaultSelectItem = cell;
        }
    }
    
    CCTableLayer *tableLayer = [balsamiqLayer getControlByName:@"table"];
    [tableLayer setCellContainer:cellContainer autoSetWithVectorMove:ccp(-1, 0)];
    
    if (refineList.count > 0)
    {
        defaultSelectItem = (defaultSelectItem == nil) ? [cellContainer.children objectAtIndex:0] : defaultSelectItem;
        [self onItemClick:[defaultSelectItem getControlByName:@"Item"]];
        
        tableLayer.curDistance = [tableLayer getCellDistance:defaultSelectItem];
    }
    else
    {
        [self clearRefineEquipmentInfo];
    }
}

- (void)updateRefineItemInfo:(AGEquipmentInfo *)info
{
    if (info == nil)
    {
        return;
    }
    
    [[balsamiqLayer getControlByName:@"count"] setString:[NSString stringWithFormat:@"%d", info.curUpCount]];
    
    [[balsamiqLayer getControlByName:@"up-max"] setVisible:info.isMaxRefine];
    [[balsamiqLayer getControlByName:@"image_equiped"] setVisible:info.isEquiped];

    CCBalsamiqLayer *detailLayer = [balsamiqLayer getControlByName:@"refine-detail"];
    detailLayer.visible = !info.isMaxRefine;
    
    if (info.isMaxRefine == NO)
    {
        [[detailLayer getControlByName:@"next-attack"] setString:[NSString stringWithFormat:@"%d", info.nextRefineTotalAttack]];
        [[detailLayer getControlByName:@"next-defense"] setString:[NSString stringWithFormat:@"%d", info.nextRefineTotalDefense]];
        
        [[detailLayer getControlByName:@"cost"] setString:[NSString stringWithFormat:@"%d", info.cost]];
    }
    
    [[balsamiqLayer getControlByName:@"image_icon"] setVisible:YES];
    [info.storeItemInfo updateDataToLayer:balsamiqLayer];
    [[balsamiqLayer getControlByName:@"attack"] setString:
     [NSString stringWithFormat:@"%d", info.totalAttack]];
    [[balsamiqLayer getControlByName:@"defense"] setString:
     [NSString stringWithFormat:@"%d", info.totalDefense]];
    
    self.selectEquipmentId = info.uniqueId;
    [self setType:info.storeItemInfo.type withDefaultEquipmentId:info.uniqueId];
    
    [self onEventHappened:@"SelectRefineEquipment"];
}

- (CCBalsamiqLayer *)selectBalsamiqLayer
{
    if (self.selectEquipmentId == INVALID_REFINE_EQUIPMENT_ID)
    {
        return nil;
    }
    
    for (NSValue *value in [layerAndRefineInfoDic allKeys])
    {
        AGEquipmentInfo *equipment = [layerAndRefineInfoDic objectForKey:value];
        if (equipment.uniqueId == self.selectEquipmentId)
        {
            return [value nonretainedObjectValue];
        }
    }
    
    return nil;
}

#pragma mark -
#pragma mark anime

- (BOOL)isAnimePlaying
{
    return [[balsamiqLayer getControlByName:@"image_anime"] getActionByTag:TAG_REFINE_ANIME] != nil;
}

- (void)playRefineAnime
{
    if (!self.isAnimePlaying)
    {
        CCSprite *sprAnime = [balsamiqLayer getControlByName:@"image_anime"];
        
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"refine.plist"];
        
        NSMutableArray *array = [NSMutableArray array];
        
        for (int i = 1; i <= 22; ++i)
        {
            CCSpriteFrame *frame = [[CCSpriteFrameCache sharedSpriteFrameCache]
                                    spriteFrameByName:[NSString stringWithFormat:@"000%02d.png", i]];
            NSLog(@"frame = %@", frame);
            [array addObject:frame];
        }
        
        CCAnimation *animation = [CCAnimation animationWithFrames:array delay:0.05f];
        
        CCSequence *action = [CCSequence actions:
                              [CCFadeIn actionWithDuration:0],
                              [CCAnimate actionWithAnimation:animation restoreOriginalFrame:NO],
                              [CCFadeOut actionWithDuration:0.1],
                              nil];
        action.tag = TAG_REFINE_ANIME;
        [sprAnime runAction:action];
        
    }
}

#pragma mark -
#pragma mark toggle

- (void)onItemClick:(id)sender
{
    [sprBorder removeFromParentAndCleanup:YES];
    [sender addChild:sprBorder];
    sprBorder.position = CGPointZero;
    
    [self updateRefineItemInfo:[layerAndRefineInfoDic objectForKey:
                                [NSValue valueWithNonretainedObject:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]]]];
}

#pragma mark -
#pragma mark refine tip

- (void)showRefineTip:(NSString *)result
{
    CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"7.2-refine-tip.bmml"
                                                        eventHandle:self];
    [self addChild:layer z:INT_MAX];
    
    [[layer getControlByName:@"result"] setString:result];
    
    [layer runAction:[CCSequence actions:
                      [CCMoveBy actionWithDuration:1.0f position:ccp(0, 60)],
                      [CCCallFunc actionWithTarget:layer selector:@selector(removeFromParentAndCleanup:)],
                      nil]];
}

#pragma mark -
#pragma mark Receive info handle

- (void)onRefineFinishRecoverTime
{
    CCLabelTTF *labTime = [balsamiqLayer getControlByName:@"refine-time"];
    labTime.string = self.refineButtonText;
}

- (void)updateRefineInfo
{
    [CCTimeManageNode startCountDown:[balsamiqLayer getControlByName:@"refine-time"]
                            timeLeft:[AGRefineInfo instance].refineTime.curTimeLeft
                            isHHMMSS:YES
                      withStopAction:[CCCallFunc actionWithTarget:self selector:@selector(onRefineFinishRecoverTime)]];
    
    CCProgressTimer *barRefine = [balsamiqLayer getControlByName:@"bar_refine"];
    barRefine.percentage = [AGRefineInfo instance].canRefine ? [AGRefineInfo instance].refinePercent : 100;
    
    [[balsamiqLayer getControlByName:@"success"] setString:
     [NSString stringWithFormat:@"%d%%", [AGRefineInfo instance].refineRatio]];
    [[balsamiqLayer getControlByName:@"item-count"] setString:
     [NSString stringWithFormat:@"x %d", [AGRefineInfo instance].itemCount]];
}

NSInteger refineItemSort(AGEquipmentInfo *num1, AGEquipmentInfo *num2, void *context)
{
    if (num1.isEquiped && num2.isEquiped == NO)
    {
        return NSOrderedAscending;
    }
    else if (num1.isEquiped == NO && num2.isEquiped)
    {
        return NSOrderedDescending;
    }
    
    if (num1.storeItemInfo.star > num2.storeItemInfo.star)
        return NSOrderedAscending;
    else if (num1.storeItemInfo.star < num2.storeItemInfo.star)
        return NSOrderedDescending;
    else
        return NSOrderedSame;
}

- (void)onReceiveInfoWithType_getRefineList:(NSDictionary *)info
{
    [self postGetRefineInfo];
    
    NSArray *refineItemList = [AGEquipmentInfo refineItemInfoArrayWithDictionaryInfo:info];
    refineItemList = [refineItemList sortedArrayUsingFunction:refineItemSort context:NULL];
    [self updateRefineList:refineItemList];
}

- (void)onReceiveInfoWithType_refineItem:(NSDictionary *)info
{
    [[SoundManager instance] playEffectRefineSuccess];
    
    [self postGetRefineInfo];
    
    [self postGetPlayerInfoRequest];
    
    AGEquipmentInfo *newItemInfo = [AGEquipmentInfo getRefineItemFromInfo:info];
    
    [self updateRefineListItemInfo:self.selectBalsamiqLayer withInfo:newItemInfo];
    [self updateRefineItemInfo:newItemInfo];
    
    [layerAndRefineInfoDic setObject:newItemInfo forKey:[NSValue valueWithNonretainedObject:self.selectBalsamiqLayer]];
    
    [self playRefineAnime];
    
    if ([AGRefineInfo instance].itemCount == 0)
    {
        [[balsamiqLayer getControlByName:@"toggle_ok"] setSelectedIndex:0];
    }
    
    [self showRefineTip:[self getLanguageString:@"7001"]];
    
    [self onEventHappened:@"RefineSuccess"];
}


- (void)onReceiveInfoWithType_refineItem_fail:(NSDictionary *)info
{
    [[SoundManager instance] playEffectRefineFail];
    
    [self postGetRefineInfo];
    
    [self postGetPlayerInfoRequest];
    
    [self showRefineTip:[self getLanguageString:@"7002"]];
}

- (void)onReceiveInfoWithType_clearRefineTime:(NSDictionary *)info
{
    [self postGetRefineInfo];
    
    [self postGetPlayerInfoRequest];
    
    [self showSystemTip:[self getLanguageString:@"7005"]];
}

- (void)onReceiveInfoWithType_getRefineInfo:(NSDictionary *)info
{
    [[AGRefineInfo instance] updateWithRefineItemInfo:info];
    [self updateRefineInfo];
}

- (void)onReceiveInfoWithType_buyPropsGoods:(NSDictionary *)info
{
    [super onReceiveInfoWithType_buyPropsGoods:info];
    
    [self postGetRefineInfo];
}

- (void)onReceiveInfoWithType_tryClearRefineTime:(NSDictionary *)info
{
    AGRefineTimeInfo *timeInfo = [AGRefineTimeInfo timeInfoFromDic:info];
    
    CCAlertLayer *alert = [CCAlertLayer showAlert:@"7.3-clear-refine-time.bmml"
                                       parentNode:self];
    
    [[alert.balsamiqLayer getControlByName:@"detail"] setString:
     [NSString stringWithFormat:[self getLanguageString:@"7004"], timeInfo.minute, timeInfo.dollar]];
}

@end
