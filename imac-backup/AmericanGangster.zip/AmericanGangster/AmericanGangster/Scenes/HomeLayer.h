//
//  HomeLayer.h
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-4-27.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseLayer.h"

@class CCBalsamiqLayer;
@interface HomeLayer : BaseLayer
{
    CCBalsamiqLayer *homeBalsamiqLayer;
}

@end
