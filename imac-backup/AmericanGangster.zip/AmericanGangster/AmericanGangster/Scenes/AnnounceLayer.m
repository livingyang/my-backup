//
//  AnnounceLayer.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-10-9.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "AnnounceLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCTableLayer.h"
#import "AGMessageInfo.h"
#import "ItemLayer.h"
#import "RefineLayer.h"
#import "BusinessLayer.h"
#import "MissionLayer.h"
#import "AttackLayer.h"

@implementation AnnounceLayer

@synthesize layerAndInfoDic;

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        [AGAnnounceCache instance].hasDisplayed = YES;
        
        [self postGetNoticeList];
    }
    return self;
}

- (void)onOkClick:(id)sender
{
    AGAnnounceInfo *announceInfo = [self.layerAndInfoDic objectForKey:
                                    [NSValue valueWithNonretainedObject:[CCBalsamiqLayer getBalsamiqLayerFromChild:sender]]];
    
    [self jumpToScene:announceInfo.jumpInfo];
}

- (void)onAnnounceCloseClick:(id)sender
{
    [self onSelect_radio_Tool_home:nil];
}

- (void)jumpToScene:(NSString *)jumpInfo
{
    NSArray *sepJumpInfo = [jumpInfo componentsSeparatedByString:@":"];
    NSString *moduleName = [sepJumpInfo objectAtIndex:0];
    if ([@"Item" isEqualToString:moduleName])
    {
        if (sepJumpInfo.count == 2)
        {
            int index = [[sepJumpInfo objectAtIndex:1] intValue];
            
            [[CCDirector sharedDirector] replaceScene:[ItemLayer sceneWithTab:index]];
        }
    }
    else if ([@"Refine" isEqualToString:moduleName])
    {
        [[CCDirector sharedDirector] replaceScene:[RefineLayer scene]];
    }
    else if ([@"Business" isEqualToString:moduleName])
    {
        [[CCDirector sharedDirector] replaceScene:[BusinessLayer scene]];
    }
    else if ([@"Mission" isEqualToString:moduleName])
    {
        [[CCDirector sharedDirector] replaceScene:[MissionLayer scene]];
    }
    else if ([@"Attack" isEqualToString:moduleName])
    {
        [[CCDirector sharedDirector] replaceScene:[AttackLayer scene]];
    }
}

- (void)updateAnnounceList:(NSArray *)announceList
{
    NSMutableDictionary *cellAndInfoDic = [NSMutableDictionary dictionary];
    self.layerAndInfoDic = cellAndInfoDic;
    
    CCTableLayer *tableLayer = [balsamiqLayer getControlByName:@"table"];
    CCNode *cellContainer = [CCNode node];
    for (AGAnnounceInfo *announceInfo in announceList)
    {
        CCBalsamiqLayer *cell = [CCBalsamiqLayer layerWithBalsamiqFile:@"16.1-announce-info.bmml"
                                                           eventHandle:self];
        cell.position = ccp(0, cell.contentSize.height * [announceList indexOfObject:announceInfo]);
        [cellContainer addChild:cell];
        
        [announceInfo updateDataToLayer:cell];
        [cellAndInfoDic setObject:announceInfo forKey:[NSValue valueWithNonretainedObject:cell]];
    }
    
    [tableLayer setCellContainer:cellContainer autoSetWithVectorMove:ccp(0, 1)];
}

- (void)onReceiveInfoWithType_getNoticeList:(NSDictionary *)info
{
    [[AGAnnounceCache instance] updateAnnounceCache:info];
    
    if ([AGAnnounceCache instance].curAnnounceList.count == 0)
    {
        [self onSelect_radio_Tool_home:nil];
        return;
    }
    
    balsamiqLayer = [CCBalsamiqLayer layerWithBalsamiqFile:@"16-announce.bmml"
                                               eventHandle:self];
    [self addChild:balsamiqLayer];
    
    [self updateAnnounceList:[AGAnnounceCache instance].curAnnounceList];
}

@end
