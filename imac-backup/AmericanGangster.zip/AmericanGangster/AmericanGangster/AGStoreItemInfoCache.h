//
//  AGStoreItemInfoCache.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class AGStoreItemInfo;
@interface AGStoreItemInfoCache : NSObject

@property (nonatomic, retain) NSArray *storeItemInfoArray;
@property (nonatomic, retain) NSDate *lastUpdateDate;

+ (AGStoreItemInfoCache *)instance;

- (NSArray *)getItemInfoFromType:(int)type playerLevel:(int)maxLevel;
- (AGStoreItemInfo *)getItemInfoFromEquipId:(int)equipId;
- (void)updateCache:(NSDictionary *)jsonItemInfoDicArray;

@end
