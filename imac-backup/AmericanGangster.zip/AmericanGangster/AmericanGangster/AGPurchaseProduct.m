//
//  AGPurchaseProduct.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-9-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGPurchaseProduct.h"
#import "CCBalsamiqLayer.h"

@implementation AGPurchaseProduct

@synthesize uniqueId;
@synthesize dollar;
@synthesize money;
@synthesize productId;

- (void)dealloc
{
    self.money = nil;
    self.productId = nil;
    
    [super dealloc];
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    [[layer getControlByName:@"dollar"] setString:[NSString stringWithFormat:@"%d", self.dollar]];
    [[layer getControlByName:@"money"] setString:self.money];
    [[layer getControlByName:@"BuyPurchase"] setTag:self.uniqueId];
}

- (void)loadPropertiesFromDic:(NSDictionary *)dic
{
    self.uniqueId = [[dic objectForKey:@"id"] intValue];
    self.dollar = [[dic objectForKey:@"dollar"] intValue];
    self.money = [dic objectForKey:@"money"];
    self.productId = [dic objectForKey:@"productId"];
}

@end

@implementation AGNewbiePurchaseProduct

@synthesize productInfo;
@synthesize isPurchased;
@synthesize title;
@synthesize detail;

- (void)dealloc
{
    self.productInfo = nil;
    self.title = nil;
    self.detail = nil;
    
    [super dealloc];
}


@end

@implementation AGPurchaseProductList

@synthesize productList;
@synthesize newbieProcuct;

- (void)dealloc
{
    self.productList = nil;
    self.newbieProcuct = nil;
    
    [super dealloc];
}

+ (AGPurchaseProductList *)productListFromInfo:(NSDictionary *)dic
{
    AGPurchaseProductList *productList = [[[AGPurchaseProductList alloc] init] autorelease];
    
    {
        NSDictionary *newbieDic = [dic objectForKey:@"newbiePurchaseProduct"];
        productList.newbieProcuct = [[[AGNewbiePurchaseProduct alloc] init] autorelease];
        productList.newbieProcuct.title = [newbieDic objectForKey:@"title"];
        productList.newbieProcuct.detail = [newbieDic objectForKey:@"detail"];
        productList.newbieProcuct.isPurchased = [[newbieDic objectForKey:@"isPurchased"] intValue];
        productList.newbieProcuct.productInfo = [[[AGPurchaseProduct alloc] init] autorelease];
        [productList.newbieProcuct.productInfo loadPropertiesFromDic:newbieDic];
    }
    
    NSMutableArray *array = [NSMutableArray array];
    productList.productList = array;
    
    for (NSDictionary *productDic in [[dic objectForKey:@"purchaseProductList"] reverseObjectEnumerator])
    {
        AGPurchaseProduct *productInfo = [[[AGPurchaseProduct alloc] init] autorelease];
        [array addObject:productInfo];

        [productInfo loadPropertiesFromDic:productDic];
    }
    
    return productList;
}

+ (AGPurchaseProductList *)instance
{
    static AGPurchaseProductList *list = nil;

    if (list == nil)
    {
        list = [[AGPurchaseProductList alloc] init];
    }
    
    return list;
}

- (void)updateWithInfo:(NSDictionary *)dic
{    
    {
        NSDictionary *newbieDic = [dic objectForKey:@"newbiePurchaseProduct"];
        self.newbieProcuct = [[[AGNewbiePurchaseProduct alloc] init] autorelease];
        self.newbieProcuct.title = [newbieDic objectForKey:@"title"];
        self.newbieProcuct.detail = [newbieDic objectForKey:@"detail"];
        self.newbieProcuct.isPurchased = [[newbieDic objectForKey:@"isPurchased"] intValue];
        self.newbieProcuct.productInfo = [[[AGPurchaseProduct alloc] init] autorelease];
        [self.newbieProcuct.productInfo loadPropertiesFromDic:newbieDic];
    }
    
    NSMutableArray *array = [NSMutableArray array];
    self.productList = array;
    
    for (NSDictionary *productDic in [[dic objectForKey:@"purchaseProductList"] reverseObjectEnumerator])
    {
        AGPurchaseProduct *productInfo = [[[AGPurchaseProduct alloc] init] autorelease];
        [array addObject:productInfo];
        
        [productInfo loadPropertiesFromDic:productDic];
    }
}

- (NSString *)getProductIdFromUniqueId:(int)uniqueId
{
    if (self.newbieProcuct.productInfo.uniqueId == uniqueId)
    {
        return self.newbieProcuct.productInfo.productId;
    }
    
    for (AGPurchaseProduct *product in self.productList)
    {
        if (product.uniqueId == uniqueId)
        {
            return product.productId;
        }
    }
    
    return nil;
}

- (int)getUniqueIdFromProductId:(NSString *)productId
{
    if ([self.newbieProcuct.productInfo.productId isEqualToString:productId])
    {
        return self.newbieProcuct.productInfo.uniqueId;
    }
    
    for (AGPurchaseProduct *product in self.productList)
    {
        if ([product.productId isEqualToString:productId])
        {
            return product.uniqueId;
        }
    }
    
    return 0;
}
//add by ganhaidong 2012-12-23
- (AGPurchaseProduct*)getProductFromProductId:(NSString *)productId
{
    for (AGPurchaseProduct *product in self.productList)
    {
        if ([product.productId isEqualToString:productId])
        {
            return product;
        }
    }
    
    return nil;
}
@end