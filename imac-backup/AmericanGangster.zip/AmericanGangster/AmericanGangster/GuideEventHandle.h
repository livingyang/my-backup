//
//  GuideEventData.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-31.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CCNode;
@interface GuideEventHandle : NSObject
{
    NSArray *eventList;
    
    int cancelClick;
    int otherEventCount;
}

@property BOOL isClearGuideEvent;
@property (nonatomic, retain) NSDictionary *curEvent;

+ (GuideEventHandle *)instance;

- (void)onEventHappened:(NSString *)eventName;

@end
