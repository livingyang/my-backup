//
//  AGLoginInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGLoginInfo.h"

@implementation AGLoginInfo

@synthesize name;
@synthesize imageName;
@synthesize sex;
@synthesize type;

- (void)dealloc
{
    self.name = nil;
    self.imageName = nil;
    self.sex = nil;
    self.type = nil;
    
    [super dealloc];
}

@end

@implementation AGPushToken

@synthesize token;

+ (AGPushToken *)instance
{
    static AGPushToken *ins = nil;
    if (ins == nil)
    {
        ins = [[AGPushToken alloc] init];
    }
    
    return ins;
}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        self.token = @"";
    }
    
    return self;
}

- (void)dealloc
{
    self.token = nil;
    
    [super dealloc];
}

@end