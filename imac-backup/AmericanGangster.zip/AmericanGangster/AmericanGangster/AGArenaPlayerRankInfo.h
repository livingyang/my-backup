//
//  AGArenaPlayerRankInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGOpponentInfo.h"

@interface AGArenaPlayerRankInfo : AGOpponentInfo

@property int rank;

+ (NSArray *)playerRankListFromInfo:(NSDictionary *)info;
+ (NSArray *)arenaOpponentListFromInfo:(NSDictionary *)info;

@end
