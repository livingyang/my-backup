//
//  ShareManager.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LoginViewController.h"
#import "SNWeiBoController.h"

@class CFaceBookHelper;
@class CTwitterHelper;
@class SinaWeibo;
@class BaseLayer;

@interface ShareManager : NSObject<LoginViewControllerDelegate>
{
    CFaceBookHelper *m_faceBookHelper;
    CTwitterHelper  *m_twitterHelper;
    LoginViewController* loginViewController;
    SinaWeibo *sinaweibo;
    BaseLayer* delegate;
}
@property(nonatomic,assign) BaseLayer* delegate;
@property (readonly, nonatomic) SinaWeibo *sinaweibo;
@property (strong, nonatomic) SNWeiBoController *snWeiBoController;

+ (ShareManager *)instance;
- (void)removeLoading;
- (void)showFacebook;
- (void)showTwitter;
- (void)showQQShare;
- (void)showSinaShare;
-(NSString*)getCNShareText;

@end
