//
//  LocalSettingManager.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "LocalSettingManager.h"

#define KEY_BGM_ENABLED @"KEY_BGM_ENABLED"
#define KEY_VIBRATE_ENABLED @"KEY_VIBRATE_ENABLED"

@implementation LocalSettingManager

+ (LocalSettingManager *)instance
{
    static LocalSettingManager *mgr = nil;
    if (mgr == nil)
    {
        mgr = [[LocalSettingManager alloc] init];
    }
    
    return mgr;
}

- (BOOL)isBgmEnabled
{
    return ([[NSUserDefaults standardUserDefaults] objectForKey:KEY_BGM_ENABLED] == nil)
    ? YES
    : [[NSUserDefaults standardUserDefaults] boolForKey:KEY_BGM_ENABLED];
}

- (void)setIsBgmEnabled:(BOOL)isBgmEnabled
{
    [[NSUserDefaults standardUserDefaults] setBool:isBgmEnabled forKey:KEY_BGM_ENABLED];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:SETTING_BGM_CHANGED_NOTIFICATION
                                                        object:self];
}

- (BOOL)isVibrateEnabled
{
    return ([[NSUserDefaults standardUserDefaults] objectForKey:KEY_VIBRATE_ENABLED] == nil)
    ? YES
    : [[NSUserDefaults standardUserDefaults] boolForKey:KEY_VIBRATE_ENABLED];
}

- (void)setIsVibrateEnabled:(BOOL)isVibrateEnabled
{
    [[NSUserDefaults standardUserDefaults] setBool:isVibrateEnabled forKey:KEY_VIBRATE_ENABLED];
}

@end
