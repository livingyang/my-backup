//
//  SoundManager.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "SoundManager.h"
#import "LocalSettingManager.h"
#import "SimpleAudioEngine.h"

#define NAME_BG_MUSIC @"bg.mp3"

@implementation SoundManager

@synthesize bgmName;

+ (SoundManager *)instance
{
    static SoundManager *mgr = nil;
    if (mgr == nil)
    {
        mgr = [[SoundManager alloc] init];
    }
    
    return mgr;
}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        [SimpleAudioEngine sharedEngine].backgroundMusicVolume = [LocalSettingManager instance].isBgmEnabled ? 1.0f : 0;

        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(onBgmSettingChanged:)
                                                     name:SETTING_BGM_CHANGED_NOTIFICATION
                                                   object:nil];
    }
    
    return self;
}

- (void)dealloc
{
    self.bgmName = nil;
    
    [super dealloc];
}

- (void)onBgmSettingChanged:(NSNotification *)notification
{
    [SimpleAudioEngine sharedEngine].backgroundMusicVolume = [LocalSettingManager instance].isBgmEnabled ? 1.0f : 0;
}

- (void)playBackgroundMusicAndRecordName:(NSString *)fileName
{    
    [[SimpleAudioEngine sharedEngine] playBackgroundMusic:fileName];
    
    self.bgmName = fileName;
}

- (void)playBackgroundMusic
{
    [self playBackgroundMusicAndRecordName:NAME_BG_MUSIC];
}

- (void)continuePlayBackgroundMusic
{
    [NSObject cancelPreviousPerformRequestsWithTarget:self
                                             selector:@selector(continuePlayBackgroundMusic)
                                               object:nil];

    if (self.bgmName != NAME_BG_MUSIC)
    {
        [self playBackgroundMusicAndRecordName:NAME_BG_MUSIC];
    }
}

- (void)playVibrate
{
    if ([LocalSettingManager instance].isVibrateEnabled)
    {
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
    }
}

- (void)playEffectButtonBack
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"button-back.wav"];
}

- (void)playEffectButtonOk
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"button-ok.wav"];
}

- (void)playEffectWin
{
    [self playBackgroundMusicAndRecordName:@"attack-win.wav"];
    [self performSelector:@selector(continuePlayBackgroundMusic) withObject:nil afterDelay:16];
}

- (void)playEffectWinBoss
{
    [self playBackgroundMusicAndRecordName:@"win-boss.wav"];
    [self performSelector:@selector(continuePlayBackgroundMusic) withObject:nil afterDelay:8];
}

- (void)playEffectLost
{
    [self playBackgroundMusicAndRecordName:@"attack-lost.wav"];
    [self performSelector:@selector(continuePlayBackgroundMusic) withObject:nil afterDelay:8];
}

- (void)playEffectLevelUp
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"level-up.wav"];
}

- (void)playEffectWarningBoss
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"warning-boss.wav"];
}

- (void)playEffectAttackSign
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"attack-sign.wav"];
}

- (void)playEffectGainCoin
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"gain-coin.wav"];
}

- (void)playEffectRecovery
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"recovery.wav"];
}

- (void)playEffectSlot
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"mission-slot.wav"];
}

- (void)playEffectSlotStop
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"slot-stop.wav"];
}

- (void)playEffectRefineFail
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"refine-fail.wav"];
}

- (void)playEffectRefineSuccess
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"refine-success.wav"];
}

- (void)playEffectCheckSelect
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"check-select.wav"];
}

- (void)playEffectCheckUnselect
{
    [[SimpleAudioEngine sharedEngine] playEffect:@"check-unselect.wav"];
}

@end
