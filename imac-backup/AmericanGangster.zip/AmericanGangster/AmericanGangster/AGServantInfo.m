//
//  AGServantInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGServantInfo.h"
#import "AGEquipmentInfo.h"
#import "AGStoreItemInfo.h"
#import "AGStoreItemInfoCache.h"

@implementation AGServantInfo

@synthesize opponentInfo;
@synthesize servantId;
@synthesize increaseCoins;
@synthesize isBattle;
@synthesize equipment1, equipment2, equipment3, equipment4;

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        self.opponentInfo = [[[AGOpponentInfo alloc] init] autorelease];
    }
    
    return self;
}

- (AGEquipmentInfo *)equipmentWithPos:(int)pos
{
    if (pos < 1 || pos > 4)
    {
        NSLog(@"AGServantInfo#equipmentWithPos pos = %d is invalid", pos);
        return nil;
    }
    
    return [self performSelector:NSSelectorFromString([NSString stringWithFormat:@"equipment%d", pos])];
}

+ (AGServantInfo *)servantInfoFromInfo:(NSDictionary *)info
{
    AGServantInfo *servantInfo = [[[AGServantInfo alloc] init] autorelease];
    
    [servantInfo.opponentInfo setPropertiesFromInfo:[info objectForKey:@"servantPlayer"]];
    servantInfo.servantId = [[info objectForKey:@"servantId"] intValue];
    
    servantInfo.equipment1 = [AGEquipmentInfo packItemFromPosDic:[info objectForKey:@"posL"]];
    servantInfo.equipment2 = [AGEquipmentInfo packItemFromPosDic:[info objectForKey:@"posR"]];
    servantInfo.equipment3 = [AGEquipmentInfo packItemFromPosDic:[info objectForKey:@"posT"]];
    servantInfo.equipment4 = [AGEquipmentInfo packItemFromPosDic:[info objectForKey:@"posD"]];
    
    return servantInfo;
}

+ (NSArray *)getServantListFromInfo:(NSDictionary *)info
{
    NSMutableArray *servantList = [NSMutableArray array];
    
    for (NSDictionary *servantDic in [info objectForKey:@"myServantList"])
    {
        AGServantInfo *servantInfo = [[[AGServantInfo alloc] init] autorelease];
        [servantList addObject:servantInfo];
        
        servantInfo.servantId = [[servantDic objectForKey:@"id"] intValue];
        servantInfo.increaseCoins = [[servantDic objectForKey:@"increaseCoins"] intValue];
        
        servantInfo.isBattle = [[servantDic objectForKey:@"isBattle"] intValue];

        [servantInfo.opponentInfo setPropertiesFromInfo:servantDic];
        servantInfo.opponentInfo.imageName = [servantDic objectForKey:@"headerUrl"];
        servantInfo.opponentInfo.level = [[servantDic objectForKey:@"level"] intValue];
    }
    
    return servantList;
}

+ (NSArray *)getNotInBattleServantList:(NSArray *)servantList
{
    NSMutableArray *notInBattleServantList = [NSMutableArray array];
    for (AGServantInfo *servantInfo in servantList)
    {
        if (servantInfo.isBattle == NO)
        {
            [notInBattleServantList addObject:servantInfo];
        }
    }
    
    return notInBattleServantList;
}

- (void)dealloc
{
    self.opponentInfo = nil;
    
    self.equipment1 = nil;
    self.equipment2 = nil;
    self.equipment3 = nil;
    self.equipment4 = nil;
    
    [super dealloc];
}

@end
