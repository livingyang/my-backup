//
//  LanguageManager.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-10-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "LanguageManager.h"
#import "CHCSV.h"

@implementation LanguageManager

@synthesize stringDic;

+ (LanguageManager *)instance
{
    static LanguageManager *mgr = nil;
    if (mgr == nil)
    {
        mgr = [[LanguageManager alloc] init];
    }
    
    return mgr;
}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        [self loadStringDictionary];
    }
    return self;
}

- (void)dealloc
{
    self.stringDic = nil;
    [super dealloc];
}

- (void)loadStringDictionary
{
    NSString *file = [[NSBundle mainBundle] pathForResource:@"LanguageStrings" ofType:@"csv"];
    NSArray *recordList = [NSArray arrayWithContentsOfCSVFile:file encoding:NSUTF8StringEncoding error:nil];
    
    self.stringDic = [NSMutableDictionary dictionary];
    for (NSArray *record in recordList)
    {
        NSString *key = [record objectAtIndex:0];
        NSString *string = [record objectAtIndex:[self isEnglishVersion] ? 1 : 2];
        
        [self.stringDic setObject:string forKey:key];
    }
}

- (NSString *)bundleIdentifier
{
    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleIdentifier"];
}

- (BOOL)isEnglishVersion
{
    return [[self bundleIdentifier] isEqualToString:@"com.zqgame.americangangster"];
}

- (BOOL)isChineseVersion
{
    return ![self isEnglishVersion];
}

- (BOOL)hasStringFromId:(NSString *)strId
{
    return ([stringDic objectForKey:strId] != nil);
}

- (NSString *)getStringFromId:(NSString *)strId
{
    return [self hasStringFromId:strId] ? [stringDic objectForKey:strId] : strId;
}

+ (NSString *)serverAddress
{
    if ([[LanguageManager instance] isEnglishVersion])
    {
        return @"http://120.197.96.36/gangster/RestServer";
//        return @"http://192.168.20.121:8080/gangster/RestServer";
    }
    else
    {
        return @"http://120.197.96.28/cn_gangster/RestServer";
//        return @"http://192.168.20.121:8080/cn_gangster/RestServer";
    }
}

@end
