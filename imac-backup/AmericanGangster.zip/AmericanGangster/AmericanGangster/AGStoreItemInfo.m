//
//  AGStoreItemInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-22.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGStoreItemInfo.h"
#import "CCBalsamiqLayer.h"
#import "ItemImageManager.h"
#import "CCLabelTTF+ChangeFont.h"

@implementation AGStoreItemInfo

@synthesize name, imageName;
@synthesize type, itemId, attack, defense, coin, dollar, star, limitLevel;
@synthesize unitCoin, unitAttack, unitDefense;

- (NSString *)equipmentImagePath
{
    return [@"equipments" stringByAppendingPathComponent:self.imageName];
}

- (void)loadFromInfo:(NSDictionary *)dic
{
    self.name = [dic objectForKey:@"equipName"];
    self.imageName = [dic objectForKey:@"imageId"];
    self.type = [[dic objectForKey:@"type"] intValue];
    self.itemId = [[dic objectForKey:@"equipId"] intValue];
    self.attack = [[dic objectForKey:@"attack"] intValue];
    self.defense = [[dic objectForKey:@"defense"] intValue];
    self.coin = [[dic objectForKey:@"coin"] intValue];
    self.dollar = [[dic objectForKey:@"money"] intValue];
    self.star = [[dic objectForKey:@"star"] intValue];
    self.limitLevel = [[dic objectForKey:@"level"] intValue];
    
    self.unitCoin = [[dic objectForKey:@"unitCoin"] intValue];
    self.unitAttack = [[dic objectForKey:@"unitIncAttack"] intValue];
    self.unitDefense = [[dic objectForKey:@"unitIncDefense"] intValue];
}

- (void)dealloc
{
    self.name = nil;
    self.imageName = nil;
    
    [super dealloc];
}

+ (AGStoreItemInfo *)itemInfoWithDictionaryInfo:(NSDictionary *)dic
{
    AGStoreItemInfo *info = [[[AGStoreItemInfo alloc] init] autorelease];
    [info loadFromInfo:dic];
    return info; 
}

+ (NSArray *)itemInfoArrayWithDictionaryInfo:(NSDictionary *)dic
{
    NSArray *storyList = [dic objectForKey:@"storeList"];
    NSMutableArray *itemInfoArray = [NSMutableArray array];
    
    for (NSDictionary *itemDic in storyList)
    {
        [itemInfoArray addObject:[AGStoreItemInfo itemInfoWithDictionaryInfo:itemDic]];
    }
    
    return itemInfoArray;
}

+ (NSArray *)shopWeaponInfoListWithInfo:(NSDictionary *)dic
{
    return [self itemInfoArrayWithDictionaryInfo:dic];
}

- (void)setImageToSprite:(CCSprite *)sprite
{
    sprite.texture = [[CCTextureCache sharedTextureCache] addImage:self.equipmentImagePath];
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    [[layer getControlByName:@"name"] setString:self.name];
    [[layer getControlByName:@"name"] changeToBlackArialFont];
    
    [[layer getControlByName:@"attack"] setString:[NSString stringWithFormat:@"%d", self.attack]];
    [[layer getControlByName:@"defense"] setString:[NSString stringWithFormat:@"%d", self.defense]];
    [[layer getControlByName:@"coin"] setString:[NSString stringWithFormat:@"%d", self.coin]];
    [[layer getControlByName:@"dollar"] setString:[NSString stringWithFormat:@"%d", self.dollar]];
    
//    [[layer getControlByName:@"level"] setString:[NSString stringWithFormat:@"%d", self.limitLevel]];
    
    for (int i = 1; i <= 5; ++i)
    {
        [[layer getControlByName:[NSString stringWithFormat:@"image_star%d", i]] setVisible:(self.star >= i)];
    }
    
    [[layer getControlByName:@"image_icon"] setTexture:[[CCTextureCache sharedTextureCache] addImage:self.equipmentImagePath]];
}

@end
