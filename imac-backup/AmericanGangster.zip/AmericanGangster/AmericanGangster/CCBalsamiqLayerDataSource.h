//
//  CCBalsamiqLayerDataSource.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-9.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CCBalsamiqLayer;

@protocol CCBalsamiqLayerDataSource <NSObject>

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer;

@end
