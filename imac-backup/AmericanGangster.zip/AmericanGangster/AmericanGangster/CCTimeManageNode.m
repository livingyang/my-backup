//
//  CCTimeManageNode.m
//  study_TimeLabel
//
//  Created by 青宝 中 on 12-8-7.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "CCTimeManageNode.h"
#import "TimeLeftManager.h"

#define TAG_TIME_NODE (123)
#define UPDATE_CYCLE (0.99f)

typedef struct
{
    int hour;
    int minutes;
    int seconds;
} TimeCountDownData;

TimeCountDownData getTimeCountDownDataFromTimeInterval(NSTimeInterval time)
{
    time = (time > 0) ? time : 0;
    
    TimeCountDownData data = {};
    data.hour = time / 3600;
    data.minutes = ((int)time % 3600) / 60;
    data.seconds = (int)time % 60;
    
    return data;
}

@implementation CCTimeManageNode

@synthesize labTime;
@synthesize timeLeft;
@synthesize finishAction;
@synthesize isHHMMSS;

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        self.timeLeft = [TimeLeftManager managerWithTimeLeft:0];
        
        [self schedule:@selector(updateTimeLeft:) interval:UPDATE_CYCLE];
    }
    
    return self;
}

- (void)dealloc
{
    self.timeLeft = nil;
    self.finishAction = nil;
    
    [self unschedule:@selector(updateTimeLeft:)];
    
    [super dealloc];
}

- (void)updateTimeLeft:(ccTime)dt
{
    labTime.string = isHHMMSS
    ? [CCTimeManageNode timeStringWithHHMMSS:self.timeLeft.curTimeLeft]
    : [CCTimeManageNode timeStringWithMMSS:self.timeLeft.curTimeLeft];
    
    if (self.timeLeft.curTimeLeft == 0)
    {
        [self unschedule:@selector(updateTimeLeft:)];
        
        [self runAction:[CCSequence actions:
                         self.finishAction,
                         [CCCallFunc actionWithTarget:self selector:@selector(cleanup)],
                         [CCCallFunc actionWithTarget:self selector:@selector(removeFromParentAndCleanup:)],
                         nil]];
    }
}

+ (NSString *)timeStringWithHHMMSS:(NSTimeInterval)time
{
    TimeCountDownData data = getTimeCountDownDataFromTimeInterval(time);
    return [NSString stringWithFormat:@"%02d : %02d : %02d", data.hour, data.minutes, data.seconds];
}

+ (NSString *)timeStringWithMMSS:(NSTimeInterval)time
{
    TimeCountDownData data = getTimeCountDownDataFromTimeInterval(time);
    return [NSString stringWithFormat:@"%02d : %02d", data.minutes, data.seconds];
}

+ (void)startCountDown:(CCLabelTTF *)label
              timeLeft:(NSTimeInterval)time
              isHHMMSS:(BOOL)isHHMMSS
        withStopAction:(CCFiniteTimeAction *)stopAction
{
    if (label == nil)
    {
        return;
    }
    
    [self stopCountDown:label];
    
    CCTimeManageNode *node = [CCTimeManageNode node];
    [node.timeLeft resetWithTimeLeft:time];
    
    node.labTime = label;
    node.isHHMMSS = isHHMMSS;
    node.finishAction = stopAction;

    [label addChild:node z:0 tag:TAG_TIME_NODE];
    
    [node updateTimeLeft:0];
}

+ (void)stopCountDown:(CCLabelTTF *)label
{
    if ([label getChildByTag:TAG_TIME_NODE] != nil)
    {
        [label removeChildByTag:TAG_TIME_NODE cleanup:YES];
    }
}

@end
