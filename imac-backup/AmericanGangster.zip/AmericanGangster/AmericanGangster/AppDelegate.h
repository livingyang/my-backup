//
//  AppDelegate.h
//  AmericanGangster_Login
//
//  Created by 青宝 中 on 12-4-26.
//  Copyright __MyCompanyName__ 2012年. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RootViewController.h"
#import "SNWeiBoController.h"
@class SinaWeibo;

@interface AppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow			*window;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) RootViewController *viewController;

@end
