//
//  AGPurchaseProduct.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-9-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCBalsamiqLayerDataSource.h"

@interface AGPurchaseProduct : NSObject <CCBalsamiqLayerDataSource>

@property int uniqueId;
@property int dollar;
@property (nonatomic, copy) NSString *money;
@property (nonatomic, copy) NSString *productId;

@end

@interface AGNewbiePurchaseProduct : NSObject

@property (nonatomic, retain) AGPurchaseProduct *productInfo;

@property BOOL isPurchased;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *detail;

@end

@interface AGPurchaseProductList : NSObject

@property (nonatomic, retain) NSArray *productList;
@property (nonatomic, retain) AGNewbiePurchaseProduct *newbieProcuct;

//+ (AGPurchaseProductList *)productListFromInfo:(NSDictionary *)dic;
+ (AGPurchaseProductList *)instance;
- (void)updateWithInfo:(NSDictionary *)dic;
- (NSString *)getProductIdFromUniqueId:(int)uniqueId;
- (int)getUniqueIdFromProductId:(NSString *)productId;
- (AGPurchaseProduct*)getProductFromProductId:(NSString *)productId;
@end