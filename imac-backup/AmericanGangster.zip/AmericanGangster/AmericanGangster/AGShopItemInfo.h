//
//  AGShopItemInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CCBalsamiqLayerDataSource.h"

@interface AGShopItemInfo : NSObject <CCBalsamiqLayerDataSource>

@property int propsId;
@property int money;
@property int count;
@property BOOL isCanUseDirect;

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, copy) NSString *detail;

@property (nonatomic, readonly) NSString *itemImagePath;

+ (AGShopItemInfo *)shopItemFromInfo:(NSDictionary *)info;
+ (NSArray *)shopItemListFromInfo:(NSDictionary *)info;

// alert item
+ (NSArray *)shopItemListFromAlertInfo:(NSDictionary *)info;

// get item
+ (AGShopItemInfo *)shopItemFromUseAndBuyInfo:(NSDictionary *)info;

@end

@interface AGShopBagItemInfo : NSObject <CCBalsamiqLayerDataSource>

@property (nonatomic, retain) AGShopItemInfo *itemInfo;
@property (nonatomic, retain) AGShopItemInfo *bagItemInfo;

@property (nonatomic, readonly) int bagItemCount;
@property (nonatomic, readonly) int costMoney;

+ (AGShopBagItemInfo *)bagItemFromInfo:(NSDictionary *)info;

@end

@interface AGShopSlotMachine : NSObject

@property int slotId;
@property int dollar;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *detail;
@property (nonatomic, retain) NSArray *randomEquipmentIdList;
@property int displayEquipmentId;

@end

@interface AGShopSlotMachineCache : NSObject

@property (nonatomic, retain) NSArray *slotMachineList;

+ (AGShopSlotMachineCache *)instance;
- (void)updateSlotMachineWithDic:(NSDictionary *)dic;
- (AGShopSlotMachine *)getSlotMachineFromId:(int)slotId;

@end

@interface AGCardInfo : NSObject <CCBalsamiqLayerDataSource>

@property int cardId;
@property int count;

@property int exchangeCardNum;
@property int exchangeItemNum;

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, copy) NSString *detail;

@property (nonatomic, retain) AGShopItemInfo *exchangeItem;

+ (NSArray *)cardListFromInfo:(NSDictionary *)info;
+ (AGCardInfo *)cardInfoFromExchangeInfo:(NSDictionary *)info;

@end

@interface AGCardInfoCache : NSObject

@property (nonatomic, retain) NSArray *cardInfoList;

+ (AGCardInfoCache *)instance;

- (void)loadTotalCardInfo:(NSDictionary *)info;
- (AGCardInfo *)getCardInfoById:(int)cardId;
- (AGCardInfo *)getCardInfoByName:(NSString *)cardName;

@end

@interface AGShopInfo : NSObject

@property NSTimeInterval reflashFinishTime;
@property (nonatomic, readonly) NSTimeInterval reflashLeftTime;

+ (AGShopInfo *)instance;

- (void)updateFromInfo:(NSDictionary *)info;

@end
