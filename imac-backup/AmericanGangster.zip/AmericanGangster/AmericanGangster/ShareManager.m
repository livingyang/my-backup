//
//  ShareManager.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ShareManager.h"

#import "CFaceBookHelper.h"
#import "CTwitterHelper.h"
#import "LanguageManager.h"
#import "cocos2d.h"
#import "SinaWeibo.h"
#import "AGPlayerInfo.h"
#import "BaseLayer.h"

@implementation ShareManager

@synthesize sinaweibo,delegate;
@synthesize snWeiBoController = _snWeiBoController;

+ (ShareManager *)instance
{
    static ShareManager *mgr = nil;
    if (mgr == nil)
    {
        mgr = [[ShareManager alloc] init];
    }
    
    return mgr;
}

- (id)init
{
    self = [super init];
    if (self != nil)
    {
        //modify by ganhaidong 2012-12-22
        if ([[LanguageManager instance]isEnglishVersion]) {
            // FACEBOOK_TEST
            m_faceBookHelper=[[CFaceBookHelper alloc] init];//facebook by linan-2012-7-23
            
            m_twitterHelper=[[CTwitterHelper alloc] init];//twitter by linan-2012-7-23
            //        [m_faceBookHelper addLoginOutButton:[[CCDirector sharedDirector] openGLView]];//facebook by linan-2012-7-23
            [[[CCDirector sharedDirector] openGLView] addSubview:m_twitterHelper.view];
        }
        
        
        //add by ganhaidong start 2012-12-22
        if ([[LanguageManager instance]isChineseVersion]) {
            
            // Override point for customization after application launch.
            self.snWeiBoController = [[SNWeiBoController alloc] init];
            
            sinaweibo = [[SinaWeibo alloc] initWithAppKey:kAppKey appSecret:kAppSecret appRedirectURI:kAppRedirectURI andDelegate:_snWeiBoController];
            NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
            NSDictionary *sinaweiboInfo = [defaults objectForKey:@"SinaWeiboAuthData"];
            if ([sinaweiboInfo objectForKey:@"AccessTokenKey"] && [sinaweiboInfo objectForKey:@"ExpirationDateKey"] && [sinaweiboInfo objectForKey:@"UserIDKey"])
            {
                sinaweibo.accessToken = [sinaweiboInfo objectForKey:@"AccessTokenKey"];
                sinaweibo.expirationDate = [sinaweiboInfo objectForKey:@"ExpirationDateKey"];
                sinaweibo.userID = [sinaweiboInfo objectForKey:@"UserIDKey"];
            }   
        }
        //add by ganhaidong end
    }
    
    return self;
}

//add by ganhaidong start 2012-12-22
-(void)removeLoading
{
    if (delegate!=nil) {
        delegate.isLoading=NO;
    }
}

-(NSString*)getCNShareText
{
    return [AGPlayerInfo defaultPlayerInfo].shareDetail;
    int x=arc4random()%100;
    CCLOG(@"arc4random x:%i",x);
    NSString* str=nil;
    if (x<33) {
        str=[NSString stringWithFormat:@"什么叫无敌！什么叫势不可挡！我在#无间风云#中，升到了XXX级，并集结了一支最强大的黑帮团伙。不服就来挑战我试试看吧！http://…………"];
    }else
    if (x>=33&&x<=66) {
        str=[NSString stringWithFormat:@"在#无间风云#里，单凭武力没有钱财可活不下去，像我这么机智聪明的老大怎么会放过赚钱的机会。来来来，XXX商业新开张，报我的名号还能给你打个7折哦亲！哈哈！http://…………"];
    }else
    if (x>66&&x<=100) {
        str=[NSString stringWithFormat:@"人靠衣装，佛靠金装。混黑道靠的什么？响当当的名号！我在#无间风云#中人称XXX，可以说是无人不知，无人不晓。要想见我庐山真面目，那就来吧！http://…………"];
    }
    CCLOG(@"getCNShareText:%@",str);
    return str;
}

+(NSString*)getCNShareImgPath
{
    NSString *iconPath = [[NSBundle mainBundle] pathForResource:@"Icon@2x" ofType:@"png"];
    CCLOG(@"iconPath:%@",iconPath);
    return iconPath;
}
- (void)showQQShare
{
    if (loginViewController==nil) {
        loginViewController = [[LoginViewController alloc] initWithNibName:nil bundle:nil];
        loginViewController.delegate = self;
        loginViewController.picPath = [ShareManager getCNShareImgPath];
    }

    [loginViewController loginWithQQWeibo:[CCDirector sharedDirector].openGLView];
}

- (void)showSinaShare
{
    [self.snWeiBoController loginSina];
}

//add by ganhaidong end

- (void)onLoginViewBack
{
    
}



- (void)showFacebook
{
    [m_faceBookHelper publishFeed:FB_APP_ID 
                             link:@"http://www.zqgame.com/" 
                          picture:@"http://a948.phobos.apple.com/us/r30/Purple/v4/bf/b8/90/bfb89097-546e-49dd-ef93-3e8b3c2f3486/mzl.slenaayf.png" 
                             name:@"American gangster" 
                          caption:@"American gangster" 
                      description:@"good game!!!!!"];
}

- (void)showTwitter
{
    [m_twitterHelper creatTwitter:@"http://www.zqgame.com/" picture:@"Icon@2x.png" name:@"American gangster" description:@"American gangster good game!!!!!"];
    [[[CCDirector sharedDirector] openGLView] addSubview:m_twitterHelper.view];
}

@end
