//
//  AGMessageInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-10.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGMessageInfo.h"
#import "CCBalsamiqLayer.h"
#import "CharacterImageManager.h"
#import "LanguageManager.h"

NSString *getTimeString(NSTimeInterval time)
{
    if (time < 0)
    {
        return [NSString stringWithFormat:[[LanguageManager instance] getStringFromId:@"14001"], time];
    }
    else if (time < 60)
    {
        return [[LanguageManager instance] getStringFromId:@"14002"];
    }
    else if (time < 3600)
    {
        return [NSString stringWithFormat:[[LanguageManager instance] getStringFromId:@"14003"], (int)(time / 60)];
    }
    else if (time < 24 * 3600)
    {
        return [NSString stringWithFormat:[[LanguageManager instance] getStringFromId:@"14004"], (int)(time / 3600)];
    }
    else
    {
        return [NSString stringWithFormat:[[LanguageManager instance] getStringFromId:@"14005"], (int)(time / (3600 * 24))];
    }
}

@implementation AGMessageInfo

@synthesize type;
@synthesize imageName, message;
@synthesize time;
@synthesize playerId;

- (void)dealloc
{
    self.imageName = nil;
    self.message = nil;
    
    [super dealloc];
}

- (BOOL)canChallenge
{
    return (self.type == 2)
    || (self.type == 4);
}

- (NSString *)timeString
{
    return getTimeString(self.time);
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    [[layer getControlByName:@"image_header"] setTexture:
     [[CCTextureCache sharedTextureCache] addImage:[CharacterImageManager headerImageFromCharacterImage:self.imageName]]];
    
    [[layer getControlByName:@"message"] setString:self.message];
    [[layer getControlByName:@"time"] setString:self.timeString];
    [[layer getControlByName:@"Challenge"] setTag:self.playerId];
    [[layer getControlByName:@"Challenge"] setVisible:self.canChallenge];
}

- (void)loadPropertiesFromDic:(NSDictionary *)dic
{
    self.type = [[dic objectForKey:@"msgType"] intValue];
    self.imageName = [dic objectForKey:@"imageId"];
    self.message = [dic objectForKey:@"msg"];
    self.playerId = [[dic objectForKey:@"playerId"] intValue];
    self.time = [[dic objectForKey:@"createdTime"] doubleValue] / 1000.0f;
}

+ (NSArray *)messageListFromBattleInfo:(NSDictionary *)info
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *dic in [info objectForKey:@"gameBattleList"])
    {
        AGMessageInfo *message = [[[AGMessageInfo alloc] init] autorelease];
        [array addObject:message];
        
        [message loadPropertiesFromDic:dic];
    }
    
    return array;
}

+ (NSArray *)messageListFromHeelerInfo:(NSDictionary *)info
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *dic in [info objectForKey:@"gameHeelerList"])
    {
        AGMessageInfo *message = [[[AGMessageInfo alloc] init] autorelease];
        [array addObject:message];
        
        [message loadPropertiesFromDic:dic];
    }
    
    return array;
}

@end

@implementation AGMessageSystemInfo

@synthesize title;
@synthesize message;
@synthesize time;

- (void)dealloc
{
    self.title = nil;
    self.message = nil;
    
    [super dealloc];
}

- (NSString *)timeString
{
    return getTimeString(self.time);
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    [[layer getControlByName:@"title"] setString:self.title];
    [[layer getControlByName:@"message"] setString:self.message];
    [[layer getControlByName:@"time"] setString:self.timeString];
}

+ (NSArray *)messageListFromSystemInfo:(NSDictionary *)info
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *dic in [info objectForKey:@"systemMsgList"])
    {
        AGMessageSystemInfo *message = [[[AGMessageSystemInfo alloc] init] autorelease];
        [array addObject:message];
        
        message.title = [dic objectForKey:@"title"];
        message.message = [dic objectForKey:@"content"];
        message.time = [[dic objectForKey:@"createdTime"] doubleValue] / 1000.0f;
    }
    
    return array;
}

@end

@implementation AGAnnounceInfo

@synthesize title;
@synthesize message;
@synthesize timeInfo;
@synthesize jumpInfo;

- (void)dealloc
{
    self.title = nil;
    self.message = nil;
    self.timeInfo = nil;
    self.jumpInfo = nil;
    
    [super dealloc];
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    [[layer getControlByName:@"title"] setString:self.title];
    [[layer getControlByName:@"message"] setString:self.message];
    [[layer getControlByName:@"time"] setString:self.timeInfo];
}

@end

@implementation AGAnnounceCache

@synthesize hasDisplayed;
@synthesize curAnnounceList;

- (void)dealloc
{
    [super dealloc];
    
    self.curAnnounceList = nil;
}

+ (AGAnnounceCache *)instance
{
    static AGAnnounceCache *cache = nil;
    
    if (cache == nil)
    {
        cache = [[AGAnnounceCache alloc] init];
    }
    
    return cache;
}

- (void)updateAnnounceCache:(NSDictionary *)info
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *announceDic in [info objectForKey:@"noticeList"])
    {
        AGAnnounceInfo *annouceInfo = [[[AGAnnounceInfo alloc] init] autorelease];
        [array addObject:annouceInfo];
        
        annouceInfo.title = [announceDic objectForKey:@"title"];
        annouceInfo.message = [NSString stringWithFormat:@"    %@", [announceDic objectForKey:@"content"]];
        annouceInfo.timeInfo = [announceDic objectForKey:@"validation"];
        annouceInfo.jumpInfo = [announceDic objectForKey:@"module"];
    }
    
    self.curAnnounceList = array;
}

@end