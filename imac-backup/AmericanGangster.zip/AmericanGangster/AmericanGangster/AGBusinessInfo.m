//
//  AGBusinessInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-13.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGBusinessInfo.h"
#import "CCBalsamiqLayer.h"

@implementation AGBusinessInfo

@synthesize name, imageName;
@synthesize level, type;
@synthesize maxLevel;
@synthesize curCostServant, maxCostServant;
@synthesize gainCoins, nextGainCoins, increaseCoins;
@synthesize upCost;
@synthesize startTime, nextGainTime, totalGainTime;

- (void)dealloc
{
    self.name = nil;
    self.imageName = nil;
    
    [super dealloc];
}

- (NSTimeInterval)curGainTime
{
    NSTimeInterval time = self.nextGainTime - ([NSDate timeIntervalSinceReferenceDate] - self.startTime);
    return time > 0 ? time : 0;
}

- (BOOL)canGain
{
    return self.curGainTime <= 0;
}

- (int)maxCanSendServantCount
{
    return self.maxCostServant - self.curCostServant;
}

- (int)isMaxLevel
{
    return self.level >= self.maxLevel;
}

- (void)loadPropertyFromInfo:(NSDictionary *)info
{
    self.name = [[info objectForKey:@"clt"] objectForKey:@"cName"];
    self.imageName = [[info objectForKey:@"clt"] objectForKey:@"image"];
    
    self.level = [[info objectForKey:@"cLevel"] intValue];
    self.type = [[info objectForKey:@"cType"] intValue];
    
    self.maxLevel = [[info objectForKey:@"maxLevel"] intValue];
    
    self.curCostServant = [[info objectForKey:@"upServant"] intValue];
    self.maxCostServant = [[[info objectForKey:@"clt"] objectForKey:@"servant"] intValue];
    
    self.upCost = [[[info objectForKey:@"clt"] objectForKey:@"upCost"] intValue];
    
    self.gainCoins = [[[info objectForKey:@"clt"] objectForKey:@"output"] intValue];
    self.nextGainCoins = [[[info objectForKey:@"clt"] objectForKey:@"nextOutput"] intValue];
    self.increaseCoins = [[info objectForKey:@"incOutput"] intValue];
    
    self.startTime = [NSDate timeIntervalSinceReferenceDate];
    self.nextGainTime = [[info objectForKey:@"startTime"] intValue] / 1000.0f;
    self.totalGainTime = [[[info objectForKey:@"clt"] objectForKey:@"costTime"] intValue] / 1000.0f;
}

+ (NSArray *)businessListFromInfo:(NSDictionary *)dic
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *businessInfo in [dic objectForKey:@"businessList"])
    {
        AGBusinessInfo *info = [[[AGBusinessInfo alloc] init] autorelease];
        [array addObject:info];
        
        [info loadPropertyFromInfo:businessInfo];
    }
    
    return array;
}

+ (int)getCountOfGainBusiness:(NSArray *)businessList
{
    int count = 0;
    for (AGBusinessInfo *info in businessList)
    {
        count += info.canGain ? 1 : 0;
    }
    
    return count;
}

+ (AGBusinessInfo *)businessInfoFromCommercialInfo:(NSDictionary *)speedDic
{
    AGBusinessInfo *businessInfo = [[[AGBusinessInfo alloc] init] autorelease];
    [businessInfo loadPropertyFromInfo:[speedDic objectForKey:@"commercial"]];
    return businessInfo;
}

@end
