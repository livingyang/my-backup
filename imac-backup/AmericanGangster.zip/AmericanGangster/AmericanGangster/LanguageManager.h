//
//  LanguageManager.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-10-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LanguageManager : NSObject
{
}

@property (nonatomic, retain) NSMutableDictionary *stringDic;

+ (LanguageManager *)instance;

- (BOOL)isEnglishVersion;
- (BOOL)isChineseVersion;
- (BOOL)hasStringFromId:(NSString *)strId;
- (NSString *)getStringFromId:(NSString *)strId;
+ (NSString *)serverAddress;

@end
