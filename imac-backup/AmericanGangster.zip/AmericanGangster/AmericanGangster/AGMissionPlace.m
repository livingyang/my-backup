//
//  AGMissionGroup.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGMissionPlace.h"
#import "CCBalsamiqLayer.h"
#import "CCMenuItemButton.h"
#import "CCLabelTTF+ChangeFont.h"

@implementation AGMissionPlace

@synthesize mapId;
@synthesize mapName;

- (void)dealloc
{
    self.mapName = nil;
    [super dealloc];
}

- (void)loadPropertyFromInfo:(NSDictionary *)dic
{
    self.mapId = [[dic objectForKey:@"mapId"] intValue];
    self.mapName = [dic objectForKey:@"mapName"];
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)placeButton
{ 
    CCMenuItemButton *button = [placeButton getControlByName:@"Place"];
    button.label.string = self.mapName;
    [button.label changeToBlackArialFont];
}

@end

@implementation AGMissionPlaceList

@synthesize unlockedPlaceArray, lockedPlaceArray;

- (void)dealloc
{
    self.unlockedPlaceArray = nil;
    self.lockedPlaceArray = nil;
    
    [super dealloc];
}

+ (AGMissionPlaceList *)placeListFromInfo:(NSDictionary *)info
{
    AGMissionPlaceList *placeList = [[[AGMissionPlaceList alloc] init] autorelease];
    
    NSMutableArray *unlockPlaceArray = [NSMutableArray array];
    placeList.unlockedPlaceArray = unlockPlaceArray;
    for (NSDictionary *placeInfo in [info objectForKey:@"placeList"])
    {
        AGMissionPlace *place = [[[AGMissionPlace alloc] init] autorelease];
        [place loadPropertyFromInfo:placeInfo];
        
        [unlockPlaceArray addObject:place];
    }
    
    NSMutableArray *lockPlaceArray = [NSMutableArray array];
    placeList.lockedPlaceArray = lockPlaceArray;
    for (NSDictionary *placeInfo in [info objectForKey:@"lockedList"])
    {
        AGMissionPlace *place = [[[AGMissionPlace alloc] init] autorelease];
        [place loadPropertyFromInfo:placeInfo];
        
        [lockPlaceArray addObject:place];
    }
    
    // 每次都会刷新地图列表
    {
        NSMutableArray *placeListCache = [NSMutableArray array];
        [placeListCache addObjectsFromArray:placeList.lockedPlaceArray];
        [placeListCache addObjectsFromArray:placeList.unlockedPlaceArray];
        [AGMissionPlaceListCache instance].placeList = placeListCache;
    }
    return placeList;
}

+ (NSTimeInterval)getForbidDoMissionTime:(NSDictionary *)info
{
    return [[info objectForKey:@"forbidDoMissionTime"] intValue] / 1000.0f;
}

@end

@implementation AGMissionPlaceListCache

@synthesize placeList;

- (void)dealloc
{
    self.placeList = nil;
    
    [super dealloc];
}

+ (AGMissionPlaceListCache *)instance
{
    static AGMissionPlaceListCache *cache = nil;
    if (cache == nil)
    {
        cache = [[AGMissionPlaceListCache alloc] init];
    }
    
    return cache;
}

- (AGMissionPlace *)getPlaceFromMapId:(int)mapId
{
    for (AGMissionPlace *place in self.placeList)
    {
        if (place.mapId == mapId)
        {
            return place;
        }
    }
    
    return nil;
}

@end