//
//  AGPackItemInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGEquipmentInfo.h"
#import "AGStoreItemInfo.h"
#import "AGStoreItemInfoCache.h"
#import "CCBalsamiqLayer.h"

@implementation AGEquipmentInfo
@synthesize storeItemInfo;
@synthesize uniqueId, goodsId;
@synthesize isEquiped;
@synthesize sellCoins;
@synthesize curUpCount, maxUpCount;
@synthesize refineAttack, refineDefense;
@synthesize factor;

//+ (AGPackItemInfo *)packItemInfoWithDictionaryInfo:(NSDictionary *)dic
//{
//    return [[AGPackItemInfo alloc] initWithDictionaryInfo:dic];
//}

//- (id)initWithDictionaryInfo:(NSDictionary *)dic
//{
//    self = [super init];
//    if (self != nil)
//    {
//        self.uniqueId = [[dic objectForKey:@"id"] intValue];
//        self.goodsId = [[dic objectForKey:@"goodsId"] intValue];
//        self.isUsing = [[dic objectForKey:@"isBattle"] intValue];
//        self.sellCoins = [[dic objectForKey:@"sellCoins"] intValue];
//    }
//    
//    return self;
//}

- (int)baseAttack
{
    return self.storeItemInfo.attack;
}

- (int)baseDefense
{
    return self.storeItemInfo.defense;
}

- (int)totalAttack
{
    return self.baseAttack + self.refineAttack;
}

- (int)totalDefense
{
    return self.baseDefense + self.refineDefense;
}

- (int)nextRefineTotalAttack
{
    return self.totalAttack + self.storeItemInfo.unitAttack;
}

- (int)nextRefineTotalDefense
{
    return self.totalDefense + self.storeItemInfo.unitDefense;
}

- (float)refinePercent
{
    if (self.maxUpCount == 0)
    {
        return 0;
    }
    
    return clampf(self.curUpCount * 100 / self.maxUpCount, 0, 100);
}

- (BOOL)isMaxRefine
{
    return self.curUpCount == self.maxUpCount;
}

- (int)cost
{
    return self.storeItemInfo.unitCoin * self.factor;
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    [self.storeItemInfo updateDataToLayer:layer];
    
    [[layer getControlByName:@"sell-coins"] setString:
     [NSString stringWithFormat:@"%d", self.sellCoins]];
    
    [[layer getControlByName:@"refine-count"] setString:
     [NSString stringWithFormat:@"%d", self.curUpCount]];
    
    [[layer getControlByName:@"total-attack"] setString:
     [NSString stringWithFormat:@"%d", self.totalAttack]];
    [[layer getControlByName:@"total-defense"] setString:
     [NSString stringWithFormat:@"%d", self.totalDefense]];
    
    [[layer getControlByName:@"detail-attack"] setString:
     [NSString stringWithFormat:@"%d + %d", self.baseAttack, self.refineAttack]];
    [[layer getControlByName:@"detail-defense"] setString:
     [NSString stringWithFormat:@"%d + %d", self.baseDefense, self.refineDefense]];
}

- (void)dealloc
{
    [super dealloc];
}

- (void)loadPropertiesFromDic:(NSDictionary *)dic
{
    self.uniqueId = [[dic objectForKey:@"id"] intValue];
    self.goodsId = [[dic objectForKey:@"goodsId"] intValue];
    self.storeItemInfo = [[AGStoreItemInfoCache instance] getItemInfoFromEquipId:self.goodsId];
    self.sellCoins = [[dic objectForKey:@"sellCoins"] intValue];
    
    self.isEquiped = [[dic objectForKey:@"isBattle"] intValue];
    self.curUpCount = [[dic objectForKey:@"upNum"] intValue];
    self.maxUpCount = [[dic objectForKey:@"upNumLimited"] intValue];
 
    self.refineAttack = [[dic objectForKey:@"incAttack"] intValue];
    self.refineDefense = [[dic objectForKey:@"incDefense"] intValue];
    
    self.factor = [[dic objectForKey:@"factor"] intValue];
}

+ (NSArray *)packItemInfoArrayWithDictionaryInfo:(NSDictionary *)dic
{    
    NSMutableArray *packList = [dic objectForKey:@"packList"];
    NSMutableArray *packItemArray = [NSMutableArray array];
    
    for (NSDictionary *itemDic in packList)
    {
        AGEquipmentInfo *packItem = [[[AGEquipmentInfo alloc] init] autorelease];
        [packItem loadPropertiesFromDic:itemDic];
        [packItemArray addObject:packItem];
        
        if (packItem.storeItemInfo == nil)
        {
            NSLog(@"AGPackItemInfo#packItemInfoArrayWithDictionaryInfo store item = nil, id = %@",
                  packItem.uniqueId);
        }
    }
    
    return packItemArray;
}

+ (NSArray *)equipmentInfoFromDictionaryInfo:(NSDictionary *)dic
{
    return [self packItemInfoArrayWithDictionaryInfo:dic];
}

+ (AGEquipmentInfo *)packItemFromPosDic:(NSDictionary *)posDic
{
    if (posDic == nil)
    {
        return nil;
    }
    
    AGEquipmentInfo *equipment = [[[AGEquipmentInfo alloc] init] autorelease];
    [equipment loadPropertiesFromDic:posDic];
    
    return equipment;
}

+ (NSArray *)getIsNotUsingPackItemList:(NSArray *)packItemList
{
    NSMutableArray *array = [NSMutableArray array];
    for (AGEquipmentInfo *item in packItemList)
    {
        if (item.isEquiped == NO)
        {
            [array addObject:item];
        }
    }
    return array;
}

+ (AGEquipmentInfo *)getPackItemFromSpinSlotMachine:(NSDictionary *)info
{
    AGEquipmentInfo *packItem = [[[AGEquipmentInfo alloc] init] autorelease];
    [packItem loadPropertiesFromDic:[info objectForKey:@"pack"]];
    return packItem;
}

@end
