//
//  CharacterImageManager.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CCTexture2D;
@interface CharacterImageManager : NSObject
{
}

@property (nonatomic, readonly) NSArray *manImageNameArray;
@property (nonatomic, readonly) NSArray *womanImageNameArray;

+ (CharacterImageManager *)instance;

- (CCTexture2D *)getTextureFromImageName:(NSString *)name;

+ (NSString *)headerImageFromCharacterImage:(NSString *)imageName;

@end
