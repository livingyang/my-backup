//
//  InAppPurchaseManager.m
//  study_InApp
//
//  Created by 青宝 中 on 11-12-22.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "InAppPurchaseManager.h"

@implementation InAppPurchaseManager

+ (InAppPurchaseManager *)instance
{
    static InAppPurchaseManager *mgr = nil;
    
    if (mgr == nil)
    {
        mgr = [[InAppPurchaseManager alloc] init];
    }
    
    return mgr;
}

- (void)requestProductData:(NSString *)productName
{
    NSSet *productIdentifiers = [NSSet setWithObject:productName ];
    productsRequest = [[SKProductsRequest alloc] initWithProductIdentifiers:productIdentifiers];
    productsRequest.delegate = self;
    [productsRequest start];
    
    // we will release the request object in the delegate callback
}

- (void)printProductInfo:(SKProduct *)product
{
    NSLog(@"Product title: %@" , proUpgradeProduct.localizedTitle);
    NSLog(@"Product description: %@" , proUpgradeProduct.localizedDescription);
    NSLog(@"Product price: %@" , proUpgradeProduct.price);
    NSLog(@"Product id: %@" , proUpgradeProduct.productIdentifier);
}

#pragma mark -
#pragma mark SKProductsRequestDelegate methods
- (void)productsRequest:(SKProductsRequest *)request didReceiveResponse:(SKProductsResponse *)response
{
    NSArray *products = response.products;
    proUpgradeProduct = [products count] == 1 ? [[products objectAtIndex:0] retain] : nil;
    if (proUpgradeProduct)
    {
        [self printProductInfo:proUpgradeProduct];
        
        [[SKPaymentQueue defaultQueue] addPayment:[SKPayment paymentWithProduct:proUpgradeProduct]];
    }
    
    for (NSString *invalidProductId in response.invalidProductIdentifiers)
    {
        NSLog(@"Invalid product id: %@" , invalidProductId);
    }
    
    // finally release the reqest we alloc/init’ed in requestProUpgradeProductData
    [productsRequest release];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:kInAppPurchaseManagerProductsFetchedNotification object:self userInfo:nil];
}
- (void)loadStore:(NSString *)productName
{
    // restarts any purchases if they were interrupted last time the app was open
    [[SKPaymentQueue defaultQueue] addTransactionObserver:self];
    
    // get the product description (defined in early sections)
    [self requestProductData:productName];
}
//
// call this before making a purchase
//
- (BOOL)canMakePurchases
{
    return [SKPaymentQueue canMakePayments];
}

#pragma -
#pragma Purchase helpers
//
// saves a record of the transaction by storing the receipt to disk
//
- (void)recordTransaction:(SKPaymentTransaction *)transaction
{
    //    if ([transaction.payment.productIdentifier isEqualToString:kInApppurchaseProductUpgradeProductId])
    //    {
    //        // save the transaction receipt to disk
    //        [[NSUserDefaults standardUserDefaults] setValue:transaction.transactionReceipt forKey:@"proUpgradeTransactionReceipt" ];
    //        [[NSUserDefaults standardUserDefaults] synchronize];
    //    }
}
//
// enable pro features
//
- (void)provideContent:(NSString *)productId
{
    //    if ([productId isEqualToString:kInApppurchaseProductUpgradeProductId])
    //    {
    //        // enable the pro features
    //        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isProUpgradePurchased" ];
    //        [[NSUserDefaults standardUserDefaults] synchronize];
    //    }
}
//
// removes the transaction from the queue and posts a notification with the transaction result
//
- (void)finishTransaction:(SKPaymentTransaction *)transaction wasSuccessful:(BOOL)wasSuccessful
{
    // remove the transaction from the payment queue.
    [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    
    NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:transaction, kTransactionKey , nil];
    if (wasSuccessful)
    {
        // send out a notification that we’ve finished the transaction
        [[NSNotificationCenter defaultCenter] postNotificationName:kInAppPurchaseManagerTransactionSucceededNotification object:self userInfo:userInfo];
        
        //NSLog(@"id = %@", transaction.payment.productIdentifier);
        [[[[UIAlertView alloc] initWithTitle:transaction.payment.productIdentifier
                                     message:@"Successfully purchase"
                                    delegate:self
                           cancelButtonTitle:@"OK"
                           otherButtonTitles:nil] autorelease] show];
    }
    else
    {
        // send out a notification for the failed transaction
        [[NSNotificationCenter defaultCenter] postNotificationName:kInAppPurchaseManagerTransactionFailedNotification object:self userInfo:userInfo];
        
        [[[[UIAlertView alloc] initWithTitle:transaction.payment.productIdentifier
                                     message:@"Fail to purchase"
                                    delegate:self
                           cancelButtonTitle:@"OK"
                           otherButtonTitles:nil] autorelease] show];
    }
}
//
// called when the transaction was successful
//
- (void)completeTransaction:(SKPaymentTransaction *)transaction
{
    [self recordTransaction:transaction];
    [self provideContent:transaction.payment.productIdentifier];
    [self finishTransaction:transaction wasSuccessful:YES];
}
//
// called when a transaction has been restored and and successfully completed
//
- (void)restoreTransaction:(SKPaymentTransaction *)transaction
{
    [self recordTransaction:transaction.originalTransaction];
    [self provideContent:transaction.originalTransaction.payment.productIdentifier];
    [self finishTransaction:transaction wasSuccessful:YES];
}
//
// called when a transaction has failed
//
- (void)failedTransaction:(SKPaymentTransaction *)transaction
{
    if (transaction.error.code != SKErrorPaymentCancelled)
    {
        // error!
        [self finishTransaction:transaction wasSuccessful:NO];
    }
    else
    {
        NSDictionary *userInfo = [NSDictionary dictionaryWithObjectsAndKeys:transaction, kTransactionKey , nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:kInAppPurchaseManagerTransactionCancelNotification object:self userInfo:userInfo];
        
        // this is fine, the user just cancelled, so don’t notify
        [[SKPaymentQueue defaultQueue] finishTransaction:transaction];
    }
}
#pragma mark -
#pragma mark SKPaymentTransactionObserver methods
//
// called when the transaction status is updated
//
- (void)paymentQueue:(SKPaymentQueue *)queue updatedTransactions:(NSArray *)transactions
{
    for (SKPaymentTransaction *transaction in transactions)
    {
        switch (transaction.transactionState)
        {
            case SKPaymentTransactionStatePurchased:
                [self completeTransaction:transaction];
                break;
            case SKPaymentTransactionStateFailed:
                [self failedTransaction:transaction];
                break;
            case SKPaymentTransactionStateRestored:
                [self restoreTransaction:transaction];
                break;
            default:
                break;
        }
    }
}

@end

@implementation InAppPurchaseListen

@synthesize delegate;

+ (InAppPurchaseListen *)instance
{
    static InAppPurchaseListen *listen = nil;
    
    if (listen == nil)
    {
        listen = [[InAppPurchaseListen alloc] init];
    }
    
    return listen;
}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(onPurchaseSuccess:)
                                                     name:kInAppPurchaseManagerTransactionSucceededNotification
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(onPurchaseFail:)
                                                     name:kInAppPurchaseManagerTransactionFailedNotification
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(onPurchaseCancel:)
                                                     name:kInAppPurchaseManagerTransactionCancelNotification
                                                   object:nil];
    }
    
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [super dealloc];
}

- (NSString *)encode:(const uint8_t *)input length:(NSInteger)length {
    static char table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    
    NSMutableData *data = [NSMutableData dataWithLength:((length + 2) / 3) * 4];
    uint8_t *output = (uint8_t *)data.mutableBytes;
    
    for (NSInteger i = 0; i < length; i += 3) {
        NSInteger value = 0;
        for (NSInteger j = i; j < (i + 3); j++) {
            value <<= 8;
            
            if (j < length) {
                value |= (0xFF & input[j]);
            }
        }
        
        NSInteger index = (i / 3) * 4;
        output[index + 0] =                    table[(value >> 18) & 0x3F];
        output[index + 1] =                    table[(value >> 12) & 0x3F];
        output[index + 2] = (i + 1) < length ? table[(value >> 6)  & 0x3F] : '=';
        output[index + 3] = (i + 2) < length ? table[(value >> 0)  & 0x3F] : '=';
    }
    
    return [[[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding] autorelease];
}

- (NSString *)getTransactionReceipt:(SKPaymentTransaction *)transaction
{
    return [self encode:(uint8_t *)transaction.transactionReceipt.bytes length:transaction.transactionReceipt.length];      
    
}

- (void)onPurchaseSuccess:(NSNotification *)notification
{
    SKPaymentTransaction *transaction = [notification.userInfo objectForKey:kTransactionKey];
    
    [self.delegate onPurchaseSuccess:transaction.payment.productIdentifier
                  transactionReceipt:[self getTransactionReceipt:transaction]];
}

- (void)onPurchaseFail:(NSNotification *)notification
{
    SKPaymentTransaction *transaction = [notification.userInfo objectForKey:kTransactionKey];
    
    [self.delegate onPurchaseFail:transaction.payment.productIdentifier];
}

- (void)onPurchaseCancel:(NSNotification *)notification
{
    SKPaymentTransaction *transaction = [notification.userInfo objectForKey:kTransactionKey];
    
    [self.delegate onPurchaseCancel:transaction.payment.productIdentifier];
}

@end
