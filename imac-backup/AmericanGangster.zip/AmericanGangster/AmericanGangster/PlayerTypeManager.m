//
//  PlayerTypeManager.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "PlayerTypeManager.h"
#import "LanguageManager.h"

@implementation PlayerTypeManager

+ (NSString *)getTypeFromRadioName:(NSString *)str
{    
    NSDictionary *typeStringAndValueDic = [NSDictionary dictionaryWithObjectsAndKeys:
                                           @"1", @"radio_type_int",
                                           @"2", @"radio_type_cha",
                                           @"3", @"radio_type_pow",
                                           nil];
    
    if ([typeStringAndValueDic objectForKey:str] == nil)
    {
        NSLog(@"PlayerTypeManager#getTypeFromRadioName: type str = %@ is invalid", str);
    }
    
    return [typeStringAndValueDic objectForKey:str];
}

+ (NSString *)getTypeImageFromRadioName:(NSString *)str
{    
    NSDictionary *typeStringAndValueDic = [NSDictionary dictionaryWithObjectsAndKeys:
                                           @"UI/1-login/img-type-int.png", @"radio_type_int",
                                           @"UI/1-login/img-type-cha.png", @"radio_type_cha",
                                           @"UI/1-login/img-type-pow.png", @"radio_type_pow",
                                           nil];
    return [typeStringAndValueDic objectForKey:str];
}

+ (NSString *)getTypeStringFromValue:(int)type
{
    NSDictionary *typeValueAndStringDic = [NSDictionary dictionaryWithObjectsAndKeys:
                                           [[LanguageManager instance] getStringFromId:@"1003"], @"1",
                                           [[LanguageManager instance] getStringFromId:@"1004"], @"2",
                                           [[LanguageManager instance] getStringFromId:@"1005"], @"3",
                                           nil];
    
    return [typeValueAndStringDic objectForKey:[NSString stringWithFormat:@"%d", type]];
}

@end
