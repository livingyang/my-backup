//
//  AGLoginInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AGLoginInfo : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *imageName;

// 0 - man, 1 - woman
@property (nonatomic, copy) NSString *sex;
@property (nonatomic, copy) NSString *type;

@end

@interface AGPushToken : NSObject

@property (nonatomic, copy) NSString *token;

+ (AGPushToken *)instance;

@end