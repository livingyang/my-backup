//
//  AGOpponentInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGOpponentInfo.h"
#import "CCBalsamiqLayer.h"
#import "CharacterImageManager.h"

@implementation AGOpponentInfo

@synthesize name, imageName;
@synthesize uniqueId;
@synthesize level;
@synthesize attack, defense;
@synthesize sex;
@synthesize isHeeler;

- (void)dealloc
{
    self.name = nil;
    self.imageName = nil;
    
    [super dealloc];
}

- (BOOL)isMan
{
    return self.sex == 1;
}

- (NSString *)headerImageName
{
    return [CharacterImageManager headerImageFromCharacterImage:self.imageName];
}

- (void)setPropertiesFromInfo:(NSDictionary *)info
{
    self.name = [info objectForKey:@"playerName"];
    self.imageName = [info objectForKey:@"imageId"];
    self.uniqueId = [[info objectForKey:@"playerId"] intValue];
    
    self.level = [[info objectForKey:@"levelId"] intValue];
    self.attack = [[info objectForKey:@"attack"] intValue];
    self.defense = [[info objectForKey:@"defense"] intValue];
    
    self.sex = [[info objectForKey:@"sex"] intValue];
    self.isHeeler = [[info objectForKey:@"isHeeler"] intValue];
}

+ (NSArray *)getOpponentList:(NSDictionary *)info
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *dic in [info objectForKey:@"searchResult"])
    {
        AGOpponentInfo *oppnentInfo = [[[AGOpponentInfo alloc] init] autorelease];
        [array addObject:oppnentInfo];
        
        [oppnentInfo setPropertiesFromInfo:dic];
    }
    
    return array;
}

+ (NSArray *)getRevengeList:(NSDictionary *)info
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *dic in [info objectForKey:@"revengeList"])
    {
        AGOpponentInfo *revengeInfo = [[[AGOpponentInfo alloc] init] autorelease];
        [array addObject:revengeInfo];
        
        [revengeInfo setPropertiesFromInfo:[dic objectForKey:@"playerInfo"]];
    }
    
    return array;
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    [[layer getControlByName:@"name"] setString:self.name];
    [[layer getControlByName:@"level"] setString:[NSString stringWithFormat:@"%d", self.level]];
    [[layer getControlByName:@"attack"] setString:[NSString stringWithFormat:@"%d", self.attack]];
    [[layer getControlByName:@"defense"] setString:[NSString stringWithFormat:@"%d", self.defense]];
    [[layer getControlByName:@"image_flag_heeler"] setVisible:self.isHeeler];
    
    CCSprite *spriteHeader = [layer getControlByName:@"image_header"];
    if (spriteHeader != nil)
    {
        spriteHeader.texture = [[CCTextureCache sharedTextureCache] addImage:self.headerImageName];
    }
}

@end

@implementation AGOpponentInfoCache

@synthesize opponentList = opponentList_;

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        opponentList_ = [[NSMutableArray alloc] init];
    }
    
    return self;
}

- (void)dealloc
{
    [opponentList_ release];
    [super dealloc];
}

+ (AGOpponentInfoCache *)instance
{
    static AGOpponentInfoCache *cache = nil;
    if (cache == nil)
    {
        cache = [[AGOpponentInfoCache alloc] init];
    }
    
    return cache;
}

- (void)clearOpponentList
{
    [self.opponentList removeAllObjects];
}

- (void)appendOpponentList:(NSArray *)array
{
    [self.opponentList addObjectsFromArray:array];
}

- (AGOpponentInfo *)getOpponentInfoFromId:(int)opponentId
{
    for (AGOpponentInfo *opponentInfo in self.opponentList)
    {
        if (opponentInfo.uniqueId == opponentId)
        {
            return opponentInfo;
        }
    }
    
    return nil;
}

@end