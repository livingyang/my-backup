//
//  LocalSettingManager.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#define SETTING_BGM_CHANGED_NOTIFICATION @"SETTING_BGM_CHANGED_NOTIFICATION"

@interface LocalSettingManager : NSObject

@property (nonatomic, readwrite) BOOL isBgmEnabled;
@property (nonatomic, readwrite) BOOL isVibrateEnabled;

+ (LocalSettingManager *)instance;

@end
