//
//  AGMessageInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-10.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCBalsamiqLayerDataSource.h"

@interface AGMessageInfo : NSObject <CCBalsamiqLayerDataSource>

@property int type;

@property (nonatomic, copy) NSString *message;
@property (nonatomic, copy) NSString *imageName;
@property NSTimeInterval time;
@property (nonatomic, readonly) NSString *timeString;

@property int playerId;
@property (nonatomic, readonly) BOOL canChallenge;

+ (NSArray *)messageListFromBattleInfo:(NSDictionary *)info;
+ (NSArray *)messageListFromHeelerInfo:(NSDictionary *)info;

@end

@interface AGMessageSystemInfo : NSObject <CCBalsamiqLayerDataSource>

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *message;
@property NSTimeInterval time;
@property (nonatomic, readonly) NSString *timeString;

+ (NSArray *)messageListFromSystemInfo:(NSDictionary *)info;

@end

@interface AGAnnounceInfo : NSObject <CCBalsamiqLayerDataSource>

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *message;
@property (nonatomic, copy) NSString *timeInfo;
@property (nonatomic, copy) NSString *jumpInfo;

@end

@interface AGAnnounceCache : NSObject

@property BOOL hasDisplayed;

@property (nonatomic, retain) NSArray *curAnnounceList;

+ (AGAnnounceCache *)instance;
- (void)updateAnnounceCache:(NSDictionary *)info;

@end
