//
//  UIImage+Grayscale.h
//
//  Created by Andreas Liebschner on 4/13/12.
//

#import <UIKit/UIKit.h>

@interface UIImage (Grayscale)

- (UIImage *)convertToGrayscale;

@end

@class CCTexture2D;

#ifdef __cplusplus
extern "C" {
#endif	
    
    CCTexture2D *getGrayTextureFromPath(NSString *filePath);
    
#ifdef __cplusplus
}
#endif	