//
//  GuideEventData.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-31.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "GuideEventHandle.h"
#import "cocos2d.h"
#import "GuideLayer.h"
#import "CCBalsamiqLayer.h"
#import "LanguageManager.h"

#define TAG_GUIDE_LAYER (123)
#define COUNT_CANCEL_CLICK (10)

@implementation GuideEventHandle

@synthesize curEvent;
@synthesize isClearGuideEvent;

+ (GuideEventHandle *)instance
{
    static GuideEventHandle *handle = nil;
    if (handle == nil)
    {
        handle = [[GuideEventHandle alloc] init];
    }
    
    return handle;
}

- (NSString *)getEventNameFromDic:(NSDictionary *)eventDic
{
    return [eventDic objectForKey:@"Event"];
}

- (NSString *)getLayerNameFromDic:(NSDictionary *)eventDic
{
    return [eventDic objectForKey:@"Layer"];
}

//- (BOOL)isClearGuideEvent
//{
//    return NO;
//}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        otherEventCount = 0;
        
        self.isClearGuideEvent = NO;
        
        NSString *eventConfigPath = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"GuideEventConfig.plist"];
        NSDictionary *eventConfigDic = [NSDictionary dictionaryWithContentsOfFile:eventConfigPath];
        eventList = [[NSArray alloc] initWithArray:[[eventConfigDic allValues] objectAtIndex:0]];
        
        self.curEvent = [eventList objectAtIndex:0];
        
        cancelClick = 0;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(onOutOfRangeClick:)
                                                     name:NOTIFICATION_GUIDE_OUT_OF_RANGE_CLICK
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(onRangeSpriteClick:)
                                                     name:NOTIFICATION_GUIDE_RANGE_SPRITE_CLICK
                                                   object:nil];
    }
    
    return self;
}

- (void)onRangeSpriteClick:(NSNotification *)notification
{
    GuideLayer *guideLayer = notification.object;
    
    if ([guideLayer.balsamiqLayer.bmmlFileName isEqualToString:@"15.2.1-guide.bmml"])
    {
        NSArray *detailStringArray = [NSArray arrayWithObjects:
                                      [[LanguageManager instance] getStringFromId:@"15003"],
                                      [[LanguageManager instance] getStringFromId:@"15020"],
                                      [[LanguageManager instance] getStringFromId:@"15021"],
                                      nil];
        
        [[guideLayer.balsamiqLayer getControlByName:@"detail"] setString:
         [detailStringArray objectAtIndex:clampf(otherEventCount, 0, detailStringArray.count - 1)]];
    }
}

- (void)onOutOfRangeClick:(NSNotification *)notification
{
    ++cancelClick;
    
    if (cancelClick >= COUNT_CANCEL_CLICK)
    {
        [[CCDirector sharedDirector].runningScene removeChildByTag:TAG_GUIDE_LAYER cleanup:YES];
        self.isClearGuideEvent = YES;
    }
    
    GuideLayer *guideLayer = notification.object;
    NSLog(@"cur event = %@, bmmlfilename = %@", [self getLayerNameFromDic:self.curEvent], guideLayer.balsamiqLayer.bmmlFileName);
}

- (void)onEventHappened:(NSString *)eventName
{
    if (self.isClearGuideEvent)
    {
        return;
    }
    
    if ([[self getEventNameFromDic:self.curEvent] isEqualToString:eventName])
    {
        otherEventCount = 0;
        cancelClick = 0;
        
        [[CCDirector sharedDirector].runningScene removeChildByTag:TAG_GUIDE_LAYER cleanup:YES];
        [[CCDirector sharedDirector].runningScene addChild:[GuideLayer guideLayerFromFileName:[self getLayerNameFromDic:self.curEvent]]
                                                         z:INT_MAX
                                                       tag:TAG_GUIDE_LAYER];
        
        if (eventList.lastObject != self.curEvent)
        {
            self.curEvent = [eventList objectAtIndex:[eventList indexOfObject:self.curEvent] + 1];
        }
        else
        {
            self.isClearGuideEvent = YES;
        }
    }
    else
    {
        ++otherEventCount;
    }
}

@end
