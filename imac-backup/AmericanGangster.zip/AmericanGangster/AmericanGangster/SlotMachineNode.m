//
//  SlotMachineNode.m
//  study_SlotMachine
//
//  Created by 青宝 中 on 12-7-11.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "SlotMachineNode.h"

#define DROP_INTERVAL (0.15f)

typedef struct
{
    GLint x;
    GLint y;
    GLsizei width;
    GLsizei height;
} GL_SCISSOR_BOX_RECT;

@implementation SlotMachineNode

- (void)dropSlotWithSprite:(CCSprite *)slot withOffsetPos:(CGPoint)stopPos needsClean:(BOOL)needsClean
{
    [self addChild:slot];
    
    slot.position = ccp(self.contentSize.width * 0.5f, self.contentSize.height * 1.5f);
    
    id action = needsClean
    ? [CCSequence actions:
       [CCMoveBy actionWithDuration:DROP_INTERVAL * 2 position:stopPos],
       [CCCallFunc actionWithTarget:slot selector:@selector(removeFromParentAndCleanup:)],
       nil]
    : [CCSequence actions:
       [CCMoveBy actionWithDuration:DROP_INTERVAL * 2 position:stopPos],
       nil];
    
    [slot runAction:action];
}

- (void)autoDropSlotImage:(ccTime)dt
{
    [self dropSlotWithSprite:[CCSprite spriteWithFile:self.randomImage] withOffsetPos:ccp(0, -self.contentSize.height * 2) needsClean:YES];
}

- (void) visit
{
    if (!self.visible)
    {
        return;
    }
    
    CGRect visitRect =
    {
        [self convertToWorldSpace:CGPointZero],
        self.contentSize,
    };
    visitRect = CC_RECT_POINTS_TO_PIXELS(visitRect);
    
    
    if (glIsEnabled(GL_SCISSOR_TEST))
    {
        GLint rect[4] = {};
        glGetIntegerv(GL_SCISSOR_BOX, rect);
        
        visitRect = CGRectIntersection(visitRect, (CGRect){{rect[0], rect[1]}, {rect[2], rect[3]}});
        glScissor(visitRect.origin.x, visitRect.origin.y, visitRect.size.width, visitRect.size.height);
        [super visit];
        
        glScissor(rect[0], rect[1], rect[2], rect[3]);
    }
    else
    {
        glEnable(GL_SCISSOR_TEST);
        glScissor(visitRect.origin.x, visitRect.origin.y, visitRect.size.width, visitRect.size.height);
        [super visit];
        glDisable(GL_SCISSOR_TEST);
    }
}

- (id)init
{
    self = [super init];
    
    if (self != nil)
    {
        slotImages = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void)dealloc
{
    [slotImages release];
    [super dealloc];
}

- (void)setSlotImages:(NSArray *)images
{
    [slotImages removeAllObjects];
    [slotImages addObjectsFromArray:images];
}

- (void)setInitImage:(NSString *)image
{
    CCSprite *sprite = [CCSprite spriteWithFile:image];
    [self addChild:sprite];
    sprite.position = ccp(self.contentSize.width * 0.5f, self.contentSize.height * 0.5f);
}

- (NSString *)randomImage
{
    return [slotImages objectAtIndex:arc4random() % slotImages.count];
}

- (void)dropAllChild
{
    //[self removeAllChildrenWithCleanup:YES];
    for (CCNode *child in self.children)
    {
        [child runAction:[CCSequence actions:
                          [CCMoveBy actionWithDuration:DROP_INTERVAL position:ccp(0, -child.contentSize.height)],
                          [CCCallFunc actionWithTarget:child selector:@selector(removeFromParentAndCleanup:)],
                          nil]];
    }
}

- (void)startSlot
{
    [self unschedule:@selector(autoDropSlotImage:)];
    [self dropAllChild];
    
    [self schedule:@selector(autoDropSlotImage:) interval:DROP_INTERVAL];
}

- (void)stopSlot
{
    [self stopSlotAtImage:self.randomImage];
}

- (void)stopSlotAtSprite:(CCSprite *)sprite
{
    [self unschedule:@selector(autoDropSlotImage:)];
    
    [self dropSlotWithSprite:sprite withOffsetPos:ccp(0, -self.contentSize.height) needsClean:NO];
}

- (void)stopSlotAtImage:(NSString *)image
{
    [self stopSlotAtSprite:[CCSprite spriteWithFile:image]];
}

@end

#define TAG_SLOTMACHINE (123453)

@implementation CCNode (SlotMachineNodeBind)

- (SlotMachineNode *)slotMachine
{
    if ([self getChildByTag:TAG_SLOTMACHINE] == nil)
    {
        SlotMachineNode *machine = [SlotMachineNode node];
        machine.contentSize = self.contentSize;
        machine.anchorPoint = CGPointZero;
        [self addChild:machine z:machine.zOrder tag:TAG_SLOTMACHINE];
    }
    return (id)[self getChildByTag:TAG_SLOTMACHINE];
}

@end