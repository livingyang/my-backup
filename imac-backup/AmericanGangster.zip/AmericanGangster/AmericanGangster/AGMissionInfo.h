//
//  AGMissionInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CCBalsamiqLayerDataSource.h"

@interface AGMissionInfo : NSObject <CCBalsamiqLayerDataSource>

@property int missionId;
@property int mapId;

@property (nonatomic, copy) NSString *missionNumber;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *detail;

@property int rank;

@property int coin;
@property int exp;
@property int energy;

@property int doNum;
@property int maxDoNum;

+ (AGMissionInfo *)missionInfoFromUpdateInfo:(NSDictionary *)dic;
+ (BOOL)needsRefleshTotalMissionListFromUpdateInfo:(NSDictionary *)dic;

@end

@interface AGMissionBossInfo : NSObject <CCBalsamiqLayerDataSource>

@property int bossId;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, copy) NSString *detail;

@property int mapId;
@property (nonatomic, readonly) NSString *mapName;
@property int level;
@property int attack;
@property int maxDefense;
@property int minDefense;

@property int energy;
@property int coin;
@property int exp;

@property int needsServantCount;

@end

@interface AGMissionFightBossInfo : NSObject

@property int rewardEquipId;
@property BOOL isWin;
@property int deadServantCount;

+ (AGMissionFightBossInfo *)fightBossInfoFromInfo:(NSDictionary *)dic;

@end

@interface AGPlaceMissionInfo : NSObject

@property (nonatomic, retain) NSArray *missionInfoArray;
@property (nonatomic, retain) AGMissionBossInfo *bossInfo;

+ (AGPlaceMissionInfo *)getTotalMissionAtPlaceInfo:(NSDictionary *)dic;

@end

@interface AGMissionEventInfo : NSObject

@property (nonatomic, copy) NSString *name;
@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, copy) NSString *detail;

@end

@interface AGMissionFinishInfo : NSObject

@property (nonatomic, retain) AGMissionInfo *missionInfo;
@property (nonatomic, retain) AGMissionEventInfo *eventInfo;

@property NSTimeInterval prizonTime;

@property BOOL needsRefresh;
@property (nonatomic, copy) NSString *rewardItem;
@property (nonatomic, readonly) NSString *rewardSlotImage;

@property (nonatomic, readonly) NSString *rewardType;
@property (nonatomic, readonly) int rewardNum;

@property (nonatomic, readonly) BOOL isRewardNone;
@property (nonatomic, readonly) BOOL isRewardCoin;
@property (nonatomic, readonly) BOOL isRewardExp;
@property (nonatomic, readonly) BOOL isRewardEvent;
@property (nonatomic, readonly) BOOL isRewardCard;

+ (AGMissionFinishInfo *)missionFinishInfoFromInfo:(NSDictionary *)info;
+ (NSArray *)totalSlotImages;
+ (NSString *)eventImage;
+ (NSString *)noneImage;

@end

@interface AGPrizonInfo : NSObject
{
    BOOL isInPrizon_;
}

@property int prizonAtMapId;
@property (nonatomic, readonly) BOOL isInPrizon;

+ (AGPrizonInfo *)instance;

- (void)arrestAtMissionPlace:(int)mapId;
- (void)leavePrizon;

@end

@interface AGPrizonTimeInfo : NSObject

@property int minute;
@property int dollar;

+ (AGPrizonTimeInfo *)prizonTimeInfoFromDic:(NSDictionary *)dic;

@end
