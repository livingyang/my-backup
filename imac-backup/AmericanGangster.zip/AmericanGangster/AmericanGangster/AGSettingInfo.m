//
//  AGSettingInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-7-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGSettingInfo.h"

@implementation AGSettingInfo

@synthesize name;
@synthesize isOn;

- (void)dealloc
{
    self.name = nil;
    
    [super dealloc];
}

+ (NSArray *)settingListFromInfo:(NSDictionary *)dic
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *settingDic in [dic objectForKey:@"settingsList"])
    {
        AGSettingInfo *info = [[[AGSettingInfo alloc] init] autorelease];
        [array addObject:info];
        
        info.name = [settingDic objectForKey:@"name"];
        info.isOn = [[settingDic objectForKey:@"value"] intValue];
    }
    
    return array;
}

@end
