//
//  SoundManager.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-8-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SoundManager : NSObject
{}

@property (nonatomic, retain) NSString *bgmName;

+ (SoundManager *)instance;

- (void)playBackgroundMusic;
- (void)continuePlayBackgroundMusic;

- (void)playVibrate;

- (void)playEffectButtonBack;
- (void)playEffectButtonOk;

- (void)playEffectWin;
- (void)playEffectWinBoss;
- (void)playEffectLost;
- (void)playEffectLevelUp;
- (void)playEffectWarningBoss;

- (void)playEffectAttackSign;

- (void)playEffectGainCoin;

- (void)playEffectRecovery;
- (void)playEffectSlot;
- (void)playEffectSlotStop;

- (void)playEffectRefineFail;
- (void)playEffectRefineSuccess;

- (void)playEffectCheckSelect;
- (void)playEffectCheckUnselect;

@end
