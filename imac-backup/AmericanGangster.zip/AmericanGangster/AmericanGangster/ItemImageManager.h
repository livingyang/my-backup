//
//  ItemImageManager.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-6-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CCTexture2D;
@class CCSpriteFrame;
@interface ItemImageManager : NSObject

+ (ItemImageManager *)instanse;

//- (CCTexture2D *)getTextureFromImageName:(NSString *)name;

- (CCSpriteFrame *)getWeaponFrameFromImageName:(NSString *)name;

@end
