//
//  AGServantHeaderInfo.m
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "AGServantHeaderInfo.h"
#import "CCBalsamiqLayer.h"
#import "CharacterImageManager.h"

@implementation AGServantHeaderInfo

@synthesize servantId;
@synthesize imageName;
@synthesize headerIndex;

- (void)dealloc
{
    self.imageName = nil;
    
    [super dealloc];
}

- (NSString *)headerImageName
{
    return [CharacterImageManager headerImageFromCharacterImage:self.imageName];
}

+ (NSArray *)getServantListFromInfo:(NSDictionary *)info
{
    NSMutableArray *array = [NSMutableArray array];
    
    for (NSDictionary *dic in [info objectForKey:@"myServantHeadersList"])
    {
        AGServantHeaderInfo *header = [[[AGServantHeaderInfo alloc] init] autorelease];
        header.servantId = [[dic objectForKey:@"servantId"] intValue];
        header.imageName = [dic objectForKey:@"headerUrl"];
        header.headerIndex = [[dic objectForKey:@"pos"] intValue];
        [array addObject:header];
    }
    
    return array;
}

- (void)updateDataToLayer:(CCBalsamiqLayer *)layer
{
    CCSprite *spriteHeader = [layer getControlByName:@"image_header"];
    spriteHeader.texture = [[CCTextureCache sharedTextureCache] addImage:self.headerImageName];
}

@end

@implementation AGServantHeaderLockInfo

@synthesize hasLockHeader;
@synthesize nextUnlockLevel;

+ (AGServantHeaderLockInfo *)headerLockInfoFromDic:(NSDictionary *)dic
{
    AGServantHeaderLockInfo *info = [[[AGServantHeaderLockInfo alloc] init] autorelease];
    
    info.hasLockHeader = [[dic objectForKey:@"hasLock"] intValue];
    info.nextUnlockLevel = [[dic objectForKey:@"nextUnlock"] intValue];
    
    return info;
}

@end