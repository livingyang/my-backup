//
//  AGServantInfo.h
//  AmericanGangster
//
//  Created by 青宝 中 on 12-5-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AGOpponentInfo.h"

@class AGEquipmentInfo;
@interface AGServantInfo : NSObject

@property (nonatomic, retain) AGOpponentInfo *opponentInfo;

@property int servantId;
@property int increaseCoins;

@property BOOL isBattle;

@property (nonatomic, retain) AGEquipmentInfo *equipment1;
@property (nonatomic, retain) AGEquipmentInfo *equipment2;
@property (nonatomic, retain) AGEquipmentInfo *equipment3;
@property (nonatomic, retain) AGEquipmentInfo *equipment4;

- (AGEquipmentInfo *)equipmentWithPos:(int)pos;

+ (AGServantInfo *)servantInfoFromInfo:(NSDictionary *)info;

+ (NSArray *)getServantListFromInfo:(NSDictionary *)info;
+ (NSArray *)getNotInBattleServantList:(NSArray *)servantList;

@end
