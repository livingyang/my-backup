//
//  CFaceBookCommon.m
//  AmericanGangster
//
//  Created by nan li on 12-7-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CFaceBookHelper.h"
#import "FBRequest.h"
@implementation CFaceBookHelper
@synthesize facebook=_facebook;

#pragma mark -
#pragma mark INIT_AND_DEALLOC
-(id)init
{
	if((self=[super init]))
	{
        
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}
#pragma mark -
#pragma mark FACEBOOKAPI

-(void)creatFaceBook:(NSString*)App_ID
{
    _facebook = [[Facebook alloc] initWithAppId:App_ID
                                   andDelegate:self];
//    facebook = [[Facebook alloc] initWithAppId:@"321586027927195" andDelegate:self];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"] 
        && [defaults objectForKey:@"FBExpirationDateKey"]) {
        _facebook.accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
        _facebook.expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
    }
    if (![_facebook isSessionValid]) {
        [_facebook authorize:nil];
    }
}

// Pre iOS 4.2 support
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    return [_facebook handleOpenURL:url]; 
}

// For iOS 4.2+ support
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    return [_facebook handleOpenURL:url]; 
}
- (void)fbDidLogin {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:[_facebook accessToken] forKey:@"FBAccessTokenKey"];
    [defaults setObject:[_facebook expirationDate] forKey:@"FBExpirationDateKey"];
    [defaults setObject:@"1" forKey:@"FBDidLogin"];
    [defaults synchronize];
    
}
-(void)publishFeed
{ 
    
    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   _app_id, @"app_id",
                                   _link, @"link",
                                   _picture, @"picture",
                                   _name, @"name",
                                   _caption, @"caption",
                                   _description, @"description",
                                   nil];
    
    [_facebook dialog:@"feed" andParams:params andDelegate:self];

}

-(void)publishFeed:(NSString*)app_id 
              link:(NSString*)link 
           picture:(NSString*)picture
              name:(NSString*)name
           caption:(NSString*)caption
       description:(NSString*)description
{
    _app_id=app_id;
    _link=link;
    _picture=picture;
    _name=name;
    _caption=caption;
    _description=description;
    
    _facebook = [[Facebook alloc] initWithAppId:_app_id
                                    andDelegate:self];
 
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    _didLogin=[[defaults objectForKey:@"FBDidLogin"] intValue];
    if (_didLogin)
    { 
        [self publishFeed];
        
    }else 
    {
        [self creatFaceBook:_app_id];
        [self fbDidLogin];
        [self publishFeed];
    }
    
}
-(void)addLoginOutButton:(UIView*)view
{
    // Add the logout button
    UIButton *logoutButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    logoutButton.frame = CGRectMake(40, 40, 200, 40);
    [logoutButton setTitle:@"Log Out" forState:UIControlStateNormal];
    [logoutButton addTarget:self action:@selector(logoutButtonClicked:)
           forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:logoutButton];
}

// Method that gets called when the logout button is pressed
- (void) logoutButtonClicked:(id)sender {
    [_facebook logout];
    [self fbDidLogout];
}

- (void) fbDidLogout {
    // Remove saved authorization information if it exists
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    _didLogin=[[defaults objectForKey:@"FBDidLogin"] intValue];
    //if ([defaults objectForKey:@"FBAccessTokenKey"]) {
    if ([defaults objectForKey:@"FBDidLogin"]) {
        [defaults removeObjectForKey:@"FBAccessTokenKey"];
        [defaults removeObjectForKey:@"FBExpirationDateKey"];
        [defaults setObject:@"0" forKey:@"FBDidLogin"];
        [defaults synchronize];
    }
}
#pragma mark -

- (void)fbDidNotLogin:(BOOL)cancelled
{}

- (void)fbDidExtendToken:(NSString*)accessToken
               expiresAt:(NSDate*)expiresAt
{}

- (void)fbSessionInvalidated
{}

@end
