//
//  CFaceBookCommon.h
//  AmericanGangster
//
//  Created by zqgame zqgame on 12-7-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FBConnect.h"
#define FB_APP_ID @"352248604851914"
@interface CFaceBookHelper : NSObject<FBDialogDelegate,FBSessionDelegate, FBRequestDelegate>
{
    Facebook *_facebook;
    int       _didLogin;
    NSString *_app_id;
    NSString *_name;
    NSString *_caption;
    NSString *_link;
    NSString *_picture;
    NSString *_description;
}
@property (nonatomic, retain) Facebook *facebook;

/**
 @creatFaceBook:  1、创建FaceBook实例
 @author: nanLi 
 @version: 1.0 
 @see: https://www.FaceBook.com
 @param: App_ID 
 @return:  
 @exception: 
 */
-(void)creatFaceBook:(NSString*)App_ID;
/**
 @publishFeed:  1、分享Feed
 @author: nanLi 
 @version: 1.0 
 @see: https://www.FaceBook.com
 @param: app_id－－Facebook key
           link－－appStore 链接
        picture－－图片链接
           name－－游戏主题
        caption－－游戏标题
    description－－游戏描述
 @return:  
 @exception: 
 */
-(void)publishFeed:(NSString*)app_id 
              link:(NSString*)link 
           picture:(NSString*)picture
              name:(NSString*)name
           caption:(NSString*)caption
       description:(NSString*)description;
/**
 @publishFeed:  1、添加注销按钮
 @author: nanLi 
 @version: 1.0 
 @see: https://www.FaceBook.com
 @param: view－－添加到的视图
 @return:  
 @exception: 
 */
-(void)addLoginOutButton:(UIView*)view;
@end
