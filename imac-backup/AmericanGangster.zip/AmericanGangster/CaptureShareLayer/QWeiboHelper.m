//
//  QWeiboHelper.m
//  WeiboHelper
//
//  Created by 青宝 中 on 11-11-10.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "QWeiboHelper.h"
#import "QWeiboAsyncApi.h"

@implementation QWeiboHelper

- (id)init
{ 
    self = [super init];
    
    if (self)
    {
        //腾讯应用key
        self.ConsumerKey = @"801273375";
        self.ConsumerSecret = @"23fd674c3ace2459a45131d0da14fb3e";
        self.requestTokenURL = @"https://open.t.qq.com/cgi-bin/request_token";
        self.authorizeURL =  @"http://open.t.qq.com/cgi-bin/authorize?oauth_token=";
        self.accessTokenURL = @"https://open.t.qq.com/cgi-bin/access_token";
    }
    
    return self;
}

- (void)postTextMessage:(NSString *)aMsg
{
    [self postTextMessage:aMsg picPath:nil];
}

- (void)postTextMessage:(NSString *)aMsg picPath:(NSString *)picPath
{
	if (aMsg == nil || self.isLogin == NO)
    {
        return;
    }
    
	//asynchronous http request
	QWeiboAsyncApi *api = [[[QWeiboAsyncApi alloc] init] autorelease];
	
	self.connection	= [api publishMsgWithConsumerKey:self.ConsumerKey 
									  consumerSecret:self.ConsumerSecret 
									  accessTokenKey:self.tokenKey 
								   accessTokenSecret:self.tokenSecret 
											 content:aMsg 
										   imageFile:picPath//@"/Users/ZQP/Desktop/me.png"
										  resultType:RESULTTYPE_JSON 
											delegate:self];
}

@end
