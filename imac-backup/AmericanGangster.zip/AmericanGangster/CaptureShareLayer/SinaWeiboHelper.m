//
//  SinaWeiboHelper.m
//  WeiboHelper
//
//  Created by 青宝 中 on 11-11-10.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "SinaWeiboHelper.h"
#import "QWeiboAsyncApi.h"

@implementation SinaWeiboHelper

- (id)init
{ 
    self = [super init];
    
    if (self)
    {
        //新浪微博
        self.ConsumerKey = @"3112828135";
        self.ConsumerSecret = @"6823d1fe63de8b6ce8a871fee0628caf";
        self.requestTokenURL = @"http://api.t.sina.com.cn/oauth/request_token";
        self.authorizeURL =  @"http://api.t.sina.com.cn/oauth/authorize?oauth_token=";
        self.accessTokenURL = @"http://api.t.sina.com.cn/oauth/access_token";
    }
    
    return self;
}

- (void)postTextMessage:(NSString *)aMsg
{
    [self postTextMessage:aMsg picPath:nil];
}

- (void)postTextMessage:(NSString *)aMsg picPath:(NSString *)picPath
{
    picPath = nil;
    
	if (aMsg == nil || self.isLogin == NO)
    {
        return;
    }
    
	//asynchronous http request
	QWeiboAsyncApi *api = [[[QWeiboAsyncApi alloc] init] autorelease];
	
    self.connection = [api publishSinaMsgWithConsumerKey:self.ConsumerKey
                                          consumerSecret:self.ConsumerSecret
                                          accessTokenKey:self.tokenKey
                                       accessTokenSecret:self.tokenSecret
                                                 content:aMsg
                                               imageFile:picPath
                                                delegate:self];
}

@end
