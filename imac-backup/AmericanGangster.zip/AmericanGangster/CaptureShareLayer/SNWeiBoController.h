//
//  SNWeiBoController.h
//  sinaweibo_ios_sdk_demo
//
//  Created by Wade Cheng on 4/23/12.
//  Copyright (c) 2012 SINA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SinaWeibo.h"
#import "SinaWeiboRequest.h"

#define kAppKey             @"3112828135"
#define kAppSecret          @"6823d1fe63de8b6ce8a871fee0628caf"
#define kAppRedirectURI     @"http://www.sina.com"

#ifndef kAppKey
#error
#endif

#ifndef kAppSecret
#error
#endif

#ifndef kAppRedirectURI
#error
#endif


@interface SNWeiBoController : NSObject <SinaWeiboDelegate, SinaWeiboRequestDelegate>
{
  
    NSDictionary *userInfo;
    NSArray *statuses;
    NSString *postStatusText;
    NSString *postImageStatusText;
}

@property(nonatomic,copy) NSString *postStatusText;
@property(nonatomic,copy) NSString *postImageStatusText;

- (void)loginSina;
@end
