//
//  SendViewController.m
//  study_CustomView
//
//  Created by 青宝 中 on 12-2-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "SendViewController.h"

@implementation SendViewController

@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    loginEndPosition = sendView.center;
    loginBeginPosition = CGPointMake(loginEndPosition.x, -sendView.frame.size.height / 2);
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    //textView.text = [NSString stringWithFormat:@"赶快加入保卫钓鱼岛，一起将小日本抛回日本岛！！ %@", [NSDate date]];
    textView.text = @"赶快加入保卫钓鱼岛，一起将小日本抛回日本岛！！";
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return YES;
}

- (void)loadBeginState
{
    sendView.center = loginBeginPosition;
    self.view.backgroundColor = [UIColor clearColor];
}

- (void)loadEndState
{
    sendView.center = loginEndPosition;
    self.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
}

- (void)openAnime:(UIView *)superView
{
    [superView addSubview:self.view];
    
    [self loadBeginState];
    
    [UIView beginAnimations:@"Send" context:nil];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:self.view cache:YES];
    [UIView setAnimationDuration:1.0];
    
    // Make your changes
    [self loadEndState];
    
    [UIView commitAnimations];
}

- (void)endLoginAnimation:(SEL)callback
{
    [self loadEndState];
    
    [UIView beginAnimations:@"Send" context:nil];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:self.view cache:YES];
    [UIView setAnimationDuration:1.0];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:callback];
    
    // Make your changes
    [self loadBeginState];
    
    [UIView commitAnimations];
}

- (void)onCancleAnimationDone
{
    [self.view removeFromSuperview];
}

- (IBAction)onCancleClick:(id)sender
{
    [self endLoginAnimation:@selector(onCancleAnimationDone)];
}

- (void)onLogoutAnimationDone
{
    [self.view removeFromSuperview];
    [self.delegate onLogout];
}

- (IBAction)onLogoutClick:(id)sender
{
    [self endLoginAnimation:@selector(onLogoutAnimationDone)];
}

- (void)onSendAnimationDone
{
    [self.view removeFromSuperview];
    [self.delegate onSendMessage:textView.text];
}

- (IBAction)onSendClick:(id)sender
{
    [self endLoginAnimation:@selector(onSendAnimationDone)];
}

@end
