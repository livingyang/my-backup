//
//  LoginViewController.m
//  study_CustomView
//
//  Created by 青宝 中 on 12-2-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "LoginViewController.h"
#import "QWeiboHelper.h"
#import "SinaWeiboHelper.h"
#import "ShareManager.h"
@implementation LoginViewController

@synthesize delegate;
@synthesize picPath;
//@synthesize sendViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        //self.sendViewController = [[[SendViewController alloc] initWithNibName:nil bundle:nil] autorelease];
        //self.sendViewController.delegate = self;
    }
    return self;
}

- (void)dealloc
{
    if (curWeiboHelper != nil)
    {
        curWeiboHelper.delegate = nil;
    }
    
    self.picPath = nil;
    
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    loginEndPosition = loginView.center;
    loginBeginPosition = CGPointMake(loginEndPosition.x, -loginView.frame.size.height / 2);
    
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.baidu.com"]];
    [webView loadRequest:request];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
	return YES;
}

- (void)loadBeginState
{
    loginView.center = loginBeginPosition;
    self.view.backgroundColor = [UIColor clearColor];
}

- (void)loadEndState
{
    loginView.center = loginEndPosition;
    self.view.backgroundColor = [UIColor colorWithWhite:0 alpha:0.5];
}

- (void)openAnime:(UIView *)superView
{
    [superView addSubview:self.view];
    
    [self loadBeginState];
    
    [UIView beginAnimations:@"Login" context:nil];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:self.view cache:YES];
    [UIView setAnimationDuration:1.0];
    
    // Make your changes
    [self loadEndState];
    
    [UIView commitAnimations];
}

- (void)loginWith:(UIView *)superView withWeiboHelper:(WeiboHelper *)weiboHelper
{

    if (curWeiboHelper != nil)
    {
        curWeiboHelper.delegate = nil;
    }
    
    curWeiboHelper = weiboHelper;

    curWeiboHelper.delegate = self;
    
    if (weiboHelper.isLogin)
    {
        [self onSendMessage:[[ShareManager instance] getCNShareText]];
        //[self.sendViewController openAnime:superView];
        return;
    }
    
    [self openAnime:superView];
    [curWeiboHelper openLoginPage:webView];
}

- (void)loginWithQQWeibo:(UIView *)superView
{
    [self loginWith:superView withWeiboHelper:[QWeiboHelper instance]];
}

- (void)loginWithSinaWeibo:(UIView *)superView
{
    [self loginWith:superView withWeiboHelper:[SinaWeiboHelper instance]];
}

- (void)onCancleAnimationDone
{
    [self.view removeFromSuperview];
    
    [self.delegate onLoginViewBack];
    
}

- (void)endLoginAnimation:(SEL)callback
{
    [self loadEndState];
    
    [UIView beginAnimations:@"Login" context:nil];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:self.view cache:YES];
    [UIView setAnimationDuration:1.0];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:callback];
    
    // Make your changes
    [self loadBeginState];
    
    [UIView commitAnimations];
}

- (IBAction)onCancleClick:(id)sender
{
    [self endLoginAnimation:@selector(onCancleAnimationDone)];
    
    [[ShareManager instance] removeLoading];
}

#pragma mark -
#pragma mark WeiboHelperDelegate

- (void)onLoginSuccess:(WeiboHelper *)helper
{
    [self onSendMessage:[[ShareManager instance] getCNShareText]];
    [self endLoginAnimation:@selector(onCancleAnimationDone)];
    //[self.sendViewController openAnime:self.view.superview];
    [[ShareManager instance] removeLoading];
}

#pragma mark -
#pragma mark SendViewControllerDelegate

- (void)onSendMessage:(NSString *)message
{
    [curWeiboHelper postTextMessage:message picPath:self.picPath];
}

- (void)onLogout
{
    [curWeiboHelper logout];
}

@end
