//
//  CaptureShareLayer.h
//  BalsamiqXmlReader
//
//  Created by 青宝 中 on 12-2-16.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "LoginViewController.h"

@class CaptureShareLayer;
@protocol CaptureShareLayerDelegate

- (void)onCaptureStart;

- (void)onCaptureShareLayerBack:(CaptureShareLayer *)layer;

@end

@interface CaptureShareLayer : CCLayer <LoginViewControllerDelegate>
{
}

@property (nonatomic, copy) NSString *capturePath;
@property (nonatomic, retain) LoginViewController *loginViewController;
@property (nonatomic, assign) id<CaptureShareLayerDelegate>captureShareLayerDelegate;

+ (CCScene *)scene;

- (void)startCapture:(id<CaptureShareLayerDelegate>)delegate;

@end
