//
//  LoginViewController.h
//  study_CustomView
//
//  Created by 青宝 中 on 12-2-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "SendViewController.h"
#import "WeiboHelper.h"

@protocol LoginViewControllerDelegate

- (void)onLoginViewBack;

@end

@class WeiboHelper;
@interface LoginViewController : UIViewController <WeiboHelperDelegate, SendViewControllerDelegate>
{
    IBOutlet UIView *loginView;
    IBOutlet UIWebView *webView;
    
    WeiboHelper *curWeiboHelper;
    
    CGPoint loginBeginPosition;
    CGPoint loginEndPosition;
}

@property (nonatomic, assign) id<LoginViewControllerDelegate> delegate;
@property (nonatomic, copy) NSString *picPath;
//@property (nonatomic, retain) SendViewController *sendViewController;

- (void)loginWithQQWeibo:(UIView *)superView;
- (void)loginWithSinaWeibo:(UIView *)superView;

@end
