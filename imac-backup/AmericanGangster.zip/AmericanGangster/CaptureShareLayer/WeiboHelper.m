//
//  WeiboHelper.m
//  WeiboHelper
//
//  Created by 青宝 中 on 11-11-8.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "WeiboHelper.h"
#import "QWeiboSyncApi.h"
#import "QWeiboAsyncApi.h"
#import "NSURL+QAdditions.h"

@implementation WeiboHelper

@synthesize delegate, requestTokenURL, accessTokenURL, authorizeURL, ConsumerKey, ConsumerSecret, tokenKey, tokenSecret, isLogin, connection, responseData;

+ (WeiboHelper *)instance
{
    static NSMutableDictionary *weiboHelperInstances = nil;
    
    if (weiboHelperInstances == nil)
    {
        weiboHelperInstances = [[NSMutableDictionary alloc] init];
    }
    
    if ([weiboHelperInstances objectForKey:NSStringFromClass(self)] == nil)
    {
        [weiboHelperInstances setObject:[[self alloc] init]
                                 forKey:NSStringFromClass(self)];
    }
    
    return [weiboHelperInstances objectForKey:NSStringFromClass(self)];
}

- (id)init
{ 
    self = [super init];
    
    if (self)
    {
        [self loadConfig];
    }
    
    return self;
}

- (void)dealloc
{
    self.delegate = nil;
    
    self.requestTokenURL = nil;
    self.accessTokenURL = nil;
    self.authorizeURL = nil;
    
    self.ConsumerKey = nil;
    self.ConsumerSecret = nil;
    
	self.tokenKey = nil;
	self.tokenSecret = nil;
    
    [super dealloc];
}

- (NSString *)helperNameKey
{
    return [NSString stringWithFormat:@"%@ config", NSStringFromClass([self class])];
}

- (void)loadConfig
{
    NSDictionary *configDic = [[NSUserDefaults standardUserDefaults] dictionaryForKey:self.helperNameKey];
    
    if (configDic == nil)
    {
        return;
    }
    
    isLogin = [[configDic objectForKey:@"isLogin"] intValue];
    if (isLogin)
    {
        self.tokenKey = [configDic objectForKey:@"tokenKey"];
        self.tokenSecret = [configDic objectForKey:@"tokenSecret"];
    }
}

- (void)saveConfig
{
    NSMutableDictionary *configDic = [NSMutableDictionary dictionary];
    
    if (isLogin)
    {
        [configDic setObject:@"1" forKey:@"isLogin"];
        [configDic setObject:self.tokenKey forKey:@"tokenKey"];
        [configDic setObject:self.tokenSecret forKey:@"tokenSecret"];
    }
    else
    {
        [configDic setObject:@"0" forKey:@"isLogin"];
    }
    
    [[NSUserDefaults standardUserDefaults] setObject:configDic forKey:self.helperNameKey];
}

- (NSString*)valueForKey:(NSString *)key ofQuery:(NSString*)query
{
	NSArray *pairs = [query componentsSeparatedByString:@"&"];
	for(NSString *aPair in pairs)
    {
		NSArray *keyAndValue = [aPair componentsSeparatedByString:@"="];
		if([keyAndValue count] != 2)
        {
            continue;
        }
            
		if([[keyAndValue objectAtIndex:0] isEqualToString:key])
        {
			return [keyAndValue objectAtIndex:1];
		}
	}
	return nil;
}

- (void)parseTokenKeyWithResponse:(NSString *)aResponse
{	
	NSDictionary *params = [NSURL parseURLQueryString:aResponse];
	self.tokenKey = [params objectForKey:@"oauth_token"];
	self.tokenSecret = [params objectForKey:@"oauth_token_secret"];	
}

- (void)openLoginPage:(UIWebView *)webView
{
    // 1 获取未授权的Request Token
    QWeiboSyncApi *api = [[[QWeiboSyncApi alloc] init] autorelease];
    NSString *retString = [api getRequestTokenWithConsumerKey:self.ConsumerKey
                                               consumerSecret:self.ConsumerSecret
                                                   requestURL:self.requestTokenURL];
    
    [self parseTokenKeyWithResponse:retString];
    
    // 2 打开登陆界面，获取授权码
    NSString *url = [NSString stringWithFormat:@"%@%@", self.authorizeURL, self.tokenKey];
	NSURL *requestUrl = [NSURL URLWithString:url];
    NSLog(@"url = %@", url);
    
    webView.delegate = self;
	NSURLRequest *request = [NSURLRequest requestWithURL:requestUrl];
	[webView loadRequest:request];
}

- (void)postTextMessage:(NSString *)aMsg
{
    return;
}

- (void)postTextMessage:(NSString *)aMsg picPath:(NSString *)picPath
{
    return;
}

- (void)printUrlInfo:(NSURL *)url
{
    NSLog(@"*********************");
    NSLog(@"scheme = %@", url.scheme);
    NSLog(@"resourceSpecifier = %@", url.resourceSpecifier);
    
    NSLog(@"host = %@", url.host);
    NSLog(@"port = %@", url.port);
    NSLog(@"user = %@", url.user);
    NSLog(@"password = %@", url.password);
    NSLog(@"path = %@", url.path);
    NSLog(@"fragment = %@", url.fragment);
    NSLog(@"parameterString = %@", url.parameterString);
    NSLog(@"query = %@", url.query);
    NSLog(@"relativePath = %@", url.relativePath);
    NSLog(@"*********************");
}

- (void)logout
{
    isLogin = NO;
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
	NSString *query = [[request URL] query];
	NSString *verifier = [self valueForKey:@"oauth_verifier" ofQuery:query];
	
	if (verifier && ![verifier isEqualToString:@""])
    {
        
        QWeiboSyncApi *api = [[[QWeiboSyncApi alloc] init] autorelease];
		NSString *retString = [api getAccessTokenWithConsumerKey:self.ConsumerKey 
												  consumerSecret:self.ConsumerSecret 
												 requestTokenKey:self.tokenKey 
											  requestTokenSecret:self.tokenSecret 
														  verify:verifier
                                                  accessTokenURL:self.accessTokenURL];
        [self parseTokenKeyWithResponse:retString];
        
        isLogin = YES;
        
        [self saveConfig];
        [delegate onLoginSuccess:self];
        
        return NO;
    }
    
    return YES;
}

#pragma mark -
#pragma mark 提交结果判断

- (void)postTextMessageSuccess
{
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"分享成功"
                                                     message:nil
                                                    delegate:self
                                           cancelButtonTitle:@"确定"
                                           otherButtonTitles:nil] autorelease];
    
    [alert show];
}

- (void)postTextMessageFail
{
    UIAlertView *alert = [[[UIAlertView alloc] initWithTitle:@"分享失败"
                                                     message:@"重新绑定账号可能会解决问题"
                                                    delegate:self
                                           cancelButtonTitle:@"确定"
                                           otherButtonTitles:nil] autorelease];
    
    [alert show];
}

- (BOOL)isPostTextMessageSuccess:(NSString *)responseString
{
    return YES;
}

#pragma mark -
#pragma mark NSURLConnection delegate

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
	[responseData appendData:data];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{	
	self.responseData = [NSMutableData data];
}

- (void) connectionDidFinishLoading:(NSURLConnection *)connection
{
	NSString *msg = [[[NSString alloc] initWithData:self.responseData encoding:NSUTF8StringEncoding] autorelease];
	
	self.connection = nil;
    
    NSLog(@"msg = %@", msg);
    
    if ([self isPostTextMessageSuccess:msg])
    {
        [self postTextMessageSuccess];
    }
    else
    {
        [self postTextMessageFail];
    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
	NSString *msg = [NSString stringWithFormat:@"connection error:%@", error];
    
	self.connection = nil;
    
    NSLog(@"msg = %@", msg);
}

@end
