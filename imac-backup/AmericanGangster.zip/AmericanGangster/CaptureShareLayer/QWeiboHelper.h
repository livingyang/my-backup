//
//  QWeiboHelper.h
//  WeiboHelper
//
//  Created by 青宝 中 on 11-11-10.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "WeiboHelper.h"

@interface QWeiboHelper : WeiboHelper
{
}

@end
