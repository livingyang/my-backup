//
//  SendViewController.h
//  study_CustomView
//
//  Created by 青宝 中 on 12-2-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SendViewControllerDelegate

- (void)onSendMessage:(NSString *)message;
- (void)onLogout;

@end

@interface SendViewController : UIViewController
{
    IBOutlet UIView *sendView;
    IBOutlet UITextView *textView;
    
    CGPoint loginBeginPosition;
    CGPoint loginEndPosition;
}

@property (nonatomic, assign) id<SendViewControllerDelegate>delegate;

- (void)openAnime:(UIView *)superView;

@end
