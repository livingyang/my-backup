//
//  CCDirectorCapture.h
//  study_Capture
//
//  Created by lee living on 11-2-24.
//  Copyright 2011 LieHuo Tech. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface CCDirector (CCDirectorCapture) 

- (UIImage*) screenshotUIImage;
- (CCTexture2D*) screenshotTexture;

// 返回图片路径
- (NSString *)captureJpgToDocumentDir:(NSString *)fileName;
- (NSString *)capturePngToDocumentDir:(NSString *)fileName;

@end
