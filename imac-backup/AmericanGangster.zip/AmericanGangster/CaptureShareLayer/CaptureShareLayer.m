//
//  CaptureShareLayer.m
//  BalsamiqXmlReader
//
//  Created by 青宝 中 on 12-2-16.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "CaptureShareLayer.h"
#import "CCBalsamiqLayer.h"
#import "CCDirectorCapture.h"

@implementation CaptureShareLayer

@synthesize loginViewController;
@synthesize capturePath;
@synthesize captureShareLayerDelegate;

+ (CCScene *)scene
{
	CCScene *scene = [CCScene node];
	[scene addChild:[CaptureShareLayer node]];
	return scene;
}

- (void)onFlashDone
{
    self.capturePath = [[CCDirector sharedDirector] captureJpgToDocumentDir:@"capture"];
    self.loginViewController.picPath = self.capturePath;
    
    CCBalsamiqLayer *layer = [CCBalsamiqLayer layerWithBalsamiqFile:@"CaptureShareLayer.bmml"
                                                        eventHandle:self];
    [self addChild:layer];
    //CCSprite *sprCapture = [layer.nameAndControlDic objectForKey:@"image_capture"];
    
    //CGSize captureSize = CGSizeMake(sprCapture.contentSize.width * sprCapture.scaleX,
                                    //sprCapture.contentSize.height * sprCapture.scaleY);
    
    CCSprite *sprite = [CCSprite spriteWithFile:self.capturePath];
    [[CCTextureCache sharedTextureCache] removeTexture:sprite.texture];
    //[sprCapture addChild:sprite];
    
    //sprCapture.scaleX = sprCapture.scaleY = 1.0f;
    //sprite.position = ccp(sprCapture.contentSize.width / 2, sprCapture.contentSize.height / 2);
    //sprite.scaleX = captureSize.width / sprite.textureRect.size.width;
    //sprite.scaleY = captureSize.height / sprite.textureRect.size.height;
}

- (void)startCapture:(id<CaptureShareLayerDelegate>)delegate
{
    self.captureShareLayerDelegate = delegate;
    [self.captureShareLayerDelegate onCaptureStart];
    
    // 播放拍照效果
    CCLayerColor *layerColor = [CCLayerColor layerWithColor:ccc4(255, 255, 255, 255)];
    [self addChild:layerColor];
    
    [layerColor setOpacity:0];
    
    [layerColor runAction:[CCSequence actions:
                           [CCFadeIn actionWithDuration:0.5f],
                           [CCFadeOut actionWithDuration:0.5f],
                           [CCCallFunc actionWithTarget:self selector:@selector(onFlashDone)],
                           //[CCCallFuncO actionWithTarget:self selector:@selector(addChild:) object:layer],
                           nil]];
    
}

- (id)init
{
	if((self=[super init]))
	{
        self.loginViewController = [[[LoginViewController alloc] initWithNibName:nil bundle:nil] autorelease];
        self.loginViewController.delegate = self;
	}
	return self;
}

- (void)dealloc
{
    self.loginViewController.delegate = nil;
    self.loginViewController = nil;
    
	[super dealloc];
}

- (void)onBackClick:(id)sender
{
    [self.captureShareLayerDelegate onCaptureShareLayerBack:self];
}

- (void)onQQClick:(id)sender
{
    [self.loginViewController loginWithQQWeibo:[CCDirector sharedDirector].openGLView];
}

- (void)onSinaClick:(id)sender
{
    [self.loginViewController loginWithSinaWeibo:[CCDirector sharedDirector].openGLView];
}

#pragma mark -
#pragma mark LoginViewControllerDelegate

- (void)onLoginViewBack
{
}

@end
