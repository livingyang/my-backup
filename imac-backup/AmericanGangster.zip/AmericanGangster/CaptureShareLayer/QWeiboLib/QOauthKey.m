//
//  QOauthKey.m
//  QWeiboSDK4iOS
//
//  Created on 11-1-12.
//  
//

#import "QOauthKey.h"


@implementation QOauthKey

#pragma mark -
#pragma mark public variables

@synthesize consumerKey;
@synthesize consumerSecret;
@synthesize tokenKey;
@synthesize tokenSecret;
@synthesize verify;
@synthesize callbackUrl;

@end
