//
//  WeiboHelper.h
//  WeiboHelper
//
//  Created by 青宝 中 on 11-11-8.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class WeiboHelper;
@protocol WeiboHelperDelegate <NSObject>

- (void)onLoginSuccess:(WeiboHelper *)helper;

@end

@interface WeiboHelper : NSObject <UIWebViewDelegate>
{
    id<WeiboHelperDelegate> delegate;
    
    NSString *requestTokenURL;
    NSString *accessTokenURL;
    NSString *authorizeURL;
    
    NSString *ConsumerKey;
    NSString *ConsumerSecret;
    
	NSString *tokenKey;
	NSString *tokenSecret;
    
    BOOL isLogin;
    
    NSURLConnection *connection;
    NSMutableData *responseData;	
}

@property (nonatomic, assign) id<WeiboHelperDelegate> delegate;

@property (nonatomic, copy) NSString *requestTokenURL;
@property (nonatomic, copy) NSString *accessTokenURL;
@property (nonatomic, copy) NSString *authorizeURL;

@property (nonatomic, copy) NSString *ConsumerKey;
@property (nonatomic, copy) NSString *ConsumerSecret;

@property (nonatomic, copy) NSString *tokenKey;
@property (nonatomic, copy) NSString *tokenSecret;

@property (readonly) BOOL isLogin;

@property (nonatomic, retain) NSURLConnection *connection;
@property (nonatomic, retain) NSMutableData	*responseData;

+ (WeiboHelper *)instance;

- (void)openLoginPage:(UIWebView *)webView;

- (void)postTextMessage:(NSString *)aMsg;

- (void)postTextMessage:(NSString *)aMsg picPath:(NSString *)picPath;

- (void)logout;

- (void)loadConfig;

- (void)saveConfig;

@end
