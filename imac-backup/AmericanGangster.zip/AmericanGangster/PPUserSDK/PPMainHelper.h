#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "InAppPurchaseManager.h"
@interface PPMainHelper : NSObject {
    NSString* productId;
}
@property (nonatomic, assign) id<InAppPurchaseListenDelegate> delegate;
@property (nonatomic, copy) NSString *productId;

+ (PPMainHelper *)instance;
-(void)buyPurchase:(NSString*)productId;
@end
