//
//  PPExchange.h
//  PPUserPayKit
//
//  Created by ellzu on 12-9-18.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#define k25ppPayResultNotification              @"k25ppPayResultNotification"

@interface PPExchange : NSObject {
    
}

//购买(兑换）
-(void)ppExchangeToGameRequestWithBillNo:(NSString *)billno         //订单号
                                  Amount:(NSString *)amount         //购买金额
                                  RoleId:(int)roldId                //角色id（没有为０）
                                  ZoneId:(int)zoneId;               //区id（没有为０）

//获取剩余虚拟币
-(double)ppPPMoneyRequest;

//设置请求地址
-(void)setRequestUrl:(NSString *)url;

@end
