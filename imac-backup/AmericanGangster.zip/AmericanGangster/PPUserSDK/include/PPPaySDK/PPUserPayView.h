//
//  PPUserPayView.h
//  PPUserPayKit
//
//  Created by ellzu on 12-9-14.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PPUserPayView : UIView <UIWebViewDelegate> {
    
}

//设置订单号（备选接口）
+(void)setBillNo:(NSString *)billNo;         //订单号

//充值页面显示(只有在用户登录的状态下此接口调用才有效）
+(void)defaultPPRechargeViewWithType:(int)type                  //设置初始页面显示的横竖屏（１为竖屏，２为横屏）
                            Rotation:(BOOL)rotation             //是否支持横竖屏（YES为支持，NO为不支持）
                              Amount:(NSString *)amount;        //充值金额

//充值记录页面显示
+(void)defaultPPBillRecordViewWithType:(int)type Rotation:(BOOL)rotation;

@end
