//
//  PPControl.h
//  PPUserUI3
//
//  Created by ellzu on 12-7-26.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#define PP_LOGIN_VIEW_TAG                               100         //登录页面tag
#define PP_REGIST_VIEW_TAG                              101         //注册页面tag
#define  PP_ALERTPSWD_VIEW_TAG                          102         //修改密码页面tag

#define k25pp_LoginView_Login_Notification              @"k25ppLoginViewLoginButtonNotification"



@interface PPControl : NSObject {
    
}

//初始化界面，须在程序启动处调用，type为横竖屏类型（１：竖屏，２：横屏），rotation是否支持旋转（YES：支持，NO：不支持）
+(void)defaultSharedPPViewWithType:(int)type Rotation:(BOOL)rotation;

+(void)showViewWithTag:(int)tag;

//显示页面
+(void)pushViewWithTag:(int)tag;

//退出当前页面
+(void)popCurrentView;

@end
