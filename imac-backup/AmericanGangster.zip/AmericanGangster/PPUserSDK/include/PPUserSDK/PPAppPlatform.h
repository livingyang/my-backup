//
//  PPAppPlatform.h
//  PPUserRequestKit
//
//  Created by ellzu on 12-8-17.
//  Copyright (c) 2012年 teiron. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface PPAppPlatform : NSObject {
    int _appId;
    NSString *_appKey;
    int _userId;
    NSString *_userName;
}

+(PPAppPlatform *)defaultPlatform;

//当前用户ID
-(int)userId;

//当前用户名
-(NSString *)userName;

//设置商户ID和Key
-(void)setAppId:(int)appId AppKey:(NSString *)appKey;

//注销当前用户
-(void)logout;

//设置最后一次登录验证成功的用户名
-(void)setLastUsername:(NSString *)username;

//获取最后一次登录用户名
-(NSString *)lastUsername;

//设置请求的地址
-(void)setRequestUrl:(NSString *)url;

@end
