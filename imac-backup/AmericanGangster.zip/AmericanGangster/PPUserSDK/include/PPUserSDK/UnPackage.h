//
//  UnPackage.h
//  UIUserFramework
//
//  Created by bin cao on 12-7-11.
//  Copyright (c) 2012年 teiron. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ServerDataDefine.h"

@interface UnPackage : NSObject {
    
}

+(MSG_PS_VERIFI2_RESPONSE)bytePSVerifi2Response:(NSData *)data;

@end
