//
//  PPSecurityView.h
//  PPAppPlatformKit
//
//  Created by ellzu on 12-9-7.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PPSecurityView : UIView<UIWebViewDelegate> {
    
}

+(void)setSecurityWebShowWithType:(int)type Rotation:(BOOL)rotation;

+(void)backPasswordWebShowWithType:(int)type Rotation:(BOOL)rotation;

+(void)helpCenterWebShowWithType:(int)type Rotation:(BOOL)rotation;
@end
