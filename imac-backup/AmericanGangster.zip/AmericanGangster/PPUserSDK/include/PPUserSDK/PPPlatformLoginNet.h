//
//  PPPlatformLoginNet.h
//  PPAppPlatformKit
//
//  Created by ellzu on 12-9-3.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#define k25ppAutoLoginNotification                  @"k25ppAutoLoginNotification"

enum {
    PP_Status_LoginErrorNotExist = 0xE0000001,           //用户名不存在
    PP_Status_LoginErrorPassword = 0xE0000002,           //密码不正确
    PP_Status_LoginErrorDisable = 0xE0000003,            //帐号被封
    PP_Status_LoginErrorSession = 0xE0000101,            //Session不存在
    PP_Status_LoginErrorResponseHash = 0xE0000102        //ResponseHash不正确
};

@interface PPPlatformLoginNet : NSObject {
     NSMutableData *_resvData;
}

@property (nonatomic,retain) NSString *address;

-(void)ppLoginRequest:(const char *)uName;

-(void)ppAutoLoginRequest:(const char *)uName PassData:(NSData *)pass;

-(void)ppVerifiRequestSID:(uint64_t)sid Challenge:(const char *)chge PassData:(NSData *)psData;

@end
