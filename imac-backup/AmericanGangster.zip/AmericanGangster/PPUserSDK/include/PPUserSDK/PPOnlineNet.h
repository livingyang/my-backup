//
//  PPOnlineNet.h
//  PPAppPlatformKit
//
//  Created by ellzu on 12-8-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PPOnlineNet : NSObject {
     
}

//将用户转正为有效用户时须调用
-(void)ppAppOnlineIsValidRequest;

@end
