//
//  ServerDataDefine.h
//  UIUserFramework
//
//  Created by bin cao on 12-7-11.
//  Copyright (c) 2012年 teiron. All rights reserved.
//

#ifndef UIUserFramework_ServerDataDefine_h
#define UIUserFramework_ServerDataDefine_h


typedef struct MsgPSVerifi2Response{
    uint32_t		len;
    uint32_t		command;	//	[0xAA00F012]
    uint32_t        status;		//	[0为成功；其他为失败。注意：成功后才包含后续字段。]
    char            token_key[16];
}MSG_PS_VERIFI2_RESPONSE;

typedef struct MsgGameServer{
    uint32_t		len;
    uint32_t		commmand;           
    char            token_key[16];
}MSG_GAME_SERVER;




#endif
