#import "PPLoginHelper.h"
#import "PPMainHelper.h"
#include "PPControl.h"
#include "PPPlatformLoginNet.h"
#import "PPAppPlatform.h"
#import "ServerDataDefine.h"
#import "UnPackage.h"
#import "PPSecurityView.h"

#include <netinet/in.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <sys/types.h>
#include <arpa/inet.h>

typedef struct MsgGameServerResponse
{
uint32_t len;
uint32_t command;              
uint32_t status;                //0为成功，其他为失败
}MSG_GAME_SERVER_RESPONSE;


@implementation PPLoginHelper

+ (PPLoginHelper *)instance
{
    static PPLoginHelper *mgr = nil;
    if (mgr == nil)
    {
        mgr = [[PPLoginHelper alloc] init];
    }
    
    return mgr;
}

- (id)init
{
    if(self=[super init])
    {
        [self logout];
        //登录按钮消息事件
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(login:) name:@"k25ppLoginViewLoginButtonNotification" object:nil];
        
        //添加自动登录请求消息
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(autoLogin:) name:@"k25ppAutoLoginNotification" object:nil];
        
        //注册并登录后返回的回调消息事件
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(registToLogin:) name:@"k25ppRegistToLoginNotification" object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(pswdHashData:) name:@"k25ppPasswordHashDataNotification" object:nil];
        
        //获取账号安全级别消息事件
        //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(securitySetted:) name:@"k25ppSecuritySetted" object:nil];
        
        //添加一个消息来监听网络链接错误的回调事件
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(connectionError:) name:@"k25ppConnectionErrorNotification" object:nil];
        
        //添加一个消息来监听服务器错误的回调事件
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(serverError:) name:@"k25ppServerErrorNotification" object:nil];
        

    }
    return self;
}




-(void)logout:(NSObject *)sender
{
    [self logout]; 
}

#pragma mark ---------------------------------------------------- 登录-------------------------------------------------------

-(void)login
{
    //如果存在密文文件则自动登录
    if([self isAutoLogin]){

        PPPlatformLoginNet *net = [[PPPlatformLoginNet alloc]init];
        [net ppAutoLoginRequest:[[[PPAppPlatform defaultPlatform] lastUsername] UTF8String] PassData:[self getScrData]];
        [net release];
    }else {
        [PPControl pushViewWithTag:PP_LOGIN_VIEW_TAG];
    }
}

-(void)login:(NSNotification *)noti
{
    MSG_PS_VERIFI2_RESPONSE mpvr = [UnPackage bytePSVerifi2Response:noti.object];
    
    /*
    MSG_GAME_SERVER mgs = {};
    mgs.len = 24;
    mgs.commmand = 0xAA000021;
    memcpy(mgs.token_key, mpvr.token_key, 16);
    NSData *gsData = [NSData dataWithBytes:&mgs length:24];
    */
     
    NSString *msg ;
    if(mpvr.status == 0){
        msg = @"登录成功";
        
        //下面请注意，登录验证分两种情况
        //1. 如果您没有业务服务器则在此处直接跳入游戏界面
        
        //2. 如果您有游戏服务器，请在这里验证登录信息，然后跳转到游戏界面
        
        //下面代码为内部服务器测试代码
        /*
        int fd = socket( AF_INET , SOCK_STREAM , 0 ) ;
        if(fd == -1) printf("socket err : %m\n"),exit(1);
        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_port = htons(8000);
        addr.sin_addr.s_addr = inet_addr("58.218.248.218");
        int r = connect(fd, (struct sockaddr *)&addr, sizeof(addr));
        if(r == -1) printf("connect err : %m\n"),exit(-1);
        send(fd, &mgs, sizeof(MSG_GAME_SERVER), 0);
        
        MSG_GAME_SERVER_RESPONSE mgsr;
        recv(fd, &mgsr, 12, 0);
        
        NSLog(@"command : %x,status : %d",mgsr.command,mgsr.status);
        
        if(mgsr.status == 0){
            [PPControl popCurrentView];
            [[CCDirector sharedDirector] replaceScene:[PPMainHelper scene]];
        }
        */
        [PPControl popCurrentView];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"k25ppLoginForBuyPurchaseNotification" object:nil];
        NSLog(@"login success!");
    }else{
        msg = @"登录失败";
    }
    
}



-(void)autoLogin:(NSNotification *)noti
{
    NSLog(@"data : %@",noti.object);
    
    MSG_PS_VERIFI2_RESPONSE mpvr = [UnPackage bytePSVerifi2Response:noti.object];
    /*
    MSG_GAME_SERVER mgs = {};
    mgs.len = 24;
    mgs.commmand = 0xAA000021;
    memcpy(mgs.token_key, mpvr.token_key, 16);
    NSData *gsData = [NSData dataWithBytes:&mgs length:24];
    
    NSLog(@"gsData : %@",gsData);
    */
    NSString *msg ;
    if(mpvr.status == 0){
        msg = @"登录成功"; 
        
        //下面请注意，登录验证分两种情况
        //1. 如果您没有业务服务器则在此处直接跳入游戏界面
        
        //2. 如果您有游戏服务器，请在这里验证登录信息，然后跳转到游戏界面
        
        //下面代码为内部服务器测试代码
        /*
        int fd = socket( AF_INET , SOCK_STREAM , 0 ) ;
        if(fd == -1) printf("socket err : %m\n"),exit(1);
        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_port = htons(8000);
        addr.sin_addr.s_addr = inet_addr("58.218.248.218");
        int r = connect(fd, (struct sockaddr *)&addr, sizeof(addr));
        if(r == -1) printf("connect err : %m\n"),exit(-1);
        send(fd, &mgs, sizeof(MSG_GAME_SERVER), 0);
        
        MSG_GAME_SERVER_RESPONSE mgsr;
        recv(fd, &mgsr, 12, 0);
        
        NSLog(@"command : %x,status : %d",mgsr.command,mgsr.status);
        
        if(mgsr.status == 0){
            [[CCDirector sharedDirector] replaceScene:[PPMainHelper scene]];
        }
        */
        NSLog(@"login success!");
    }else{
        msg = @"登录失败";
    }
}


-(void)pswdHashData:(NSNotification *)noti
{
    [self savePasswordHash:noti.object];
}

-(void)savePasswordHash:(NSData *)data
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    NSString *filename = [path stringByAppendingPathComponent:@"25ppScr.plist"];
    
    
    [data writeToFile:filename atomically:YES];
}

#pragma mark ---------------------------------------------------- 注册并登录 -------------------------------------------------------

-(void)registToLogin:(NSNotification *)noti
{
    
    MSG_PS_VERIFI2_RESPONSE mpvr = [UnPackage bytePSVerifi2Response:noti.object];
    /*
    MSG_GAME_SERVER mgs = {};
    mgs.len = 24;
    mgs.commmand = 0xAA000021;
    memcpy(mgs.token_key, mpvr.token_key, 16);
    */
    if(mpvr.status == 0){
        
        //下面请注意
        //1. 如果您没有业务服务器则在此处直接跳入游戏界面
        
        //2. 如果您有游戏服务器，请在这里验证登录信息，然后跳转到游戏界面
        
        //下面代码为内部服务器测试代码
        /*
        int fd = socket( AF_INET , SOCK_STREAM , 0 ) ;
        if(fd == -1) printf("socket err : %m\n"),exit(1);
        struct sockaddr_in addr;
        addr.sin_family = AF_INET;
        addr.sin_port = htons(8000);
        addr.sin_addr.s_addr = inet_addr("58.218.248.218");
        int r = connect(fd, (struct sockaddr *)&addr, sizeof(addr));
        if(r == -1) printf("connect err : %m\n"),exit(-1);
        send(fd, &mgs, sizeof(MSG_GAME_SERVER), 0);
        
        MSG_GAME_SERVER_RESPONSE mgsr;
        recv(fd, &mgsr, 12, 0);
        
        NSLog(@"command : %x,status : %d",mgsr.command,mgsr.status);
        
        if(mgsr.status == 0){
            [PPControl popCurrentView];
            [[CCDirector sharedDirector] replaceScene:[PPMainHelper scene]];
        }
        */
        [PPControl popCurrentView];
        
    }else {
        
    }
    
}

#pragma mark -------------------------------------------------- 注销　---------------------------------------------------------------

//注销当前用户
-(void)logout
{
    [[PPAppPlatform defaultPlatform] logout];
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    NSString *filename = [path stringByAppendingPathComponent:@"25ppScr.plist"];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    //删除密码密文
    [fileManager removeItemAtPath:filename error:nil];
}

#pragma mark --------------------------------------------------- 错误处理 ------------------------------------------------------------

-(void)connectionError:(NSNotification *)noti
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"网络故障！" delegate:nil
                                        cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
    [alert release];

}

-(void)serverError:(NSNotification *)noti
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"温馨提示" message:@"服务器故障！" delegate:nil
                                         cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
    [alert release];
}

//获取安全级别
-(void)securitySetted:(NSNotification *)noti
{
    
    if([noti.object intValue] < 3) {
        
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"温馨提示"
                                                       message:@"您的账号安全级别较低，请立即对您账号设置密保!"
                                                      delegate:nil
                                             cancelButtonTitle:@"确定" 
                                             otherButtonTitles:nil, nil];
        [alert show];
        [alert release];
    }
}


-(NSData *)getScrData
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    NSString *filename = [path stringByAppendingPathComponent:@"25ppScr.plist"];
    
    NSData *data = [NSData dataWithContentsOfFile:filename];
    
    return data;
}

-(BOOL)isAutoLogin
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    NSString *scrFilename = [path stringByAppendingPathComponent:@"25ppScr.plist"];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    return [fileManager fileExistsAtPath:scrFilename];
}




@end