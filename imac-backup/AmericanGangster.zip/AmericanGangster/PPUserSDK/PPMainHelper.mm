#import "PPMainHelper.h"
#import "PPSecurityView.h"
#import "PPControl.h"
#import "PPExchange.h"
#import "PPUserPayView.h"
#import "ServerDataDefine.h"
#import "UnPackage.h"
#import "BaseLayer.h"
#import "ShareManager.h"
#import "AGPurchaseProduct.h"

#define BACKGROUND_IMAGENAME @"bg.png"

#define BTN_IMAGENAME @"btn.png"
#define SELECTED_BTN_IMAGENAME @"selectedbtn.png"

@implementation PPMainHelper

@synthesize delegate;
@synthesize productId;

+ (PPMainHelper *)instance
{
    static PPMainHelper *mgr = nil;
    if (mgr == nil)
    {
        mgr = [[PPMainHelper alloc] init];
    }
    
    return mgr;
}

- (id)init
{
    if(self=[super init])
    { 
        //添加一个消息来监听支付结果返回信息
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(payResult:) name:k25ppPayResultNotification object:nil];
        
        //关闭充值界面
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cancelPay:) name:@"k25ppPayWebViewClose" object:nil];
    }
    return self;
}
-(void)buyPurchase:(NSString*)_productId
{
    self.productId=_productId;
    
    AGPurchaseProduct *product=[[AGPurchaseProductList instance]getProductFromProductId:productId];
    CCLOG(@"[product.money doubleValue]:%f",[product.money doubleValue]);
    [self exchangeGoods:[product.money doubleValue]];
    
}

-(void)exchangeGoods:(double)price
{    
    PPExchange *exchange = [[PPExchange alloc]init];
    double ppmoney =[exchange ppPPMoneyRequest];
    
    CCLOG(@"price:%f",price);
    CCLOG(@"ppmoney:%f",ppmoney);

    if(ppmoney < 0){
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"温馨提示"
                                                       message:@"请求不合法" 
                                                      delegate:nil
                                             cancelButtonTitle:@"确定" 
                                             otherButtonTitles:nil, nil];
        [alert show];
        
        ((BaseLayer*)self.delegate).isLoading=NO;
        
    }else if(ppmoney >= price){
      
        NSString *amount =[NSString stringWithFormat:@"%i",[[NSNumber numberWithDouble:price]intValue]];
        CCLOG(@"Amount1:%@",amount);

        [exchange ppExchangeToGameRequestWithBillNo:productId Amount:amount RoleId:0 ZoneId:0];
        
    }else {
        /*
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"温馨提示"
                                                       message:@"您的余额不足，您需要先充值后再购买？" 
                                                      delegate:nil
                                             cancelButtonTitle:@"确定" 
                                             otherButtonTitles:nil, nil];
        [alert show];
         */
        NSString *amount =[NSString stringWithFormat:@"%i",[[NSNumber numberWithDouble:(price-ppmoney)]intValue]];
        
        CCLOG(@"Amount2:%@",amount);
        [PPUserPayView defaultPPRechargeViewWithType:1 Rotation:YES Amount:amount];
    }
}

-(void)cancelPay:(NSNotification *)noti
{
    ((BaseLayer*)self.delegate).isLoading=NO;
}

-(void)payResult:(NSNotification *)noti
{
    NSLog(@"noti : %@",noti.object);
    
    int result = [[noti.object objectForKey:@"result"] intValue];
    NSString *msg ;
    if(result == 0){
        [self.delegate onPurchaseSuccess:productId
                      transactionReceipt:@"ppbuy"];
        
        msg = @"购买成功";
    }else if(result == 2){
        msg = @"该用户不存在";
    }else if(result == 3){
        msg = @"必选参数缺失";
    }else if(result == 4){
        msg = @"PP币不足";
    }else if(result == 5){
        msg = @"该游戏数据不存在";
    }else if(result == 6){
        msg = @"开发者数据不存在";
    }else if(result == 7){
        msg = @"该区数据不存在";
    }else if(result == 8){
        msg = @"系统繁忙";
    }else if(result == 9){
        msg = @"购买失败";
    }else if(result == 10){
        msg = @"与开发商服务器通信失败，如果长时间未收到商品请联系PP客服：电话：020-38276673　 QQ：1259377484";
    }else if(result == 11){
        msg = @"开发商服务器未成功处理该订单，如果长时间未收到商品请联系PP客服：电话：020-38276673　 QQ：1259377484";
    }else if(result == 88){
        msg = @"非法访问，可能用户已经下线";
    }else {
        msg = @"其他错误";
    }
    
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"温馨提示" message:msg delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    [alert show];
    [alert release];
    ((BaseLayer*)self.delegate).isLoading=NO;
}

- (void)setSecurity
{
    [PPSecurityView setSecurityWebShowWithType:1 Rotation:YES];
}

-(void)alertPswd
{
    [PPControl pushViewWithTag:PP_ALERTPSWD_VIEW_TAG];
}

-(void)rechargeWebView
{
    [PPUserPayView defaultPPRechargeViewWithType:1 Rotation:YES Amount:@"5.0"];
}


-(void)record
{
    [PPUserPayView defaultPPBillRecordViewWithType:1 Rotation:YES];
}

-(void)helpCenter
{
    [PPSecurityView helpCenterWebShowWithType:1 Rotation:YES];
}

-(void)backPass
{
    [PPSecurityView backPasswordWebShowWithType:1 Rotation:YES];
}

- (void)dealloc {
    self.productId=nil;
    [super dealloc];
}

@end
