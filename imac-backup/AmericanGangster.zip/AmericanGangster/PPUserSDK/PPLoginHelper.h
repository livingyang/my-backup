#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface PPLoginHelper : NSObject {

}

+ (PPLoginHelper *)instance;
-(NSData *)getScrData;
-(void)logout;
-(void)login;
-(BOOL)isAutoLogin;
-(void)savePasswordHash:(NSData *)data;
@end
